# Ledger — Personal BI Platform (V1 Foundation)

A personal Business Intelligence + Finance + Risk dashboard, built as an
extensible foundation for a 12-version roadmap (analytics, finance
modeling, risk modeling, forecasting, scenarios, AI assistant, ML,
CEO/consultant mode, and production hardening).

## Tech stack

- **React 18 + TypeScript** — component architecture, strict typing
- **Vite** — dev server and build tool
- **Tailwind CSS** — utility styling against a small custom token set (see `tailwind.config.js`)
- **Recharts** — charts (bar, line, area)
- No backend, no database — V1 runs entirely on in-memory demo data

## How to run it

```bash
npm install
npm run dev       # starts a local dev server, usually http://localhost:5173
npm run build     # type-checks and produces a static /dist you can host anywhere
npm run preview   # serves the production build locally
```

This project was scaffolded and written in an environment without network
access, so `npm install` has not been run here — install locally before
first use.

## Folder structure

```
src/
  types/index.ts          Core data model — every future module extends these
                           shapes rather than replacing them
  data/demoData.ts         Demo dataset only. V2 (CSV/Excel upload) replaces
                           where data comes from, not the FinancialPeriod[] shape
  lib/
    calculations.ts        All derived numbers (profit, margin, risk score,
                           insights). Never inline calculations in components.
    format.ts               Currency/number formatting helpers
  components/
    layout/Sidebar.tsx      Navigation; "Coming in future versions" for
                           everything except Dashboard
    dashboard/              KPI cards, charts, snapshots, insights, alerts —
                           each one only presentational, fed by lib/calculations
    common/                 ResourcePanel (loading/empty/error/invalid states),
                           ComingSoon placeholder, shared section heading
  pages/Dashboard.tsx       Composes the dashboard from the above
  App.tsx                   Shell: sidebar + routing between Dashboard and
                           the "coming soon" placeholders
```

## What was built (V1)

- Sidebar navigation with all 8 sections; only **Dashboard** is functional,
  the rest render an honest "coming in a future version" placeholder
- KPI cards: Revenue, Expenses, Profit, Cash, Assets, Liabilities, Net Worth,
  Risk Score — each with current value, previous-period value, % change,
  direction, and a plain-language explanation
- Charts: Revenue vs Expenses, Profit Trend, Cash Flow, Risk Trend (12 months
  of demo data, interactive tooltips)
- Financial snapshot: Revenue, Expenses, Profit, Profit Margin, Cash, Debt,
  Working Capital
- Risk snapshot: overall score + level, and a breakdown across Financial,
  Operational, Market, and Strategic risk
- Today's Insights: generated from the same KPI results shown on the cards,
  not separately hard-coded
- Alert Center with severity-coded demo alerts
- Loading / empty / error / invalid-data states via a shared `ResourcePanel`
  wrapper — the dashboard won't crash on missing or malformed data
- Responsive layout: collapsible sidebar on mobile, stacked panels on small
  screens, grid layout on desktop
- Accessible: visible keyboard focus rings, `aria-label`s on nav and major
  regions, reduced-motion respected

## What is demo-only

- All financial and risk figures come from `src/data/demoData.ts` — clearly
  labeled "Demo data" in the UI
- The risk trend history is a synthetic backfill for charting purposes, not
  a real historical series
- Working capital uses a simplified proxy (cash − debt); a real current
  assets/liabilities split arrives with the V3 finance engine

## Known limitations

- No persistence — refreshing the browser resets nothing (there's nothing
  to reset yet; all data is static demo data, not user input)
- No authentication, multi-user, or multi-organization support yet, though
  `Organization` already exists in the data model for when that's needed
- No CSV/Excel import — that's V2
- Risk scoring is a simple average of four demo factors, not a real model

## Recommended V2 architecture (CSV/Excel upload)

- Add a `src/lib/importers/` module that parses CSV/XLSX into
  `FinancialPeriod[]`, validates it, and reports row-level errors
- Replace `demoData.ts`'s role with an uploaded dataset held in React state
  (or persisted to `localStorage`/IndexedDB) — components already consume
  `FinancialPeriod[]` and `Resource<T>`, so they need no changes
- Add an upload screen behind the existing Sidebar; no routing rework needed
- Keep `calculations.ts` untouched — it doesn't know or care where periods
  came from

## Upgrade rule

When asked to "UPGRADE TO Vn", inspect this existing structure first and
extend it — don't rebuild. `types/index.ts` already reserves shapes for
Transaction, Scenario, ForecastPoint, and Report so later versions can grow
into them without a breaking change.

---

# V2 — Data Import, Cleaning, and Exploratory Analysis

## New features

- **Import**: CSV, XLSX, JSON — parsed entirely client-side, never uploaded
  anywhere. Drag-and-drop or browse, with file name/size/type/row/column
  feedback and honest error messages for unsupported/corrupt/empty files.
- **Profile**: automatic per-column stats (numeric: mean/median/min/max/std/
  quartiles/unique/missing%; categorical: unique/most common/top values/
  missing%; date: min/max/range/missing%), a dataset overview card, and a
  paginated, searchable, sortable data table (25 rows/page).
- **Data Quality Score** (0–100, labeled a heuristic, not a statistical
  authority): deducts for missingness, duplicates, outlier concentration,
  and inconsistent categorical formatting, with a visible breakdown.
- **Clean**: duplicates, missing-value fill (mean/median/zero for numeric;
  mode/constant for categorical), type conversion, text standardization,
  invalid-row removal, and outlier removal (IQR or Z-score) — always
  applied to a separate "cleaned" copy. Original upload is never touched.
  Full cleaning history log (timestamp, operation, column, rows affected,
  before/after) with one-click reset to original.
- **Outlier detection**: IQR and Z-score methods, with keep/review/remove
  actions and a plain warning that an outlier isn't automatically an error.
- **EDA workspace**: X/Y/group-by/filter selectors, chart-type
  recommendations (★) based on the selected columns' types, and bar/line/
  area/histogram/scatter/pie/box-plot rendering.
- **Correlation matrix**: Pearson r across numeric columns, color-coded by
  strength/direction, with a standing "correlation ≠ causation" notice.
- **Auto insights**: descriptive + diagnostic findings (concentration,
  trends, missingness, outliers, correlation highlights) computed from the
  actual dataset — each with Finding / Supporting data / Business meaning /
  Confidence. Predictive/prescriptive categories are defined but
  intentionally unused in V2.
- **Ask a business question**: a keyword-driven engine that maps questions
  like "which category generates the highest revenue?" to a real
  group/aggregate calculation, or explains what's missing if the dataset
  can't support an answer. Never fabricates a number.
- **My Datasets**: list, open, rename, delete uploaded datasets; switch
  between demo and user data at any time.
- **Dashboard integration**: the V1 executive dashboard now detects
  revenue/expense/date/category-like columns in whichever dataset is
  active. Demo data renders exactly as in V1. A user dataset without a
  recognizable revenue column shows an honest "this dataset does not
  contain sufficient information" message instead of fake numbers.
- **Learn This**: inline concept popovers (correlation, mean vs. median,
  outliers, data quality score, revenue growth formula) with business
  meaning, formula, example, managerial interpretation, and common mistake.
- **Export**: cleaned CSV, cleaned XLSX, and a Markdown analysis summary
  (overview, quality breakdown, cleaning log, key insights).

## Modified files

- `App.tsx` — wrapped in `DatasetProvider`; `analytics` now routes to the
  real page
- `pages/Dashboard.tsx` — added a user-dataset branch; the demo-data path
  is unchanged code, still gated as the default
- `package.json` — added `papaparse` and `xlsx`

## New files

`types/analytics.ts` · `state/DatasetContext.tsx` · `lib/dataImport.ts` ·
`lib/dataProfiling.ts` · `lib/dataQuality.ts` · `lib/outliers.ts` ·
`lib/dataCleaning.ts` · `lib/correlation.ts` · `lib/autoEda.ts` ·
`lib/businessQuestions.ts` · `lib/datasetToFinancials.ts` ·
`lib/edaCharting.ts` · `pages/Analytics.tsx` · everything under
`components/analytics/`

## Data flow

`File` → `lib/dataImport.ts` (parse + type inference) → `DatasetContext`
(`originalRows` set once; `cleanedRows` starts as a copy) →
`lib/dataProfiling.ts` / `lib/dataQuality.ts` / `lib/autoEda.ts` /
`lib/correlation.ts` (all read `cleanedRows`, never `originalRows`) →
Analytics page panels. Cleaning operations in `lib/dataCleaning.ts` take
`cleanedRows` in, return new rows + a log entry, which
`DatasetContext.applyCleaningStep` appends — `originalRows` is never
reassigned, so "Reset to original" is always available.

## Supported file types

CSV, XLSX/XLS, JSON (array of records, or an object containing one array
property). Capped at 50,000 rows per import as a browser-safety limit.

## Data-cleaning methods

Remove duplicates · fill missing (mean/median/zero, mode/constant) ·
convert type · standardize text (trim/lower/upper/title case) · remove
invalid rows · remove outliers (IQR/Z-score).

## Analytics available

Column profiling, data quality scoring, IQR/Z-score outlier detection,
7 chart types with recommendations, Pearson correlation matrix, automatic
descriptive/diagnostic insight generation, keyword-driven business Q&A.

## Known limitations

- Uploaded datasets live in memory for the browser session only — no
  backend, so nothing survives a page reload except the demo dataset. A
  real persistent store is V12's job.
- The EDA filter (X/Y/group/filter selectors) scopes to the chart it's
  attached to, not the whole page — a true cross-filter that also updates
  the Insights and Ask tabs in real time is a reasonable next iteration
  rather than something squeezed into V2.
- Business-question answering is keyword-matching against column names and
  a handful of question patterns, not real NLP — it's honest about what it
  can't answer rather than guessing.
- Box plots are rendered with a small custom SVG component since Recharts
  has no built-in box plot.
- Data quality score is explicitly a heuristic (stated in the UI itself),
  not a statistical certification.

## Security considerations

- All parsing happens in the browser via `papaparse`/`xlsx`; no file
  content is sent to any server or third party.
- No `dangerouslySetInnerHTML` or `eval`; uploaded cell values are only
  ever rendered as text.
- The 50,000-row cap and paginated table prevent a malicious or oversized
  file from locking up the tab.

## Testing performed

Manually traced each calculation by hand against small fixed inputs
(profit/margin/quartiles/correlation/outlier bounds) while writing
`lib/`. Could not run `npm install`/`npm run build` in this sandbox
(no network access) — see "How to test every major V2 feature" below for
what to check once you run it locally.

## How to test every major V2 feature

1. `npm install && npm run dev`
2. **Import**: go to Analytics → Import, drop in a CSV with at least one
   date, one categorical, and one numeric column. Confirm row/column
   counts match the file.
3. **Profile**: check the Profile tab's per-column stats against a quick
   manual spot-check (e.g. sort the column yourself and compare min/max).
4. **Quality**: confirm the score's breakdown lines match what you'd
   expect (e.g. delete some cells in the source file first, re-upload,
   and watch the missing-data deduction appear).
5. **Clean**: fill a missing numeric column with "mean", confirm the
   Cleaning History log shows the operation and affected-row count, then
   hit "Reset to original" and confirm it reverts.
6. **Outliers**: pick a numeric column, switch between IQR and Z-score,
   and use "Review flagged rows" before removing anything.
7. **Explore**: pick a categorical X and numeric Y, confirm the ★
   recommended chart type appears first, then try switching chart types
   and adding a "Group by" column.
8. **Insights**: confirm each insight's "Supporting data" line matches
   something you can verify from the raw file.
9. **Ask**: try one of the example question chips, then a variant with
   different wording, then a nonsense question to see the honest
   "insufficient data" response.
10. **Dashboard**: with a user dataset active that has no revenue-like
    column, confirm the dashboard shows the "insufficient information"
    message rather than fake numbers. Switch back to demo data and
    confirm V1's dashboard is unchanged.
11. **Export**: download the cleaned CSV/XLSX and the analysis summary,
    and confirm the original uploaded file itself was never modified.

## V3 recommended architecture (Finance Engine) — superseded, see below

This section described the plan before V3 was built; see the "V4 recommended architecture" section at the end of this file for what's now current.

---

# V3 — Finance Intelligence Engine

## V1/V2 compatibility

Both untouched. V1's demo dashboard path in `pages/Dashboard.tsx` is the
same code as before, still the default. V2's Analytics workspace, cleaning,
and dataset management are unchanged — Finance reads `cleanedRows` from
the same `DatasetContext`, never forks it.

## Architecture changes

- New `finance/` folder: pure calculation modules, mirroring how `lib/`
  works for V2 — no UI code in any of these files.
- New `FinanceProvider` (in `state/FinanceContext.tsx`), nested inside
  `DatasetProvider` in `App.tsx`. Holds account mapping and settings
  **per dataset id**, so switching datasets doesn't lose your mapping work.
- `buildFinanceModel()` is the single entry point every Finance UI
  component reads from — one call per render in `pages/Finance.tsx`,
  passed down as props (no duplicate recomputation across tabs).

## New files

`finance/types.ts` · `finance/accountMapping.ts` · `finance/periodizer.ts` ·
`finance/statements.ts` · `finance/cashFlow.ts` · `finance/ratios.ts` ·
`finance/workingCapital.ts` · `finance/dupont.ts` · `finance/breakEven.ts` ·
`finance/healthScore.ts` · `finance/redFlags.ts` · `finance/insights.ts` ·
`finance/profitDiagnostic.ts` · `finance/validation.ts` ·
`finance/financeQuestions.ts` · `finance/demoCompany.ts` ·
`finance/buildFinanceModel.ts` · `state/FinanceContext.tsx` ·
`pages/Finance.tsx` · everything under `components/finance/`.

## Modified files

- `App.tsx` — added `FinanceProvider`, routes `finance` to the real page
- `components/layout/Sidebar.tsx` — marked Finance as ready
- `pages/Dashboard.tsx` — Step 31: added ROE/Current Ratio/Health
  Score/Major Financial Risk cards to the user-dataset branch, additive
  only; the demo-data branch is untouched
- `components/analytics/LearnThis.tsx` — extended the concept dictionary
  with finance concepts and an optional `mbaExamPoint` field (V2 concepts
  and the component's rendering logic for them are unchanged)

## Finance modules created

Account Mapping · Periodizer (flow-vs-stock aggregation) · Income
Statement · Balance Sheet (with balance validation) · Cash Flow (indirect
method estimate) · Ratios (Liquidity/Profitability/Solvency/Efficiency) ·
Working Capital (DSO/DIO/DPO/CCC) · DuPont · Break-even · Financial Health
Score · Red Flags · Financial Insights · Profit Diagnostic (waterfall) ·
Data Validation · Financial Decision Q&A.

## Formulas implemented

All formulas are the standard textbook definitions, shown verbatim in each
`RatioResult.formula` and in the Income Statement/Balance Sheet views —
see `finance/ratios.ts`, `finance/statements.ts`, `finance/workingCapital.ts`,
and `finance/dupont.ts` for the exact code. Every ratio card has a
"Show formula" toggle with the real inputs substituted in.

## Data validation implemented

Negative revenue/expenses, missing periods (gaps in the date sequence),
balance sheet mismatches (flagged, never auto-corrected), and a check that
Revenue is mapped before anything else runs. See `finance/validation.ts`.

## Demo financial dataset

**ABC Manufacturing Ltd.** — 24 months, generated deterministically (no
randomness) in `finance/demoCompany.ts`. Equity is set as the balancing
residual (Total Assets − Total Liabilities) each month, which is what
makes the balance sheet legitimately balance rather than by luck.

## Known limitations (stated plainly)

- **Account mapping is 15 flat categories**, matching the spec's own
  Section 5 list. This means the Balance Sheet shows combined "Current
  Liabilities" and single-line "Equity" rather than the fuller
  payables/short-term-debt or share-capital/retained-earnings split in
  Section 8 — the mapping doesn't collect that detail, so the statement
  doesn't fabricate it.
- **Cash Flow is a simplified indirect-method estimate.** There's no
  separate investing/financing mapping, so Investing + Financing cash flow
  is shown as one combined "implied" line (Actual Net Change in Cash minus
  estimated Operating Cash Flow) rather than being split into numbers that
  would have to be guessed.
- **Debt-to-Equity and Payables Turnover use Total Liabilities / Current
  Liabilities as proxies** for "debt" and "payables" respectively, since
  the mapping doesn't separate interest-bearing debt or payables from
  other current liabilities. Every ratio card with this caveat shows it.
- **Budget vs. Actual comparison is not implemented** — there's no budget
  data source yet. Current vs. Previous Period and Current vs. Same Period
  Last Year (when ≥13 periods exist) both work.
- **Multi-currency is fields only** (currency code, exchange rate source/
  date) — no conversion math, and datasets are never silently mixed across
  currencies.
- Same sandbox caveat as V1/V2: no network access here, so `npm install`/
  `npm run build` could not be run to compile-check this. I traced the
  calculations by hand and did a manual unused-import/type sweep across
  every new file instead — please run the build locally and flag anything
  that breaks.

## How to test V3 manually

1. `npm install && npm run dev`, then go to the **Finance** sidebar item.
2. Click **Load demo company** on the Data & Mapping tab — this should
   immediately populate every other tab (Statements, Ratios, Working
   Capital, etc.) since its columns are pre-mapped exactly.
3. **Statements**: switch the period selector and confirm Income Statement
   percentages recompute; confirm the Balance Sheet always shows "balances:
   true" for the demo company (it's constructed to balance).
4. **Break a balance sheet on purpose**: use manual entry to add a period
   where Assets obviously won't equal Liabilities + Equity, and confirm
   the BALANCE SHEET ERROR banner appears with the exact difference shown.
5. **Ratios**: click "Show formula" on any ratio card and confirm the
   substituted numbers actually multiply/divide to the displayed value.
6. **Working Capital & DuPont**: confirm the Cash Conversion Cycle chart
   has multiple points once several demo-company periods exist.
7. **Break-even**: change Fixed Costs/Variable Cost/Selling Price and
   confirm the chart's break-even reference line moves accordingly.
8. **Financial Health & Red Flags**: with the demo company loaded, check
   whether any red flags fire, and read through each one's five fields.
9. **Insights & Diagnostic**: confirm the Profit Diagnostic waterfall's
   four bars sum exactly to the actual profit change between the two
   periods shown.
10. **Decision Support**: try each example question chip, then a
    nonsense question, and confirm the "Missing Information" response is
    honest about what's needed.
11. **Validation & Export**: download the financial report and ratio CSV,
    and confirm every number in them matches what's shown on screen.
12. **Dashboard integration**: switch the active dataset (top of
    Analytics or Finance) to the demo company, go to Dashboard, and
    confirm the "From the Finance Engine (V3)" section appears with real
    ROE/Current Ratio/Health Score — then switch back to V1's demo data
    and confirm the original dashboard is unchanged.

## V4 recommended architecture (Risk Management Engine)

- Add `risk/` alongside `finance/`, consuming `FinanceMetricsSnapshot`
  from `finance/buildFinanceModel.ts` — V4 reads this snapshot, it never
  recomputes ratios itself.
- The snapshot already exposes: current ratio, debt-to-equity, interest
  coverage, operating cash flow, net margin, revenue volatility, working
  capital, and health score — everything Section 32 of the V3 spec asked
  V3 to expose for V4.
- Keep Finance's tabs and `FinanceContext` untouched; add a new Risk
  sidebar item and page the same way Finance was added in V3.

---

# V4 — Risk Management Intelligence Engine

## V1/V2/V3 compatibility

All untouched. V1's demo dashboard, V2's Analytics workspace, and V3's
Finance Center all work exactly as before. Risk only *adds* to
`pages/Dashboard.tsx` (a new `<RiskDashboardSection />` at the bottom of
both existing branches) — nothing above it changed.

## Scope decision (stated up front)

Section 3 of the spec asks for 19 dedicated Risk Center sections,
including separate dashboards for Operational, Technology, Compliance,
Supply Chain, and Reputational Risk. I built those five as **category
tags in the Risk Register and Heatmap**, not as separate computed pages —
there's no incident/downtime/defect/SLA data source feeding this app yet,
and Section 20 itself says "do not fabricate operational incidents."
Building empty dedicated pages for categories with no real data behind
them would be exactly that. Financial Risk *does* get a dedicated,
fully computed page, because it has a real data source: V3's Finance
Engine.

## Architecture

- New `risk/` folder: pure calculation, no UI, same pattern as `finance/`.
- New `RiskProvider` (`state/RiskContext.tsx`) — **global, not per-dataset**,
  since the Risk Register is a qualitative, company-level record, unlike
  Finance's per-dataset account mapping.
- `risk/financialRisk.ts` reads V3's `PeriodModel` (ratios, statements,
  working capital) directly — it does not recompute a single ratio.
- `risk/buildRiskModel.ts` is the single entry point every Risk UI
  component reads from, mirroring `buildFinanceModel.ts`'s role in V3.

## New files

`risk/types.ts` · `risk/scoring.ts` · `risk/appetite.ts` · `risk/kri.ts` ·
`risk/financialRisk.ts` · `risk/creditRisk.ts` · `risk/concentration.ts` ·
`risk/trends.ts` · `risk/insights.ts` · `risk/alerts.ts` ·
`risk/validation.ts` · `risk/decisionQuestions.ts` · `risk/demoData.ts` ·
`risk/buildRiskModel.ts` · `state/RiskContext.tsx` · `pages/Risk.tsx` ·
everything under `components/risk/`.

## Modified files

- `App.tsx` — added `RiskProvider`, routes `risk` to the real page
- `components/layout/Sidebar.tsx` — marked Risk as ready
- `pages/Dashboard.tsx` — Step 38: added `<RiskDashboardSection />`
  (Overall Risk Score, Critical Risks, Top Risk, Risk Appetite Status,
  Financial Risk Status, KRI Alerts, Overdue Mitigation Actions, Risk
  Trend) to both the demo and user-dataset branches, purely additive
- `components/analytics/LearnThis.tsx` — extended with risk concepts
  (risk appetite, tolerance, inherent/residual risk, risk matrix, KRI,
  control effectiveness, credit risk, liquidity/market/operational risk,
  concentration risk) — V2/V3 concepts unchanged

## Risk Register fields

All fields from Section 5 are implemented: ID, name, category,
subcategory, description, cause, risk event, consequence, owner,
department, dates, impact dimension, inherent/residual probability and
impact, existing controls, control effectiveness, treatment strategy,
mitigation action/owner/date, status, evidence source, notes. Add, edit,
delete, duplicate, filter, search, sort, and CSV export all work.

## Scoring, appetite, and KRIs

Risk Score = Probability × Impact (both 1-5), with **configurable**
level bands (Low/Moderate/High/Very High/Critical) — the thresholds live
in `risk/scoring.ts` as data, not hard-coded into any component. Risk
Appetite thresholds (tolerance/management attention/escalation) are
editable in the Appetite tab. KRI status respects a per-KRI configurable
direction (`higherIsWorse` / `lowerIsWorse`) — nothing assumes higher is
always worse.

## Credit risk

Expected Loss = PD × LGD × EAD, shown with the actual numbers substituted
in. The demo scorecard is a transparent weighted heuristic (input → weight
→ score → level) — the UI states plainly, more than once, that this is
not a validated statistical model and makes no Basel/IFRS 9 claim.

## Known limitations

- **Risk Register data is entirely user-entered or demo-seeded** — there's
  no automated incident/downtime/defect feed. This is by design (Section
  20's "do not fabricate" instruction), not an oversight.
- **Financial Risk signals only cover what V3's mapping supports** —
  e.g. a debt-to-equity signal inherits V3's own documented proxy caveat
  (Total Liabilities standing in for interest-bearing debt).
- **Risk trend classification needs register history** — a risk added
  today with no prior review shows "New," not a fabricated trend.
- **The Concentration Risk tab depends on the Finance Center's Revenue
  mapping being set** — without it, the tab says so rather than guessing.
- Same sandbox caveat as V1-V3: no network access here, so `npm install`/
  `npm run build` could not be run. I did a manual unused-import sweep
  across all 111 source files instead of a compiler — please run the
  build locally and flag anything that breaks.

## How to test V4 manually

1. `npm install && npm run dev`, go to the **Risk** sidebar item.
2. On **Risk Register**, click "Load demo risk register" — this also
   seeds KRIs, Controls, and Mitigation Actions (check those tabs too).
3. **Heatmap**: toggle Inherent/Residual and click a bubble to see its
   detail panel.
4. **Appetite**: change the escalation threshold lower than an existing
   risk's score and confirm it flips to "Escalation — above appetite."
5. **KRIs**: confirm "Current Ratio" (lowerIsWorse direction) and
   "Customer Concentration" (higherIsWorse direction) both show sensible
   statuses — this checks the configurable-direction logic actually works.
6. **Financial Risk**: load the ABC Manufacturing demo company in the
   Finance Center first, then check this tab reflects real signals from
   it (or none, if nothing crosses a threshold).
7. **Credit Risk**: change PD/LGD/EAD and confirm the Expected Loss
   updates and the formula line matches your inputs exactly.
8. **Concentration**: with a dataset that has a mapped Revenue column and
   a categorical column, confirm a concentration percentage appears.
9. **Controls & Mitigation**: change a mitigation action's due date to
   the past and confirm it's highlighted as overdue and shows up as an
   alert on the Trends & Insights tab.
10. **Decision Support**: try each example question, then a nonsense one.
11. **Report & Learning**: export the risk report and confirm every
    number matches what's on screen; click a few "Learn" buttons.
12. **Dashboard integration**: go to Dashboard (either demo or a mapped
    user dataset) and confirm the "From the Risk Engine (V4)" section
    appears once demo risk data is loaded, and shows an honest "not
    loaded yet" message before that.

## V5 recommended architecture (Business Problem Solver) — superseded, see below

This described the plan before V5 was built. See the V5 section below.

---

# V5 — Business Problem Solver + Decision Intelligence Engine

## V1-V4 compatibility

All untouched. Nothing in V5 modifies Dashboard, Analytics, Finance, or
Risk code — it only reads from `buildFinanceModel.ts` and
`buildRiskModel.ts` as inputs.

## Scope decisions (stated up front)

- **CEO Mode / Consultant Mode / Analyst Mode** (Sections 41-43) are one
  `ManagementSummaryView` component with a mode toggle that changes
  framing and emphasis — not three separate calculation engines reading
  different data. They're explicitly labeled as reading "the same
  underlying diagnosis, options, and decision data."
- **Cross-functional analysis** (45) is an `affectedFunctions` tag list
  on each problem, not a dedicated modeling engine.
- **Decision Tree** (39) is not built as a separate visual tool — the
  Problem Tree (cause tree) plus category-adapted diagnostic questions
  cover branching diagnosis, and the spec itself says not to force a
  decision tree onto simple problems.
- **MBA Learning Mode across 9 disciplines** (44): I added a solid batch
  of problem-solving framework concepts (5 Whys, Fishbone, Pareto
  Principle, MECE, Decision Matrix) with cross-sector, non-healthcare
  examples (retail, telecom, manufacturing, e-commerce) — a real starting
  set via the same `LearnThis` component from V2, not exhaustive coverage
  of Finance/Marketing/Ops/HR/Strategy/Economics/Analytics/Risk/Accounting
  individually.
- **A real bug I found and fixed during review, not after:** the Pareto
  and Impact steps initially tried to read row data off dataset
  *metadata* (which only has columns/types, not rows — only the actively
  selected dataset carries full row data in this app's architecture).
  Fixed by always running those analyses against `activeDataset` with an
  explicit on-screen note if that differs from the dataset a problem was
  linked to, rather than silently using the wrong data or crashing.

## Architecture

- New `problemSolver/` folder: pure calculation, no UI, same pattern as
  `finance/` and `risk/`.
- New `ProblemSolverProvider` (`state/ProblemSolverContext.tsx`) — global,
  like `RiskContext`, since problems are qualitative records independent
  of which dataset happens to be active.
- `problemSolver/financialImpact.ts` and `problemSolver/riskImpact.ts`
  read V3's `PeriodModel` and V4's `RiskModel` directly — no financial or
  risk calculation is duplicated anywhere in this layer.
- `problemSolver/businessQuestionEngine.ts` calls V3's
  `answerFinancialQuestion` and V4's `answerRiskQuestion` internally and
  wraps whichever answered into the 11-part structure — it does not
  reimplement either engine's reasoning.

## New files

`problemSolver/types.ts` · `problemSolver/diagnosticQuestions.ts` ·
`problemSolver/pareto.ts` · `problemSolver/financialImpact.ts` ·
`problemSolver/riskImpact.ts` · `problemSolver/priority.ts` ·
`problemSolver/decisionConfidence.ts` · `problemSolver/optionScoring.ts` ·
`problemSolver/solutionGeneration.ts` · `problemSolver/businessQuestionEngine.ts` ·
`problemSolver/recurringProblems.ts` · `problemSolver/buildProblemSolverModel.ts` ·
`problemSolver/demoData.ts` · `state/ProblemSolverContext.tsx` ·
`pages/ProblemSolver.tsx` · everything under `components/problemSolver/`.

## Modified files

- `App.tsx` — added `ProblemSolverProvider`, routes `problemSolver` to
  the real page
- `components/layout/Sidebar.tsx` — marked Problem Solver as ready
- `components/analytics/LearnThis.tsx` — extended with problem-solving
  framework concepts (5 Whys, Fishbone, Pareto Principle, MECE, Decision
  Matrix) — V2/V3/V4 concepts unchanged

Dashboard, Analytics, Finance, and Risk pages themselves are **not**
modified — V5's spec didn't include a "V1 Dashboard integration" section
the way V3 and V4 did, so none was added.

## The 14-step workflow, as built

Define (problem statement) → Diagnose (5 Whys, Fishbone, Pareto,
category-adapted questions, cause tree with FACT/HYPOTHESIS/CONFIRMED_CAUSE
tagging) → Impact (financial from V3, risk from V4) → Options (cause-driven
solution suggestions + weighted decision matrix) → Decision (log +
confidence + mandatory Red Team challenge) → Action (plan with KPI and KRI
links) → Monitor & Review (before/after + lessons learned). Steps 2-3 and
13-14 from the spec are folded into Diagnose and Monitor & Review
respectively rather than being separate tabs — they're natural sub-parts
of those steps in this implementation.

## Known limitations

- **Cause tree, 5 Whys, and Fishbone entries are entirely user-entered** —
  there's no automated root-cause detection; the tool structures your
  thinking and tags claim types, it doesn't diagnose for you.
- **Solution suggestions are keyword-matched against logged causes** — a
  small library, not an exhaustive one, and it never suggests anything
  unrelated to a cause you've actually logged (Section 20's requirement).
- **Financial/Risk Impact analysis only works against the currently
  active dataset** — a consequence of how `DatasetContext` is architected
  (one full dataset "active" at a time, metadata-only for the rest). If a
  problem is linked to a different dataset, the UI says so explicitly
  rather than silently substituting data.
- **Recurring problem detection** is a simple shared-keyword heuristic
  across problem titles within the same category — it flags a pattern
  worth investigating, never asserts a shared root cause.
- Same sandbox caveat as V1-V4: no network access here, so `npm install`/
  `npm run build` could not be run. I did a manual unused-import sweep
  across all 138 source files, and specifically caught and fixed the
  dataset-metadata-vs-full-dataset bug described above during that review
  — please still run the build locally and flag anything else that breaks.

## How to test V5 manually

1. `npm install && npm run dev`, go to the **Problem solver** sidebar item.
2. Click **Load demo problem** — a fully populated "Gross margin
   compression" problem appears, already through Diagnose and into Options.
3. Open it and walk each tab: **Diagnose** → confirm the 5 Whys and
   Fishbone entries are visible and editable; **Impact** → click "Estimate
   from [dataset]" (works once a dataset with ≥2 Finance periods is
   active) and confirm the numbers match what's in the Finance Center.
4. **Options**: click a suggested solution chip (derived from the
   Fishbone causes), score it against the decision matrix criteria, and
   confirm the Weighted Score updates live and the math is visible.
5. **Decision**: confirm the Decision Confidence reasons list changes as
   you fill in more of the workflow (statement, confirmed causes,
   assumptions, ≥2 options) — this is the sufficiency heuristic in action.
6. Fill in Red Team notes and the Decision Log, then move to **Action**:
   add an action, link it to a KRI (works once V4 demo risk data is
   loaded), and set a due date in the past to confirm it's flagged overdue.
7. **Monitor & Review**: add a before/after metric and fill in Lessons
   Learned, then confirm the problem's lifecycle bar shows "Closed."
8. **Summary tab**: toggle between CEO / Consultant / Analyst mode and
   confirm the numbers stay identical across all three — only the framing
   text changes.
9. **Ask a business question**: try one of the example chips and confirm
   the 11-part structured answer appears, with an honest "no finding"
   response for a nonsense question.
10. From the Problem Solver home page, confirm the dashboard KPIs
    (Active/Critical/Awaiting Decision/Overdue Actions) update correctly
    as you change the demo problem's status and add actions.
11. **Bug regression check**: link a new problem to a dataset, then
    switch the active dataset to something else via Analytics, and
    confirm the Diagnose/Impact tabs show the "linked to a different
    dataset" message instead of crashing or silently using wrong data.

## V6 recommended architecture (Forecasting Engine)

- V6 can read historical `PeriodModel[]` series from V3 and `BusinessProblem`
  action/KPI baselines from V5 as inputs for trend projection — it
  should not recompute either.
- Keep Problem Solver's tabs and `ProblemSolverContext` untouched; add a
  new Forecasting sidebar item and page the same way Problem Solver was
  added in V5.

---

# V6 — Forecasting + Predictive Intelligence Engine

## V1-V5 compatibility

All untouched except one small, explicitly-noted architecture change: a
`forecast` `NavKey` was **added** to the sidebar (V1's original nav list
only had 8 items reserved for specific later versions — Reports/V8,
Learning/V11, Settings/V12 — and never included a Forecasting slot, so
this is a genuine addition, not a repurposed or renamed existing item).
Dashboard gets one new additive section, same pattern as V3/V4.

## Scope decisions (stated up front)

- **Sections 3's items 11-17** (Financial/Demand/Sales/Expense/Cash-Flow/
  Customer/Inventory Forecast as separate pages) → one generic forecast
  builder where you pick any target column, plus a dedicated **Financial
  Forecast** tab for the real V3-integrated multi-line projection.
  Building eight near-identical single-column-picker pages would be
  padding, not value — the underlying engine is identical either way.
- **No ML churn model** (Section 29 explicitly permits this) — churn is
  shown as an observed rate only, with a note that predictive churn
  modeling is V10's job.
- **No fake predictive AI, ever** (Section 52's central mandate) — every
  number in `forecast/` traces to a real, inspectable calculation:
  `models.ts` implements the 7 named methods as actual math, `backtesting.ts`
  validates them chronologically (never shuffled), `errorMetrics.ts`
  computes real MAE/RMSE/MAPE/sMAPE/bias with zero-safe MAPE handling.

## Architecture

- New `forecast/` folder: pure calculation, no UI, same pattern as
  `finance/`, `risk/`, and `problemSolver/`.
- New `ForecastProvider` (`state/ForecastContext.tsx`) — global, holding
  saved forecasts for the Forecast-vs-Actual history (Section 39-40).
- `forecast/financialForecast.ts` forecasts revenue with the generic
  engine, then projects COGS/OpEx/D&A/Interest/Tax using the **average of
  their real historical ratios from V3's own PeriodModel series** — it
  never re-derives V3's Income Statement formulas.
- `forecast/riskIntegration.ts` reads V4's `KeyRiskIndicator` types
  directly; every signal is phrased as "potential" per Section 30.
- `forecast/historicalAnalysis.ts` reuses `lib/outliers.ts`'s IQR
  detection from V2 rather than reimplementing outlier detection.

## New files

`forecast/types.ts` · `forecast/timeSeriesPrep.ts` · `forecast/historicalAnalysis.ts` ·
`forecast/models.ts` · `forecast/errorMetrics.ts` · `forecast/backtesting.ts` ·
`forecast/forecastIntervals.ts` · `forecast/buildForecastModel.ts` ·
`forecast/financialForecast.ts` · `forecast/cashFlowForecast.ts` ·
`forecast/riskIntegration.ts` · `forecast/problemSolverIntegration.ts` ·
`forecast/whatIf.ts` · `forecast/alerts.ts` · `state/ForecastContext.tsx` ·
`pages/Forecast.tsx` · everything under `components/forecast/`.

## Modified files

- `App.tsx` — added `ForecastProvider`, routes `forecast` to the real page
- `components/layout/Sidebar.tsx` — added the `forecast` NavKey (see
  compatibility note above)
- `pages/Dashboard.tsx` — Step 49: added `<ForecastDashboardSection />`
  (Revenue/Profit/Cash Forecast, Upcoming Financial Pressure, forecast
  risk signal count) to both dashboard branches, purely additive and
  deliberately concise per the spec's "do not clutter" instruction
- `components/analytics/LearnThis.tsx` — extended with 8 forecasting
  concepts (time series, moving average, exponential smoothing,
  regression forecasting, error metrics, backtesting, forecast intervals,
  overfitting/underfitting) — earlier concepts unchanged

## The 7 forecast models, as built

Naive · Mean · Moving Average · Weighted Moving Average · Exponential
Smoothing · Linear Regression/Trend · Seasonal (additive, only offered
once ≥2 full cycles of data exist and seasonality is actually detected).
`applicableModels()` in `models.ts` gates which ones even run based on
data length — a 4-observation series never gets offered Exponential
Smoothing or Regression.

## Validation, backtesting, and model selection

Chronological expanding-window backtesting (`backtesting.ts`) — training
window grows, one-step-ahead forecasts are compared to real held-out
actuals, never a random shuffle. Models are ranked by validation RMSE,
not training fit. Each backtest result carries an `overfittingFlag`
(training error far below validation error) and `underfittingFlag`
(both errors large relative to the data's scale).

## Known limitations

- **Forecast intervals use a simplified √(horizon) widening** of the
  backtest RMSE under a normal-residual assumption — a real but simplified
  interval, not a rigorously derived one for every model type.
- **Seasonality detection is periodicity-based variance decomposition** —
  real and inspectable, but simpler than formal decomposition methods
  (e.g. STL); it needs ≥2 full cycles or it explicitly says "not enough
  history" rather than guessing.
- **Financial Forecast's cash flow projects operating activity only** —
  Section 24 explicitly forbids inventing future investing/financing
  activity, so those are never shown as forecasted numbers.
- **What-If is a single growth-rate slider** (Section 33's explicit
  scope) — full multi-variable scenario/stress testing is V7's job.
- Same sandbox caveat as every prior version: no network access here, so
  `npm install`/`npm run build` could not be run. I did a manual
  unused-import sweep across all 164 source files instead — please run
  the build locally and flag anything that breaks.

## How to test V6 manually

1. `npm install && npm run dev`, go to the **Forecasting** sidebar item.
2. Click **Load demo company** (Overview tab), then go to **New Forecast**
   and build one against `revenue` (monthly, horizon 3).
3. **Historical Analysis**: confirm Forecast Readiness, trend, and
   volatility look sensible against the demo company's known ~1.2%/month
   growth trend.
4. **Models & Backtesting**: confirm models are ranked by RMSE and that
   MAPE shows "n/a" gracefully if any backtest window has a near-zero
   actual (unlikely for revenue, but check the logic holds for a target
   column with small values).
5. **Forecast Result**: confirm the chart shows Historical, Base,
   Upside/Downside, and an interval band; confirm every number under
   "Why this forecast?" traces back to the Historical Analysis tab.
6. **Financial Forecast**: confirm the projected Income Statement's COGS/
   OpEx percentages roughly match the demo company's actual historical
   ratios (~56-60% COGS, ~22%+ OpEx per `finance/demoCompany.ts`).
7. **Risk Signals**: confirm signals are phrased as "potential," never as
   certainties.
8. **What-If**: move the slider and confirm the adjusted number scales
   linearly with the percentage shown.
9. **History**: save a forecast, then manually enter an "actual" value
   for one period and confirm the accuracy metrics update.
10. **Edge case check**: build a forecast against a target/date
    combination with only 2-3 observations and confirm you get the
    "Insufficient historical data" message with a clear explanation,
    not a crash.
11. **Dashboard integration**: go to Dashboard with the demo company
    active and confirm the "From the Forecasting Engine (V6)" section
    appears concisely — 4 metrics, not a cluttered wall of charts.

## V7 recommended architecture (Scenario + Stress Testing)

- V7 can read `ForecastRun` (via `forecast/buildForecastModel.ts`) as the
  base case to stress, and `FinanceModel`/`RiskModel` for the metrics to
  shock — it should build a genuine multi-variable scenario engine on top
  of what V6's single-variable What-If started, not duplicate it.
- Keep Forecasting's tabs and `ForecastContext` untouched; add a new
  Scenario sidebar item and page the same way Forecasting was added in V6.

---

# V7 — Scenario Planning + Sensitivity Analysis + Stress Testing Engine

## V1-V6 compatibility

All untouched. A `scenario` NavKey was added (same pattern as V6's
`forecast` addition). Dashboard gets one new, deliberately concise
additive section.

## Scope decisions (stated up front)

- **Sections 3's 16 Scenario Center pages** → Financial/Revenue/Cost/
  Cash-Flow/Risk/Operational "Scenarios" (items 6-11) are the same
  driver-propagation engine pointed at different variable categories in
  one Scenario Builder — not six separate pages.
- **CEO/CFO/CRO/Consultant modes** (52-55) → one toggle over identical
  scenario data, same pattern as V5's mode toggle — not four engines.
- **FX Scenario** (23) → stated plainly as an illustrative calculator,
  since the app tracks no real multi-currency exposure to shock against.
- **Customer Churn / Supplier Shock** (24-25) → reuse V4's actual
  concentration-analysis function on whatever categorical columns exist
  — real, not fabricated operational data.

## The literal fulfillment of "never duplicate V3/V4 formulas"

`scenario/driverModel.ts` builds a shocked `IncomeStatementLine` and
`BalanceSheetLine` using the same arithmetic relationships V3 defines
(Revenue − COGS = Gross Profit, etc.), then feeds the result through
**V3's own functions** — `buildLiquidityRatios`, `buildProfitabilityRatios`,
`buildSolvencyRatios`, `buildEfficiencyRatios`, `buildWorkingCapital`,
`buildDuPont`, `buildCashFlow` — imported and called directly, not
reimplemented. `scenario/riskCascade.ts` does the same with V4's
`detectRedFlags` and `computeHealthScore`. `scenario/breakEvenScenario.ts`
calls V3's `computeBreakEven` directly on shocked inputs.

## Architecture

- New `scenario/` folder: pure calculation, no UI, same pattern as
  `finance/`, `risk/`, `problemSolver/`, and `forecast/`.
- New `ScenarioProvider` (`state/ScenarioContext.tsx`) — global scenario
  history with real versioning: editing a saved scenario creates a new
  version via `createNewVersion()` rather than mutating the old one
  (Section 46) — the old version stays in history untouched.
- Survival thresholds (`survivalThresholds.ts`) are found via binary
  search directly against the propagation engine — calculated, not
  guessed (Section 33).

## New files

`scenario/types.ts` · `scenario/driverModel.ts` · `scenario/sensitivity.ts` ·
`scenario/stressTesting.ts` · `scenario/breakEvenScenario.ts` ·
`scenario/thresholds.ts` · `scenario/decisionTriggers.ts` ·
`scenario/riskCascade.ts` · `scenario/survivalThresholds.ts` ·
`scenario/robustness.ts` · `scenario/expectedValue.ts` ·
`scenario/fxScenario.ts` · `scenario/churnSupplierScenario.ts` ·
`scenario/resilience.ts` · `scenario/buildScenarioModel.ts` ·
`state/ScenarioContext.tsx` · `pages/Scenario.tsx` · everything under
`components/scenario/`.

## Modified files

- `App.tsx` — added `ScenarioProvider`, routes `scenario` to the real page
- `components/layout/Sidebar.tsx` — added the `scenario` NavKey
- `pages/Dashboard.tsx` — Step 56: added `<ScenarioDashboardSection />`
  (Base/Downside/Stress Net Profit, Cash Under Stress, Biggest
  Sensitivity, Critical Threshold Breach — 8 figures, concise per the
  spec's explicit "do not overload" instruction) to both branches
- `components/analytics/LearnThis.tsx` — extended with 6 scenario/stress
  concepts — earlier concepts unchanged

## Known limitations

- **Balance sheet propagation is a simplified roll-forward**: DSO/DIO/DPO
  day-changes are applied against the shocked income statement, and cash
  absorbs the net profit + working-capital delta versus base — a real,
  inspectable calculation, but simpler than a full 3-statement model with
  independently modeled financing/investing activity (consistent with
  V3's own stated cash-flow simplification).
- **Break-even scenario uses an illustrative per-unit price/cost**
  (revenue and COGS divided by an assumed volume) since the app has no
  real unit-economics data — stated plainly in the UI, not hidden.
- **Decision Trigger Engine ships with 3 starting rules**, not a full
  rule-builder UI — the evaluation logic is real and inspectable, but
  authoring new rules currently means adding to `decisionTriggers.ts`.
- **Robustness analysis in the Decision Analysis tab uses illustrative
  scenario multipliers** (1.3×/0.6×/0.2× of a V5 option's stated ROI) to
  visualize "how would this look under different conditions" — a real
  V5 integration, but not a full per-option scenario re-run.
- Same sandbox caveat as every prior version: no network access here, so
  `npm install`/`npm run build` could not be run. I did a manual
  unused-import sweep across all 192 source files instead — please run
  the build locally and flag anything that breaks.

## How to test V7 manually

1. `npm install && npm run dev`, load the demo company in Finance
   Center, then go to the **Scenario** sidebar item.
2. **Overview**: confirm the Base/Upside/Downside/Stress table shows
   real, different numbers for each column.
3. **Scenario Builder**: build a custom scenario (e.g. COGS +15%, DSO
   +20 days), run it, and confirm the Comparison tab's propagation chain
   shows the change flowing all the way from Revenue/COGS through to Cash.
4. **Sensitivity**: confirm the Tornado chart's ranking changes if you
   change the swing % — the ranking should always reflect actual
   calculated net-profit swings, never a fixed order.
5. **Stress Testing**: select multiple presets together and confirm the
   combined effect differs from any single preset alone; check the
   Resilience Score drops under stress.
6. **Survival Thresholds**: confirm the reported revenue-decline
   threshold actually produces EBITDA ≈ 0 when you manually build a
   scenario at that exact revenue growth % in the Builder.
7. **Risk Impact**: confirm red flags shown here match what V4's Risk
   Center would show for the same shocked numbers — this checks the
   "reuse, don't duplicate" claim directly.
8. **Decision Analysis**: enter scenario probabilities that don't sum to
   100% and confirm Expected Value refuses to calculate and explains why;
   fix them to sum to 100% and confirm it then computes correctly.
9. **History**: save a scenario, duplicate it as a new version, and
   confirm both versions remain visible (the original unchanged).
10. **Modes**: confirm all four mode views (CEO/CFO/CRO/Consultant) show
    numbers consistent with each other — they're framings of one result.
11. **Dashboard integration**: confirm the Scenario Engine section
    appears concisely (8 metrics) on Dashboard, not as a wall of charts.

## V8 recommended architecture (Advanced Business Intelligence)

- V8 can read `ScenarioResult`, `ForecastRun`, `RiskModel`, and
  `FinanceModel` as inputs for cross-cutting BI views — it should
  compose these, not recompute any of them.
- Keep Scenario's tabs and `ScenarioContext` untouched; add a new
  Advanced BI sidebar item (likely replacing the placeholder "Reports"
  slot) the same way Scenario was added in V7.
