/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: '#F6F7F5',
        surface: '#FFFFFF',
        line: '#E2E5E1',
        ink: {
          DEFAULT: '#14231F',
          soft: '#4B5A55',
          faint: '#8A968F',
        },
        emerald: {
          DEFAULT: '#1F6F54',
          soft: '#E4F0EB',
        },
        rust: {
          DEFAULT: '#B3452C',
          soft: '#F5E8E3',
        },
        amber: {
          DEFAULT: '#A9782E',
          soft: '#F3ECDC',
        },
        slateblue: {
          DEFAULT: '#4A5B68',
          soft: '#E9EDEF',
        },
      },
      fontFamily: {
        serif: ['"Source Serif 4"', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
