import { createContext, ReactNode, useCallback, useContext, useMemo, useState } from 'react';
import { useDatasets } from './DatasetContext';
import { AccountMapping, FinanceCategory, FinanceSettings, PeriodGranularity } from '../finance/types';
import { suggestAccountMapping } from '../finance/accountMapping';
import { buildAbcManufacturingRows, ABC_MANUFACTURING_NAME } from '../finance/demoCompany';
import { Row } from '../types/analytics';

interface FinanceContextValue {
  mapping: AccountMapping;
  setMapping: (mapping: AccountMapping) => void;
  settings: FinanceSettings;
  setSettings: (settings: FinanceSettings) => void;
  loadAbcDemoCompany: () => void;
  addManualEntryPeriod: (values: Record<string, number>, periodLabel: string) => void;
}

const FinanceContext = createContext<FinanceContextValue | null>(null);

function defaultSettings(columns: string[], columnTypes: Record<string, string>): FinanceSettings {
  const dateColumn = columns.find((c) => columnTypes[c] === 'date') ?? null;
  return { currency: 'USD', exchangeRateSource: null, exchangeRateDate: null, granularity: 'month', dateColumn };
}

export function FinanceProvider({ children }: { children: ReactNode }) {
  const { activeDataset, activeId, addDataset } = useDatasets();
  const [mappingByDataset, setMappingByDataset] = useState<Record<string, AccountMapping>>({});
  const [settingsByDataset, setSettingsByDataset] = useState<Record<string, FinanceSettings>>({});

  const mapping = useMemo(() => {
    return mappingByDataset[activeId] ?? suggestAccountMapping(activeDataset.columns);
  }, [mappingByDataset, activeId, activeDataset.columns]);

  const settings = useMemo(() => {
    return settingsByDataset[activeId] ?? defaultSettings(activeDataset.columns, activeDataset.columnTypes as Record<string, string>);
  }, [settingsByDataset, activeId, activeDataset.columns, activeDataset.columnTypes]);

  const setMapping = useCallback(
    (next: AccountMapping) => {
      setMappingByDataset((prev) => ({ ...prev, [activeId]: next }));
    },
    [activeId]
  );

  const setSettings = useCallback(
    (next: FinanceSettings) => {
      setSettingsByDataset((prev) => ({ ...prev, [activeId]: next }));
    },
    [activeId]
  );

  const loadAbcDemoCompany = useCallback(() => {
    const rows = buildAbcManufacturingRows();
    const columns = Object.keys(rows[0]);
    const id = addDataset({ name: ABC_MANUFACTURING_NAME, fileType: 'json', columns, rows });
    // Pre-map the demo company's own column names exactly, so it works
    // immediately without relying on keyword auto-detection.
    const exactMapping: AccountMapping = {
      period: 'unmapped',
      revenue: 'revenue',
      cogs: 'cogs',
      operating_expenses: 'operatingExpenses',
      depreciation: 'depreciation',
      interest: 'interest',
      tax: 'tax',
      other_income: 'otherIncome',
      other_expenses: 'otherExpenses',
      cash: 'cash',
      receivables: 'receivables',
      inventory: 'inventory',
      fixed_assets: 'fixedAssets',
      current_liabilities: 'currentLiabilities',
      long_term_debt: 'longTermDebt',
      equity: 'equity',
    };
    setMappingByDataset((prev) => ({ ...prev, [id]: exactMapping }));
    setSettingsByDataset((prev) => ({ ...prev, [id]: { currency: 'USD', exchangeRateSource: null, exchangeRateDate: null, granularity: 'month', dateColumn: 'period' } }));
  }, [addDataset]);

  const addManualEntryPeriod = useCallback(
    (values: Record<string, number>, periodLabel: string) => {
      const row: Row = { period: periodLabel, ...values };
      const columns = Object.keys(row);
      const id = addDataset({ name: `Manual entry — ${periodLabel}`, fileType: 'json', columns, rows: [row] });
      const exactMapping: AccountMapping = { period: 'unmapped' };
      columns.forEach((c) => {
        if (c !== 'period') exactMapping[c] = c as FinanceCategory;
      });
      setMappingByDataset((prev) => ({ ...prev, [id]: exactMapping }));
      setSettingsByDataset((prev) => ({ ...prev, [id]: { currency: 'USD', exchangeRateSource: null, exchangeRateDate: null, granularity: 'month' as PeriodGranularity, dateColumn: 'period' } }));
    },
    [addDataset]
  );

  const value: FinanceContextValue = { mapping, setMapping, settings, setSettings, loadAbcDemoCompany, addManualEntryPeriod };

  return <FinanceContext.Provider value={value}>{children}</FinanceContext.Provider>;
}

export function useFinance(): FinanceContextValue {
  const ctx = useContext(FinanceContext);
  if (!ctx) throw new Error('useFinance must be used within a FinanceProvider');
  return ctx;
}
