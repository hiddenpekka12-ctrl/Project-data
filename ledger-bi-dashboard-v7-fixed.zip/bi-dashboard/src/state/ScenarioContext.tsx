import { createContext, ReactNode, useCallback, useContext, useState } from 'react';
import { ScenarioConfig } from '../scenario/types';

interface ScenarioContextValue {
  scenarios: ScenarioConfig[];
  addScenario: (config: ScenarioConfig) => void;
  archiveScenario: (id: string) => void;
  deleteScenario: (id: string) => void;
  /** Modifying a scenario creates a NEW version rather than mutating the
   * old one (Section 46) — the old version stays in history untouched. */
  createNewVersion: (baseConfig: ScenarioConfig, updates: Partial<ScenarioConfig>) => ScenarioConfig;
}

const ScenarioContext = createContext<ScenarioContextValue | null>(null);

export function ScenarioProvider({ children }: { children: ReactNode }) {
  const [scenarios, setScenarios] = useState<ScenarioConfig[]>([]);

  const addScenario = useCallback((config: ScenarioConfig) => setScenarios((prev) => [...prev, config]), []);
  const archiveScenario = useCallback((id: string) => setScenarios((prev) => prev.map((s) => (s.id === id ? { ...s, status: 'Archived' } : s))), []);
  const deleteScenario = useCallback((id: string) => setScenarios((prev) => prev.filter((s) => s.id !== id)), []);

  const createNewVersion = useCallback(
    (baseConfig: ScenarioConfig, updates: Partial<ScenarioConfig>): ScenarioConfig => {
      const newVersion: ScenarioConfig = {
        ...baseConfig,
        ...updates,
        id: `scenario-${Date.now()}`,
        version: baseConfig.version + 1,
        previousVersionId: baseConfig.id,
        createdDate: new Date().toISOString().slice(0, 10),
      };
      setScenarios((prev) => [...prev, newVersion]);
      return newVersion;
    },
    []
  );

  const value: ScenarioContextValue = { scenarios, addScenario, archiveScenario, deleteScenario, createNewVersion };
  return <ScenarioContext.Provider value={value}>{children}</ScenarioContext.Provider>;
}

export function useScenario(): ScenarioContextValue {
  const ctx = useContext(ScenarioContext);
  if (!ctx) throw new Error('useScenario must be used within a ScenarioProvider');
  return ctx;
}
