import { createContext, ReactNode, useCallback, useContext, useState } from 'react';
import { ForecastRun, ForecastVsActualPoint, SavedForecast } from '../forecast/types';

interface ForecastContextValue {
  savedForecasts: SavedForecast[];
  saveForecast: (run: ForecastRun) => void;
  deleteForecast: (id: string) => void;
  recordActual: (forecastId: string, point: ForecastVsActualPoint) => void;
}

const ForecastContext = createContext<ForecastContextValue | null>(null);

export function ForecastProvider({ children }: { children: ReactNode }) {
  const [savedForecasts, setSavedForecasts] = useState<SavedForecast[]>([]);

  const saveForecast = useCallback((run: ForecastRun) => {
    setSavedForecasts((prev) => [...prev, { id: `saved-${Date.now()}`, createdDate: new Date().toISOString().slice(0, 10), run, actuals: [] }]);
  }, []);

  const deleteForecast = useCallback((id: string) => {
    setSavedForecasts((prev) => prev.filter((f) => f.id !== id));
  }, []);

  const recordActual = useCallback((forecastId: string, point: ForecastVsActualPoint) => {
    setSavedForecasts((prev) => prev.map((f) => (f.id === forecastId ? { ...f, actuals: [...f.actuals.filter((a) => a.date !== point.date), point] } : f)));
  }, []);

  const value: ForecastContextValue = { savedForecasts, saveForecast, deleteForecast, recordActual };
  return <ForecastContext.Provider value={value}>{children}</ForecastContext.Provider>;
}

export function useForecast(): ForecastContextValue {
  const ctx = useContext(ForecastContext);
  if (!ctx) throw new Error('useForecast must be used within a ForecastProvider');
  return ctx;
}
