import { createContext, ReactNode, useCallback, useContext, useMemo, useState } from 'react';
import { ColumnType, Dataset, DatasetMeta, Row } from '../types/analytics';
import { inferColumnTypes } from '../lib/dataImport';
import { demoOrg, demoPeriods } from '../data/demoData';
import { CleaningStepResult } from '../lib/dataCleaning';

const STORAGE_KEY = 'ledger.datasets.v2';
const DEMO_DATASET_ID = 'demo-financials';

/**
 * V1 had no backend, and V2 still doesn't. Uploaded datasets live in memory
 * for the current browser session. We do NOT pretend to persist full row
 * data to localStorage (large uploads would blow the quota) — a real
 * persistent store is V12's job. Only the demo dataset is guaranteed to be
 * there after a reload.
 */

function periodsToRows(): Row[] {
  return demoPeriods.map((p) => ({
    period: p.label,
    revenue: p.revenue,
    expenses: p.expenses,
    cash: p.cash,
    assets: p.assets,
    liabilities: p.liabilities,
    debt: p.debt,
  }));
}

function buildDemoDataset(): Dataset {
  const rows = periodsToRows();
  const columns = Object.keys(rows[0]);
  const columnTypes: Record<string, ColumnType> = {
    period: 'date',
    revenue: 'numeric',
    expenses: 'numeric',
    cash: 'numeric',
    assets: 'numeric',
    liabilities: 'numeric',
    debt: 'numeric',
  };
  return {
    id: DEMO_DATASET_ID,
    name: `${demoOrg.name} — trailing 12 months`,
    source: 'demo',
    fileType: 'json',
    uploadedAt: demoPeriods[0].periodStart,
    rowCount: rows.length,
    columns,
    columnTypes,
    originalRows: rows,
    cleanedRows: rows,
    cleaningLog: [],
  };
}

interface StoredRegistry {
  activeId: string;
}

function loadRegistry(): StoredRegistry | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as StoredRegistry) : null;
  } catch {
    return null;
  }
}

interface DatasetContextValue {
  datasets: DatasetMeta[];
  activeDataset: Dataset;
  activeId: string;
  setActiveId: (id: string) => void;
  addDataset: (input: { name: string; fileType: Dataset['fileType']; columns: string[]; rows: Row[] }) => string;
  renameDataset: (id: string, name: string) => void;
  deleteDataset: (id: string) => void;
  applyCleaningStep: (id: string, step: CleaningStepResult) => void;
  resetCleaned: (id: string) => void;
}

const DatasetContext = createContext<DatasetContextValue | null>(null);

export function DatasetProvider({ children }: { children: ReactNode }) {
  const demoDataset = useMemo(buildDemoDataset, []);
  const [datasetsById, setDatasetsById] = useState<Record<string, Dataset>>(() => ({
    [DEMO_DATASET_ID]: demoDataset,
  }));
  const [activeId, setActiveIdState] = useState<string>(() => loadRegistry()?.activeId ?? DEMO_DATASET_ID);

  const persist = useCallback((active: string) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ activeId: active }));
    } catch {
      // Best-effort only; the active dataset still works for this session.
    }
  }, []);

  const setActiveId = useCallback(
    (id: string) => {
      setActiveIdState(id);
      persist(id);
    },
    [persist]
  );

  const addDataset = useCallback(
    (input: { name: string; fileType: Dataset['fileType']; columns: string[]; rows: Row[] }): string => {
      const id = `ds-${Date.now()}-${Math.round(Math.random() * 1000)}`;
      const columnTypes = inferColumnTypes(input.columns, input.rows);
      const dataset: Dataset = {
        id,
        name: input.name,
        source: 'user',
        fileType: input.fileType,
        uploadedAt: new Date().toISOString(),
        rowCount: input.rows.length,
        columns: input.columns,
        columnTypes,
        originalRows: input.rows,
        cleanedRows: input.rows,
        cleaningLog: [],
      };
      setDatasetsById((prev) => {
        const next = { ...prev, [id]: dataset };
        persist(id);
        return next;
      });
      setActiveIdState(id);
      return id;
    },
    [persist]
  );

  const renameDataset = useCallback(
    (id: string, name: string) => {
      setDatasetsById((prev) => {
        if (!prev[id]) return prev;
        const next = { ...prev, [id]: { ...prev[id], name } };
        persist(activeId);
        return next;
      });
    },
    [activeId, persist]
  );

  const deleteDataset = useCallback(
    (id: string) => {
      if (id === DEMO_DATASET_ID) return;
      setDatasetsById((prev) => {
        const next = { ...prev };
        delete next[id];
        const nextActive = activeId === id ? DEMO_DATASET_ID : activeId;
        persist(nextActive);
        return next;
      });
      setActiveIdState((prev) => (prev === id ? DEMO_DATASET_ID : prev));
    },
    [activeId, persist]
  );

  const applyCleaningStep = useCallback(
    (id: string, step: CleaningStepResult) => {
      setDatasetsById((prev) => {
        if (!prev[id]) return prev;
        const dataset = prev[id];
        const next = {
          ...prev,
          [id]: {
            ...dataset,
            cleanedRows: step.rows,
            cleaningLog: [...dataset.cleaningLog, step.log],
          },
        };
        persist(activeId);
        return next;
      });
    },
    [activeId, persist]
  );

  const resetCleaned = useCallback(
    (id: string) => {
      setDatasetsById((prev) => {
        if (!prev[id]) return prev;
        const dataset = prev[id];
        const next = { ...prev, [id]: { ...dataset, cleanedRows: dataset.originalRows, cleaningLog: [] } };
        persist(activeId);
        return next;
      });
    },
    [activeId, persist]
  );

  const value: DatasetContextValue = {
    datasets: Object.values(datasetsById).map(({ originalRows, cleanedRows, cleaningLog, ...meta }) => meta),
    activeDataset: datasetsById[activeId] ?? demoDataset,
    activeId,
    setActiveId,
    addDataset,
    renameDataset,
    deleteDataset,
    applyCleaningStep,
    resetCleaned,
  };

  return <DatasetContext.Provider value={value}>{children}</DatasetContext.Provider>;
}

export function useDatasets(): DatasetContextValue {
  const ctx = useContext(DatasetContext);
  if (!ctx) throw new Error('useDatasets must be used within a DatasetProvider');
  return ctx;
}

export { DEMO_DATASET_ID };
