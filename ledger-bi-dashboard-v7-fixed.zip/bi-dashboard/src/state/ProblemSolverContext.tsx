import { createContext, ReactNode, useCallback, useContext, useState } from 'react';
import { BusinessProblem, ProblemLifecycleStatus } from '../problemSolver/types';
import { buildDemoProblem } from '../problemSolver/demoData';

interface ProblemSolverContextValue {
  problems: BusinessProblem[];
  addProblem: (problem: BusinessProblem) => void;
  updateProblem: (id: string, updates: Partial<BusinessProblem>) => void;
  deleteProblem: (id: string) => void;
  setProblemStatus: (id: string, status: ProblemLifecycleStatus) => void;
  loadDemoProblem: () => void;
}

const ProblemSolverContext = createContext<ProblemSolverContextValue | null>(null);

export function ProblemSolverProvider({ children }: { children: ReactNode }) {
  const [problems, setProblems] = useState<BusinessProblem[]>([]);

  const addProblem = useCallback((problem: BusinessProblem) => setProblems((prev) => [...prev, problem]), []);
  const updateProblem = useCallback((id: string, updates: Partial<BusinessProblem>) => setProblems((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p))), []);
  const deleteProblem = useCallback((id: string) => setProblems((prev) => prev.filter((p) => p.id !== id)), []);

  const setProblemStatus = useCallback((id: string, status: ProblemLifecycleStatus) => {
    setProblems((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status, history: [...p.history, { date: new Date().toISOString().slice(0, 10), status }] } : p))
    );
  }, []);

  const loadDemoProblem = useCallback(() => {
    setProblems((prev) => (prev.some((p) => p.id === 'problem-demo-1') ? prev : [...prev, buildDemoProblem()]));
  }, []);

  const value: ProblemSolverContextValue = { problems, addProblem, updateProblem, deleteProblem, setProblemStatus, loadDemoProblem };
  return <ProblemSolverContext.Provider value={value}>{children}</ProblemSolverContext.Provider>;
}

export function useProblemSolver(): ProblemSolverContextValue {
  const ctx = useContext(ProblemSolverContext);
  if (!ctx) throw new Error('useProblemSolver must be used within a ProblemSolverProvider');
  return ctx;
}
