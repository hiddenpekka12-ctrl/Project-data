import { createContext, ReactNode, useCallback, useContext, useState } from 'react';
import { Control, KeyRiskIndicator, MitigationAction, RiskAppetiteSettings, RiskItem, RiskScoringSettings } from '../risk/types';
import { DEFAULT_APPETITE_SETTINGS } from '../risk/appetite';
import { DEFAULT_SCORING_SETTINGS } from '../risk/scoring';
import { buildDemoControls, buildDemoKris, buildDemoMitigations, buildDemoRiskRegister } from '../risk/demoData';

interface RiskContextValue {
  registerItems: RiskItem[];
  kris: KeyRiskIndicator[];
  controls: Control[];
  mitigations: MitigationAction[];
  appetiteSettings: RiskAppetiteSettings;
  scoringSettings: RiskScoringSettings;
  isDemoLoaded: boolean;

  addRisk: (risk: RiskItem) => void;
  updateRisk: (id: string, updates: Partial<RiskItem>) => void;
  deleteRisk: (id: string) => void;
  duplicateRisk: (id: string) => void;

  addKri: (kri: KeyRiskIndicator) => void;
  updateKri: (id: string, updates: Partial<KeyRiskIndicator>) => void;
  deleteKri: (id: string) => void;

  addControl: (control: Control) => void;
  updateControl: (id: string, updates: Partial<Control>) => void;
  deleteControl: (id: string) => void;

  addMitigation: (action: MitigationAction) => void;
  updateMitigation: (id: string, updates: Partial<MitigationAction>) => void;
  deleteMitigation: (id: string) => void;

  setAppetiteSettings: (settings: RiskAppetiteSettings) => void;
  setScoringSettings: (settings: RiskScoringSettings) => void;

  loadDemoRiskData: () => void;
}

const RiskContext = createContext<RiskContextValue | null>(null);

function newId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.round(Math.random() * 1000)}`;
}

export function RiskProvider({ children }: { children: ReactNode }) {
  const [registerItems, setRegisterItems] = useState<RiskItem[]>([]);
  const [kris, setKris] = useState<KeyRiskIndicator[]>([]);
  const [controls, setControls] = useState<Control[]>([]);
  const [mitigations, setMitigations] = useState<MitigationAction[]>([]);
  const [appetiteSettings, setAppetiteSettings] = useState<RiskAppetiteSettings>(DEFAULT_APPETITE_SETTINGS);
  const [scoringSettings, setScoringSettings] = useState<RiskScoringSettings>(DEFAULT_SCORING_SETTINGS);
  const [isDemoLoaded, setIsDemoLoaded] = useState(false);

  const addRisk = useCallback((risk: RiskItem) => setRegisterItems((prev) => [...prev, risk]), []);
  const updateRisk = useCallback((id: string, updates: Partial<RiskItem>) => setRegisterItems((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r))), []);
  const deleteRisk = useCallback((id: string) => setRegisterItems((prev) => prev.filter((r) => r.id !== id)), []);
  const duplicateRisk = useCallback((id: string) => {
    setRegisterItems((prev) => {
      const found = prev.find((r) => r.id === id);
      if (!found) return prev;
      return [...prev, { ...found, id: newId('risk'), name: `${found.name} (copy)` }];
    });
  }, []);

  const addKri = useCallback((kri: KeyRiskIndicator) => setKris((prev) => [...prev, kri]), []);
  const updateKri = useCallback((id: string, updates: Partial<KeyRiskIndicator>) => setKris((prev) => prev.map((k) => (k.id === id ? { ...k, ...updates } : k))), []);
  const deleteKri = useCallback((id: string) => setKris((prev) => prev.filter((k) => k.id !== id)), []);

  const addControl = useCallback((control: Control) => setControls((prev) => [...prev, control]), []);
  const updateControl = useCallback((id: string, updates: Partial<Control>) => setControls((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c))), []);
  const deleteControl = useCallback((id: string) => setControls((prev) => prev.filter((c) => c.id !== id)), []);

  const addMitigation = useCallback((action: MitigationAction) => setMitigations((prev) => [...prev, action]), []);
  const updateMitigation = useCallback((id: string, updates: Partial<MitigationAction>) => setMitigations((prev) => prev.map((m) => (m.id === id ? { ...m, ...updates } : m))), []);
  const deleteMitigation = useCallback((id: string) => setMitigations((prev) => prev.filter((m) => m.id !== id)), []);

  const loadDemoRiskData = useCallback(() => {
    const demoRisks = buildDemoRiskRegister();
    setRegisterItems(demoRisks);
    setKris(buildDemoKris());
    setControls(buildDemoControls());
    // Link demo mitigations to their corresponding risk by matching action text
    const demoMitigations = buildDemoMitigations().map((m) => {
      const match = demoRisks.find((r) => r.mitigationAction === m.action);
      return { ...m, riskId: match?.id ?? '' };
    });
    setMitigations(demoMitigations);
    setIsDemoLoaded(true);
  }, []);

  const value: RiskContextValue = {
    registerItems,
    kris,
    controls,
    mitigations,
    appetiteSettings,
    scoringSettings,
    isDemoLoaded,
    addRisk,
    updateRisk,
    deleteRisk,
    duplicateRisk,
    addKri,
    updateKri,
    deleteKri,
    addControl,
    updateControl,
    deleteControl,
    addMitigation,
    updateMitigation,
    deleteMitigation,
    setAppetiteSettings,
    setScoringSettings,
    loadDemoRiskData,
  };

  return <RiskContext.Provider value={value}>{children}</RiskContext.Provider>;
}

export function useRisk(): RiskContextValue {
  const ctx = useContext(RiskContext);
  if (!ctx) throw new Error('useRisk must be used within a RiskProvider');
  return ctx;
}
