import { Priority } from './types';

export interface PriorityInputs {
  financialImpactScore: number; // 0-10, caller-supplied based on magnitude
  riskSeverityScore: number; // 0-10
  urgencyScore: number; // 0-10
  strategicImportanceScore: number; // 0-10
}

export interface PriorityWeights {
  financialImpact: number;
  riskSeverity: number;
  urgency: number;
  strategicImportance: number;
}

export const DEFAULT_PRIORITY_WEIGHTS: PriorityWeights = {
  financialImpact: 0.35,
  riskSeverity: 0.25,
  urgency: 0.25,
  strategicImportance: 0.15,
};

export function computePriorityScore(inputs: PriorityInputs, weights: PriorityWeights = DEFAULT_PRIORITY_WEIGHTS): number {
  const totalWeight = weights.financialImpact + weights.riskSeverity + weights.urgency + weights.strategicImportance || 1;
  return (
    (inputs.financialImpactScore * weights.financialImpact +
      inputs.riskSeverityScore * weights.riskSeverity +
      inputs.urgencyScore * weights.urgency +
      inputs.strategicImportanceScore * weights.strategicImportance) /
    totalWeight
  );
}

export function priorityLabel(score: number): Priority {
  if (score >= 7.5) return 'Critical';
  if (score >= 5.5) return 'High';
  if (score >= 3) return 'Medium';
  return 'Low';
}
