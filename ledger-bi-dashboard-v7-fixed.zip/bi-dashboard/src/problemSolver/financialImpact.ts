import { PeriodModel } from '../finance/buildFinanceModel';
import { FinancialImpactEstimate } from './types';

/**
 * Reads V3's already-computed income statement figures to estimate the
 * financial impact of a stated revenue/cost gap. Every estimate states
 * its method and assumptions explicitly — nothing here is presented as
 * more certain than a back-of-envelope calculation.
 */
export function estimateFinancialImpact(current: PeriodModel, previous: PeriodModel | null, gapDescription: string): FinancialImpactEstimate[] {
  const estimates: FinancialImpactEstimate[] = [];
  if (!previous) return estimates;

  const revenueChange = current.income.revenue - previous.income.revenue;
  const grossMarginPct = current.income.grossMarginPct / 100;

  estimates.push({
    metric: 'Revenue impact',
    estimatedImpact: revenueChange,
    method: 'Current period revenue minus previous period revenue (from V3 Finance Engine).',
    assumptions: [],
  });

  estimates.push({
    metric: 'Estimated gross profit impact',
    estimatedImpact: revenueChange * grossMarginPct,
    method: `Revenue impact × current gross margin (${current.income.grossMarginPct.toFixed(1)}%).`,
    assumptions: [`Assumes the revenue change carries the same gross margin as the current period (${current.income.grossMarginPct.toFixed(1)}%) — the actual margin on the specific lost/gained revenue may differ.`],
  });

  const ebitdaChange = current.income.ebitda - previous.income.ebitda;
  estimates.push({
    metric: 'EBITDA impact',
    estimatedImpact: ebitdaChange,
    method: 'Current period EBITDA minus previous period EBITDA (from V3 Finance Engine).',
    assumptions: [],
  });

  const netProfitChange = current.income.netProfit - previous.income.netProfit;
  estimates.push({
    metric: 'Net profit impact',
    estimatedImpact: netProfitChange,
    method: 'Current period net profit minus previous period net profit (from V3 Finance Engine).',
    assumptions: [],
  });

  const wcChange = current.workingCapital.workingCapital - previous.workingCapital.workingCapital;
  estimates.push({
    metric: 'Working capital impact',
    estimatedImpact: wcChange,
    method: 'Current period working capital minus previous period working capital (from V3 Finance Engine).',
    assumptions: [],
  });

  return estimates;
}
