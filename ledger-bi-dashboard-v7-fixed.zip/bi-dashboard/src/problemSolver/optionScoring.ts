import { OptionScore, ScoringCriterion } from './types';

export const DEFAULT_SCORING_CRITERIA: ScoringCriterion[] = [
  { key: 'financialImpact', label: 'Financial Impact', weight: 0.3 },
  { key: 'risk', label: 'Risk', weight: 0.2 },
  { key: 'cost', label: 'Cost', weight: 0.15 },
  { key: 'speed', label: 'Speed', weight: 0.1 },
  { key: 'strategicFit', label: 'Strategic Fit', weight: 0.15 },
  { key: 'complexity', label: 'Complexity', weight: 0.1 },
];

/** Weighted Score = Σ(Weight × Option Score). Raw scores (0-10) are
 * supplied by the caller per criterion — this function only combines
 * them transparently, it never invents a score. */
export function computeOptionScore(optionId: string, rawScores: Record<string, number>, criteria: ScoringCriterion[]): OptionScore {
  const totalWeight = criteria.reduce((s, c) => s + c.weight, 0) || 1;
  const weightedTotal = criteria.reduce((sum, c) => sum + ((rawScores[c.key] ?? 0) * c.weight) / totalWeight, 0);
  return { optionId, scores: rawScores, weightedTotal };
}

export function rankOptions(scores: OptionScore[]): OptionScore[] {
  return [...scores].sort((a, b) => b.weightedTotal - a.weightedTotal);
}
