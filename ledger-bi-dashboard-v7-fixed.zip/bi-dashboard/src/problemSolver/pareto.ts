import { Row } from '../types/analytics';
import { groupSum } from '../lib/autoEda';
import { ParetoResult } from './types';

export function buildParetoAnalysis(rows: Row[], dimensionColumn: string, measureColumn: string): ParetoResult {
  const totals = groupSum(rows, dimensionColumn, measureColumn);
  const grandTotal = totals.reduce((s, t) => s + t.total, 0);

  let cumulative = 0;
  const items = totals.map((t) => {
    const percentage = grandTotal === 0 ? 0 : (t.total / grandTotal) * 100;
    cumulative += percentage;
    return { key: t.key, value: t.total, percentage, cumulativePercentage: cumulative };
  });

  // How many of the top items make up ~80% of the total, and what share
  // of the item COUNT do they represent? This is checked, not assumed.
  const eightyIndex = items.findIndex((i) => i.cumulativePercentage >= 80);
  const top20PctItemCount = eightyIndex === -1 ? items.length : eightyIndex + 1;
  const itemCountShare = items.length === 0 ? 0 : (top20PctItemCount / items.length) * 100;
  const followsEightyTwenty = itemCountShare <= 25 && eightyIndex !== -1; // roughly: ~20% of items drive ~80%

  return {
    dimension: dimensionColumn,
    measure: measureColumn,
    items,
    top20PctItemCount,
    top20PctCumulativeShare: eightyIndex === -1 ? 100 : items[eightyIndex].cumulativePercentage,
    followsEightyTwenty,
  };
}
