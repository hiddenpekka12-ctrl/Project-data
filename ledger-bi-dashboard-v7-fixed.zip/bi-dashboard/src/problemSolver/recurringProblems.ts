import { BusinessProblem } from './types';

export interface RecurringProblemGroup {
  category: string;
  titleKeyword: string;
  occurrences: { id: string; title: string; dateIdentified: string }[];
}

/** Groups problems that share a category and a significant word in their
 * title. Flags a pattern worth investigating — never asserts the same
 * root cause across occurrences. */
export function detectRecurringProblems(problems: BusinessProblem[]): RecurringProblemGroup[] {
  const STOPWORDS = new Set(['the', 'a', 'an', 'is', 'are', 'of', 'in', 'on', 'for', 'to', 'and', 'or', 'declined', 'increased', 'decreased']);
  const groups = new Map<string, RecurringProblemGroup>();

  problems.forEach((p) => {
    const words = p.title.toLowerCase().split(/\W+/).filter((w) => w.length > 3 && !STOPWORDS.has(w));
    words.forEach((w) => {
      const key = `${p.category}::${w}`;
      if (!groups.has(key)) groups.set(key, { category: p.category, titleKeyword: w, occurrences: [] });
      groups.get(key)!.occurrences.push({ id: p.id, title: p.title, dateIdentified: p.dateIdentified });
    });
  });

  return Array.from(groups.values()).filter((g) => g.occurrences.length >= 2);
}
