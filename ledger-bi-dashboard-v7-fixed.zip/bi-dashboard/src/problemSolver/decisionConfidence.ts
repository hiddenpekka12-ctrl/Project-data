import { Assumption, BusinessProblem, ConfidenceLevel } from './types';

/**
 * Decision confidence is NOT the same as probability of success (Section
 * 24) — it reflects how well-supported the recommendation is by the
 * available evidence, not how likely the chosen option is to work.
 */
export function computeDecisionConfidence(problem: BusinessProblem): { level: ConfidenceLevel; reasons: string[] } {
  const reasons: string[] = [];
  let points = 0;
  const maxPoints = 5;

  if (problem.statement) {
    points += 1;
  } else {
    reasons.push('Problem statement not yet structured (current/expected/gap).');
  }

  const confirmedCauses = problem.fishbone.filter((f) => f.status === 'Confirmed Root Cause').length;
  if (confirmedCauses > 0) {
    points += 1;
  } else {
    reasons.push('No confirmed root causes yet — only potential causes.');
  }

  if (problem.financialImpacts.length > 0) {
    points += 1;
  } else {
    reasons.push('Financial impact not yet quantified.');
  }

  const unvalidated = problem.assumptions.filter((a: Assumption) => a.validationStatus === 'Unvalidated').length;
  if (problem.assumptions.length > 0 && unvalidated === 0) {
    points += 1;
  } else if (unvalidated > 0) {
    reasons.push(`${unvalidated} assumption(s) remain unvalidated.`);
  } else {
    reasons.push('No assumptions have been logged yet.');
  }

  if (problem.options.length >= 2) {
    points += 1;
  } else {
    reasons.push('Fewer than two options were compared.');
  }

  const level: ConfidenceLevel = points >= 4 ? 'High' : points >= 2 ? 'Medium' : 'Low';
  return { level, reasons };
}

/** Data sufficiency is explicitly a heuristic percentage, not a
 * statistical measure — Section 36 requires this label. */
export function computeDataSufficiency(problem: BusinessProblem): { pct: number; label: 'Sufficient' | 'Partially Sufficient' | 'Insufficient' } {
  let points = 0;
  const checks = [
    Boolean(problem.statement),
    problem.fiveWhys.length > 0 || problem.fishbone.length > 0,
    problem.paretoResults.length > 0,
    problem.financialImpacts.length > 0,
    problem.datasetId !== null,
  ];
  checks.forEach((c) => {
    if (c) points += 1;
  });
  const pct = Math.round((points / checks.length) * 100);
  const label = pct >= 80 ? 'Sufficient' : pct >= 40 ? 'Partially Sufficient' : 'Insufficient';
  return { pct, label };
}
