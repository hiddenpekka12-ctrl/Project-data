import { RiskModel } from '../risk/buildRiskModel';
import { KeyRiskIndicator, RiskItem } from '../risk/types';
import { computeKriStatus } from '../risk/kri';
import { ProblemCategory } from './types';

/** Maps a problem category to the risk categories most likely relevant —
 * a starting heuristic for filtering, never a hard rule. */
const CATEGORY_TO_RISK_CATEGORIES: Partial<Record<ProblemCategory, string[]>> = {
  Revenue: ['strategic', 'financial'],
  Profitability: ['financial'],
  Cost: ['financial', 'supplyChain'],
  'Cash Flow': ['financial'],
  Customer: ['strategic', 'reputational'],
  'Supply Chain': ['supplyChain', 'operational'],
  Operations: ['operational'],
  Technology: ['technology'],
  Finance: ['financial'],
  Risk: ['financial', 'strategic', 'operational', 'technology', 'compliance', 'supplyChain', 'reputational'],
};

export interface RiskImpactContext {
  relatedRisks: RiskItem[];
  relatedKris: { kri: KeyRiskIndicator; status: ReturnType<typeof computeKriStatus> }[];
  activeFinancialSignalCount: number;
}

export function findRiskImpact(category: ProblemCategory, riskModel: RiskModel, allKris: KeyRiskIndicator[]): RiskImpactContext {
  const relevantCategories = CATEGORY_TO_RISK_CATEGORIES[category] ?? [];
  const relatedRisks = riskModel.scoredRisks.filter((s) => relevantCategories.includes(s.risk.category)).map((s) => s.risk);
  const relatedKris = allKris
    .filter((k) => relevantCategories.includes(k.category))
    .map((kri) => ({ kri, status: computeKriStatus(kri) }));

  return {
    relatedRisks,
    relatedKris,
    activeFinancialSignalCount: riskModel.financialSignals.length,
  };
}
