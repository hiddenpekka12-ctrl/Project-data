import { ProblemCategory } from './types';

/** Guided questions per category (Section 13). This is a starting set
 * per category, not an exhaustive interview script. */
export const DIAGNOSTIC_QUESTIONS: Partial<Record<ProblemCategory, string[]>> = {
  Revenue: [
    'Which product declined?',
    'Which customer declined?',
    'Which region declined?',
    'Which channel declined?',
    'When did the decline begin?',
    'Was price changed?',
    'Was volume changed?',
  ],
  Profitability: [
    'Did revenue decline?',
    'Did COGS increase?',
    'Did operating expenses increase?',
    'Did gross margin decline?',
    'Which cost category changed most?',
  ],
  'Cash Flow': [
    'Is operating cash flow declining?',
    'Are receivables increasing?',
    'Is inventory increasing?',
    'Is debt increasing?',
    'Is the cash conversion cycle deteriorating?',
  ],
  Customer: [
    'Which segment churned?',
    'Which customers reduced purchases?',
    'Is customer concentration increasing?',
    'Is the complaint rate increasing?',
  ],
  Cost: [
    'Which cost category is growing fastest?',
    'Is the increase from price or volume?',
    'Is a single supplier or vendor responsible?',
    'Is the increase one-off or recurring?',
  ],
  'Supply Chain': [
    'Is a single supplier responsible for most of the disruption?',
    'Has lead time changed?',
    'Has input pricing changed?',
    'Is inventory buffer adequate?',
  ],
};

/** Root Cause Library (Section 49) — a starting taxonomy to prompt
 * investigation, never a substitute for actual evidence from the data. */
export const ROOT_CAUSE_LIBRARY: Partial<Record<ProblemCategory, string[]>> = {
  Revenue: ['Demand decline', 'Price change', 'Volume change', 'Product mix shift', 'Customer churn', 'Channel weakness', 'Competitive pressure'],
  Cost: ['Input price increase', 'Volume change', 'Operational inefficiency', 'Supplier pricing change', 'Labor cost change', 'Logistics cost change', 'Overhead growth'],
  'Cash Flow': ['Receivables buildup', 'Inventory buildup', 'Payables timing', 'Profitability decline', 'Capital expenditure', 'Debt service'],
  Profitability: ['Revenue decline', 'COGS increase', 'Operating expense growth', 'Margin mix shift', 'Interest expense increase'],
  Customer: ['Product/service failure', 'Pricing dissatisfaction', 'Competitive switching', 'Support quality decline', 'Relationship management gap'],
};

export function questionsFor(category: ProblemCategory): string[] {
  return DIAGNOSTIC_QUESTIONS[category] ?? ['What changed?', 'When did it change?', 'Where is it concentrated?', 'What evidence supports this?'];
}

export function rootCausesFor(category: ProblemCategory): string[] {
  return ROOT_CAUSE_LIBRARY[category] ?? [];
}
