import { answerFinancialQuestion, FinanceQAContext } from '../finance/financeQuestions';
import { answerRiskQuestion, RiskQAContext } from '../risk/decisionQuestions';
import { generateSolutionSuggestions } from './solutionGeneration';
import { FishboneCause } from './types';

export interface StructuredAnswer {
  question: string;
  dataUsed: string;
  finding: string;
  evidence: string;
  diagnosis: string;
  risk: string;
  options: string[];
  recommendation: string;
  assumptions: string;
  action: string;
  kpi: string;
  insufficientData: boolean;
}

/**
 * Routes the question to V3's or V4's own Q&A engine first — never
 * re-implements financial or risk reasoning here. This function only
 * assembles whatever came back into the structured 11-part format
 * Section 35 asks for, and is honest when nothing could be answered.
 */
export function answerBusinessQuestionStructured(question: string, financeCtx: FinanceQAContext | null, riskCtx: RiskQAContext | null, knownCauses: FishboneCause[]): StructuredAnswer {
  const financeAnswer = financeCtx ? answerFinancialQuestion(question, financeCtx) : null;
  const riskAnswer = riskCtx ? answerRiskQuestion(question, riskCtx) : null;

  const financeHit = financeAnswer?.answered ?? false;
  const riskHit = riskAnswer?.answered ?? false;

  if (!financeHit && !riskHit) {
    return {
      question,
      dataUsed: 'Finance Engine (V3) and Risk Engine (V4) were both consulted.',
      finding: 'No finding could be generated from the available data.',
      evidence: '',
      diagnosis: '',
      risk: '',
      options: [],
      recommendation: '',
      assumptions: '',
      action: 'Consider rephrasing the question, or check that a dataset and account mapping are set up in Finance/Risk.',
      kpi: '',
      insufficientData: true,
    };
  }

  const finding = [financeHit ? financeAnswer!.answer : null, riskHit ? riskAnswer!.answer : null].filter(Boolean).join(' ');
  const evidence = financeHit ? financeAnswer!.supporting ?? '' : '';
  const suggestions = generateSolutionSuggestions(knownCauses.filter((c) => c.status !== 'Ruled Out'));
  const allOptions = Array.from(new Set(suggestions.flatMap((s) => s.suggestions)));

  return {
    question,
    dataUsed: [financeHit ? 'V3 Finance Engine' : null, riskHit ? 'V4 Risk Engine' : null].filter(Boolean).join(' + '),
    finding,
    evidence,
    diagnosis: allOptions.length > 0 ? 'Based on causes already logged for related problems — see the Root Cause tab for the evidence behind each.' : 'No confirmed or potential causes logged yet for this question\'s topic.',
    risk: riskHit ? riskAnswer!.answer ?? '' : 'No specific risk-register match for this question.',
    options: allOptions.slice(0, 5),
    recommendation: allOptions.length > 0 ? `Consider: ${allOptions[0]}` : 'Not enough diagnosed causes yet to recommend a specific option.',
    assumptions: 'This answer assumes the active dataset and account mapping accurately reflect current operations.',
    action: 'Log this question as a Business Problem to track it through diagnosis, options, and a decision.',
    kpi: '',
    insufficientData: false,
  };
}
