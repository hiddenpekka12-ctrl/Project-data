/**
 * PROBLEM SOLVER TYPES
 * --------------------
 * Financial and risk impact fields here are always populated FROM V3/V4
 * models (finance/buildFinanceModel.ts, risk/buildRiskModel.ts) — never
 * recomputed independently. This file only models the problem-solving
 * workflow itself: the diagnosis, options, decision, and action layers
 * that V1-V4 didn't have.
 */

export type ProblemCategory =
  | 'Revenue' | 'Profitability' | 'Cost' | 'Cash Flow' | 'Customer' | 'Marketing'
  | 'Sales' | 'Operations' | 'Supply Chain' | 'People' | 'Technology' | 'Finance'
  | 'Risk' | 'Strategy' | 'Productivity' | 'Quality' | 'Growth' | 'Other';

export const PROBLEM_CATEGORIES: ProblemCategory[] = [
  'Revenue', 'Profitability', 'Cost', 'Cash Flow', 'Customer', 'Marketing', 'Sales',
  'Operations', 'Supply Chain', 'People', 'Technology', 'Finance', 'Risk', 'Strategy',
  'Productivity', 'Quality', 'Growth', 'Other',
];

export type ProblemLifecycleStatus =
  | 'New' | 'Data Collection' | 'Analysis' | 'Diagnosis' | 'Options' | 'Decision Pending'
  | 'Approved' | 'Implementation' | 'Monitoring' | 'Resolved' | 'Closed' | 'Reopened';

export const LIFECYCLE_STATUSES: ProblemLifecycleStatus[] = [
  'New', 'Data Collection', 'Analysis', 'Diagnosis', 'Options', 'Decision Pending',
  'Approved', 'Implementation', 'Monitoring', 'Resolved', 'Closed', 'Reopened',
];

export type Priority = 'Critical' | 'High' | 'Medium' | 'Low';
export type ConfidenceLevel = 'High' | 'Medium' | 'Low';
export type EvidenceQuality = 'Strong' | 'Moderate' | 'Weak' | 'Unknown';
export type ClaimType = 'FACT' | 'HYPOTHESIS' | 'CONFIRMED_CAUSE' | 'CORRELATION';

export interface ProblemStatement {
  currentState: string;
  expectedState: string;
  gapDescription: string;
  timePeriod: string;
  scope: string; // product/customer/region/channel/process
}

export interface CauseNode {
  id: string;
  label: string;
  claimType: ClaimType;
  evidence: string;
  confidence: ConfidenceLevel;
  children: CauseNode[];
}

export interface FiveWhysStep {
  level: number;
  question: string;
  answer: string;
  evidence: string;
  confidence: ConfidenceLevel;
  notes: string;
}

export const FISHBONE_CATEGORIES = ['People', 'Process', 'Technology', 'Materials', 'Measurement', 'Environment', 'Management'] as const;
export type FishboneCategory = (typeof FISHBONE_CATEGORIES)[number] | string;

export interface FishboneCause {
  id: string;
  category: FishboneCategory;
  cause: string;
  evidence: string;
  confidence: ConfidenceLevel;
  impact: 'Low' | 'Medium' | 'High';
  status: 'Potential Cause' | 'Confirmed Root Cause' | 'Ruled Out';
}

export interface ParetoItem {
  key: string;
  value: number;
  percentage: number;
  cumulativePercentage: number;
}

export interface ParetoResult {
  dimension: string;
  measure: string;
  items: ParetoItem[];
  top20PctItemCount: number;
  top20PctCumulativeShare: number;
  followsEightyTwenty: boolean;
}

export interface FinancialImpactEstimate {
  metric: string;
  estimatedImpact: number;
  method: string;
  assumptions: string[];
}

export interface Assumption {
  id: string;
  description: string;
  value: string;
  source: string;
  confidence: ConfidenceLevel;
  financialImpact: string;
  riskImpact: string;
  validationStatus: 'Unvalidated' | 'Validated' | 'Invalidated';
}

export interface SolutionOption {
  id: string;
  description: string;
  causeAddressed: string;
  expectedBenefit: string;
  estimatedCost: number;
  implementationTimeWeeks: number;
  risk: EvidenceQuality; // reuse the same qualitative scale for "how risky"
  complexity: 'Low' | 'Medium' | 'High';
  resourcesRequired: string;
  dependencies: string;
  reversibility: 'Easily reversible' | 'Difficult to reverse' | 'Irreversible';
  expectedRoiPct: number | null;
  confidence: ConfidenceLevel;
  assumptions: string;
}

export interface ScoringCriterion {
  key: string;
  label: string;
  weight: number; // sums to 1 across criteria
}

export interface OptionScore {
  optionId: string;
  scores: Record<string, number>; // criterion key -> 0-10 raw score
  weightedTotal: number;
}

export interface DecisionRecord {
  id: string;
  problemId: string;
  date: string;
  decisionMaker: string;
  selectedOptionId: string | null;
  alternativesConsidered: string[];
  reason: string;
  expectedOutcome: string;
  assumptions: string[];
  risksAccepted: string;
  actionOwner: string;
  reviewDate: string;
  actualOutcome: string;
  confidence: ConfidenceLevel;
  redTeamNotes: string;
}

export type ActionStatus = 'Not Started' | 'In Progress' | 'Blocked' | 'Completed' | 'Cancelled';

export interface ActionPlanItem {
  id: string;
  action: string;
  owner: string;
  priority: Priority;
  startDate: string;
  dueDate: string;
  dependency: string;
  status: ActionStatus;
  progressPct: number;
  kpiName: string;
  kpiBaseline: number | null;
  kpiTarget: number | null;
  kpiCurrent: number | null;
  linkedKriId: string | null;
}

export interface LessonsLearned {
  whatHappened: string;
  rootCause: string;
  wrongAssumption: string;
  actionThatWorked: string;
  actionThatFailed: string;
  whatToDoDifferently: string;
  kpiToMonitorEarlier: string;
  riskSignalThatCouldHaveHelped: string;
}

export interface BeforeAfterMetric {
  label: string;
  before: number;
  after: number;
}

export interface BusinessProblem {
  id: string;
  title: string;
  category: ProblemCategory;
  description: string;
  businessUnit: string;
  department: string;
  owner: string;
  dateIdentified: string;
  priority: Priority;
  timePeriod: string;
  targetOutcome: string;
  datasetId: string | null;
  status: ProblemLifecycleStatus;
  affectedFunctions: string[];

  statement: ProblemStatement | null;
  causeTree: CauseNode[];
  fiveWhys: FiveWhysStep[];
  fishbone: FishboneCause[];
  paretoResults: ParetoResult[];
  financialImpacts: FinancialImpactEstimate[];
  assumptions: Assumption[];
  options: SolutionOption[];
  scoringCriteria: ScoringCriterion[];
  optionScores: OptionScore[];
  decision: DecisionRecord | null;
  actionPlan: ActionPlanItem[];
  lessonsLearned: LessonsLearned | null;
  beforeAfterMetrics: BeforeAfterMetric[];

  history: { date: string; status: ProblemLifecycleStatus }[];
}
