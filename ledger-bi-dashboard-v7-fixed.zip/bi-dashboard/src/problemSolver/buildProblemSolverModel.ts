import { BusinessProblem, ProblemCategory } from './types';
import { detectRecurringProblems, RecurringProblemGroup } from './recurringProblems';

export interface ProblemSolverKpis {
  activeProblems: number;
  criticalProblems: number;
  highImpactProblems: number;
  problemsAwaitingDecision: number;
  problemsInImplementation: number;
  overdueActions: number;
  resolvedProblems: number;
  averageResolutionDays: number | null;
}

export interface ProblemSolverModel {
  kpis: ProblemSolverKpis;
  categoryDistribution: { category: string; count: number }[];
  lifecycleDistribution: { status: string; count: number }[];
  recurring: RecurringProblemGroup[];
}

const ACTIVE_STATUSES = new Set(['New', 'Data Collection', 'Analysis', 'Diagnosis', 'Options', 'Decision Pending', 'Approved', 'Implementation', 'Monitoring']);
const RESOLVED_STATUSES = new Set(['Resolved', 'Closed']);

export function buildProblemSolverModel(problems: BusinessProblem[]): ProblemSolverModel {
  const today = new Date().toISOString().slice(0, 10);

  const activeProblems = problems.filter((p) => ACTIVE_STATUSES.has(p.status)).length;
  const criticalProblems = problems.filter((p) => p.priority === 'Critical').length;
  const highImpactProblems = problems.filter((p) => p.priority === 'Critical' || p.priority === 'High').length;
  const problemsAwaitingDecision = problems.filter((p) => p.status === 'Decision Pending').length;
  const problemsInImplementation = problems.filter((p) => p.status === 'Implementation').length;
  const overdueActions = problems.reduce((sum, p) => sum + p.actionPlan.filter((a) => a.status !== 'Completed' && a.status !== 'Cancelled' && a.dueDate < today).length, 0);
  const resolved = problems.filter((p) => RESOLVED_STATUSES.has(p.status));

  const resolutionDurations = resolved
    .map((p) => {
      const resolvedEntry = [...p.history].reverse().find((h) => RESOLVED_STATUSES.has(h.status));
      if (!resolvedEntry || !p.dateIdentified) return null;
      const days = (new Date(resolvedEntry.date).getTime() - new Date(p.dateIdentified).getTime()) / (1000 * 60 * 60 * 24);
      return days >= 0 ? days : null;
    })
    .filter((d): d is number => d !== null);

  const averageResolutionDays = resolutionDurations.length ? Math.round(resolutionDurations.reduce((a, b) => a + b, 0) / resolutionDurations.length) : null;

  const categoryCounts = new Map<string, number>();
  problems.forEach((p) => categoryCounts.set(p.category, (categoryCounts.get(p.category) ?? 0) + 1));

  const statusCounts = new Map<string, number>();
  problems.forEach((p) => statusCounts.set(p.status, (statusCounts.get(p.status) ?? 0) + 1));

  return {
    kpis: {
      activeProblems,
      criticalProblems,
      highImpactProblems,
      problemsAwaitingDecision,
      problemsInImplementation,
      overdueActions,
      resolvedProblems: resolved.length,
      averageResolutionDays,
    },
    categoryDistribution: Array.from(categoryCounts.entries()).map(([category, count]) => ({ category, count })),
    lifecycleDistribution: Array.from(statusCounts.entries()).map(([status, count]) => ({ status, count })),
    recurring: detectRecurringProblems(problems),
  };
}

export function emptyProblem(idHint: string): BusinessProblem {
  return {
    id: idHint,
    title: '',
    category: 'Other' as ProblemCategory,
    description: '',
    businessUnit: '',
    department: '',
    owner: '',
    dateIdentified: new Date().toISOString().slice(0, 10),
    priority: 'Medium',
    timePeriod: '',
    targetOutcome: '',
    datasetId: null,
    status: 'New',
    affectedFunctions: [],
    statement: null,
    causeTree: [],
    fiveWhys: [],
    fishbone: [],
    paretoResults: [],
    financialImpacts: [],
    assumptions: [],
    options: [],
    scoringCriteria: [],
    optionScores: [],
    decision: null,
    actionPlan: [],
    lessonsLearned: null,
    beforeAfterMetrics: [],
    history: [{ date: new Date().toISOString().slice(0, 10), status: 'New' }],
  };
}
