import { FishboneCause } from './types';

/** A small library mapping common cause keywords to plausible solution
 * directions. This only ever suggests solutions for causes the user has
 * actually logged — it never generates a solution unrelated to a stated
 * cause (Section 20's explicit requirement). */
const CAUSE_TO_SOLUTIONS: { keywords: string[]; solutions: string[] }[] = [
  { keywords: ['supplier', 'input cost', 'raw material', 'procurement'], solutions: ['Supplier negotiation', 'Qualify an alternative supplier', 'Product redesign to reduce input dependency', 'Hedge input cost where feasible'] },
  { keywords: ['price', 'pricing', 'discount'], solutions: ['Price optimization', 'Value-based re-pricing', 'Bundle/unbundle offerings', 'Promotional strategy review'] },
  { keywords: ['churn', 'customer', 'complaint', 'satisfaction'], solutions: ['Customer success outreach program', 'Root-cause fix for the reported failure', 'Loyalty/retention offer', 'Support quality improvement'] },
  { keywords: ['inventory', 'stock'], solutions: ['Inventory optimization / safety stock review', 'Demand forecasting improvement', 'SKU rationalization'] },
  { keywords: ['receivable', 'collection', 'dso'], solutions: ['Tighten credit terms', 'Collections process improvement', 'Early payment incentive'] },
  { keywords: ['process', 'efficiency', 'productivity', 'waste'], solutions: ['Process redesign', 'Waste reduction initiative', 'Automation of the affected step'] },
  { keywords: ['labor', 'staffing', 'people', 'training'], solutions: ['Staffing level review', 'Training program', 'Incentive redesign'] },
  { keywords: ['technology', 'system', 'software', 'downtime'], solutions: ['System upgrade', 'Redundancy/failover investment', 'Vendor support escalation'] },
  { keywords: ['mix', 'product mix', 'channel'], solutions: ['Product mix rebalancing', 'Channel strategy review'] },
];

export function generateSolutionSuggestions(causes: FishboneCause[]): { cause: string; suggestions: string[] }[] {
  const confirmedOrPotential = causes.filter((c) => c.status !== 'Ruled Out');
  return confirmedOrPotential.map((cause) => {
    const lower = `${cause.cause} ${cause.evidence}`.toLowerCase();
    const matched = CAUSE_TO_SOLUTIONS.filter((entry) => entry.keywords.some((k) => lower.includes(k)));
    const suggestions = Array.from(new Set(matched.flatMap((m) => m.solutions)));
    return { cause: cause.cause, suggestions };
  });
}
