import { Dispatch, SetStateAction } from 'react';

export type NavKey =
  | 'dashboard'
  | 'analytics'
  | 'finance'
  | 'risk'
  | 'problemSolver'
  | 'forecast'
  | 'scenario'
  | 'reports'
  | 'learning'
  | 'settings';

interface NavItem {
  key: NavKey;
  label: string;
  ready: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { key: 'dashboard', label: 'Dashboard', ready: true },
  { key: 'analytics', label: 'Analytics', ready: true },
  { key: 'finance', label: 'Finance', ready: true },
  { key: 'risk', label: 'Risk', ready: true },
  { key: 'problemSolver', label: 'Problem solver', ready: true },
  { key: 'forecast', label: 'Forecasting', ready: true },
  { key: 'scenario', label: 'Scenario', ready: true },
  { key: 'reports', label: 'Reports', ready: false },
  { key: 'learning', label: 'Learning', ready: false },
  { key: 'settings', label: 'Settings', ready: false },
];

export function Sidebar({
  active,
  onSelect,
  open,
  onClose,
}: {
  active: NavKey;
  onSelect: Dispatch<SetStateAction<NavKey>>;
  open: boolean;
  onClose: () => void;
}) {
  return (
    <>
      {open && (
        <button
          aria-label="Close navigation"
          onClick={onClose}
          className="fixed inset-0 z-30 bg-ink/20 md:hidden"
        />
      )}
      <nav
        aria-label="Primary"
        className={`fixed z-40 flex h-full w-64 flex-col border-r border-line bg-surface px-4 py-6 transition-transform md:sticky md:top-0 md:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="mb-8 px-2">
          <p className="font-serif text-xl text-ink">Ledger</p>
          <p className="text-xs text-ink-faint">Personal BI platform · V1</p>
        </div>
        <ul className="flex flex-1 flex-col gap-1">
          {NAV_ITEMS.map((item) => (
            <li key={item.key}>
              <button
                onClick={() => {
                  onSelect(item.key);
                  onClose();
                }}
                className={`flex w-full items-center justify-between rounded px-3 py-2 text-left text-sm transition-colors ${
                  active === item.key
                    ? 'bg-emerald-soft text-emerald'
                    : 'text-ink-soft hover:bg-base'
                }`}
              >
                <span>{item.label}</span>
                {!item.ready && (
                  <span className="text-[10px] text-ink-faint">soon</span>
                )}
              </button>
            </li>
          ))}
        </ul>
        <p className="px-2 text-xs text-ink-faint">Version 1 · Foundation build</p>
      </nav>
    </>
  );
}
