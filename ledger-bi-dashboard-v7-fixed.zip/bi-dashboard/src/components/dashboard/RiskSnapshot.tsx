import { RiskSnapshot as RiskSnapshotType } from '../../types';
import { SectionHeading } from '../common/StatusStates';

const LEVEL_STYLES: Record<string, string> = {
  low: 'text-emerald',
  moderate: 'text-amber',
  high: 'text-rust',
  critical: 'text-rust',
};

export function RiskSnapshot({ snapshot }: { snapshot: RiskSnapshotType }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <SectionHeading title="Risk snapshot" description="Advanced risk modeling arrives in a future risk module." />
      <div className="mb-4 flex items-baseline gap-3">
        <span className="font-serif text-3xl tabular text-ink">{snapshot.overallScore}</span>
        <span className={`text-sm capitalize ${LEVEL_STYLES[snapshot.overallLevel]}`}>{snapshot.overallLevel} risk</span>
      </div>
      <ul className="space-y-2.5">
        {snapshot.factors.map((f) => (
          <li key={f.id} className="text-sm">
            <div className="flex items-center justify-between">
              <span className="text-ink-soft">{f.label}</span>
              <span className={`tabular ${LEVEL_STYLES[f.level]}`}>{f.score}</span>
            </div>
            <div className="mt-1 h-1 w-full rounded-full bg-line">
              <div
                className={`h-1 rounded-full ${f.level === 'low' ? 'bg-emerald' : f.level === 'moderate' ? 'bg-amber' : 'bg-rust'}`}
                style={{ width: `${f.score}%` }}
              />
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
