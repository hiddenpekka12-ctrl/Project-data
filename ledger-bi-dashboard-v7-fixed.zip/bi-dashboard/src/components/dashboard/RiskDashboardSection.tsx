import { useMemo } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { useFinance } from '../../state/FinanceContext';
import { useRisk } from '../../state/RiskContext';
import { buildFinanceModel } from '../../finance/buildFinanceModel';
import { buildRiskModel } from '../../risk/buildRiskModel';
import { computeKriStatus } from '../../risk/kri';

/**
 * Reads the same buildRiskModel() the Risk Center itself uses — nothing
 * here is recalculated independently. Shown on both the demo and
 * user-dataset dashboard paths since the Risk Register is global, not
 * tied to whichever dataset happens to be active.
 */
export function RiskDashboardSection() {
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const { registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings } = useRisk();

  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);
  const revenueColumn = useMemo(() => Object.entries(mapping).find(([, cat]) => cat === 'revenue')?.[0] ?? null, [mapping]);
  const categoricalColumns = useMemo(
    () => activeDataset.columns.filter((c) => (activeDataset.columnTypes as Record<string, string>)[c] === 'categorical'),
    [activeDataset.columns, activeDataset.columnTypes]
  );

  const riskModel = useMemo(
    () => buildRiskModel(registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings, financeModel.periods, activeDataset.cleanedRows, categoricalColumns, revenueColumn),
    [registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings, financeModel.periods, activeDataset.cleanedRows, categoricalColumns, revenueColumn]
  );

  if (registerItems.length === 0 && kris.length === 0 && riskModel.financialSignals.length === 0) {
    return (
      <section>
        <p className="mb-2 text-xs uppercase tracking-wide text-ink-faint">From the Risk Engine (V4)</p>
        <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">
          No risk data loaded yet. Visit the Risk Center to load demo risk data or build out the register.
        </p>
      </section>
    );
  }

  const topRisk = [...riskModel.scoredRisks].sort((a, b) => b.residualScore - a.residualScore)[0] ?? null;
  const kriAlerts = kris.filter((k) => {
    const status = computeKriStatus(k);
    return status === 'Warning' || status === 'Critical';
  }).length;
  const financialRiskStatus = riskModel.financialSignals.length === 0 ? 'No active signals' : `${riskModel.financialSignals.length} active signal(s)`;

  return (
    <section>
      <p className="mb-2 text-xs uppercase tracking-wide text-ink-faint">From the Risk Engine (V4)</p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Metric label="Overall Risk Score" value={String(riskModel.overview.overallScore)} note="Average residual score, open risks" />
        <Metric label="Critical Risks" value={String(riskModel.overview.criticalRisks)} note={`${riskModel.overview.veryHighRisks} very high`} />
        <Metric label="Top Risk" value={topRisk?.risk.name ?? null} note={topRisk ? `Residual score ${topRisk.residualScore}` : 'No risks in the register'} />
        <Metric label="Risk Appetite Status" value={String(riskModel.overview.risksAboveAppetite)} note="Risks above appetite" />
        <Metric label="Financial Risk Status" value={financialRiskStatus} note="From the Finance Engine" />
        <Metric label="KRI Alerts" value={String(kriAlerts)} note="Warning or Critical status" />
        <Metric label="Overdue Mitigation Actions" value={String(riskModel.overview.overdueMitigationActions)} note="Past due date" />
        <Metric label="Risk Trend" value={`${riskModel.overview.risksIncreasing} ↑ / ${riskModel.overview.risksDecreasing} ↓`} note="Increasing vs decreasing" />
      </div>
    </section>
  );
}

function Metric({ label, value, note }: { label: string; value: string | null; note: string }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-xs text-ink-faint">{label}</p>
      {value ? <p className="mt-1.5 font-serif text-lg tabular text-ink">{value}</p> : <p className="mt-1.5 text-sm text-ink-faint">Not available</p>}
      <p className="mt-2 text-xs text-ink-faint">{note}</p>
    </div>
  );
}
