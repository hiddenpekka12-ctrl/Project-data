import { AlertItem } from '../../types';
import { SectionHeading } from '../common/StatusStates';

const SEVERITY_STYLES: Record<AlertItem['severity'], string> = {
  critical: 'border-rust bg-rust-soft text-rust',
  warning: 'border-amber bg-amber-soft text-amber',
  info: 'border-slateblue bg-slateblue-soft text-slateblue',
  positive: 'border-emerald bg-emerald-soft text-emerald',
};

export function AlertCenter({ alerts }: { alerts: AlertItem[] }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <SectionHeading title="Alert center" />
      {alerts.length === 0 ? (
        <p className="text-sm text-ink-faint">No alerts right now.</p>
      ) : (
        <ul className="space-y-2">
          {alerts.map((alert) => (
            <li key={alert.id} className={`rounded border-l-2 px-3 py-2 text-sm ${SEVERITY_STYLES[alert.severity]}`}>
              {alert.message}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
