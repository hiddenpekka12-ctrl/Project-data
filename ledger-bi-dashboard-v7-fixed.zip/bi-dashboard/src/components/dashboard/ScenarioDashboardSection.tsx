import { useMemo } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { useFinance } from '../../state/FinanceContext';
import { buildFinanceModel } from '../../finance/buildFinanceModel';
import { propagateScenario } from '../../scenario/driverModel';
import { NEUTRAL_DRIVERS } from '../../scenario/types';
import { buildTornadoRanking } from '../../scenario/sensitivity';
import { detectThresholdBreaches, DEFAULT_DECISION_THRESHOLDS } from '../../scenario/thresholds';
import { formatCurrency } from '../../lib/format';

const DOWNSIDE_DRIVERS = { ...NEUTRAL_DRIVERS, revenueGrowthPct: -10, cogsChangePct: 5 };
const STRESS_DRIVERS = { ...NEUTRAL_DRIVERS, revenueGrowthPct: -25, cogsChangePct: 12, dsoChangeDays: 15 };

/**
 * Reads propagateScenario() — the same function the Scenario Center
 * itself uses — nothing here is recalculated independently. Kept
 * concise per Section 56's explicit "do not overload the dashboard"
 * instruction: 8 headline figures, drill-down lives in Scenario Center.
 */
export function ScenarioDashboardSection() {
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);
  const base = financeModel.periods[financeModel.periods.length - 1] ?? null;

  if (!base) {
    return (
      <section>
        <p className="mb-2 text-xs uppercase tracking-wide text-ink-faint">From the Scenario Engine (V7)</p>
        <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">Map accounts in the Finance Center to see a scenario snapshot here.</p>
      </section>
    );
  }

  const downside = propagateScenario(base, DOWNSIDE_DRIVERS);
  const stress = propagateScenario(base, STRESS_DRIVERS);
  const tornado = buildTornadoRanking(base, ['revenueGrowthPct', 'cogsChangePct', 'opexChangePct', 'interestRateChangePct']);
  const breaches = detectThresholdBreaches(base, stress, DEFAULT_DECISION_THRESHOLDS, null).filter((b) => b.breached);

  return (
    <section>
      <p className="mb-2 text-xs uppercase tracking-wide text-ink-faint">From the Scenario Engine (V7) — SCENARIO, not a forecast</p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Metric label="Base Case (Net Profit)" value={formatCurrency(base.income.netProfit)} />
        <Metric label="Downside (Net Profit)" value={formatCurrency(downside.income.netProfit)} />
        <Metric label="Stress Case (Net Profit)" value={formatCurrency(stress.income.netProfit)} tone={stress.income.netProfit < 0 ? 'rust' : undefined} />
        <Metric label="Cash Under Stress" value={formatCurrency(stress.balanceSheet.cash)} tone={stress.balanceSheet.cash < 0 ? 'rust' : undefined} />
        <Metric label="Profit Under Stress" value={formatCurrency(stress.income.netProfit)} />
        <Metric label="Risk Under Stress" value={breaches.length > 0 ? `${breaches.length} threshold(s) breached` : 'None flagged'} tone={breaches.length > 0 ? 'rust' : undefined} />
        <Metric label="Biggest Sensitivity" value={tornado[0]?.label ?? 'n/a'} />
        <Metric label="Critical Threshold Breach" value={breaches[0]?.metric ?? 'None'} tone={breaches[0] ? 'rust' : undefined} />
      </div>
    </section>
  );
}

function Metric({ label, value, tone }: { label: string; value: string; tone?: 'rust' }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className={`mt-1.5 font-serif text-lg tabular ${tone === 'rust' ? 'text-rust' : 'text-ink'}`}>{value}</p>
    </div>
  );
}
