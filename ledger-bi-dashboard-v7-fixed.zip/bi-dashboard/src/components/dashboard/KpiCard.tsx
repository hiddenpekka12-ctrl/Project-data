import { KpiResult } from '../../types';
import { formatCurrency, formatNumber } from '../../lib/format';

/** Metrics where a downward move is the good outcome (costs, risk). */
const INVERTED_KEYS = new Set(['expenses', 'liabilities', 'riskScore']);

export function KpiCard({ kpi }: { kpi: KpiResult }) {
  const isGood = INVERTED_KEYS.has(kpi.key) ? kpi.direction !== 'up' : kpi.direction === 'up';
  const toneClass =
    kpi.direction === 'flat'
      ? 'text-ink-faint'
      : isGood
      ? 'text-emerald'
      : 'text-rust';

  const formatted =
    kpi.unit === 'currency'
      ? formatCurrency(kpi.value)
      : kpi.unit === 'score'
      ? `${Math.round(kpi.value)}`
      : formatNumber(kpi.value);

  const arrow = kpi.direction === 'up' ? '↑' : kpi.direction === 'down' ? '↓' : '→';

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-xs text-ink-faint">{kpi.label}</p>
      <p className="mt-1.5 font-serif text-2xl tabular text-ink">{formatted}</p>
      <p className={`mt-1 text-xs tabular ${toneClass}`}>
        {arrow} {Math.abs(kpi.percentChange).toFixed(1)}% vs previous period
      </p>
      <p className="mt-2 text-xs leading-snug text-ink-faint">{kpi.explanation}</p>
    </div>
  );
}
