import { Insight } from '../../types';
import { SectionHeading } from '../common/StatusStates';

export function InsightsPanel({ insights }: { insights: Insight[] }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <SectionHeading title="Today's insights" description="Generated from the current period's KPI figures." />
      {insights.length === 0 ? (
        <p className="text-sm text-ink-faint">No insights available for this period yet.</p>
      ) : (
        <ul className="space-y-3">
          {insights.map((insight) => (
            <li key={insight.id} className="border-l-2 border-line pl-3 text-sm text-ink-soft">
              {insight.message}
              <p className="mt-0.5 text-xs text-ink-faint">Based on: {insight.basedOn.join(', ')}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
