import { useMemo } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { useFinance } from '../../state/FinanceContext';
import { useRisk } from '../../state/RiskContext';
import { buildFinanceModel } from '../../finance/buildFinanceModel';
import { buildFinancialForecast } from '../../forecast/financialForecast';
import { buildCashForecast } from '../../forecast/cashFlowForecast';
import { deriveForecastRiskSignals } from '../../forecast/riskIntegration';
import { formatCurrency } from '../../lib/format';

/**
 * Reads buildFinancialForecast() — the same function the Forecasting
 * Center itself uses — nothing here is recalculated independently. Kept
 * concise (Section 49 explicitly asks not to clutter the dashboard):
 * headline numbers only, with a note to drill into the Forecasting
 * Center for the full picture.
 */
export function ForecastDashboardSection() {
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const { kris } = useRisk();

  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);
  const forecast = useMemo(() => buildFinancialForecast(financeModel.periods, 3, 'monthly'), [financeModel.periods]);

  if ('insufficientData' in forecast) {
    return (
      <section>
        <p className="mb-2 text-xs uppercase tracking-wide text-ink-faint">From the Forecasting Engine (V6)</p>
        <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">
          Not enough historical finance data yet for a forecast. Visit the Forecasting Center once at least 3 periods are available.
        </p>
      </section>
    );
  }

  const lastActual = financeModel.periods[financeModel.periods.length - 1];
  const cashLines = buildCashForecast(lastActual.balanceSheet.cash, forecast.lines);
  const signals = deriveForecastRiskSignals(forecast.lines, cashLines, kris);
  const lastLine = forecast.lines[forecast.lines.length - 1];
  const lastCash = cashLines[cashLines.length - 1];
  const negativeCashAhead = cashLines.find((c) => c.closingCash < 0);

  return (
    <section>
      <p className="mb-2 text-xs uppercase tracking-wide text-ink-faint">From the Forecasting Engine (V6) — 3-period FORECAST, not actuals</p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Metric label="Revenue Forecast" value={formatCurrency(lastLine.revenue)} note={`Period +${forecast.lines.length}`} />
        <Metric label="Profit Forecast" value={formatCurrency(lastLine.netProfit)} note="Net profit, same period" />
        <Metric label="Cash Forecast" value={formatCurrency(lastCash.closingCash)} note="Operating activity only" />
        <Metric
          label="Upcoming Financial Pressure"
          value={negativeCashAhead ? `Cash negative by period +${negativeCashAhead.periodLabel}` : 'None flagged'}
          note={negativeCashAhead ? 'See Forecasting Center → Risk Signals' : 'Based on current forecast'}
        />
      </div>
      {signals.length > 0 && (
        <p className="mt-2 text-xs text-amber">
          {signals.length} potential forecast risk signal(s) — see the Forecasting Center for detail. These are projections under stated assumptions, not certainties.
        </p>
      )}
    </section>
  );
}

function Metric({ label, value, note }: { label: string; value: string; note: string }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className="mt-1.5 font-serif text-lg tabular text-ink">{value}</p>
      <p className="mt-2 text-xs text-ink-faint">{note}</p>
    </div>
  );
}
