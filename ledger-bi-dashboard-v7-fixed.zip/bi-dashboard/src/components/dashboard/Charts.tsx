import { ReactNode } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { FinancialPeriod } from '../../types';
import { profit } from '../../lib/calculations';
import { formatCurrency } from '../../lib/format';

const AXIS_COLOR = '#8A968F';
const GRID_COLOR = '#E2E5E1';

function ChartFrame({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="mb-3 text-sm text-ink-soft">{title}</p>
      <div className="h-56">{children}</div>
    </div>
  );
}

export function RevenueVsExpensesChart({ periods }: { periods: FinancialPeriod[] }) {
  const data = periods.map((p) => ({ label: p.label, Revenue: p.revenue, Expenses: p.expenses }));
  return (
    <ChartFrame title="Revenue vs expenses">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={GRID_COLOR} vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: AXIS_COLOR }} axisLine={{ stroke: GRID_COLOR }} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: AXIS_COLOR }} axisLine={false} tickLine={false} tickFormatter={(v) => formatCurrency(v)} width={64} />
          <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ fontSize: 12, borderRadius: 4, borderColor: GRID_COLOR }} />
          <Bar dataKey="Revenue" fill="#1F6F54" radius={[2, 2, 0, 0]} />
          <Bar dataKey="Expenses" fill="#B3452C" radius={[2, 2, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartFrame>
  );
}

export function ProfitTrendChart({ periods }: { periods: FinancialPeriod[] }) {
  const data = periods.map((p) => ({ label: p.label, Profit: profit(p) }));
  return (
    <ChartFrame title="Profit trend">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={GRID_COLOR} vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: AXIS_COLOR }} axisLine={{ stroke: GRID_COLOR }} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: AXIS_COLOR }} axisLine={false} tickLine={false} tickFormatter={(v) => formatCurrency(v)} width={64} />
          <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ fontSize: 12, borderRadius: 4, borderColor: GRID_COLOR }} />
          <Line type="monotone" dataKey="Profit" stroke="#1F6F54" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </ChartFrame>
  );
}

export function CashFlowChart({ periods }: { periods: FinancialPeriod[] }) {
  const data = periods.map((p) => ({ label: p.label, Cash: p.cash }));
  return (
    <ChartFrame title="Cash flow">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
          <defs>
            <linearGradient id="cashFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#4A5B68" stopOpacity={0.25} />
              <stop offset="100%" stopColor="#4A5B68" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke={GRID_COLOR} vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: AXIS_COLOR }} axisLine={{ stroke: GRID_COLOR }} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: AXIS_COLOR }} axisLine={false} tickLine={false} tickFormatter={(v) => formatCurrency(v)} width={64} />
          <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ fontSize: 12, borderRadius: 4, borderColor: GRID_COLOR }} />
          <Area type="monotone" dataKey="Cash" stroke="#4A5B68" strokeWidth={2} fill="url(#cashFill)" />
        </AreaChart>
      </ResponsiveContainer>
    </ChartFrame>
  );
}

export function RiskTrendChart({ history }: { history: { label: string; score: number }[] }) {
  const data = history.map((h) => ({ label: h.label, Risk: h.score }));
  return (
    <ChartFrame title="Risk trend">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={GRID_COLOR} vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: AXIS_COLOR }} axisLine={{ stroke: GRID_COLOR }} tickLine={false} />
          <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: AXIS_COLOR }} axisLine={false} tickLine={false} width={32} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4, borderColor: GRID_COLOR }} />
          <Line type="monotone" dataKey="Risk" stroke="#A9782E" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </ChartFrame>
  );
}
