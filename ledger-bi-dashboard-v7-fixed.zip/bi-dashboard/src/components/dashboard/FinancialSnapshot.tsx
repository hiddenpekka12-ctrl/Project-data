import { FinancialPeriod } from '../../types';
import { profit, profitMargin, workingCapital } from '../../lib/calculations';
import { formatCurrency } from '../../lib/format';
import { SectionHeading } from '../common/StatusStates';

export function FinancialSnapshot({ period }: { period: FinancialPeriod }) {
  const rows: { label: string; value: string }[] = [
    { label: 'Revenue', value: formatCurrency(period.revenue) },
    { label: 'Expenses', value: formatCurrency(period.expenses) },
    { label: 'Profit', value: formatCurrency(profit(period)) },
    { label: 'Profit margin', value: `${profitMargin(period).toFixed(1)}%` },
    { label: 'Cash', value: formatCurrency(period.cash) },
    { label: 'Debt', value: formatCurrency(period.debt) },
    { label: 'Working capital', value: formatCurrency(workingCapital(period)) },
  ];

  return (
    <div className="rounded border border-line bg-surface p-4">
      <SectionHeading title="Financial snapshot" description={`As of ${period.label}. Advanced modeling arrives in a future finance module.`} />
      <dl className="divide-y divide-line">
        {rows.map((row) => (
          <div key={row.label} className="flex items-center justify-between py-2 text-sm">
            <dt className="text-ink-soft">{row.label}</dt>
            <dd className="tabular text-ink">{row.value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
