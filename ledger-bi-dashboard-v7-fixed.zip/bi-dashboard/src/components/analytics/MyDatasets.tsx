import { useMemo, useState } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { profileDataset, computeOverview } from '../../lib/dataProfiling';
import { computeDataQuality } from '../../lib/dataQuality';

export function MyDatasets() {
  const { datasets, activeId, setActiveId, renameDataset, deleteDataset } = useDatasets();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [nameDraft, setNameDraft] = useState('');

  return (
    <div className="overflow-x-auto rounded border border-line bg-surface">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-line text-xs text-ink-faint">
            <th className="px-3 py-2 font-normal">Dataset</th>
            <th className="px-3 py-2 font-normal">Source</th>
            <th className="px-3 py-2 font-normal">Uploaded</th>
            <th className="px-3 py-2 font-normal">Rows</th>
            <th className="px-3 py-2 font-normal">Columns</th>
            <th className="px-3 py-2 font-normal">Status</th>
            <th className="px-3 py-2 font-normal">Actions</th>
          </tr>
        </thead>
        <tbody>
          {datasets.map((d) => (
            <tr key={d.id} className={`border-b border-line/60 last:border-0 ${activeId === d.id ? 'bg-emerald-soft/40' : ''}`}>
              <td className="px-3 py-2">
                {editingId === d.id ? (
                  <input
                    value={nameDraft}
                    onChange={(e) => setNameDraft(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        renameDataset(d.id, nameDraft.trim() || d.name);
                        setEditingId(null);
                      }
                    }}
                    onBlur={() => {
                      renameDataset(d.id, nameDraft.trim() || d.name);
                      setEditingId(null);
                    }}
                    autoFocus
                    className="rounded border border-line bg-base px-2 py-1 text-sm"
                  />
                ) : (
                  <span className="text-ink">{d.name}</span>
                )}
              </td>
              <td className="px-3 py-2">
                <span className={`rounded-sm px-1.5 py-0.5 text-[11px] ${d.source === 'demo' ? 'bg-slateblue-soft text-slateblue' : 'bg-amber-soft text-amber'}`}>
                  {d.source === 'demo' ? 'Demo data' : 'User data'}
                </span>
              </td>
              <td className="px-3 py-2 text-xs text-ink-faint">{new Date(d.uploadedAt).toLocaleDateString()}</td>
              <td className="px-3 py-2 tabular text-ink-soft">{d.rowCount.toLocaleString()}</td>
              <td className="px-3 py-2 tabular text-ink-soft">{d.columns.length}</td>
              <td className="px-3 py-2">
                <QualityBadge datasetId={d.id} />
              </td>
              <td className="px-3 py-2">
                <div className="flex flex-wrap gap-2 text-xs">
                  <button onClick={() => setActiveId(d.id)} className="rounded border border-line px-2 py-1 text-ink-soft hover:border-emerald hover:text-emerald">
                    {activeId === d.id ? 'Active' : 'Open'}
                  </button>
                  {d.source === 'user' && (
                    <>
                      <button
                        onClick={() => {
                          setEditingId(d.id);
                          setNameDraft(d.name);
                        }}
                        className="rounded border border-line px-2 py-1 text-ink-soft hover:bg-base"
                      >
                        Rename
                      </button>
                      <button onClick={() => deleteDataset(d.id)} className="rounded border border-line px-2 py-1 text-ink-soft hover:border-rust hover:text-rust">
                        Delete
                      </button>
                    </>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function QualityBadge({ datasetId }: { datasetId: string }) {
  const { activeDataset, activeId } = useDatasets();
  // Only the active dataset has its rows readily at hand in this simple
  // context shape; other rows aren't loaded until opened. Show a live
  // score for the active row, and a neutral placeholder otherwise.
  const isActive = activeId === datasetId;
  const quality = useMemo(() => {
    if (!isActive) return null;
    const overview = computeOverview(activeDataset.columns, activeDataset.columnTypes, activeDataset.cleanedRows);
    const profiles = profileDataset(activeDataset.columns, activeDataset.columnTypes, activeDataset.cleanedRows);
    return computeDataQuality(overview, profiles, activeDataset.cleanedRows);
  }, [isActive, activeDataset]);

  if (!quality) return <span className="text-xs text-ink-faint">Open to see score</span>;
  return <span className="tabular text-xs text-ink-soft">{quality.score}/100 · {quality.status}</span>;
}
