import { BoxStats } from '../../lib/edaCharting';

export function BoxPlotChart({ stats }: { stats: BoxStats[] }) {
  if (stats.length === 0) return <p className="text-sm text-ink-faint">Not enough data to draw a box plot.</p>;

  const globalMin = Math.min(...stats.map((s) => s.min));
  const globalMax = Math.max(...stats.map((s) => s.max));
  const range = globalMax - globalMin || 1;
  const width = 700;
  const height = 220;
  const padding = 40;
  const plotWidth = width - padding * 2;
  const plotHeight = height - padding * 2;
  const bandWidth = plotWidth / stats.length;

  const scaleY = (v: number) => padding + plotHeight - ((v - globalMin) / range) * plotHeight;

  return (
    <div className="overflow-x-auto">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ minWidth: 480 }}>
        <line x1={padding} y1={padding} x2={padding} y2={height - padding} stroke="#E2E5E1" />
        <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#E2E5E1" />
        {stats.map((s, i) => {
          const cx = padding + bandWidth * i + bandWidth / 2;
          const boxWidth = Math.min(48, bandWidth * 0.5);
          return (
            <g key={s.key}>
              <line x1={cx} y1={scaleY(s.min)} x2={cx} y2={scaleY(s.q1)} stroke="#4A5B68" />
              <line x1={cx} y1={scaleY(s.q3)} x2={cx} y2={scaleY(s.max)} stroke="#4A5B68" />
              <rect
                x={cx - boxWidth / 2}
                y={scaleY(s.q3)}
                width={boxWidth}
                height={Math.max(1, scaleY(s.q1) - scaleY(s.q3))}
                fill="#E9EDEF"
                stroke="#4A5B68"
              />
              <line x1={cx - boxWidth / 2} y1={scaleY(s.median)} x2={cx + boxWidth / 2} y2={scaleY(s.median)} stroke="#1F6F54" strokeWidth={2} />
              <text x={cx} y={height - padding + 16} textAnchor="middle" fontSize="10" fill="#8A968F">
                {s.key.length > 10 ? `${s.key.slice(0, 9)}…` : s.key}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
