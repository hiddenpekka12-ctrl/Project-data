import { AnalyticsInsight, InsightCategory } from '../../types/analytics';

const CATEGORY_META: Record<InsightCategory, { icon: string; label: string }> = {
  descriptive: { icon: '🔵', label: 'Descriptive — what happened' },
  diagnostic: { icon: '🟣', label: 'Diagnostic — why it might have happened' },
  predictive: { icon: '🟢', label: 'Predictive — what might happen' },
  prescriptive: { icon: '🟠', label: 'Prescriptive — what to consider doing' },
};

const CONFIDENCE_STYLES: Record<AnalyticsInsight['confidence'], string> = {
  High: 'text-emerald',
  Medium: 'text-amber',
  Low: 'text-ink-faint',
};

export function AutoInsightsPanel({ insights }: { insights: AnalyticsInsight[] }) {
  if (insights.length === 0) {
    return <p className="text-sm text-ink-faint">Not enough structure in this dataset yet to generate insights — try uploading a dataset with at least one categorical and one numeric column.</p>;
  }

  return (
    <div className="space-y-3">
      {insights.map((insight) => (
        <div key={insight.id} className="rounded border border-line bg-surface p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-ink-faint">
              {CATEGORY_META[insight.category].icon} {CATEGORY_META[insight.category].label}
            </span>
            <span className={`text-xs font-medium ${CONFIDENCE_STYLES[insight.confidence]}`}>Confidence: {insight.confidence}</span>
          </div>
          <p className="mt-2 text-sm text-ink">{insight.finding}</p>
          <p className="mt-1 text-xs text-ink-faint">Supporting data: {insight.supportingData}</p>
          <p className="mt-1 text-xs text-ink-soft">{insight.businessMeaning}</p>
        </div>
      ))}
      <p className="text-xs text-ink-faint">
        V2 focuses on descriptive and diagnostic analytics only. Predictive and prescriptive insights arrive with the forecasting (V6) and scenario (V7) engines.
      </p>
    </div>
  );
}
