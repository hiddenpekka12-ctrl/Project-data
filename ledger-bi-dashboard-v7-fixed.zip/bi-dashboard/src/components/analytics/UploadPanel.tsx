import { useCallback, useRef, useState } from 'react';
import { ImportError, MAX_ROWS, parseCsv, parseJson, parseXlsx } from '../../lib/dataImport';
import { useDatasets } from '../../state/DatasetContext';
import { Dataset } from '../../types/analytics';

interface UploadStatus {
  fileName: string;
  fileSize: string;
  fileType: string;
  rows: number;
  columns: number;
  state: 'success' | 'error' | 'loading';
  message?: string;
  truncated?: boolean;
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function UploadPanel({ onImported }: { onImported: (id: string) => void }) {
  const { addDataset } = useDatasets();
  const [status, setStatus] = useState<UploadStatus | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(
    async (file: File) => {
      const extension = file.name.split('.').pop()?.toLowerCase() ?? '';
      setStatus({
        fileName: file.name,
        fileSize: formatFileSize(file.size),
        fileType: extension.toUpperCase(),
        rows: 0,
        columns: 0,
        state: 'loading',
      });

      try {
        let parsed;
        let fileType: Dataset['fileType'];
        if (extension === 'csv') {
          parsed = parseCsv(await file.text());
          fileType = 'csv';
        } else if (extension === 'xlsx' || extension === 'xls') {
          parsed = parseXlsx(await file.arrayBuffer());
          fileType = 'xlsx';
        } else if (extension === 'json') {
          parsed = parseJson(await file.text());
          fileType = 'json';
        } else {
          throw new ImportError(`".${extension}" files aren't supported. Upload a CSV, XLSX, or JSON file.`);
        }

        if (parsed.rows.length === 0) {
          throw new ImportError('This file does not contain any data rows.');
        }

        const id = addDataset({
          name: file.name.replace(/\.[^.]+$/, ''),
          fileType,
          columns: parsed.columns,
          rows: parsed.rows,
        });

        setStatus({
          fileName: file.name,
          fileSize: formatFileSize(file.size),
          fileType: extension.toUpperCase(),
          rows: parsed.rows.length,
          columns: parsed.columns.length,
          state: 'success',
          truncated: parsed.truncated,
        });
        onImported(id);
      } catch (err) {
        setStatus({
          fileName: file.name,
          fileSize: formatFileSize(file.size),
          fileType: extension.toUpperCase(),
          rows: 0,
          columns: 0,
          state: 'error',
          message: err instanceof ImportError ? err.message : 'Something went wrong reading this file. Try a different file or check its formatting.',
        });
      }
    },
    [addDataset, onImported]
  );

  return (
    <div className="space-y-4">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragActive(true);
        }}
        onDragLeave={() => setDragActive(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragActive(false);
          const file = e.dataTransfer.files?.[0];
          if (file) handleFile(file);
        }}
        className={`flex flex-col items-center justify-center rounded border-2 border-dashed px-6 py-10 text-center transition-colors ${
          dragActive ? 'border-emerald bg-emerald-soft' : 'border-line bg-surface'
        }`}
      >
        <p className="font-serif text-lg text-ink">Drag a file here</p>
        <p className="mt-1 text-sm text-ink-faint">or</p>
        <button
          onClick={() => inputRef.current?.click()}
          className="mt-3 rounded border border-line bg-base px-4 py-2 text-sm text-ink-soft hover:bg-line/40"
        >
          Browse files
        </button>
        <input
          ref={inputRef}
          type="file"
          accept=".csv,.xlsx,.xls,.json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFile(file);
            e.target.value = '';
          }}
        />
        <p className="mt-3 text-xs text-ink-faint">CSV, XLSX, or JSON · processed in your browser, not uploaded anywhere · up to {MAX_ROWS.toLocaleString()} rows</p>
      </div>

      {status && (
        <div
          className={`rounded border px-4 py-3 text-sm ${
            status.state === 'error'
              ? 'border-rust/30 bg-rust-soft text-rust'
              : status.state === 'loading'
              ? 'border-line bg-surface text-ink-soft'
              : 'border-emerald/30 bg-emerald-soft text-emerald'
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="font-medium">{status.fileName}</span>
            <span className="text-xs">{status.fileSize} · {status.fileType}</span>
          </div>
          {status.state === 'loading' && <p className="mt-1">Reading and profiling file…</p>}
          {status.state === 'success' && (
            <p className="mt-1">
              Imported {status.rows.toLocaleString()} rows × {status.columns} columns.
              {status.truncated && ' File was larger than the row limit — extra rows were not loaded.'}
            </p>
          )}
          {status.state === 'error' && <p className="mt-1">{status.message}</p>}
        </div>
      )}
    </div>
  );
}
