import { DatasetOverview } from '../../types/analytics';

export function DatasetOverviewCard({ overview }: { overview: DatasetOverview }) {
  const items: { label: string; value: string | number }[] = [
    { label: 'Rows', value: overview.rows.toLocaleString() },
    { label: 'Columns', value: overview.columns },
    { label: 'Numeric columns', value: overview.numericColumns },
    { label: 'Categorical columns', value: overview.categoricalColumns },
    { label: 'Date columns', value: overview.dateColumns },
    { label: 'Text columns', value: overview.textColumns },
    { label: 'Missing values', value: overview.missingValues.toLocaleString() },
    { label: 'Duplicate rows', value: overview.duplicateRows.toLocaleString() },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {items.map((item) => (
        <div key={item.label} className="rounded border border-line bg-surface p-3">
          <p className="text-xs text-ink-faint">{item.label}</p>
          <p className="mt-1 font-serif text-xl tabular text-ink">{item.value}</p>
        </div>
      ))}
    </div>
  );
}
