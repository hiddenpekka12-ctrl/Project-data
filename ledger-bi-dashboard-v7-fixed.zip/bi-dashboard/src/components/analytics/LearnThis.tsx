import { useState } from 'react';

interface Concept {
  business: string;
  statistical: string;
  formula?: string;
  example: string;
  interpretation: string;
  commonMistake: string;
  mbaExamPoint?: string;
}

export const CONCEPTS: Record<string, Concept> = {
  correlation: {
    business: 'How closely two things move together — e.g. do marketing spend and sales rise and fall together?',
    statistical: 'Pearson\'s r measures the strength and direction of a linear relationship between two numeric variables, from -1 to +1.',
    formula: 'r = Σ((x−x̄)(y−ȳ)) / √(Σ(x−x̄)² · Σ(y−ȳ)²)',
    example: 'Ice cream sales and drowning incidents both rise in summer — they correlate, but neither causes the other. Heat causes both.',
    interpretation: 'Values near 0 mean little linear relationship; near ±1 means a strong one. The sign tells you direction, not strength.',
    commonMistake: 'Assuming correlation proves causation. It never does on its own.',
  },
  dataQualityScore: {
    business: 'A single number summarizing how trustworthy a dataset is before you build decisions on it.',
    statistical: 'A weighted heuristic combining missingness, duplication, and outlier concentration — not a formal statistical test.',
    example: 'A dataset with 20% missing revenue values and many duplicate rows would score lower even if the non-missing values look fine.',
    interpretation: 'Treat the score as a starting checklist, not a certificate. Always read the breakdown behind it.',
    commonMistake: 'Treating the score as objective truth rather than a configurable heuristic.',
  },
  outlier: {
    business: 'A value that stands far apart from the rest — could be a real rare event or a data-entry mistake.',
    statistical: 'IQR method: values below Q1−1.5×IQR or above Q3+1.5×IQR. Z-score method: values more than a set number of standard deviations from the mean.',
    formula: 'IQR bounds = [Q1 − 1.5×IQR, Q3 + 1.5×IQR], where IQR = Q3 − Q1',
    example: 'One month with revenue 5x the usual average could be a huge one-time contract, or a data entry error adding an extra zero.',
    interpretation: 'Always look at the actual row before deciding — an outlier is a flag to investigate, not a verdict.',
    commonMistake: 'Automatically deleting outliers, which can remove your most important real events.',
  },
  meanVsMedian: {
    business: 'Two different ways to describe a "typical" value — they can tell very different stories.',
    statistical: 'Mean is the arithmetic average; median is the middle value when sorted. Median is less sensitive to extreme values.',
    example: 'If 9 employees earn $50k and one earns $2M, the mean salary looks huge, but the median still reflects what most people earn.',
    interpretation: 'When mean and median diverge a lot, the distribution is skewed — check which one better represents your audience\'s question.',
    commonMistake: 'Reporting only the mean for skewed data like income, home prices, or deal sizes.',
  },
  revenueGrowth: {
    business: 'How much revenue increased or decreased compared to a prior period, expressed as a percentage.',
    statistical: 'A simple period-over-period percent change calculation.',
    formula: 'Revenue Growth % = (Current Revenue − Previous Revenue) / Previous Revenue × 100',
    example: 'Revenue of $120k this month vs $100k last month is (120,000 − 100,000) / 100,000 × 100 = 20% growth.',
    interpretation: 'Compare like periods (month vs same month last year, not month vs the month before) when seasonality matters.',
    commonMistake: 'Comparing mismatched period lengths (e.g. a 31-day month vs a 28-day month) without adjusting.',
  },
  roe: {
    business: 'How much profit a company generates for every rupee/dollar its shareholders have invested.',
    statistical: 'Net Profit divided by average shareholder Equity, expressed as a percentage.',
    formula: 'ROE = Net Profit / Average Equity × 100',
    example: 'Net profit of ₹10 lakh on average equity of ₹50 lakh gives an ROE of 20%.',
    interpretation: 'Higher is generally better, but check DuPont analysis first — high ROE from heavy leverage is riskier than high ROE from strong margins.',
    commonMistake: 'Treating high ROE as automatically good without checking whether leverage (debt) is inflating it.',
    mbaExamPoint: 'Always be ready to decompose ROE via DuPont: Net Margin × Asset Turnover × Equity Multiplier.',
  },
  currentRatio: {
    business: 'Whether a company has enough short-term assets to cover its short-term bills.',
    statistical: 'Current Assets divided by Current Liabilities.',
    formula: 'Current Ratio = Current Assets / Current Liabilities',
    example: 'Current assets of ₹10 lakh and current liabilities of ₹5 lakh give a current ratio of 2.0 — ₹2 of current assets for every ₹1 of current liabilities.',
    interpretation: 'Above 1 generally means short-term obligations are covered; well above 2 could also mean idle assets not being put to work.',
    commonMistake: 'Assuming a higher ratio is always better — excess current assets can mean inefficient capital use.',
  },
  debtToEquity: {
    business: 'How much a company relies on borrowed money versus owner funds.',
    statistical: 'Total Liabilities divided by Equity.',
    formula: 'Debt-to-Equity = Total Liabilities / Equity',
    example: 'Total liabilities of ₹80 lakh and equity of ₹40 lakh give a debt-to-equity of 2.0×.',
    interpretation: 'Higher leverage amplifies both gains and losses. What counts as "too high" varies a lot by industry.',
    commonMistake: 'Comparing debt-to-equity across industries without adjusting for typical capital structure norms (e.g. utilities vs. software).',
  },
  ebitda: {
    business: 'A rough proxy for operating cash-generating ability, before financing and accounting decisions get involved.',
    statistical: 'Earnings Before Interest, Tax, Depreciation, and Amortization.',
    formula: 'EBITDA = Gross Profit − Operating Expenses (before D&A, interest, tax)',
    example: 'Gross profit of ₹30 lakh minus operating expenses of ₹18 lakh gives EBITDA of ₹12 lakh.',
    interpretation: 'Useful for comparing operating performance across companies with different debt levels or depreciation policies — but it ignores real cash needs like capex and debt service.',
    commonMistake: 'Treating EBITDA as equivalent to cash flow — it ignores capital expenditure and working capital changes entirely.',
  },
  workingCapital: {
    business: 'The cash tied up in day-to-day operations — inventory and money owed by customers, net of what you owe suppliers.',
    statistical: 'Current Assets minus Current Liabilities.',
    formula: 'Working Capital = Current Assets − Current Liabilities',
    example: 'Current assets of ₹15 lakh and current liabilities of ₹9 lakh give working capital of ₹6 lakh.',
    interpretation: 'Positive working capital generally supports smooth operations; negative isn\'t always bad (some retail/subscription models run on negative working capital deliberately).',
    commonMistake: 'Assuming more working capital is always better — excess ties up cash that could be used elsewhere.',
  },
  breakEven: {
    business: 'The sales volume at which a business stops losing money and starts making a profit.',
    statistical: 'The point where total revenue equals total costs (fixed + variable).',
    formula: 'Break-even Units = Fixed Costs / (Selling Price − Variable Cost per Unit)',
    example: 'Fixed costs of ₹50,000, selling price ₹60/unit, variable cost ₹30/unit → break-even at 1,667 units.',
    interpretation: 'Below break-even, each unit sold reduces losses; above it, each unit adds pure profit (the contribution margin).',
    commonMistake: 'Ignoring that fixed and variable costs can both change at different volume levels (e.g. needing a new factory line).',
  },
  cashConversionCycle: {
    business: 'How many days cash is tied up between paying suppliers and collecting from customers.',
    statistical: 'Days Sales Outstanding + Days Inventory Outstanding − Days Payable Outstanding.',
    formula: 'CCC = DSO + DIO − DPO',
    example: 'DSO of 45 days, DIO of 60 days, DPO of 30 days gives a CCC of 75 days.',
    interpretation: 'A shorter cycle means cash is freed up faster for reinvestment; a lengthening cycle can signal collection or inventory problems even when sales look fine.',
    commonMistake: 'Looking at DSO, DIO, or DPO in isolation instead of the combined cycle they create together.',
  },
  dupont: {
    business: 'Breaks down "why" a company\'s ROE is what it is — profitability, efficiency, or leverage.',
    statistical: 'Decomposes ROE into three multiplicative drivers.',
    formula: 'ROE = Net Margin × Asset Turnover × Equity Multiplier',
    example: 'A retailer with thin margins but fast inventory turnover can reach the same ROE as a software company with fat margins but slow asset use.',
    interpretation: 'Two companies can have identical ROE for very different — and differently risky — reasons.',
    commonMistake: 'Comparing ROE across companies without checking which of the three drivers is doing the work.',
    mbaExamPoint: 'A high equity multiplier means leverage is inflating ROE — flag this as a risk factor, not just a strength, in case analysis.',
  },
  interestCoverage: {
    business: 'How comfortably operating profit covers the interest a company owes on its debt.',
    statistical: 'EBIT divided by Interest Expense.',
    formula: 'Interest Coverage = EBIT / Interest Expense',
    example: 'EBIT of ₹20 lakh and interest expense of ₹4 lakh gives an interest coverage of 5×.',
    interpretation: 'Below roughly 1.5–2× is generally considered thin — a modest earnings dip could jeopardize debt payments.',
    commonMistake: 'Treating zero or undefined interest coverage as automatically safe — it may just mean the company hasn\'t disclosed interest expense.',
  },
  freeCashFlow: {
    business: 'The cash a business generates after covering both operations and the investment needed to sustain/grow them.',
    statistical: 'Operating Cash Flow minus Capital Expenditure.',
    formula: 'Free Cash Flow = Operating Cash Flow − Capital Expenditure',
    example: 'Operating cash flow of ₹15 lakh minus capex of ₹6 lakh gives free cash flow of ₹9 lakh.',
    interpretation: 'Positive and growing FCF gives a business options — debt paydown, dividends, reinvestment — without needing outside capital.',
    commonMistake: 'Confusing Free Cash Flow with Net Profit — a profitable company investing heavily in growth can have negative FCF by design.',
  },
  riskAppetite: {
    business: 'How much risk an organization is willing to accept in pursuit of its objectives.',
    statistical: 'A set of thresholds (tolerance, management attention, escalation) applied to a risk score.',
    example: 'A company might accept risk scores up to 9, want management attention between 10-14, and escalate anything 15+.',
    interpretation: 'Appetite is a management choice, not a calculated fact — two companies can reasonably set different thresholds for the same risk.',
    commonMistake: 'Treating a single appetite threshold as universally correct across every risk category.',
    mbaExamPoint: 'Distinguish risk appetite (how much you\'re willing to take) from risk tolerance (the acceptable variation around that).',
  },
  riskTolerance: {
    business: 'The acceptable range of variation around the risk appetite before action is triggered.',
    statistical: 'Often expressed as a band around the appetite threshold.',
    example: 'Appetite is a risk score of 9; tolerance might allow scores up to 12 before mandatory escalation.',
    interpretation: 'Tolerance gives room for normal fluctuation without triggering a response every time a metric moves slightly.',
    commonMistake: 'Setting tolerance so wide that it never actually triggers management attention.',
  },
  inherentResidualRisk: {
    business: 'Inherent risk is how risky something is with no controls in place; residual risk is what remains after existing controls are applied.',
    statistical: 'Both use the same Probability × Impact formula, just with different probability/impact inputs.',
    example: 'A fire risk might be inherently severe, but sprinklers and alarms (controls) reduce the residual risk substantially.',
    interpretation: 'The gap between inherent and residual risk shows how much existing controls are actually doing.',
    commonMistake: 'Assuming controls eliminate risk entirely rather than reducing it — residual risk is rarely zero.',
    mbaExamPoint: 'If residual risk is set higher than inherent risk in a register, that\'s a data entry error worth flagging, not a real finding.',
  },
  riskMatrix: {
    business: 'A visual tool (usually 5×5) plotting probability against impact so the most urgent risks stand out at a glance.',
    statistical: 'Each cell corresponds to a Probability × Impact score, color-coded into risk bands.',
    example: 'A risk with Probability 4 and Impact 5 sits in the top-right corner, scoring 20 (Critical).',
    interpretation: 'The matrix is a communication tool for prioritization, not a precise measurement — treat scores as ordinal, not literally proportional.',
    commonMistake: 'Comparing risk scores across very different risk types as if they were on a truly continuous, comparable scale.',
  },
  kri: {
    business: 'A measurable metric that gives early warning of increasing risk exposure before it becomes a full-blown problem.',
    statistical: 'A tracked value compared against warning and critical thresholds, with a configurable direction (higher or lower is worse).',
    example: 'Customer concentration at 42% against a 35% warning level and 50% critical level would show a "Warning" status.',
    interpretation: 'KRIs work best when tracked consistently over time — a single reading is much less useful than a trend.',
    commonMistake: 'Assuming every KRI gets worse as it goes up — for metrics like cash balance or interest coverage, lower is worse.',
  },
  controlEffectiveness: {
    business: 'Whether a safeguard against a risk is actually working, not just whether it exists on paper.',
    statistical: 'A qualitative rating (Strong/Adequate/Weak/Unknown/Not Assessed) based on evidence of performance.',
    example: 'A "buffer inventory" control that hasn\'t been reviewed in a year and has no evidence of testing might be rated Weak or Not Assessed rather than assumed Strong.',
    interpretation: 'A documented control with no evidence of testing is not the same as an effective one.',
    commonMistake: 'Assuming a control is effective merely because it exists and was designed well.',
  },
  creditRisk: {
    business: 'The risk that a borrower or counterparty fails to repay what they owe.',
    statistical: 'Often summarized as Expected Loss = Probability of Default × Loss Given Default × Exposure at Default.',
    formula: 'Expected Loss = PD × LGD × EAD',
    example: 'PD of 5%, LGD of 40%, EAD of ₹10,00,000 gives an expected loss of ₹20,000.',
    interpretation: 'Expected Loss is an average across many similar exposures — any single loan either defaults or doesn\'t; this is a portfolio-level planning figure.',
    commonMistake: 'Treating a demo/heuristic PD as if it were a regulator-validated statistical model.',
    mbaExamPoint: 'Be ready to explain PD, LGD, and EAD separately — mixing them up is a common exam error.',
  },
  liquidityRisk: {
    business: 'The risk of not having enough readily available cash or convertible assets to meet short-term obligations.',
    statistical: 'Assessed via ratios like Current Ratio, Quick Ratio, and Cash Ratio, alongside actual cash flow.',
    example: 'A company with strong profits but cash tied up in slow-paying receivables can still face a liquidity crunch.',
    interpretation: 'Liquidity risk is about timing, not solvency — a fundamentally healthy company can still face a liquidity crisis.',
    commonMistake: 'Assuming profitability automatically means adequate liquidity.',
  },
  marketRisk: {
    business: 'The risk of loss from changes in market prices — interest rates, exchange rates, commodity prices, or asset values.',
    statistical: 'Often measured via sensitivity analysis (e.g. how much does profit change per 1% interest rate move).',
    example: 'A company with floating-rate debt faces market risk if interest rates rise, increasing its interest expense.',
    interpretation: 'Market risk applies even to well-run companies — it comes from external forces, not internal mismanagement.',
    commonMistake: 'Ignoring market risk simply because a company has no direct trading or investment activities — currency and rate exposure can still exist through debt and suppliers.',
  },
  operationalRisk: {
    business: 'The risk of loss from failed internal processes, people, systems, or external events.',
    statistical: 'Typically assessed qualitatively (probability × impact) rather than through a single formula, given its breadth.',
    example: 'A key production line going down for a day due to equipment failure is an operational risk event.',
    interpretation: 'Operational risk is broad by nature — the goal is identifying the highest-probability, highest-impact scenarios specific to the business, not cataloguing everything possible.',
    commonMistake: 'Fabricating specific operational incidents rather than acknowledging when no incident data is actually available.',
  },
  concentrationRiskConcept: {
    business: 'The risk of being overly dependent on a single customer, supplier, product, or market.',
    statistical: 'Measured as the share of total revenue/procurement/etc. held by the largest single entity (or top 5).',
    example: '"Customer A represents 72% of revenue" is a concentration finding — whether it\'s dangerous depends on the relationship\'s stability and switching costs.',
    interpretation: 'High concentration isn\'t automatically bad — it can reflect an efficient, deep relationship — but it does mean disproportionate exposure to one relationship weakening.',
    commonMistake: 'Automatically calling any concentration "dangerous" without considering the context or the cost of diversifying.',
  },
  fiveWhys: {
    business: 'A simple technique for digging past a surface symptom to find the underlying driver behind it.',
    statistical: 'Not statistical — a structured questioning technique. Repeatedly ask "why" until you reach an actionable, evidence-backed cause.',
    example: 'A logistics company\'s late deliveries: Why? → Trucks left late. Why? → Loading took too long. Why? → Warehouse layout causes bottlenecks at pickup.',
    interpretation: 'Not forced to exactly five levels — stop once you reach something you can act on with evidence, or continue further if needed.',
    commonMistake: 'Stopping at the first plausible-sounding answer and treating it as confirmed without evidence.',
    mbaExamPoint: 'Distinguish a hypothesis generated by the 5 Whys from a confirmed root cause — they are not the same until evidence backs it.',
  },
  fishboneAnalysis: {
    business: 'A visual way to brainstorm every plausible cause of a problem across different categories (people, process, technology, etc.) before narrowing down.',
    statistical: 'A qualitative categorization tool, not a calculation — though causes can later be tested against data.',
    example: 'A retailer investigating checkout delays might find causes across People (staffing), Process (queue design), and Technology (POS system speed).',
    interpretation: 'The goal is breadth first (don\'t miss a category of cause), then depth (test which ones the data actually supports).',
    commonMistake: 'Treating every brainstormed cause as equally likely without weighing evidence or impact.',
  },
  paretoPrinciple: {
    business: 'The idea that a small share of causes/customers/products often drives a large share of the outcome.',
    statistical: 'Sort contributors by size, then check what share of the total the top ones represent — this is calculated, not assumed.',
    example: 'A telecom operator might find 15% of support ticket categories account for 78% of total tickets — worth checking before assuming a strict "80/20."',
    interpretation: 'The 80/20 split is a common pattern, not a law — some datasets are much more evenly spread, and the tool should say so rather than force the label.',
    commonMistake: 'Calling any skewed distribution "the 80/20 rule" without checking the actual cumulative percentages.',
  },
  meceFramework: {
    business: 'A way of breaking a problem into pieces that don\'t overlap and don\'t leave anything out, so the analysis doesn\'t double-count or miss a driver.',
    statistical: 'MECE = Mutually Exclusive, Collectively Exhaustive — a structuring principle, not a formula.',
    example: 'An e-commerce revenue problem split into "new customers" vs "repeat customers" is MECE; splitting into "new customers" vs "high-value customers" is not, since a customer can be both.',
    interpretation: 'Used to build issue trees so every branch adds up cleanly to the whole, without gaps or double-counting.',
    commonMistake: 'Creating categories that overlap (not mutually exclusive) or that miss an entire driver (not collectively exhaustive).',
  },
  decisionMatrix: {
    business: 'A structured way to compare multiple options against several criteria at once, instead of picking by gut feel.',
    statistical: 'Weighted Score = Σ(Weight × Option Score) — each criterion is weighted by importance, then scores are combined.',
    formula: 'Weighted Score = Σ(Weight × Score)',
    example: 'A manufacturer choosing between three cost-reduction options might weight Financial Impact 30%, Risk 20%, Speed 10%, Strategic Fit 15%, Cost 15%, Complexity 10%.',
    interpretation: 'The ranking is only as good as the weights and scores chosen — always show the full calculation so the logic is visible, not a hidden black box.',
    commonMistake: 'Adjusting weights after seeing the scores in order to make a preferred option win — the weights should be set before scoring, based on what actually matters.',
  },
  timeSeriesForecasting: {
    business: 'Using a metric\'s own history to project what it will likely do next.',
    statistical: 'A sequence of observations ordered by time, analyzed for trend, seasonality, and noise before projecting forward.',
    example: 'A logistics company projecting next quarter\'s shipment volume from the last two years of monthly volumes.',
    interpretation: 'A forecast is a model estimate under stated assumptions, not a guarantee — it should always come with an uncertainty range.',
    commonMistake: 'Treating a forecast as a fact rather than a model output with explicit assumptions and limitations.',
    mbaExamPoint: 'Be ready to name what could invalidate a time-series forecast: a structural break, a regime change, or a pattern that was never really there (overfitting noise).',
  },
  movingAverageForecast: {
    business: 'Smooths out short-term noise by averaging the last few periods, so the underlying level is easier to see and project.',
    statistical: 'Simple Moving Average = average of the last N observations. Weighted Moving Average gives more weight to more recent ones.',
    formula: 'MA(n) = (x₁ + x₂ + ... + xₙ) / n',
    example: 'A retailer averaging the last 3 months of sales to smooth out a single unusually high or low month before projecting next month.',
    interpretation: 'Larger windows smooth more but react slower to genuine changes; smaller windows react faster but stay noisier.',
    commonMistake: 'Picking a window size that happens to fit the historical data well without checking it still performs on validation data.',
  },
  exponentialSmoothingConcept: {
    business: 'A forecasting method that weights recent observations more heavily, with the weight decaying smoothly the further back in time you go.',
    statistical: 'Level = α × (latest actual) + (1 − α) × (previous level), where α (0-1) controls how much weight recent data gets.',
    formula: 'Level(t) = α·x(t) + (1−α)·Level(t−1)',
    example: 'A telecom operator smoothing monthly churn rate — a higher α reacts faster to a recent spike, a lower α stays steadier through noise.',
    interpretation: 'A higher α makes the forecast more reactive to recent changes; a lower α makes it steadier but slower to catch real shifts.',
    commonMistake: 'Picking an α value once and never re-validating it as the underlying pattern changes.',
  },
  regressionForecastConcept: {
    business: 'Projects a metric forward by fitting a straight-line trend through its history over time.',
    statistical: 'Ordinary least-squares regression with time as the independent variable.',
    formula: 'ŷ = intercept + slope × time',
    example: 'A manufacturer projecting steady production-cost inflation based on a consistent upward trend over the last 24 months.',
    interpretation: 'Works well for a clear, consistent trend; poorly for a series with sharp turns, cycles, or seasonality it doesn\'t account for.',
    commonMistake: 'Extrapolating a straight line far beyond the historical range, where real-world limits (market size, capacity) make a straight line increasingly unrealistic.',
  },
  forecastErrorMetrics: {
    business: 'A way of scoring how good a forecasting method actually was, using errors it made on data it didn\'t get to see in advance.',
    statistical: 'MAE (mean absolute error), RMSE (root mean squared error — penalizes large errors more), and MAPE (mean absolute percentage error — undefined when actuals are near zero) are the common ones; sMAPE is a variant that handles small/zero values better.',
    formula: 'MAE = mean(|actual − forecast|); RMSE = √(mean((actual − forecast)²)); MAPE = mean(|actual − forecast| / |actual|) × 100',
    example: 'A retailer comparing two demand-forecast methods: the one with lower RMSE on held-out months is the better performer for that dataset — not necessarily for every dataset.',
    interpretation: 'Lower is better for all of these — but MAPE breaks down when actual values are at or near zero, which is common for things like new-product sales or rare defect counts.',
    commonMistake: 'Using MAPE on a series that includes zero or near-zero actual values without checking whether it produces a nonsensical (very large or undefined) result.',
  },
  backtestingConcept: {
    business: 'Testing a forecasting method by pretending you\'re back at an earlier date and checking whether its forecast matched what actually happened.',
    statistical: 'Chronological, expanding-window validation — never randomly shuffled, since that would let the model "see the future" during training.',
    example: 'An e-commerce company backtests a demand model on the last 12 months, one month at a time, to see how it would have performed in practice.',
    interpretation: 'Backtest performance is the best available evidence for how a forecast method will do going forward — but it\'s still based on the past, and can\'t anticipate a genuine regime change.',
    commonMistake: 'Validating a time-series model with a random train/test split instead of a chronological one — this leaks future information into training and overstates accuracy.',
  },
  forecastIntervalConcept: {
    business: 'A range around a point forecast that reflects how much uncertainty the model actually has, instead of pretending to know an exact number.',
    statistical: 'Built from the spread (e.g. RMSE) of the model\'s own backtest errors — wider historical errors produce a wider interval.',
    example: '"Revenue is projected at ₹52 lakh, with a range of ₹47-57 lakh" is far more honest than "Revenue will be ₹52 lakh."',
    interpretation: 'The interval reflects model uncertainty under stated assumptions — it is not a guarantee that the actual value will fall inside it.',
    commonMistake: 'Reporting only the single point forecast and dropping the interval, which makes the forecast look more certain than it is.',
  },
  overfittingUnderfitting: {
    business: 'Overfitting is a model that memorizes the past too closely and fails on new data; underfitting is a model too simple to capture the real pattern at all.',
    statistical: 'Overfitting: training error much lower than validation error. Underfitting: both training and validation error are large.',
    example: 'A complex model that perfectly matches 24 months of historical revenue but forecasts poorly going forward is overfit; a flat naive forecast on a strongly trending series is underfit.',
    interpretation: 'There\'s a trade-off between simplicity (interpretable, stable) and flexibility (can fit complex patterns, but risks overfitting on limited data).',
    commonMistake: 'Choosing the model with the best-looking historical fit without checking its out-of-sample (validation/backtest) performance.',
    mbaExamPoint: 'If asked to pick a model, always ask for validation performance, not just training fit — a model that "fits perfectly" on history is a red flag, not a strength.',
  },
  scenarioPlanningConcept: {
    business: 'Working through "what would happen if" a key assumption changed, before it actually changes.',
    statistical: 'A driver-based recalculation: change one or more inputs, propagate the effect through the full model, observe the outcome.',
    example: 'A manufacturer models what happens to profit if a key raw material price rises 15% — before it actually does.',
    interpretation: 'A scenario is not a prediction — it\'s a structured "what if," useful regardless of how likely it is to occur.',
    commonMistake: 'Treating a scenario\'s output as a forecast of what will actually happen.',
    mbaExamPoint: 'Always distinguish Scenario ("what if X") from Forecast ("what is likely") from Stress Test ("what if conditions turn severely adverse") — mixing these up is a common exam trap.',
  },
  sensitivityAnalysisConcept: {
    business: 'Finding out which assumptions matter most to an outcome, so management knows where to focus attention and data-gathering effort.',
    statistical: 'One-way: vary a single input, hold others constant. Two-way: vary two inputs together. A tornado chart ranks inputs by the size of their effect.',
    example: 'A retailer might find that sales volume swings profit far more than a 1% change in interest rates — meaning volume deserves more forecasting effort.',
    interpretation: 'The biggest bars in a tornado chart are where getting the assumption right (or monitoring it closely) matters most.',
    commonMistake: 'Spending equal analytical effort on every assumption instead of focusing on the ones sensitivity analysis shows matter most.',
  },
  stressTestingConcept: {
    business: 'Checking how a business would hold up under severe but plausible bad conditions, before those conditions happen.',
    statistical: 'Applies multiple simultaneous adverse shocks (e.g. revenue down + costs up + collections slower) rather than one variable at a time.',
    example: 'A bank stress-tests loan portfolios against a severe recession scenario; a manufacturer can stress-test cash flow against a demand collapse plus a supplier price shock.',
    interpretation: 'Combined stress scenarios are more realistic than single-variable ones — real crises rarely involve just one thing going wrong.',
    commonMistake: 'Treating "passing" a stress test as a guarantee of survival — it only means resilience under the SPECIFIC conditions tested.',
  },
  expectedValueConcept: {
    business: 'A single "weighted average" outcome across multiple possible scenarios, useful when you have genuine probability estimates.',
    statistical: 'Expected Value = Σ(Probability × Outcome), only valid when probabilities are real and sum to 100%.',
    formula: 'EV = Σ(Pᵢ × Outcomeᵢ)',
    example: '50% chance of ₹10L profit, 30% chance of ₹6L, 20% chance of a ₹4L loss gives an EV of ₹6.2L.',
    interpretation: 'EV is useful for repeated decisions or portfolio thinking — for a single high-stakes decision, the downside case often matters more than the average.',
    commonMistake: 'Calculating an expected value from made-up or unstated probabilities, or forgetting that a positive EV doesn\'t rule out a severe downside.',
  },
  resilienceConcept: {
    business: 'How well a business could absorb a shock — cash buffer, low leverage, diversified revenue — without needing a rating agency to tell you.',
    statistical: 'A weighted heuristic score combining cash buffer, liquidity, leverage, margin, cash flow, debt service capacity, and concentration.',
    example: 'A company with 6 months of cash buffer, low debt, and no single customer above 20% of revenue would score well on resilience even with modest profitability.',
    interpretation: 'A heuristic starting point for a resilience conversation, not a regulated rating or a guarantee that the business will survive any given shock.',
    commonMistake: 'Treating a high resilience score as proof a company can survive absolutely anything.',
  },
  tradeOffAnalysisConcept: {
    business: 'Making the "you can\'t have everything" trade-offs in a business decision visible and explicit, instead of leaving them implicit.',
    statistical: 'Not a formula — a structured comparison of what you gain vs. what you give up under different options.',
    example: 'Higher inventory improves service levels but ties up more cash; higher debt funds growth but increases risk and interest cost.',
    interpretation: 'Making trade-offs explicit helps a decision-maker choose deliberately rather than by default.',
    commonMistake: 'Presenting only the upside of a preferred option while leaving its trade-off unstated.',
  },
};

export function LearnThis({ conceptKey, label = 'Learn this' }: { conceptKey: keyof typeof CONCEPTS; label?: string }) {
  const [open, setOpen] = useState(false);
  const concept = CONCEPTS[conceptKey];
  if (!concept) return null;

  return (
    <span className="relative inline-block">
      <button
        onClick={() => setOpen((o) => !o)}
        className="ml-1.5 rounded-full border border-line px-1.5 py-0.5 text-[10px] text-ink-faint hover:border-emerald hover:text-emerald"
        aria-expanded={open}
      >
        {label}
      </button>
      {open && (
        <>
          <button aria-label="Close" onClick={() => setOpen(false)} className="fixed inset-0 z-40 cursor-default" />
          <div className="absolute left-0 top-6 z-50 w-80 rounded border border-line bg-surface p-4 text-left shadow-lg">
            <dl className="space-y-2 text-xs">
              <div>
                <dt className="font-medium text-ink">Business meaning</dt>
                <dd className="text-ink-soft">{concept.business}</dd>
              </div>
              <div>
                <dt className="font-medium text-ink">Statistical concept</dt>
                <dd className="text-ink-soft">{concept.statistical}</dd>
              </div>
              {concept.formula && (
                <div>
                  <dt className="font-medium text-ink">Formula</dt>
                  <dd className="tabular text-ink-soft">{concept.formula}</dd>
                </div>
              )}
              <div>
                <dt className="font-medium text-ink">Example</dt>
                <dd className="text-ink-soft">{concept.example}</dd>
              </div>
              <div>
                <dt className="font-medium text-ink">Managerial interpretation</dt>
                <dd className="text-ink-soft">{concept.interpretation}</dd>
              </div>
              <div>
                <dt className="font-medium text-rust">Common mistake</dt>
                <dd className="text-ink-soft">{concept.commonMistake}</dd>
              </div>
              {concept.mbaExamPoint && (
                <div>
                  <dt className="font-medium text-slateblue">MBA exam point</dt>
                  <dd className="text-ink-soft">{concept.mbaExamPoint}</dd>
                </div>
              )}
            </dl>
          </div>
        </>
      )}
    </span>
  );
}
