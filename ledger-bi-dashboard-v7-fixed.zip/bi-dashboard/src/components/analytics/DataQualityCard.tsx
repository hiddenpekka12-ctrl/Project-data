import { DataQualityResult } from '../../types/analytics';
import { LearnThis } from './LearnThis';

const STATUS_STYLES: Record<DataQualityResult['status'], string> = {
  Excellent: 'text-emerald',
  Good: 'text-emerald',
  Fair: 'text-amber',
  Poor: 'text-rust',
};

export function DataQualityCard({ result }: { result: DataQualityResult }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="flex items-center text-sm text-ink-soft">
        Data quality score
        <LearnThis conceptKey="dataQualityScore" />
      </p>
      <div className="mt-1 flex items-baseline gap-3">
        <span className="font-serif text-3xl tabular text-ink">{result.score}/100</span>
        <span className={`text-sm ${STATUS_STYLES[result.status]}`}>{result.status}</span>
      </div>
      <p className="mt-1 text-xs text-ink-faint">A configurable heuristic, not a statistically authoritative measure.</p>
      <ul className="mt-3 space-y-2">
        {result.breakdown.map((item, i) => (
          <li key={i} className="border-l-2 border-line pl-3 text-sm">
            <div className="flex items-center justify-between text-ink-soft">
              <span>{item.label}</span>
              {item.pointsDeducted > 0 && <span className="tabular text-rust">−{item.pointsDeducted}</span>}
            </div>
            <p className="text-xs text-ink-faint">{item.detail}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
