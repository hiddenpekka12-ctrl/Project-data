import { ColumnProfile } from '../../types/analytics';
import { LearnThis } from './LearnThis';

function NumericCard({ name, p }: { name: string; p: Extract<ColumnProfile, { type: 'numeric' }> }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="flex items-center text-sm font-medium text-ink">
        {name} <span className="ml-2 text-[10px] uppercase text-ink-faint">numeric</span>
        <LearnThis conceptKey="meanVsMedian" label="mean vs median" />
      </p>
      <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs text-ink-soft">
        <Row label="Mean" value={p.mean.toFixed(2)} />
        <Row label="Median" value={p.median.toFixed(2)} />
        <Row label="Min" value={p.min.toFixed(2)} />
        <Row label="Max" value={p.max.toFixed(2)} />
        <Row label="Std dev" value={p.std.toFixed(2)} />
        <Row label="Q1 / Q3" value={`${p.q1.toFixed(1)} / ${p.q3.toFixed(1)}`} />
        <Row label="Unique" value={String(p.unique)} />
        <Row label="Missing" value={`${p.missingPct.toFixed(1)}%`} />
      </dl>
    </div>
  );
}

function CategoricalCard({ name, p }: { name: string; p: Extract<ColumnProfile, { type: 'categorical' }> }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="text-sm font-medium text-ink">
        {name} <span className="ml-2 text-[10px] uppercase text-ink-faint">categorical</span>
      </p>
      <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs text-ink-soft">
        <Row label="Unique values" value={String(p.unique)} />
        <Row label="Most common" value={`${p.mostCommon} (${p.mostCommonCount})`} />
        <Row label="Missing" value={`${p.missingPct.toFixed(1)}%`} />
      </dl>
      <div className="mt-2 flex flex-wrap gap-1">
        {p.topValues.map((v) => (
          <span key={v.value} className="rounded-sm bg-base px-1.5 py-0.5 text-[11px] text-ink-faint">
            {v.value} · {v.count}
          </span>
        ))}
      </div>
    </div>
  );
}

function DateCard({ name, p }: { name: string; p: Extract<ColumnProfile, { type: 'date' }> }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="text-sm font-medium text-ink">
        {name} <span className="ml-2 text-[10px] uppercase text-ink-faint">date</span>
      </p>
      <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs text-ink-soft">
        <Row label="Min date" value={p.min} />
        <Row label="Max date" value={p.max} />
        <Row label="Range" value={`${p.rangeDays} days`} />
        <Row label="Missing" value={`${p.missingPct.toFixed(1)}%`} />
      </dl>
    </div>
  );
}

function TextCard({ name, p }: { name: string; p: Extract<ColumnProfile, { type: 'text' }> }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="text-sm font-medium text-ink">
        {name} <span className="ml-2 text-[10px] uppercase text-ink-faint">text</span>
      </p>
      <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs text-ink-soft">
        <Row label="Unique" value={String(p.unique)} />
        <Row label="Missing" value={`${p.missingPct.toFixed(1)}%`} />
      </dl>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <>
      <dt className="text-ink-faint">{label}</dt>
      <dd className="tabular text-right">{value}</dd>
    </>
  );
}

export function ProfilingPanel({ profiles }: { profiles: Record<string, ColumnProfile> }) {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {Object.entries(profiles).map(([name, p]) => {
        if (p.type === 'numeric') return <NumericCard key={name} name={name} p={p} />;
        if (p.type === 'categorical') return <CategoricalCard key={name} name={name} p={p} />;
        if (p.type === 'date') return <DateCard key={name} name={name} p={p} />;
        return <TextCard key={name} name={name} p={p} />;
      })}
    </div>
  );
}
