import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { useDatasets } from '../../state/DatasetContext';
import { profileDataset, computeOverview } from '../../lib/dataProfiling';
import { computeDataQuality } from '../../lib/dataQuality';
import { generateAutoInsights } from '../../lib/autoEda';

function downloadBlob(content: BlobPart, filename: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function ExportButtons() {
  const { activeDataset } = useDatasets();

  const exportCsv = () => {
    const csv = Papa.unparse(activeDataset.cleanedRows);
    downloadBlob(csv, `${activeDataset.name}-cleaned.csv`, 'text/csv');
  };

  const exportXlsx = () => {
    const sheet = XLSX.utils.json_to_sheet(activeDataset.cleanedRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, 'Cleaned data');
    const buffer = XLSX.write(workbook, { type: 'array', bookType: 'xlsx' });
    downloadBlob(buffer, `${activeDataset.name}-cleaned.xlsx`, 'application/octet-stream');
  };

  const exportSummary = () => {
    const overview = computeOverview(activeDataset.columns, activeDataset.columnTypes, activeDataset.cleanedRows);
    const profiles = profileDataset(activeDataset.columns, activeDataset.columnTypes, activeDataset.cleanedRows);
    const quality = computeDataQuality(overview, profiles, activeDataset.cleanedRows);
    const insights = generateAutoInsights(activeDataset.cleanedRows, activeDataset.columnTypes, profiles);

    const lines = [
      `# Analysis summary — ${activeDataset.name}`,
      '',
      `Generated ${new Date().toLocaleString()}`,
      '',
      '## Overview',
      `Rows: ${overview.rows} · Columns: ${overview.columns} · Missing values: ${overview.missingValues} · Duplicate rows: ${overview.duplicateRows}`,
      '',
      `## Data quality: ${quality.score}/100 (${quality.status})`,
      ...quality.breakdown.map((b) => `- ${b.label}: ${b.detail}`),
      '',
      `## Cleaning operations applied (${activeDataset.cleaningLog.length})`,
      ...activeDataset.cleaningLog.map((l) => `- ${l.operation}${l.column ? ` on ${l.column}` : ''} — ${l.affectedRows} row(s) affected`),
      '',
      '## Key insights',
      ...insights.map((i) => `- [${i.category}] ${i.finding} (confidence: ${i.confidence})`),
    ];

    downloadBlob(lines.join('\n'), `${activeDataset.name}-analysis-summary.md`, 'text/markdown');
  };

  return (
    <div className="flex flex-wrap gap-2">
      <button onClick={exportCsv} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
        Export cleaned CSV
      </button>
      <button onClick={exportXlsx} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
        Export cleaned Excel
      </button>
      <button onClick={exportSummary} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
        Export analysis summary
      </button>
    </div>
  );
}
