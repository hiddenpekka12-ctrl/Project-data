import { useState } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { answerBusinessQuestion } from '../../lib/businessQuestions';
import { BusinessQuestionAnswer } from '../../types/analytics';

const EXAMPLES = [
  'Which category generates the highest value?',
  'Which category is performing poorly?',
  'What is the monthly trend?',
  'Which category has the highest average value?',
];

export function BusinessQuestionBox() {
  const { activeDataset } = useDatasets();
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<BusinessQuestionAnswer | null>(null);

  const ask = (q: string) => {
    setQuestion(q);
    setAnswer(answerBusinessQuestion(q, activeDataset.cleanedRows, activeDataset.columnTypes));
  };

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-sm font-medium text-ink">Ask a business question</p>
      <div className="mt-2 flex gap-2">
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && ask(question)}
          placeholder="e.g. Which category generates the highest value?"
          className="flex-1 rounded border border-line bg-base px-3 py-2 text-sm text-ink outline-none focus:border-emerald"
        />
        <button onClick={() => ask(question)} className="rounded border border-line bg-base px-4 py-2 text-sm text-ink-soft hover:bg-line/40">
          Ask
        </button>
      </div>
      <div className="mt-2 flex flex-wrap gap-2">
        {EXAMPLES.map((ex) => (
          <button key={ex} onClick={() => ask(ex)} className="rounded-full border border-line px-2.5 py-1 text-xs text-ink-faint hover:text-ink-soft">
            {ex}
          </button>
        ))}
      </div>

      {answer && (
        <div className="mt-3 rounded border border-line bg-base p-3 text-sm">
          {answer.answered ? (
            <>
              <p className="text-ink">{answer.answer}</p>
              {answer.supporting && <p className="mt-1 text-xs text-ink-faint">Based on: {answer.supporting}</p>}
            </>
          ) : (
            <p className="text-ink-soft">{answer.missingRequirement}</p>
          )}
        </div>
      )}
    </div>
  );
}
