import { ReactNode, useMemo, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useDatasets } from '../../state/DatasetContext';
import { ChartType, EdaSelection, Row } from '../../types/analytics';
import {
  aggregateByDate,
  aggregateCategorical,
  aggregateGrouped,
  boxPlotStats,
  histogramBins,
  recommendChartTypes,
  scatterPoints,
} from '../../lib/edaCharting';
import { BoxPlotChart } from './BoxPlotChart';

const PIE_COLORS = ['#1F6F54', '#4A5B68', '#A9782E', '#B3452C', '#8A968F', '#2F9E7A', '#6B7F8C', '#C99A57'];
const CHART_LABELS: Record<ChartType, string> = {
  bar: 'Bar chart',
  line: 'Line chart',
  area: 'Area chart',
  histogram: 'Histogram',
  scatter: 'Scatter plot',
  pie: 'Pie / donut',
  box: 'Box plot',
};

function toNumber(v: unknown): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return null;
}

function applyFilter(rows: Row[], filterCol: string | null, filterValue: string): Row[] {
  if (!filterCol || !filterValue) return rows;
  return rows.filter((r) => String(r[filterCol] ?? '') === filterValue);
}

export function EdaWorkspace() {
  const { activeDataset } = useDatasets();
  const { columns, columnTypes, cleanedRows } = activeDataset;

  const categoricalCols = columns.filter((c) => columnTypes[c] === 'categorical');
  const numericCols = columns.filter((c) => columnTypes[c] === 'numeric');
  const dateCols = columns.filter((c) => columnTypes[c] === 'date');

  const [selection, setSelection] = useState<EdaSelection>({
    xColumn: dateCols[0] ?? categoricalCols[0] ?? numericCols[0] ?? null,
    yColumn: numericCols[0] ?? null,
    groupBy: null,
    chartType: 'bar',
  });
  const [filterCol, setFilterCol] = useState<string | null>(null);
  const [filterValue, setFilterValue] = useState<string>('');

  const xType = selection.xColumn ? columnTypes[selection.xColumn] : null;
  const yType = selection.yColumn ? columnTypes[selection.yColumn] : null;
  const xUnique = selection.xColumn ? new Set(cleanedRows.map((r) => r[selection.xColumn!])).size : null;
  const recommended = recommendChartTypes(xType ?? null, yType ?? null, xUnique);

  const filteredRows = useMemo(() => applyFilter(cleanedRows, filterCol, filterValue), [cleanedRows, filterCol, filterValue]);

  const filterOptions = filterCol ? Array.from(new Set(cleanedRows.map((r) => String(r[filterCol] ?? '')))).filter(Boolean).slice(0, 50) : [];

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <Field label="X-axis">
            <select
              value={selection.xColumn ?? ''}
              onChange={(e) => setSelection((s) => ({ ...s, xColumn: e.target.value || null }))}
              className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm text-ink-soft"
            >
              <option value="">Select…</option>
              {columns.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Y-axis">
            <select
              value={selection.yColumn ?? ''}
              onChange={(e) => setSelection((s) => ({ ...s, yColumn: e.target.value || null }))}
              className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm text-ink-soft"
            >
              <option value="">None (count only)</option>
              {numericCols.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Group by (optional)">
            <select
              value={selection.groupBy ?? ''}
              onChange={(e) => setSelection((s) => ({ ...s, groupBy: e.target.value || null }))}
              className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm text-ink-soft"
            >
              <option value="">None</option>
              {categoricalCols
                .filter((c) => c !== selection.xColumn)
                .map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
            </select>
          </Field>
          <Field label="Filter column">
            <select
              value={filterCol ?? ''}
              onChange={(e) => {
                setFilterCol(e.target.value || null);
                setFilterValue('');
              }}
              className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm text-ink-soft"
            >
              <option value="">None</option>
              {categoricalCols.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Filter value">
            <select
              value={filterValue}
              onChange={(e) => setFilterValue(e.target.value)}
              disabled={!filterCol}
              className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm text-ink-soft disabled:opacity-40"
            >
              <option value="">All</option>
              {filterOptions.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </Field>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="text-xs text-ink-faint">Chart type:</span>
          {(['bar', 'line', 'area', 'histogram', 'scatter', 'pie', 'box'] as ChartType[]).map((t) => (
            <button
              key={t}
              onClick={() => setSelection((s) => ({ ...s, chartType: t }))}
              className={`rounded border px-2.5 py-1 text-xs ${
                selection.chartType === t
                  ? 'border-emerald bg-emerald-soft text-emerald'
                  : 'border-line text-ink-faint hover:text-ink-soft'
              }`}
            >
              {CHART_LABELS[t]}
              {recommended[0] === t && <span className="ml-1">★</span>}
            </button>
          ))}
        </div>
        {recommended.length > 0 && (
          <p className="mt-1 text-xs text-ink-faint">★ recommended for the columns selected — recharts don't force a fit that doesn't make sense.</p>
        )}
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <ChartRenderer selection={selection} rows={filteredRows} />
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      {children}
    </label>
  );
}

function ChartRenderer({ selection, rows }: { selection: EdaSelection; rows: Row[] }) {
  const { xColumn, yColumn, groupBy, chartType } = selection;

  if (!xColumn) return <p className="text-sm text-ink-faint">Choose an X-axis column to build a chart.</p>;

  if (chartType === 'histogram') {
    const col = yColumn ?? xColumn;
    const values = rows.map((r) => toNumber(r[col])).filter((v): v is number => v !== null);
    if (values.length === 0) return <p className="text-sm text-ink-faint">{col} has no numeric values to bin.</p>;
    const bins = histogramBins(values);
    return (
      <ResponsiveContainer width="100%" height={280}>
        <BarChart data={bins}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
          <XAxis dataKey="bin" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
          <Bar dataKey="count" fill="#1F6F54" radius={[2, 2, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    );
  }

  if (!yColumn) return <p className="text-sm text-ink-faint">Choose a Y-axis column for this chart type.</p>;

  if (chartType === 'scatter') {
    const points = scatterPoints(rows, xColumn, yColumn);
    if (points.length === 0) return <p className="text-sm text-ink-faint">No numeric pairs found for {xColumn} and {yColumn}.</p>;
    return (
      <ResponsiveContainer width="100%" height={280}>
        <ScatterChart>
          <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" />
          <XAxis dataKey="x" name={xColumn} tick={{ fontSize: 11, fill: '#8A968F' }} />
          <YAxis dataKey="y" name={yColumn} tick={{ fontSize: 11, fill: '#8A968F' }} />
          <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ fontSize: 12, borderRadius: 4 }} />
          <Scatter data={points} fill="#4A5B68" />
        </ScatterChart>
      </ResponsiveContainer>
    );
  }

  if (chartType === 'box') {
    const stats = boxPlotStats(rows, xColumn, yColumn);
    return <BoxPlotChart stats={stats} />;
  }

  if (chartType === 'pie') {
    const data = aggregateCategorical(rows, xColumn, yColumn).slice(0, 8);
    if (data.length === 0) return <p className="text-sm text-ink-faint">No data to chart.</p>;
    return (
      <ResponsiveContainer width="100%" height={280}>
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="key" outerRadius={90} innerRadius={50}>
            {data.map((_, i) => (
              <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
            ))}
          </Pie>
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
        </PieChart>
      </ResponsiveContainer>
    );
  }

  // bar / line / area, with optional group-by as multi-series
  if (groupBy) {
    const { data, groupKeys } = aggregateGrouped(rows, xColumn, yColumn, groupBy);
    if (data.length === 0) return <p className="text-sm text-ink-faint">No data to chart for this combination.</p>;
    if (chartType === 'area') {
      return (
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
            <XAxis dataKey="key" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
            {groupKeys.map((g, i) => (
              <Area key={g} type="monotone" dataKey={g} stroke={PIE_COLORS[i % PIE_COLORS.length]} fill={PIE_COLORS[i % PIE_COLORS.length]} fillOpacity={0.2} />
            ))}
          </AreaChart>
        </ResponsiveContainer>
      );
    }
    const ChartComponent = chartType === 'line' ? LineChart : BarChart;
    return (
      <ResponsiveContainer width="100%" height={300}>
        <ChartComponent data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
          <XAxis dataKey="key" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
          {groupKeys.map((g, i) =>
            chartType === 'line' ? (
              <Line key={g} type="monotone" dataKey={g} stroke={PIE_COLORS[i % PIE_COLORS.length]} dot={false} strokeWidth={2} />
            ) : (
              <Bar key={g} dataKey={g} fill={PIE_COLORS[i % PIE_COLORS.length]} radius={[2, 2, 0, 0]} />
            )
          )}
        </ChartComponent>
      </ResponsiveContainer>
    );
  }

  const data = xColumn && columnsAreDate(rows, xColumn) ? aggregateByDate(rows, xColumn, yColumn) : aggregateCategorical(rows, xColumn, yColumn);
  if (data.length === 0) return <p className="text-sm text-ink-faint">No data to chart for this combination.</p>;

  if (chartType === 'area') {
    return (
      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
          <XAxis dataKey="key" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
          <Area type="monotone" dataKey="value" stroke="#4A5B68" fill="#4A5B68" fillOpacity={0.2} />
        </AreaChart>
      </ResponsiveContainer>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      {chartType === 'line' ? (
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
          <XAxis dataKey="key" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
          <Line type="monotone" dataKey="value" stroke="#1F6F54" strokeWidth={2} dot={false} />
        </LineChart>
      ) : (
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
          <XAxis dataKey="key" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
          <Bar dataKey="value" fill="#1F6F54" radius={[2, 2, 0, 0]} />
        </BarChart>
      )}
    </ResponsiveContainer>
  );
}

function columnsAreDate(rows: Row[], col: string): boolean {
  const sample = rows.find((r) => r[col] !== null && r[col] !== '');
  if (!sample) return false;
  return !isNaN(Date.parse(String(sample[col])));
}
