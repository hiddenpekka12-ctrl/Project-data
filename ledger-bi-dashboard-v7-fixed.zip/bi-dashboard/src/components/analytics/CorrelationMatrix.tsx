import { CorrelationCell } from '../../types/analytics';
import { LearnThis } from './LearnThis';

function cellColor(cell: CorrelationCell): string {
  if (cell.strength === 'weak') return 'bg-base text-ink-faint';
  const intensity = cell.strength === 'strong' ? '600' : '400';
  return cell.direction === 'positive' ? `bg-emerald-soft text-emerald` : `bg-rust-soft text-rust`;
}

export function CorrelationMatrix({ cells, columns }: { cells: CorrelationCell[]; columns: string[] }) {
  if (columns.length < 2) {
    return <p className="text-sm text-ink-faint">Need at least two numeric columns to compute correlations.</p>;
  }

  const lookup = new Map<string, CorrelationCell>();
  cells.forEach((c) => {
    lookup.set(`${c.columnA}|${c.columnB}`, c);
    lookup.set(`${c.columnB}|${c.columnA}`, c);
  });

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="flex items-center text-sm font-medium text-ink">
        Correlation matrix
        <LearnThis conceptKey="correlation" />
      </p>
      <div className="mt-3 overflow-x-auto">
        <table className="text-xs">
          <thead>
            <tr>
              <th className="p-1" />
              {columns.map((c) => (
                <th key={c} className="p-1 text-ink-faint">
                  {c}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {columns.map((rowCol) => (
              <tr key={rowCol}>
                <th className="p-1 text-right text-ink-faint">{rowCol}</th>
                {columns.map((colCol) => {
                  if (rowCol === colCol) {
                    return (
                      <td key={colCol} className="p-1 text-center tabular text-ink-faint">
                        1.00
                      </td>
                    );
                  }
                  const cell = lookup.get(`${rowCol}|${colCol}`);
                  return (
                    <td key={colCol} className={`p-1 text-center tabular ${cell ? cellColor(cell) : ''}`}>
                      {cell ? cell.r.toFixed(2) : '—'}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 rounded border border-amber/30 bg-amber-soft px-3 py-2 text-xs text-amber">
        Correlation does not establish causation. A strong relationship here is a prompt to investigate further, not a conclusion.
      </p>
    </div>
  );
}
