import { CleaningLogEntry } from '../../types/analytics';

export function CleaningLog({ log }: { log: CleaningLogEntry[] }) {
  if (log.length === 0) {
    return <p className="text-sm text-ink-faint">No cleaning operations applied yet.</p>;
  }

  return (
    <div className="overflow-x-auto rounded border border-line bg-surface">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-line text-xs text-ink-faint">
            <th className="px-3 py-2 font-normal">Date/time</th>
            <th className="px-3 py-2 font-normal">Operation</th>
            <th className="px-3 py-2 font-normal">Column</th>
            <th className="px-3 py-2 font-normal">Rows affected</th>
            <th className="px-3 py-2 font-normal">Before → After</th>
          </tr>
        </thead>
        <tbody>
          {[...log].reverse().map((entry) => (
            <tr key={entry.id} className="border-b border-line/60 last:border-0">
              <td className="whitespace-nowrap px-3 py-2 text-xs text-ink-faint">{new Date(entry.timestamp).toLocaleString()}</td>
              <td className="px-3 py-2 text-ink-soft">{entry.operation}</td>
              <td className="px-3 py-2 text-ink-soft">{entry.column ?? '—'}</td>
              <td className="px-3 py-2 tabular text-ink-soft">{entry.affectedRows}</td>
              <td className="px-3 py-2 text-xs text-ink-faint">
                {entry.before} → {entry.after}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
