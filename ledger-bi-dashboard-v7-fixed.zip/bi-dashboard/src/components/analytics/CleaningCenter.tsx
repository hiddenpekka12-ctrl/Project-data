import { ReactNode, useMemo, useState } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { profileDataset, computeOverview } from '../../lib/dataProfiling';
import {
  convertColumnType,
  fillMissingCategorical,
  fillMissingNumeric,
  removeDuplicateRows,
  removeInvalidRows,
  standardizeTextColumn,
} from '../../lib/dataCleaning';
import { ColumnType } from '../../types/analytics';

export function CleaningCenter() {
  const { activeDataset, applyCleaningStep, resetCleaned } = useDatasets();
  const { id, columns, columnTypes, cleanedRows, cleaningLog } = activeDataset;
  const [convertTargets, setConvertTargets] = useState<Record<string, ColumnType>>({});
  const [standardizeTargets, setStandardizeTargets] = useState<Record<string, string>>({});

  const profiles = useMemo(() => profileDataset(columns, columnTypes, cleanedRows), [columns, columnTypes, cleanedRows]);
  const overview = useMemo(() => computeOverview(columns, columnTypes, cleanedRows), [columns, columnTypes, cleanedRows]);

  const numericCols = columns.filter((c) => columnTypes[c] === 'numeric');
  const categoricalCols = columns.filter((c) => columnTypes[c] === 'categorical' || columnTypes[c] === 'text');
  const columnsWithMissing = columns.filter((c) => (profiles[c]?.missing ?? 0) > 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between rounded border border-line bg-surface p-3 text-sm">
        <p className="text-ink-soft">
          Cleaning applies to a <strong>separate copy</strong> — the original upload is never modified.
          {cleaningLog.length > 0 && ` ${cleaningLog.length} operation(s) applied so far.`}
        </p>
        {cleaningLog.length > 0 && (
          <button onClick={() => resetCleaned(id)} className="rounded border border-line px-3 py-1 text-xs text-ink-soft hover:bg-base">
            Reset to original
          </button>
        )}
      </div>

      {overview.duplicateRows > 0 && (
        <Section title="Duplicate rows">
          <p className="mb-2 text-sm text-ink-soft">{overview.duplicateRows} duplicate row(s) detected across all columns.</p>
          <ActionButton onClick={() => applyCleaningStep(id, removeDuplicateRows(cleanedRows, columns))}>
            Remove duplicates
          </ActionButton>
        </Section>
      )}

      {columnsWithMissing.length > 0 && (
        <Section title="Missing values">
          <div className="space-y-3">
            {columnsWithMissing.map((c) => {
              const isNumeric = columnTypes[c] === 'numeric';
              const missing = profiles[c]?.missing ?? 0;
              return (
                <div key={c} className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 pb-2 last:border-0">
                  <span className="text-sm text-ink-soft">
                    <strong className="text-ink">{c}</strong> — {missing} missing
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {isNumeric ? (
                      <>
                        <ActionButton onClick={() => applyCleaningStep(id, fillMissingNumeric(cleanedRows, c, 'mean'))}>Fill with mean</ActionButton>
                        <ActionButton onClick={() => applyCleaningStep(id, fillMissingNumeric(cleanedRows, c, 'median'))}>Fill with median</ActionButton>
                        <ActionButton onClick={() => applyCleaningStep(id, fillMissingNumeric(cleanedRows, c, 'zero'))}>Fill with zero</ActionButton>
                      </>
                    ) : (
                      <>
                        <ActionButton onClick={() => applyCleaningStep(id, fillMissingCategorical(cleanedRows, c, 'mode'))}>Fill with most common</ActionButton>
                        <ActionButton onClick={() => applyCleaningStep(id, fillMissingCategorical(cleanedRows, c, 'constant', 'Unknown'))}>Fill with "Unknown"</ActionButton>
                      </>
                    )}
                    <ActionButton onClick={() => applyCleaningStep(id, removeInvalidRows(cleanedRows, c))}>Remove these rows</ActionButton>
                  </div>
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {categoricalCols.length > 0 && (
        <Section title="Standardize text">
          <div className="space-y-2">
            {categoricalCols.map((c) => (
              <div key={c} className="flex items-center justify-between gap-2 border-b border-line/60 pb-2 last:border-0">
                <span className="text-sm text-ink-soft">{c}</span>
                <div className="flex items-center gap-2">
                  <select
                    value={standardizeTargets[c] ?? 'trim'}
                    onChange={(e) => setStandardizeTargets((prev) => ({ ...prev, [c]: e.target.value }))}
                    className="rounded border border-line bg-base px-2 py-1 text-xs text-ink-soft"
                  >
                    <option value="trim">Trim whitespace</option>
                    <option value="lowercase">lowercase</option>
                    <option value="uppercase">UPPERCASE</option>
                    <option value="titlecase">Title Case</option>
                  </select>
                  <ActionButton
                    onClick={() =>
                      applyCleaningStep(id, standardizeTextColumn(cleanedRows, c, (standardizeTargets[c] as any) ?? 'trim'))
                    }
                  >
                    Apply
                  </ActionButton>
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      <Section title="Convert data types">
        <div className="space-y-2">
          {columns.map((c) => (
            <div key={c} className="flex items-center justify-between gap-2 border-b border-line/60 pb-2 last:border-0">
              <span className="text-sm text-ink-soft">
                {c} <span className="text-xs text-ink-faint">currently {columnTypes[c]}</span>
              </span>
              <div className="flex items-center gap-2">
                <select
                  value={convertTargets[c] ?? columnTypes[c]}
                  onChange={(e) => setConvertTargets((prev) => ({ ...prev, [c]: e.target.value as ColumnType }))}
                  className="rounded border border-line bg-base px-2 py-1 text-xs text-ink-soft"
                >
                  <option value="numeric">Numeric</option>
                  <option value="text">Text</option>
                  <option value="categorical">Categorical</option>
                  <option value="date">Date</option>
                  <option value="boolean">Boolean</option>
                </select>
                <ActionButton onClick={() => applyCleaningStep(id, convertColumnType(cleanedRows, c, convertTargets[c] ?? columnTypes[c]))}>
                  Convert
                </ActionButton>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {numericCols.length === 0 && categoricalCols.length === 0 && columnsWithMissing.length === 0 && overview.duplicateRows === 0 && (
        <p className="text-sm text-ink-faint">No cleaning issues detected in this dataset.</p>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="mb-3 text-sm font-medium text-ink">{title}</p>
      {children}
    </div>
  );
}

function ActionButton({ onClick, children }: { onClick: () => void; children: ReactNode }) {
  return (
    <button onClick={onClick} className="whitespace-nowrap rounded border border-line px-2.5 py-1 text-xs text-ink-soft hover:border-emerald hover:text-emerald">
      {children}
    </button>
  );
}
