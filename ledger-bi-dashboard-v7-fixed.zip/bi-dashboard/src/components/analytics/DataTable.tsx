import { useMemo, useState } from 'react';
import { Row } from '../../types/analytics';

const PAGE_SIZE = 25;

export function DataTable({ columns, rows }: { columns: string[]; rows: Row[] }) {
  const [search, setSearch] = useState('');
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(0);

  const filtered = useMemo(() => {
    if (!search.trim()) return rows;
    const q = search.toLowerCase();
    return rows.filter((r) => columns.some((c) => String(r[c] ?? '').toLowerCase().includes(q)));
  }, [rows, columns, search]);

  const sorted = useMemo(() => {
    if (!sortCol) return filtered;
    const copy = [...filtered];
    copy.sort((a, b) => {
      const av = a[sortCol];
      const bv = b[sortCol];
      if (av === null) return 1;
      if (bv === null) return -1;
      if (typeof av === 'number' && typeof bv === 'number') return sortDir === 'asc' ? av - bv : bv - av;
      return sortDir === 'asc' ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });
    return copy;
  }, [filtered, sortCol, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  const pageRows = sorted.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  return (
    <div className="rounded border border-line bg-surface">
      <div className="flex items-center justify-between gap-3 border-b border-line p-3">
        <input
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(0);
          }}
          placeholder="Search rows…"
          className="w-full max-w-xs rounded border border-line bg-base px-3 py-1.5 text-sm text-ink outline-none focus:border-emerald"
        />
        <p className="whitespace-nowrap text-xs text-ink-faint">{sorted.length.toLocaleString()} rows</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-ink-faint">
              {columns.map((c) => (
                <th
                  key={c}
                  onClick={() => {
                    if (sortCol === c) setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
                    else {
                      setSortCol(c);
                      setSortDir('asc');
                    }
                  }}
                  className="cursor-pointer whitespace-nowrap px-3 py-2 font-normal hover:text-ink"
                >
                  {c}
                  {sortCol === c && <span className="ml-1">{sortDir === 'asc' ? '↑' : '↓'}</span>}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((r, i) => (
              <tr key={i} className="border-b border-line/60 last:border-0">
                {columns.map((c) => (
                  <td key={c} className="whitespace-nowrap px-3 py-1.5 tabular text-ink-soft">
                    {r[c] === null || r[c] === '' ? <span className="text-ink-faint">—</span> : String(r[c])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between border-t border-line p-3 text-xs text-ink-faint">
        <span>
          Page {page + 1} of {totalPages}
        </span>
        <div className="flex gap-2">
          <button
            disabled={page === 0}
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            className="rounded border border-line px-2 py-1 disabled:opacity-40"
          >
            Previous
          </button>
          <button
            disabled={page >= totalPages - 1}
            onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
            className="rounded border border-line px-2 py-1 disabled:opacity-40"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}
