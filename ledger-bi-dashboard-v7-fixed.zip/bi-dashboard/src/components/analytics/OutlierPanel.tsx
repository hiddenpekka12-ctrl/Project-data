import { useMemo, useState } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { detectOutliers } from '../../lib/outliers';
import { removeOutlierRows } from '../../lib/dataCleaning';
import { OutlierMethod } from '../../types/analytics';
import { LearnThis } from './LearnThis';

export function OutlierPanel() {
  const { activeDataset, applyCleaningStep } = useDatasets();
  const { id, columns, columnTypes, cleanedRows } = activeDataset;
  const numericCols = columns.filter((c) => columnTypes[c] === 'numeric');
  const [column, setColumn] = useState<string>(numericCols[0] ?? '');
  const [method, setMethod] = useState<OutlierMethod>('iqr');
  const [reviewOpen, setReviewOpen] = useState(false);

  const result = useMemo(() => (column ? detectOutliers(cleanedRows, column, method) : null), [cleanedRows, column, method]);

  if (numericCols.length === 0) {
    return <p className="text-sm text-ink-faint">No numeric columns available to check for outliers.</p>;
  }

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="flex items-center text-sm font-medium text-ink">
        Outlier detection
        <LearnThis conceptKey="outlier" />
      </p>
      <p className="mt-1 text-xs text-ink-faint">An outlier is not automatically an error — review before deciding what to do.</p>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <select value={column} onChange={(e) => setColumn(e.target.value)} className="rounded border border-line bg-base px-2 py-1 text-sm text-ink-soft">
          {numericCols.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <select value={method} onChange={(e) => setMethod(e.target.value as OutlierMethod)} className="rounded border border-line bg-base px-2 py-1 text-sm text-ink-soft">
          <option value="iqr">IQR method</option>
          <option value="zscore">Z-score method</option>
        </select>
      </div>

      {result && (
        <div className="mt-3 space-y-2">
          <p className="text-sm text-ink-soft">
            <strong className="tabular text-ink">{result.outlierRowIndexes.length}</strong> of {cleanedRows.length} rows flagged, outside
            <span className="tabular"> [{result.lowerBound.toFixed(2)}, {result.upperBound.toFixed(2)}]</span>.
          </p>
          {result.outlierRowIndexes.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <button onClick={() => setReviewOpen((o) => !o)} className="rounded border border-line px-2.5 py-1 text-xs text-ink-soft hover:bg-base">
                {reviewOpen ? 'Hide flagged rows' : 'Review flagged rows'}
              </button>
              <button
                onClick={() => applyCleaningStep(id, removeOutlierRows(cleanedRows, column, method))}
                className="rounded border border-line px-2.5 py-1 text-xs text-ink-soft hover:border-rust hover:text-rust"
              >
                Remove flagged rows
              </button>
              <span className="rounded border border-line px-2.5 py-1 text-xs text-ink-faint">Keep as-is (no action needed)</span>
            </div>
          )}
          {reviewOpen && result.outlierRowIndexes.length > 0 && (
            <div className="max-h-48 overflow-y-auto rounded border border-line">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-line text-ink-faint">
                    <th className="px-2 py-1 font-normal">Row #</th>
                    <th className="px-2 py-1 font-normal">{column}</th>
                  </tr>
                </thead>
                <tbody>
                  {result.outlierRowIndexes.slice(0, 100).map((idx) => (
                    <tr key={idx} className="border-b border-line/60 last:border-0">
                      <td className="px-2 py-1 text-ink-faint">{idx + 1}</td>
                      <td className="px-2 py-1 tabular text-ink-soft">{String(cleanedRows[idx][column])}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
