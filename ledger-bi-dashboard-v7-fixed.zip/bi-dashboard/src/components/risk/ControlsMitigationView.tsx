import { useRisk } from '../../state/RiskContext';
import { ControlEffectiveness, MitigationStatus } from '../../risk/types';

const EFFECTIVENESS_STYLES: Record<ControlEffectiveness, string> = {
  Strong: 'text-emerald',
  Adequate: 'text-slateblue',
  Weak: 'text-rust',
  Unknown: 'text-ink-faint',
  'Not Assessed': 'text-ink-faint',
};

const STATUS_STYLES: Record<MitigationStatus, string> = {
  'Not Started': 'text-ink-faint',
  'In Progress': 'text-slateblue',
  Completed: 'text-emerald',
  Delayed: 'text-rust',
  Cancelled: 'text-ink-faint',
};

export function ControlsMitigationView() {
  const { controls, mitigations, registerItems, updateMitigation } = useRisk();
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      <div>
        <p className="mb-2 text-sm font-medium text-ink">Control Library</p>
        {controls.length === 0 ? (
          <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">No controls defined yet. Load demo risk data from the Risk Register tab.</p>
        ) : (
          <div className="overflow-x-auto rounded border border-line bg-surface">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line text-xs text-ink-faint">
                  <th className="px-3 py-2 font-normal">Control</th>
                  <th className="px-3 py-2 font-normal">Type</th>
                  <th className="px-3 py-2 font-normal">Nature</th>
                  <th className="px-3 py-2 font-normal">Owner</th>
                  <th className="px-3 py-2 font-normal">Effectiveness</th>
                  <th className="px-3 py-2 font-normal">Next Review</th>
                </tr>
              </thead>
              <tbody>
                {controls.map((c) => (
                  <tr key={c.id} className="border-b border-line/60 last:border-0">
                    <td className="px-3 py-2 text-ink">{c.name}</td>
                    <td className="px-3 py-2 text-ink-soft">{c.controlType}</td>
                    <td className="px-3 py-2 text-ink-soft">{c.natureType}</td>
                    <td className="px-3 py-2 text-ink-soft">{c.owner}</td>
                    <td className={`px-3 py-2 ${EFFECTIVENESS_STYLES[c.effectiveness]}`}>{c.effectiveness}</td>
                    <td className="px-3 py-2 text-ink-soft">{c.nextReview}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-ink">Mitigation Action Tracker</p>
        {mitigations.length === 0 ? (
          <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">No mitigation actions yet. Load demo risk data from the Risk Register tab.</p>
        ) : (
          <div className="overflow-x-auto rounded border border-line bg-surface">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line text-xs text-ink-faint">
                  <th className="px-3 py-2 font-normal">Action</th>
                  <th className="px-3 py-2 font-normal">Owner</th>
                  <th className="px-3 py-2 font-normal">Priority</th>
                  <th className="px-3 py-2 font-normal">Due Date</th>
                  <th className="px-3 py-2 font-normal">Status</th>
                  <th className="px-3 py-2 font-normal">Progress</th>
                </tr>
              </thead>
              <tbody>
                {mitigations.map((m) => {
                  const isOverdue = m.status !== 'Completed' && m.status !== 'Cancelled' && m.dueDate < today;
                  const linkedRisk = registerItems.find((r) => r.id === m.riskId);
                  return (
                    <tr key={m.id} className={`border-b border-line/60 last:border-0 ${isOverdue ? 'bg-rust-soft/40' : ''}`}>
                      <td className="px-3 py-2 text-ink">
                        {m.action}
                        {linkedRisk && <span className="ml-1 text-xs text-ink-faint">({linkedRisk.name})</span>}
                      </td>
                      <td className="px-3 py-2 text-ink-soft">{m.owner}</td>
                      <td className="px-3 py-2 text-ink-soft">{m.priority}</td>
                      <td className={`px-3 py-2 tabular ${isOverdue ? 'font-medium text-rust' : 'text-ink-soft'}`}>
                        {m.dueDate} {isOverdue && '(overdue)'}
                      </td>
                      <td className="px-3 py-2">
                        <select
                          value={m.status}
                          onChange={(e) => updateMitigation(m.id, { status: e.target.value as MitigationStatus })}
                          className={`rounded border border-line bg-base px-1.5 py-1 text-xs ${STATUS_STYLES[m.status]}`}
                        >
                          {(['Not Started', 'In Progress', 'Completed', 'Delayed', 'Cancelled'] as MitigationStatus[]).map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="px-3 py-2">
                        <div className="h-1.5 w-20 rounded-full bg-line">
                          <div className="h-1.5 rounded-full bg-emerald" style={{ width: `${m.progressPct}%` }} />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
