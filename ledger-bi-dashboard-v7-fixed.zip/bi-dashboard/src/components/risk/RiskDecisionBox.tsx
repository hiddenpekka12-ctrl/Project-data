import { useState } from 'react';
import { answerRiskQuestion, RiskQAAnswer, RiskQAContext } from '../../risk/decisionQuestions';

const EXAMPLES = [
  'Which risks are most important?',
  'Which risks are above appetite?',
  'Which financial risks are increasing?',
  'Which risks have weak controls?',
  'Which risks have overdue actions?',
  'Where should management investigate first?',
];

export function RiskDecisionBox({ ctx }: { ctx: RiskQAContext }) {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<RiskQAAnswer | null>(null);

  const ask = (q: string) => {
    setQuestion(q);
    setAnswer(answerRiskQuestion(q, ctx));
  };

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-sm font-medium text-ink">Risk Decision Support</p>
      <p className="mb-2 text-xs text-ink-faint">Answers only from the register, KRIs, and financial signals currently loaded.</p>
      <div className="mt-2 flex gap-2">
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && ask(question)}
          placeholder="e.g. Which risks are most important?"
          className="flex-1 rounded border border-line bg-base px-3 py-2 text-sm text-ink outline-none focus:border-emerald"
        />
        <button onClick={() => ask(question)} className="rounded border border-line bg-base px-4 py-2 text-sm text-ink-soft hover:bg-line/40">
          Ask
        </button>
      </div>
      <div className="mt-2 flex flex-wrap gap-2">
        {EXAMPLES.map((ex) => (
          <button key={ex} onClick={() => ask(ex)} className="rounded-full border border-line px-2.5 py-1 text-xs text-ink-faint hover:text-ink-soft">
            {ex}
          </button>
        ))}
      </div>
      {answer && (
        <div className="mt-3 rounded border border-line bg-base p-3 text-sm">
          {answer.answered ? (
            <p className="text-ink">{answer.answer}</p>
          ) : (
            <>
              <p className="font-medium text-ink-soft">Insufficient data to determine this reliably</p>
              <p className="mt-1 text-ink-soft">{answer.missingRequirement}</p>
            </>
          )}
        </div>
      )}
    </div>
  );
}
