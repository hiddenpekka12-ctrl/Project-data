import { useState, ReactNode } from 'react';
import { computeExpectedLoss, computeScorecardTotal, DEFAULT_SCORECARD_VARIABLES, scorecardRiskLevel } from '../../risk/creditRisk';
import { LearnThis } from '../analytics/LearnThis';

export function CreditRiskView() {
  const [pdPct, setPdPct] = useState(5);
  const [lgdPct, setLgdPct] = useState(40);
  const [ead, setEad] = useState(1000000);
  const [variables, setVariables] = useState(DEFAULT_SCORECARD_VARIABLES);

  const result = computeExpectedLoss({ pd: pdPct / 100, lgd: lgdPct / 100, ead });
  const scorecardTotal = computeScorecardTotal(variables);
  const scorecardLevel = scorecardRiskLevel(scorecardTotal);

  return (
    <div className="space-y-4">
      <div className="rounded border border-amber/30 bg-amber-soft px-4 py-3 text-xs text-amber">
        This is an educational/analytical foundation, not a bank-grade credit model. It makes no claim of regulatory approval, IFRS 9 compliance, Basel compliance, or a
        statistically validated probability of default.
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="flex items-center text-sm font-medium text-ink">
          Expected Loss Calculator
          <LearnThis conceptKey="creditRisk" />
        </p>
        <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Field label="Probability of Default (PD) %"><input type="number" value={pdPct} onChange={(e) => setPdPct(Number(e.target.value))} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
          <Field label="Loss Given Default (LGD) %"><input type="number" value={lgdPct} onChange={(e) => setLgdPct(Number(e.target.value))} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
          <Field label="Exposure at Default (EAD)"><input type="number" value={ead} onChange={(e) => setEad(Number(e.target.value))} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        </div>
        <div className="mt-3 rounded border border-line bg-base p-3 text-sm">
          <p className="text-ink-soft">
            Expected Loss = PD × LGD × EAD = {(pdPct / 100).toFixed(2)} × {(lgdPct / 100).toFixed(2)} × {ead.toLocaleString()}
          </p>
          <p className="mt-1 font-serif text-xl tabular text-ink">= {result.expectedLoss.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
        </div>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Credit Risk Scorecard (demo, configurable)</p>
        <p className="mb-3 text-xs text-ink-faint">A transparent heuristic — not a validated statistical model. Adjust weights/scores to see how the total changes.</p>
        <div className="space-y-2">
          {variables.map((v, i) => (
            <div key={v.key} className="grid grid-cols-3 items-center gap-2 text-sm">
              <span className="text-ink-soft">{v.label}</span>
              <label className="flex items-center gap-2">
                <span className="text-xs text-ink-faint">Weight</span>
                <input
                  type="number"
                  step={0.05}
                  value={v.weight}
                  onChange={(e) => {
                    const next = [...variables];
                    next[i] = { ...v, weight: Number(e.target.value) };
                    setVariables(next);
                  }}
                  className="w-20 rounded border border-line bg-base px-2 py-1 text-xs"
                />
              </label>
              <label className="flex items-center gap-2">
                <span className="text-xs text-ink-faint">Score (0-100)</span>
                <input
                  type="number"
                  value={v.score}
                  onChange={(e) => {
                    const next = [...variables];
                    next[i] = { ...v, score: Number(e.target.value) };
                    setVariables(next);
                  }}
                  className="w-20 rounded border border-line bg-base px-2 py-1 text-xs"
                />
              </label>
            </div>
          ))}
        </div>
        <div className="mt-3 flex items-center gap-3 border-t border-line pt-3">
          <span className="font-serif text-2xl tabular text-ink">{scorecardTotal.toFixed(1)}</span>
          <span className={`text-sm ${scorecardLevel === 'Low Risk' ? 'text-emerald' : scorecardLevel === 'Moderate Risk' ? 'text-amber' : 'text-rust'}`}>{scorecardLevel}</span>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      {children}
    </label>
  );
}
