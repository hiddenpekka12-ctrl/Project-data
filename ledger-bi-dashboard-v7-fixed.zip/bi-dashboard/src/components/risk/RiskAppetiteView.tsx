import { ReactNode } from 'react';
import { useRisk } from '../../state/RiskContext';
import { computeRiskScore } from '../../risk/scoring';
import { evaluateAppetite } from '../../risk/appetite';

export function RiskAppetiteView() {
  const { registerItems, appetiteSettings, setAppetiteSettings } = useRisk();

  const scored = registerItems.map((r) => ({ risk: r, score: computeRiskScore(r.residualProbability, r.residualImpact) }));
  const aboveAppetite = scored.filter((s) => evaluateAppetite(s.score, appetiteSettings).status === 'Escalation — above appetite');

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Risk Appetite Settings (configurable)</p>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Field label="Tolerance threshold (score ≤ this = within tolerance)">
            <input type="number" value={appetiteSettings.toleranceThreshold} onChange={(e) => setAppetiteSettings({ ...appetiteSettings, toleranceThreshold: Number(e.target.value) })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </Field>
          <Field label="Management attention threshold">
            <input type="number" value={appetiteSettings.managementAttentionThreshold} onChange={(e) => setAppetiteSettings({ ...appetiteSettings, managementAttentionThreshold: Number(e.target.value) })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </Field>
          <Field label="Escalation threshold (score ≥ this = escalate)">
            <input type="number" value={appetiteSettings.escalationThreshold} onChange={(e) => setAppetiteSettings({ ...appetiteSettings, escalationThreshold: Number(e.target.value) })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </Field>
        </div>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Current Risk → Appetite → Gap</p>
        {scored.length === 0 ? (
          <p className="text-sm text-ink-faint">No risks in the register yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line text-xs text-ink-faint">
                  <th className="px-2 py-1.5 font-normal">Risk</th>
                  <th className="px-2 py-1.5 font-normal">Current Risk</th>
                  <th className="px-2 py-1.5 font-normal">Appetite Limit</th>
                  <th className="px-2 py-1.5 font-normal">Gap</th>
                  <th className="px-2 py-1.5 font-normal">Status</th>
                </tr>
              </thead>
              <tbody>
                {scored.map(({ risk, score }) => {
                  const appetite = evaluateAppetite(score, appetiteSettings);
                  return (
                    <tr key={risk.id} className="border-b border-line/60 last:border-0">
                      <td className="px-2 py-1.5 text-ink">{risk.name}</td>
                      <td className="px-2 py-1.5 tabular text-ink-soft">{score}</td>
                      <td className="px-2 py-1.5 tabular text-ink-soft">{appetiteSettings.toleranceThreshold}</td>
                      <td className={`px-2 py-1.5 tabular ${appetite.gap > 0 ? 'text-rust' : 'text-emerald'}`}>
                        {appetite.gap >= 0 ? '+' : ''}
                        {appetite.gap}
                      </td>
                      <td className="px-2 py-1.5">
                        <span
                          className={`rounded-sm px-1.5 py-0.5 text-[11px] ${
                            appetite.status === 'Escalation — above appetite' ? 'bg-rust-soft text-rust' : appetite.status === 'Management attention' ? 'bg-amber-soft text-amber' : 'bg-emerald-soft text-emerald'
                          }`}
                        >
                          {appetite.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        <p className="mt-3 text-xs text-ink-faint">
          {aboveAppetite.length} risk(s) currently above appetite. This reflects the configured thresholds only — it does not automatically declare the business unsafe.
        </p>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      {children}
    </label>
  );
}
