import { RiskModel } from '../../risk/buildRiskModel';
import { RiskTrendDirection } from '../../risk/types';

const TREND_STYLES: Record<RiskTrendDirection, string> = {
  Increasing: 'text-rust',
  Stable: 'text-ink-faint',
  Decreasing: 'text-emerald',
  New: 'text-slateblue',
  Resolved: 'text-emerald',
  'Insufficient data': 'text-ink-faint',
};

export function RiskTrendsInsightsView({ model }: { model: RiskModel }) {
  return (
    <div className="space-y-6">
      <div>
        <p className="mb-2 text-sm font-medium text-ink">Risk Trends</p>
        {model.scoredRisks.length === 0 ? (
          <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">No risks in the register yet.</p>
        ) : (
          <div className="overflow-x-auto rounded border border-line bg-surface">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line text-xs text-ink-faint">
                  <th className="px-3 py-2 font-normal">Risk</th>
                  <th className="px-3 py-2 font-normal">Residual Score</th>
                  <th className="px-3 py-2 font-normal">Trend</th>
                </tr>
              </thead>
              <tbody>
                {model.scoredRisks.map((s) => (
                  <tr key={s.risk.id} className="border-b border-line/60 last:border-0">
                    <td className="px-3 py-2 text-ink">{s.risk.name}</td>
                    <td className="px-3 py-2 tabular text-ink-soft">{s.residualScore}</td>
                    <td className={`px-3 py-2 ${TREND_STYLES[s.trend]}`}>{s.trend}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-ink">Risk Insight Engine</p>
        {model.insights.length === 0 ? (
          <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">Not enough signals yet to generate insights.</p>
        ) : (
          <div className="space-y-3">
            {model.insights.map((i) => (
              <div key={i.id} className="rounded border border-line bg-surface p-4">
                <p className="text-sm text-ink">{i.finding}</p>
                <p className="mt-1 text-xs text-ink-faint">Evidence: {i.evidence}</p>
                <p className="mt-2 text-xs font-medium text-ink-soft">Risk meaning</p>
                <p className="text-xs text-ink-soft">{i.riskMeaning}</p>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-xs text-ink-faint">Recommended investigation: {i.recommendedInvestigation}</span>
                  <span className={`text-xs font-medium ${i.confidence === 'High' ? 'text-emerald' : i.confidence === 'Medium' ? 'text-amber' : 'text-ink-faint'}`}>{i.confidence}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-ink">Risk Alerts</p>
        {model.alerts.length === 0 ? (
          <p className="rounded border border-emerald/30 bg-emerald-soft p-4 text-sm text-emerald">No active alerts.</p>
        ) : (
          <div className="space-y-2">
            {model.alerts.map((a) => (
              <div key={a.id} className={`rounded border px-3 py-2 text-sm ${a.severity === 'critical' ? 'border-rust/40 bg-rust-soft text-rust' : 'border-amber/40 bg-amber-soft text-amber'}`}>
                <p className="font-medium">{a.label}</p>
                <p className="mt-0.5 text-xs">
                  {a.metric}: {a.currentValue} (threshold: {a.threshold}) · {a.source}
                </p>
                <p className="mt-0.5 text-xs">Recommended: {a.recommendedAction}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {model.validation.length > 0 && (
        <div>
          <p className="mb-2 text-sm font-medium text-ink">Data Validation</p>
          <div className="space-y-2">
            {model.validation.map((issue, i) => (
              <div key={i} className={`rounded border px-3 py-2 text-xs ${issue.severity === 'error' ? 'border-rust/40 bg-rust-soft text-rust' : 'border-amber/40 bg-amber-soft text-amber'}`}>
                <p className="font-medium">{issue.label}</p>
                <p className="mt-0.5">{issue.detail}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
