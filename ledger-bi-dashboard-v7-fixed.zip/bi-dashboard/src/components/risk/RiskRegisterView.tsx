import { ReactNode, useMemo, useState } from 'react';
import { useRisk } from '../../state/RiskContext';
import { RiskCategory, RiskItem, RISK_CATEGORY_LABELS, RISK_SUBCATEGORY_SUGGESTIONS, ControlEffectiveness, RiskStatus, TreatmentStrategy, ImpactDimension } from '../../risk/types';
import { computeRiskScore, riskLevelFor } from '../../risk/scoring';

function emptyRisk(): RiskItem {
  return {
    id: `risk-${Date.now()}-${Math.round(Math.random() * 1000)}`,
    name: '',
    category: 'financial',
    subcategory: '',
    description: '',
    cause: '',
    riskEvent: '',
    consequence: '',
    owner: '',
    department: '',
    dateIdentified: new Date().toISOString().slice(0, 10),
    reviewDate: '',
    impactDimension: 'financial',
    inherentProbability: 3,
    inherentImpact: 3,
    existingControls: '',
    controlEffectiveness: 'Not Assessed',
    residualProbability: 3,
    residualImpact: 3,
    treatmentStrategy: 'Reduce',
    mitigationAction: '',
    actionOwner: '',
    targetDate: '',
    status: 'Open',
    evidenceSource: '',
    notes: '',
    history: [],
  };
}

function downloadCsv(rows: RiskItem[]) {
  const headers = ['Name', 'Category', 'Subcategory', 'Owner', 'Status', 'Inherent Score', 'Residual Score', 'Control Effectiveness', 'Treatment', 'Target Date'];
  const lines = [
    headers.join(','),
    ...rows.map((r) =>
      [r.name, RISK_CATEGORY_LABELS[r.category], r.subcategory, r.owner, r.status, computeRiskScore(r.inherentProbability, r.inherentImpact), computeRiskScore(r.residualProbability, r.residualImpact), r.controlEffectiveness, r.treatmentStrategy, r.targetDate]
        .map((v) => `"${String(v).replace(/"/g, "'")}"`)
        .join(',')
    ),
  ];
  const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'risk-register.csv';
  a.click();
  URL.revokeObjectURL(url);
}

export function RiskRegisterView() {
  const { registerItems, addRisk, updateRisk, deleteRisk, duplicateRisk, loadDemoRiskData } = useRisk();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<RiskCategory | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<RiskStatus | 'all'>('all');
  const [sortKey, setSortKey] = useState<'name' | 'residualScore'>('residualScore');
  const [editing, setEditing] = useState<RiskItem | null>(null);

  const filtered = useMemo(() => {
    let items = registerItems;
    if (categoryFilter !== 'all') items = items.filter((r) => r.category === categoryFilter);
    if (statusFilter !== 'all') items = items.filter((r) => r.status === statusFilter);
    if (search.trim()) {
      const q = search.toLowerCase();
      items = items.filter((r) => r.name.toLowerCase().includes(q) || r.owner.toLowerCase().includes(q) || r.description.toLowerCase().includes(q));
    }
    return [...items].sort((a, b) => {
      if (sortKey === 'name') return a.name.localeCompare(b.name);
      return computeRiskScore(b.residualProbability, b.residualImpact) - computeRiskScore(a.residualProbability, a.residualImpact);
    });
  }, [registerItems, categoryFilter, statusFilter, search, sortKey]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search risks…" className="rounded border border-line bg-base px-3 py-1.5 text-sm" />
        <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value as RiskCategory | 'all')} className="rounded border border-line bg-base px-2 py-1.5 text-sm">
          <option value="all">All categories</option>
          {Object.entries(RISK_CATEGORY_LABELS).map(([k, l]) => (
            <option key={k} value={k}>
              {l}
            </option>
          ))}
        </select>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as RiskStatus | 'all')} className="rounded border border-line bg-base px-2 py-1.5 text-sm">
          <option value="all">All statuses</option>
          {(['Open', 'Monitoring', 'Mitigated', 'Closed'] as RiskStatus[]).map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <select value={sortKey} onChange={(e) => setSortKey(e.target.value as 'name' | 'residualScore')} className="rounded border border-line bg-base px-2 py-1.5 text-sm">
          <option value="residualScore">Sort: Residual Score</option>
          <option value="name">Sort: Name</option>
        </select>
        <div className="ml-auto flex gap-2">
          {registerItems.length === 0 && (
            <button onClick={loadDemoRiskData} className="rounded border border-emerald bg-emerald-soft px-3 py-1.5 text-xs text-emerald">
              Load demo risk register
            </button>
          )}
          <button onClick={() => setEditing(emptyRisk())} className="rounded border border-line bg-base px-3 py-1.5 text-xs text-ink-soft hover:bg-line/40">
            + Add risk
          </button>
          <button onClick={() => downloadCsv(filtered)} className="rounded border border-line bg-base px-3 py-1.5 text-xs text-ink-soft hover:bg-line/40">
            Export CSV
          </button>
        </div>
      </div>

      <div className="overflow-x-auto rounded border border-line bg-surface">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-ink-faint">
              <th className="px-3 py-2 font-normal">Name</th>
              <th className="px-3 py-2 font-normal">Category</th>
              <th className="px-3 py-2 font-normal">Owner</th>
              <th className="px-3 py-2 font-normal">Inherent</th>
              <th className="px-3 py-2 font-normal">Residual</th>
              <th className="px-3 py-2 font-normal">Level</th>
              <th className="px-3 py-2 font-normal">Status</th>
              <th className="px-3 py-2 font-normal">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => {
              const inherentScore = computeRiskScore(r.inherentProbability, r.inherentImpact);
              const residualScore = computeRiskScore(r.residualProbability, r.residualImpact);
              const level = riskLevelFor(residualScore);
              return (
                <tr key={r.id} className="border-b border-line/60 last:border-0">
                  <td className="px-3 py-2 text-ink">{r.name || '(untitled)'}</td>
                  <td className="px-3 py-2 text-ink-soft">{RISK_CATEGORY_LABELS[r.category]}</td>
                  <td className="px-3 py-2 text-ink-soft">{r.owner || '—'}</td>
                  <td className="px-3 py-2 tabular text-ink-soft">{inherentScore}</td>
                  <td className="px-3 py-2 tabular text-ink-soft">{residualScore}</td>
                  <td className="px-3 py-2">
                    <span className="rounded-sm px-1.5 py-0.5 text-[11px]" style={{ backgroundColor: `${level.color}22`, color: level.color }}>
                      {level.label}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-ink-soft">{r.status}</td>
                  <td className="px-3 py-2">
                    <div className="flex gap-2 text-xs">
                      <button onClick={() => setEditing(r)} className="text-ink-soft hover:text-emerald">
                        Edit
                      </button>
                      <button onClick={() => duplicateRisk(r.id)} className="text-ink-soft hover:text-ink">
                        Duplicate
                      </button>
                      <button onClick={() => deleteRisk(r.id)} className="text-ink-soft hover:text-rust">
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-6 text-center text-sm text-ink-faint">
                  No risks match the current filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {editing && (
        <RiskEditForm
          risk={editing}
          isNew={!registerItems.some((r) => r.id === editing.id)}
          onCancel={() => setEditing(null)}
          onSave={(risk) => {
            if (registerItems.some((r) => r.id === risk.id)) updateRisk(risk.id, risk);
            else addRisk(risk);
            setEditing(null);
          }}
        />
      )}
    </div>
  );
}

function RiskEditForm({ risk, isNew, onCancel, onSave }: { risk: RiskItem; isNew: boolean; onCancel: () => void; onSave: (risk: RiskItem) => void }) {
  const [draft, setDraft] = useState<RiskItem>(risk);
  const set = <K extends keyof RiskItem>(key: K, value: RiskItem[K]) => setDraft((prev) => ({ ...prev, [key]: value }));

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="mb-3 text-sm font-medium text-ink">{isNew ? 'New risk' : 'Edit risk'}</p>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Field label="Name"><input value={draft.name} onChange={(e) => set('name', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Category">
          <select value={draft.category} onChange={(e) => set('category', e.target.value as RiskCategory)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            {Object.entries(RISK_CATEGORY_LABELS).map(([k, l]) => (
              <option key={k} value={k}>{l}</option>
            ))}
          </select>
        </Field>
        <Field label="Subcategory">
          <input list="subcat-options" value={draft.subcategory} onChange={(e) => set('subcategory', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          <datalist id="subcat-options">
            {RISK_SUBCATEGORY_SUGGESTIONS[draft.category].map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
        </Field>
        <Field label="Owner"><input value={draft.owner} onChange={(e) => set('owner', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Department"><input value={draft.department} onChange={(e) => set('department', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Impact Dimension">
          <select value={draft.impactDimension} onChange={(e) => set('impactDimension', e.target.value as ImpactDimension)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            {(['financial', 'operational', 'customer', 'strategic', 'regulatory', 'reputational', 'technology'] as ImpactDimension[]).map((d) => (
              <option key={d} value={d}>{d.charAt(0).toUpperCase() + d.slice(1)}</option>
            ))}
          </select>
        </Field>
        <Field label="Status">
          <select value={draft.status} onChange={(e) => set('status', e.target.value as RiskStatus)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            {(['Open', 'Monitoring', 'Mitigated', 'Closed'] as RiskStatus[]).map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </Field>
        <Field label="Description" wide><textarea value={draft.description} onChange={(e) => set('description', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" rows={2} /></Field>
        <Field label="Cause"><input value={draft.cause} onChange={(e) => set('cause', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Risk Event"><input value={draft.riskEvent} onChange={(e) => set('riskEvent', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Consequence"><input value={draft.consequence} onChange={(e) => set('consequence', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>

        <Field label="Inherent Probability (1-5)"><NumberInput value={draft.inherentProbability} onChange={(v) => set('inherentProbability', v)} /></Field>
        <Field label="Inherent Impact (1-5)"><NumberInput value={draft.inherentImpact} onChange={(v) => set('inherentImpact', v)} /></Field>
        <Field label="Existing Controls"><input value={draft.existingControls} onChange={(e) => set('existingControls', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Control Effectiveness">
          <select value={draft.controlEffectiveness} onChange={(e) => set('controlEffectiveness', e.target.value as ControlEffectiveness)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            {(['Strong', 'Adequate', 'Weak', 'Unknown', 'Not Assessed'] as ControlEffectiveness[]).map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </Field>
        <Field label="Residual Probability (1-5)"><NumberInput value={draft.residualProbability} onChange={(v) => set('residualProbability', v)} /></Field>
        <Field label="Residual Impact (1-5)"><NumberInput value={draft.residualImpact} onChange={(v) => set('residualImpact', v)} /></Field>

        <Field label="Treatment Strategy">
          <select value={draft.treatmentStrategy} onChange={(e) => set('treatmentStrategy', e.target.value as TreatmentStrategy)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            {(['Avoid', 'Reduce', 'Transfer', 'Accept'] as TreatmentStrategy[]).map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </Field>
        <Field label="Mitigation Action"><input value={draft.mitigationAction} onChange={(e) => set('mitigationAction', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Action Owner"><input value={draft.actionOwner} onChange={(e) => set('actionOwner', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Target Date"><input type="date" value={draft.targetDate} onChange={(e) => set('targetDate', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Date Identified"><input type="date" value={draft.dateIdentified} onChange={(e) => set('dateIdentified', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Review Date"><input type="date" value={draft.reviewDate} onChange={(e) => set('reviewDate', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Evidence / Source"><input value={draft.evidenceSource} onChange={(e) => set('evidenceSource', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Notes" wide><textarea value={draft.notes} onChange={(e) => set('notes', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" rows={2} /></Field>
      </div>
      <div className="mt-4 flex gap-2">
        <button
          onClick={() =>
            onSave({
              ...draft,
              history: [...draft.history, { date: new Date().toISOString().slice(0, 10), residualProbability: draft.residualProbability, residualImpact: draft.residualImpact }],
            })
          }
          className="rounded border border-emerald bg-emerald-soft px-4 py-1.5 text-sm text-emerald"
        >
          Save
        </button>
        <button onClick={onCancel} className="rounded border border-line px-4 py-1.5 text-sm text-ink-soft hover:bg-base">
          Cancel
        </button>
      </div>
    </div>
  );
}

function Field({ label, children, wide }: { label: string; children: ReactNode; wide?: boolean }) {
  return (
    <label className={`block ${wide ? 'sm:col-span-2 lg:col-span-3' : ''}`}>
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      {children}
    </label>
  );
}

function NumberInput({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <select value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
      {[1, 2, 3, 4, 5].map((n) => (
        <option key={n} value={n}>
          {n}
        </option>
      ))}
    </select>
  );
}
