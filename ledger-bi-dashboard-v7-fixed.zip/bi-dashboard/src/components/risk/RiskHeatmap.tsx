import { useState } from 'react';
import { ScoredRisk } from '../../risk/buildRiskModel';
import { RiskCategory, RISK_CATEGORY_LABELS } from '../../risk/types';

export function RiskHeatmap({ scoredRisks }: { scoredRisks: ScoredRisk[] }) {
  const [mode, setMode] = useState<'inherent' | 'residual'>('residual');
  const [categoryFilter, setCategoryFilter] = useState<RiskCategory | 'all'>('all');
  const [selected, setSelected] = useState<ScoredRisk | null>(null);

  const filtered = scoredRisks.filter((s) => categoryFilter === 'all' || s.risk.category === categoryFilter);

  const cellSize = 64;
  const gridSize = cellSize * 5;

  function riskAt(probability: number, impact: number): ScoredRisk[] {
    return filtered.filter((s) => {
      const p = mode === 'inherent' ? s.risk.inherentProbability : s.risk.residualProbability;
      const i = mode === 'inherent' ? s.risk.inherentImpact : s.risk.residualImpact;
      return p === probability && i === impact;
    });
  }

  function bandColor(probability: number, impact: number): string {
    const score = probability * impact;
    if (score >= 20) return '#5C1610';
    if (score >= 15) return '#8B2F1D';
    if (score >= 10) return '#B3452C';
    if (score >= 5) return '#A9782E';
    return '#1F6F54';
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex overflow-hidden rounded border border-line">
          <button onClick={() => setMode('inherent')} className={`px-3 py-1.5 text-xs ${mode === 'inherent' ? 'bg-emerald-soft text-emerald' : 'bg-surface text-ink-faint'}`}>
            Inherent
          </button>
          <button onClick={() => setMode('residual')} className={`px-3 py-1.5 text-xs ${mode === 'residual' ? 'bg-emerald-soft text-emerald' : 'bg-surface text-ink-faint'}`}>
            Residual
          </button>
        </div>
        <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value as RiskCategory | 'all')} className="rounded border border-line bg-base px-2 py-1.5 text-xs text-ink-soft">
          <option value="all">All categories</option>
          {Object.entries(RISK_CATEGORY_LABELS).map(([key, label]) => (
            <option key={key} value={key}>
              {label}
            </option>
          ))}
        </select>
      </div>

      <div className="flex gap-3">
        <div className="flex flex-col justify-between py-2 text-[10px] text-ink-faint" style={{ height: gridSize }}>
          {[5, 4, 3, 2, 1].map((i) => (
            <span key={i} style={{ height: cellSize }} className="flex items-center">
              Impact {i}
            </span>
          ))}
        </div>
        <div>
          <div className="grid" style={{ gridTemplateColumns: `repeat(5, ${cellSize}px)`, gridTemplateRows: `repeat(5, ${cellSize}px)` }}>
            {[5, 4, 3, 2, 1].flatMap((impact) =>
              [1, 2, 3, 4, 5].map((probability) => {
                const cellRisks = riskAt(probability, impact);
                return (
                  <div
                    key={`${probability}-${impact}`}
                    className="relative flex items-center justify-center border border-white/40"
                    style={{ backgroundColor: bandColor(probability, impact), width: cellSize, height: cellSize }}
                  >
                    {cellRisks.length > 0 && (
                      <button
                        onClick={() => setSelected(cellRisks[0])}
                        className="flex h-6 w-6 items-center justify-center rounded-full bg-surface text-[11px] font-medium text-ink shadow"
                        title={cellRisks.map((r) => r.risk.name).join(', ')}
                      >
                        {cellRisks.length}
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </div>
          <div className="mt-1 flex text-[10px] text-ink-faint" style={{ width: gridSize }}>
            {[1, 2, 3, 4, 5].map((p) => (
              <span key={p} style={{ width: cellSize }} className="text-center">
                Prob {p}
              </span>
            ))}
          </div>
        </div>
      </div>

      {selected && (
        <div className="rounded border border-line bg-surface p-4">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-ink">{selected.risk.name}</p>
            <button onClick={() => setSelected(null)} className="text-xs text-ink-faint hover:text-ink-soft">
              Close
            </button>
          </div>
          <p className="mt-1 text-xs text-ink-faint">
            {RISK_CATEGORY_LABELS[selected.risk.category]} · {selected.risk.subcategory}
          </p>
          <p className="mt-2 text-sm text-ink-soft">{selected.risk.description}</p>
          <div className="mt-2 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
            <span>Inherent: {selected.inherentScore}</span>
            <span>Residual: {selected.residualScore}</span>
            <span>Level: {selected.level.label}</span>
            <span>Appetite: {selected.appetite.status}</span>
          </div>
        </div>
      )}
    </div>
  );
}
