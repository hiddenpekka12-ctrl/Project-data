import { ConcentrationResult } from '../../risk/types';
import { LearnThis } from '../analytics/LearnThis';

export function ConcentrationRiskView({ concentrations, revenueColumn }: { concentrations: ConcentrationResult[]; revenueColumn: string | null }) {
  if (!revenueColumn) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">Concentration analysis needs a Revenue column mapped in the Finance Center's Account Mapping.</p>;
  }
  if (concentrations.length === 0) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">No categorical columns (customer, supplier, product, region...) found in the active dataset to analyze concentration by.</p>;
  }

  return (
    <div className="space-y-3">
      <p className="flex items-center text-xs text-ink-faint">
        Evidence → potential exposure → investigation. Concentration is reported, not automatically judged dangerous.
        <LearnThis conceptKey="concentrationRiskConcept" />
      </p>
      {concentrations.map((c) => (
        <div key={c.dimension} className="rounded border border-line bg-surface p-4">
          <p className="text-sm font-medium text-ink">Concentration by {c.dimension}</p>
          <p className="mt-2 text-sm text-ink-soft">
            "{c.topEntity}" represents <strong className="tabular text-ink">{c.topSharePct.toFixed(1)}%</strong> of total {revenueColumn}.
            {c.top5SharePct !== null && (
              <>
                {' '}
                The top 5 together represent <strong className="tabular text-ink">{c.top5SharePct.toFixed(1)}%</strong>.
              </>
            )}
          </p>
          {c.topSharePct > 40 && (
            <p className="mt-2 rounded border border-amber/30 bg-amber-soft px-3 py-2 text-xs text-amber">
              This indicates potential exposure if the relationship with "{c.topEntity}" weakens. Worth investigating relationship stability and switching costs, not an automatic red flag.
            </p>
          )}
        </div>
      ))}
    </div>
  );
}
