import { RiskModel } from '../../risk/buildRiskModel';
import { LearnThis } from '../analytics/LearnThis';

function downloadBlob(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const LEARNING_CONCEPTS: { key: Parameters<typeof LearnThis>[0]['conceptKey']; label: string }[] = [
  { key: 'riskAppetite', label: 'Risk Appetite' },
  { key: 'riskTolerance', label: 'Risk Tolerance' },
  { key: 'inherentResidualRisk', label: 'Inherent vs Residual Risk' },
  { key: 'riskMatrix', label: 'Risk Matrix' },
  { key: 'kri', label: 'Key Risk Indicators' },
  { key: 'controlEffectiveness', label: 'Control Effectiveness' },
  { key: 'creditRisk', label: 'Credit Risk (PD/LGD/EAD)' },
  { key: 'liquidityRisk', label: 'Liquidity Risk' },
  { key: 'marketRisk', label: 'Market Risk' },
  { key: 'operationalRisk', label: 'Operational Risk' },
  { key: 'concentrationRiskConcept', label: 'Concentration Risk' },
];

export function RiskReportAndLearning({ model, companyName }: { model: RiskModel; companyName: string }) {
  const exportReport = () => {
    const top = [...model.scoredRisks].sort((a, b) => b.residualScore - a.residualScore).slice(0, 5);
    const critical = model.scoredRisks.filter((s) => s.level.label === 'Critical' || s.level.label === 'Very High');

    const lines = [
      `# Executive Risk Report — ${companyName}`,
      '',
      `Generated ${new Date().toLocaleString()}`,
      '',
      '**This report is a decision-support tool. It does not replace professional risk, legal, or audit advice.**',
      '',
      '## 1. Executive Risk Summary',
      `Overall Risk Score (avg, open risks): ${model.overview.overallScore} · Total Risks: ${model.overview.totalRisks} · Above Appetite: ${model.overview.risksAboveAppetite}`,
      '',
      '## 2. Top Risks',
      ...(top.length ? top.map((s) => `- ${s.risk.name} (residual score ${s.residualScore}, ${s.level.label})`) : ['No risks in the register yet.']),
      '',
      '## 3. Critical / Very High Risks',
      ...(critical.length ? critical.map((s) => `- ${s.risk.name}: ${s.risk.description}`) : ['None currently.']),
      '',
      '## 4. Risk Heatmap',
      'See the interactive heatmap in the Risk Center — not reproducible in this text export.',
      '',
      '## 5. Financial Risk',
      ...(model.financialSignals.length ? model.financialSignals.map((s) => `- ${s.label}: ${s.metric} ${s.changeDescription}`) : ['No active financial risk signals.']),
      '',
      '## 6-10. Operational / Strategic / Technology / Compliance / Concentration Risk',
      'Tracked qualitatively via the Risk Register\'s category tags (see full register export) — dedicated computed sections are not built for these categories since no incident/operational data source exists yet.',
      ...(model.concentrations.length ? model.concentrations.map((c) => `- Concentration by ${c.dimension}: top entity "${c.topEntity}" at ${c.topSharePct.toFixed(1)}%`) : []),
      '',
      '## 11. KRI Status',
      'See the KRI tab for current values and thresholds.',
      '',
      '## 12. Control Effectiveness',
      'See the Controls & Mitigation tab.',
      '',
      '## 13. Risk Appetite Breaches',
      `${model.overview.risksAboveAppetite} risk(s) currently above the configured appetite threshold.`,
      '',
      '## 14-15. Mitigation Actions / Overdue Actions',
      `${model.overview.overdueMitigationActions} overdue mitigation action(s).`,
      '',
      '## 16. Management Recommendations',
      ...(model.insights.length ? model.insights.map((i) => `- ${i.recommendedInvestigation}`) : ['No specific recommendations from current data.']),
      '',
      '## 17. Data Limitations',
      '- Risk register entries are user-entered (or demo data) and reflect qualitative judgment, not measured incidents.',
      '- Financial risk signals depend on the Finance Engine mapping being complete for the active dataset.',
      '- Credit risk figures use a demo/heuristic scorecard, not a validated statistical model.',
    ];

    downloadBlob(lines.join('\n'), `${companyName}-risk-report.md`);
  };

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Executive Risk Report</p>
        <button onClick={exportReport} className="rounded border border-line bg-base px-3 py-1.5 text-xs text-ink-soft hover:bg-line/40">
          Export risk report
        </button>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Fact vs Inference vs Assumption</p>
        <p className="mb-3 text-xs text-ink-faint">Every risk signal in this system is tagged with one of these — never presented as more certain than it is.</p>
        <dl className="grid grid-cols-1 gap-2 text-xs sm:grid-cols-2">
          <div><dt className="font-medium text-ink">FACT</dt><dd className="text-ink-soft">Directly observed in the dataset (e.g. operating cash flow is negative).</dd></div>
          <div><dt className="font-medium text-ink">INFERENCE</dt><dd className="text-ink-soft">A reasonable interpretation based on evidence (e.g. rising DSO suggests collection risk).</dd></div>
          <div><dt className="font-medium text-ink">ASSUMPTION</dt><dd className="text-ink-soft">Something assumed because data is unavailable (e.g. a proxy metric standing in for one that isn't mapped).</dd></div>
          <div><dt className="font-medium text-ink">RECOMMENDATION</dt><dd className="text-ink-soft">A suggested management action, not a guaranteed outcome.</dd></div>
        </dl>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Risk Learning Mode</p>
        <div className="flex flex-wrap gap-2">
          {LEARNING_CONCEPTS.map((c) => (
            <span key={c.key} className="flex items-center rounded border border-line bg-base px-2 py-1 text-xs text-ink-soft">
              {c.label}
              <LearnThis conceptKey={c.key} label="Learn" />
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
