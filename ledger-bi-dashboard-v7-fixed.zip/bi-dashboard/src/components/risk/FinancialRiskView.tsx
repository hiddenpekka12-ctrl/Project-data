import { RiskSignal } from '../../risk/types';

export function FinancialRiskView({ signals }: { signals: RiskSignal[] }) {
  if (signals.length === 0) {
    return <p className="rounded border border-emerald/30 bg-emerald-soft p-4 text-sm text-emerald">No active financial risk signals from the current Finance Engine data.</p>;
  }

  return (
    <div className="space-y-3">
      <p className="text-xs text-ink-faint">Signals are read directly from V3's Finance Engine ratios and statements — nothing here is recalculated separately.</p>
      {signals.map((s) => (
        <div key={s.id} className="rounded border border-amber/30 bg-amber-soft p-4">
          <p className="text-sm font-medium text-amber">{s.label}</p>
          <dl className="mt-2 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
            <div>
              <dt className="text-ink-faint">Metric</dt>
              <dd className="text-ink-soft">{s.metric}</dd>
            </div>
            <div>
              <dt className="text-ink-faint">Current</dt>
              <dd className="tabular text-ink-soft">{s.currentValue}</dd>
            </div>
            <div>
              <dt className="text-ink-faint">Change</dt>
              <dd className="tabular text-ink-soft">{s.changeDescription}</dd>
            </div>
            <div>
              <dt className="text-ink-faint">Threshold</dt>
              <dd className="tabular text-ink-soft">{s.threshold ?? 'n/a'}</dd>
            </div>
          </dl>
          <p className="mt-2 text-xs text-ink-soft">
            <span className="rounded-sm bg-base px-1 py-0.5 text-[10px] text-ink-faint">{s.evidenceType}</span> {s.interpretation}
          </p>
          <p className="mt-1 text-xs text-ink-faint">Recommended investigation: {s.recommendedInvestigation}</p>
        </div>
      ))}
    </div>
  );
}
