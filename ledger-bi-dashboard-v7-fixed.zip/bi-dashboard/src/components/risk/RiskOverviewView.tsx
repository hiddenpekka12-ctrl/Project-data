import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { RiskModel } from '../../risk/buildRiskModel';
import { RISK_CATEGORY_LABELS } from '../../risk/types';

const PIE_COLORS = ['#1F6F54', '#4A5B68', '#A9782E', '#B3452C', '#8A968F', '#2F9E7A', '#6B7F8C'];

export function RiskOverviewView({ model }: { model: RiskModel }) {
  const { overview } = model;

  const kpis: { label: string; value: string | number; tone?: string }[] = [
    { label: 'Overall Risk Score (avg, open)', value: overview.overallScore },
    { label: 'Total Risks', value: overview.totalRisks },
    { label: 'Critical Risks', value: overview.criticalRisks, tone: overview.criticalRisks > 0 ? 'text-rust' : undefined },
    { label: 'Very High Risks', value: overview.veryHighRisks },
    { label: 'High Risks', value: overview.highRisks },
    { label: 'Open Risks', value: overview.openRisks },
    { label: 'Overdue Mitigation Actions', value: overview.overdueMitigationActions, tone: overview.overdueMitigationActions > 0 ? 'text-amber' : undefined },
    { label: 'Risks Increasing', value: overview.risksIncreasing },
    { label: 'Risks Decreasing', value: overview.risksDecreasing },
    { label: 'Risks Without Controls', value: overview.risksWithoutControls },
    { label: 'Risks Above Appetite', value: overview.risksAboveAppetite, tone: overview.risksAboveAppetite > 0 ? 'text-rust' : undefined },
  ];

  const topRisks = [...model.scoredRisks].sort((a, b) => b.residualScore - a.residualScore).slice(0, 10);
  const statusCounts = new Map<string, number>();
  model.scoredRisks.forEach((s) => statusCounts.set(s.risk.status, (statusCounts.get(s.risk.status) ?? 0) + 1));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {kpis.map((k) => (
          <div key={k.label} className="rounded border border-line bg-surface p-3">
            <p className="text-xs text-ink-faint">{k.label}</p>
            <p className={`mt-1 font-serif text-xl tabular ${k.tone ?? 'text-ink'}`}>{k.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Top 10 Risks (by residual score)</p>
          {topRisks.length === 0 ? (
            <p className="text-sm text-ink-faint">No risks in the register yet.</p>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topRisks.map((r) => ({ name: r.risk.name.length > 18 ? `${r.risk.name.slice(0, 17)}…` : r.risk.name, score: r.residualScore }))} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="name" type="category" width={130} tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
                  <Bar dataKey="score" fill="#B3452C" radius={[0, 2, 2, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Risk Category Distribution</p>
          {model.categoryDistribution.length === 0 ? (
            <p className="text-sm text-ink-faint">No risks in the register yet.</p>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={model.categoryDistribution.map((c) => ({ name: RISK_CATEGORY_LABELS[c.category as keyof typeof RISK_CATEGORY_LABELS] ?? c.category, value: c.count }))} dataKey="value" nameKey="name" outerRadius={90} innerRadius={50}>
                    {model.categoryDistribution.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Risk Status</p>
        <div className="flex flex-wrap gap-3 text-sm">
          {Array.from(statusCounts.entries()).map(([status, count]) => (
            <span key={status} className="rounded border border-line bg-base px-3 py-1.5 text-ink-soft">
              {status}: <strong className="tabular text-ink">{count}</strong>
            </span>
          ))}
          {statusCounts.size === 0 && <span className="text-ink-faint">No risks in the register yet.</span>}
        </div>
      </div>
    </div>
  );
}
