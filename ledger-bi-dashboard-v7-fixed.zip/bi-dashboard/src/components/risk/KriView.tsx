import { useRisk } from '../../state/RiskContext';
import { computeKriStatus } from '../../risk/kri';
import { KriStatus } from '../../risk/types';

const STATUS_STYLES: Record<KriStatus, string> = {
  Normal: 'bg-emerald-soft text-emerald',
  Watch: 'bg-slateblue-soft text-slateblue',
  Warning: 'bg-amber-soft text-amber',
  Critical: 'bg-rust-soft text-rust',
  'No Data': 'bg-base text-ink-faint',
};

export function KriView() {
  const { kris } = useRisk();

  if (kris.length === 0) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">No KRIs defined yet. Load demo risk data from the Risk Register tab, or add KRIs (coming from your own data sources).</p>;
  }

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {kris.map((k) => {
        const status = computeKriStatus(k);
        return (
          <div key={k.id} className="rounded border border-line bg-surface p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-ink">{k.name}</p>
              <span className={`rounded-sm px-1.5 py-0.5 text-[11px] ${STATUS_STYLES[status]}`}>{status}</span>
            </div>
            <p className="mt-1 text-xs text-ink-faint">{k.metric}</p>
            <p className="mt-2 font-serif text-2xl tabular text-ink">{k.currentValue === null ? 'n/a' : k.currentValue}</p>
            <p className="mt-1 text-xs text-ink-faint">
              Warning: {k.warningLevel} · Critical: {k.criticalLevel} · Direction: {k.direction === 'higherIsWorse' ? 'higher is worse' : 'lower is worse'}
            </p>
            <p className="mt-1 text-xs text-ink-faint">
              Owner: {k.owner || '—'} · {k.frequency} · Source: {k.sourceDataset}
            </p>
          </div>
        );
      })}
    </div>
  );
}
