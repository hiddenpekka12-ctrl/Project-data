import { ReactNode, useState } from 'react';
import { BusinessProblem, ScoringCriterion, SolutionOption, Assumption } from '../../problemSolver/types';
import { generateSolutionSuggestions } from '../../problemSolver/solutionGeneration';
import { computeOptionScore, DEFAULT_SCORING_CRITERIA, rankOptions } from '../../problemSolver/optionScoring';
import { LearnThis } from '../analytics/LearnThis';

export function OptionsStep({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const [options, setOptions] = useState<SolutionOption[]>(problem.options);
  const [criteria] = useState<ScoringCriterion[]>(problem.scoringCriteria.length ? problem.scoringCriteria : DEFAULT_SCORING_CRITERIA);
  const [rawScores, setRawScores] = useState<Record<string, Record<string, number>>>({});
  const [assumptions, setAssumptions] = useState<Assumption[]>(problem.assumptions);

  const suggestions = generateSolutionSuggestions(problem.fishbone);
  const scored = rankOptions(options.map((o) => computeOptionScore(o.id, rawScores[o.id] ?? {}, criteria)));

  const addOption = (description: string) => {
    const option: SolutionOption = {
      id: `opt-${Date.now()}`,
      description,
      causeAddressed: '',
      expectedBenefit: '',
      estimatedCost: 0,
      implementationTimeWeeks: 4,
      risk: 'Unknown',
      complexity: 'Medium',
      resourcesRequired: '',
      dependencies: '',
      reversibility: 'Easily reversible',
      expectedRoiPct: null,
      confidence: 'Medium',
      assumptions: '',
    };
    setOptions([...options, option]);
  };

  return (
    <div className="space-y-4">
      {suggestions.some((s) => s.suggestions.length > 0) && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Suggested solutions (derived from logged causes only)</p>
          {suggestions.filter((s) => s.suggestions.length > 0).map((s) => (
            <div key={s.cause} className="mb-2">
              <p className="text-xs text-ink-faint">For cause: "{s.cause}"</p>
              <div className="mt-1 flex flex-wrap gap-2">
                {s.suggestions.map((sug) => (
                  <button key={sug} onClick={() => addOption(sug)} className="rounded-full border border-line px-2.5 py-1 text-xs text-ink-soft hover:border-emerald hover:text-emerald">
                    + {sug}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Options</p>
        <div className="space-y-3">
          {options.map((o, i) => (
            <div key={o.id} className="rounded border border-line/60 p-3">
              <input
                value={o.description}
                onChange={(e) => {
                  const next = [...options];
                  next[i] = { ...o, description: e.target.value };
                  setOptions(next);
                }}
                className="mb-2 w-full rounded border border-line bg-base px-2 py-1.5 text-sm font-medium"
              />
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <MiniField label="Cost">
                  <input type="number" value={o.estimatedCost} onChange={(e) => updateOption(options, setOptions, i, { estimatedCost: Number(e.target.value) })} className="w-full rounded border border-line bg-base px-2 py-1 text-xs" />
                </MiniField>
                <MiniField label="Weeks">
                  <input type="number" value={o.implementationTimeWeeks} onChange={(e) => updateOption(options, setOptions, i, { implementationTimeWeeks: Number(e.target.value) })} className="w-full rounded border border-line bg-base px-2 py-1 text-xs" />
                </MiniField>
                <MiniField label="Complexity">
                  <select value={o.complexity} onChange={(e) => updateOption(options, setOptions, i, { complexity: e.target.value as SolutionOption['complexity'] })} className="w-full rounded border border-line bg-base px-2 py-1 text-xs">
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </MiniField>
                <MiniField label="Reversibility">
                  <select value={o.reversibility} onChange={(e) => updateOption(options, setOptions, i, { reversibility: e.target.value as SolutionOption['reversibility'] })} className="w-full rounded border border-line bg-base px-2 py-1 text-xs">
                    <option>Easily reversible</option>
                    <option>Difficult to reverse</option>
                    <option>Irreversible</option>
                  </select>
                </MiniField>
              </div>
              <p className="mt-2 text-xs font-medium text-ink-soft">Score each criterion 0-10:</p>
              <div className="mt-1 grid grid-cols-3 gap-2 sm:grid-cols-6">
                {criteria.map((c) => (
                  <label key={c.key} className="text-xs">
                    <span className="mb-0.5 block text-ink-faint">{c.label}</span>
                    <input
                      type="number"
                      min={0}
                      max={10}
                      value={rawScores[o.id]?.[c.key] ?? 5}
                      onChange={(e) => setRawScores((prev) => ({ ...prev, [o.id]: { ...prev[o.id], [c.key]: Number(e.target.value) } }))}
                      className="w-full rounded border border-line bg-base px-1.5 py-1"
                    />
                  </label>
                ))}
              </div>
            </div>
          ))}
          {options.length === 0 && <p className="text-sm text-ink-faint">No options yet. Add suggestions above, or add one manually.</p>}
        </div>
        <button onClick={() => addOption('')} className="mt-2 rounded border border-line px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
          + Add option manually
        </button>
      </div>

      {options.length > 0 && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="flex items-center text-sm font-medium text-ink">
            Decision Matrix — Weighted Score = Σ(Weight × Score)
            <LearnThis conceptKey="decisionMatrix" />
          </p>
          <div className="mt-2 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-line text-ink-faint">
                  <th className="px-2 py-1.5 font-normal">Option</th>
                  {criteria.map((c) => (
                    <th key={c.key} className="px-2 py-1.5 font-normal">
                      {c.label} ({(c.weight * 100).toFixed(0)}%)
                    </th>
                  ))}
                  <th className="px-2 py-1.5 font-normal">Weighted Score</th>
                </tr>
              </thead>
              <tbody>
                {scored.map((s) => {
                  const option = options.find((o) => o.id === s.optionId);
                  return (
                    <tr key={s.optionId} className="border-b border-line/60 last:border-0">
                      <td className="px-2 py-1.5 text-ink">{option?.description || '(untitled)'}</td>
                      {criteria.map((c) => (
                        <td key={c.key} className="px-2 py-1.5 tabular text-ink-soft">
                          {s.scores[c.key] ?? 5}
                        </td>
                      ))}
                      <td className="px-2 py-1.5 tabular font-medium text-ink">{s.weightedTotal.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Assumption Register</p>
        <AssumptionEditor assumptions={assumptions} setAssumptions={setAssumptions} />
      </div>

      <button
        onClick={() => onUpdate({ options, scoringCriteria: criteria, optionScores: scored, assumptions, status: 'Decision Pending' })}
        className="rounded border border-emerald bg-emerald-soft px-4 py-1.5 text-sm text-emerald"
      >
        Save options & move to Decision
      </button>
    </div>
  );
}

function updateOption(options: SolutionOption[], setOptions: (o: SolutionOption[]) => void, i: number, updates: Partial<SolutionOption>) {
  const next = [...options];
  next[i] = { ...next[i], ...updates };
  setOptions(next);
}

function MiniField({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-xs">
      <span className="mb-0.5 block text-ink-faint">{label}</span>
      {children}
    </label>
  );
}

function AssumptionEditor({ assumptions, setAssumptions }: { assumptions: Assumption[]; setAssumptions: (a: Assumption[]) => void }) {
  const [draft, setDraft] = useState('');
  return (
    <div>
      <div className="flex gap-2">
        <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder='e.g. "Assume gross margin remains at 30%"' className="flex-1 rounded border border-line bg-base px-2 py-1.5 text-sm" />
        <button
          onClick={() => {
            if (!draft.trim()) return;
            setAssumptions([...assumptions, { id: `assum-${Date.now()}`, description: draft, value: '', source: '', confidence: 'Medium', financialImpact: '', riskImpact: '', validationStatus: 'Unvalidated' }]);
            setDraft('');
          }}
          className="rounded border border-line bg-base px-3 py-1.5 text-sm text-ink-soft hover:bg-line/40"
        >
          + Add
        </button>
      </div>
      <div className="mt-2 space-y-2">
        {assumptions.map((a, i) => (
          <div key={a.id} className="flex items-center justify-between gap-2 rounded border border-line/60 p-2 text-sm">
            <span className="text-ink-soft">{a.description}</span>
            <select
              value={a.validationStatus}
              onChange={(e) => {
                const next = [...assumptions];
                next[i] = { ...a, validationStatus: e.target.value as Assumption['validationStatus'] };
                setAssumptions(next);
              }}
              className="rounded border border-line bg-base px-2 py-1 text-xs"
            >
              <option value="Unvalidated">Unvalidated</option>
              <option value="Validated">Validated</option>
              <option value="Invalidated">Invalidated</option>
            </select>
          </div>
        ))}
      </div>
    </div>
  );
}
