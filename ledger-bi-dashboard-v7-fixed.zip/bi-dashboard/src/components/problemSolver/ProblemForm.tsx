import { ReactNode, useState } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { BusinessProblem, PROBLEM_CATEGORIES, ProblemCategory, Priority } from '../../problemSolver/types';

export function ProblemForm({ problem, onSave, onCancel }: { problem: BusinessProblem; onSave: (p: BusinessProblem) => void; onCancel: () => void }) {
  const { datasets } = useDatasets();
  const [draft, setDraft] = useState<BusinessProblem>(problem);
  const set = <K extends keyof BusinessProblem>(key: K, value: BusinessProblem[K]) => setDraft((prev) => ({ ...prev, [key]: value }));

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="mb-3 text-sm font-medium text-ink">New Business Problem</p>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Field label="Title" wide>
          <input value={draft.title} onChange={(e) => set('title', e.target.value)} placeholder='e.g. "Monthly revenue declined 18% over the last three months"' className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
        </Field>
        <Field label="Category">
          <select value={draft.category} onChange={(e) => set('category', e.target.value as ProblemCategory)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            {PROBLEM_CATEGORIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="Priority">
          <select value={draft.priority} onChange={(e) => set('priority', e.target.value as Priority)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            {(['Critical', 'High', 'Medium', 'Low'] as Priority[]).map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </Field>
        <Field label="Business Unit"><input value={draft.businessUnit} onChange={(e) => set('businessUnit', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Department"><input value={draft.department} onChange={(e) => set('department', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Owner"><input value={draft.owner} onChange={(e) => set('owner', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Date Identified"><input type="date" value={draft.dateIdentified} onChange={(e) => set('dateIdentified', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Time Period"><input value={draft.timePeriod} onChange={(e) => set('timePeriod', e.target.value)} placeholder="e.g. Q2 2026" className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        <Field label="Available Dataset">
          <select value={draft.datasetId ?? ''} onChange={(e) => set('datasetId', e.target.value || null)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            <option value="">None selected</option>
            {datasets.map((d) => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
        </Field>
        <Field label="Description" wide>
          <textarea value={draft.description} onChange={(e) => set('description', e.target.value)} rows={2} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
        </Field>
        <Field label="Target Outcome" wide>
          <input value={draft.targetOutcome} onChange={(e) => set('targetOutcome', e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
        </Field>
      </div>
      <div className="mt-4 flex gap-2">
        <button onClick={() => onSave(draft)} disabled={!draft.title.trim()} className="rounded border border-emerald bg-emerald-soft px-4 py-1.5 text-sm text-emerald disabled:opacity-40">
          Save & Start Diagnosis
        </button>
        <button onClick={onCancel} className="rounded border border-line px-4 py-1.5 text-sm text-ink-soft hover:bg-base">
          Cancel
        </button>
      </div>
    </div>
  );
}

function Field({ label, children, wide }: { label: string; children: ReactNode; wide?: boolean }) {
  return (
    <label className={`block ${wide ? 'sm:col-span-2 lg:col-span-3' : ''}`}>
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      {children}
    </label>
  );
}
