import { ReactNode, useState } from 'react';
import { BusinessProblem, ProblemStatement } from '../../problemSolver/types';

export function DefineStep({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const [statement, setStatement] = useState<ProblemStatement>(
    problem.statement ?? { currentState: '', expectedState: '', gapDescription: '', timePeriod: problem.timePeriod, scope: '' }
  );

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Problem Statement Framework</p>
        <p className="mb-3 text-xs text-ink-faint">
          Turn a vague problem ("Sales are poor") into a structured one ("Monthly revenue declined 18% over the last three months compared with the previous three-month period").
        </p>
        <div className="space-y-3">
          <Field label="Current State — what is happening?">
            <textarea value={statement.currentState} onChange={(e) => setStatement({ ...statement, currentState: e.target.value })} rows={2} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </Field>
          <Field label="Expected State — what should happen?">
            <textarea value={statement.expectedState} onChange={(e) => setStatement({ ...statement, expectedState: e.target.value })} rows={2} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </Field>
          <Field label="Gap (Current − Expected)">
            <input value={statement.gapDescription} onChange={(e) => setStatement({ ...statement, gapDescription: e.target.value })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </Field>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Field label="Time Period">
              <input value={statement.timePeriod} onChange={(e) => setStatement({ ...statement, timePeriod: e.target.value })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
            </Field>
            <Field label="Scope (product/customer/region/channel/process)">
              <input value={statement.scope} onChange={(e) => setStatement({ ...statement, scope: e.target.value })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
            </Field>
          </div>
        </div>
        <button
          onClick={() => onUpdate({ statement, status: problem.status === 'New' ? 'Data Collection' : problem.status })}
          className="mt-3 rounded border border-emerald bg-emerald-soft px-3 py-1.5 text-xs text-emerald"
        >
          Save statement
        </button>
      </div>

      {problem.statement && (
        <div className="rounded border border-emerald/30 bg-emerald-soft p-4 text-sm text-emerald">
          <p className="font-medium">Structured statement</p>
          <p className="mt-1 text-ink-soft">
            {problem.statement.currentState || '(current state not set)'} — expected: {problem.statement.expectedState || '(not set)'}. Gap: {problem.statement.gapDescription || '(not set)'}.
          </p>
        </div>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      {children}
    </label>
  );
}
