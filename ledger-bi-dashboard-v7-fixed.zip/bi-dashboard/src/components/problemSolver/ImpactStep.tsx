import { useMemo } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { useFinance } from '../../state/FinanceContext';
import { useRisk } from '../../state/RiskContext';
import { buildFinanceModel } from '../../finance/buildFinanceModel';
import { buildRiskModel } from '../../risk/buildRiskModel';
import { estimateFinancialImpact } from '../../problemSolver/financialImpact';
import { findRiskImpact } from '../../problemSolver/riskImpact';
import { BusinessProblem } from '../../problemSolver/types';
import { formatCurrency } from '../../lib/format';

export function ImpactStep({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const { datasets, activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const { registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings } = useRisk();

  // Only the currently active dataset carries full row data in this app's
  // architecture (DatasetContext exposes one active Dataset at a time,
  // plus lightweight metadata for the rest). So Impact analysis always
  // runs against activeDataset, with an explicit note if that doesn't
  // match whatever dataset this problem was linked to.
  const linkedDatasetMeta = problem.datasetId ? datasets.find((d) => d.id === problem.datasetId) : null;
  const datasetMismatch = problem.datasetId !== null && problem.datasetId !== activeDataset.id;

  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);
  const current = financeModel.periods[financeModel.periods.length - 1] ?? null;
  const previous = financeModel.periods.length > 1 ? financeModel.periods[financeModel.periods.length - 2] : null;

  const revenueColumn = useMemo(() => Object.entries(mapping).find(([, cat]) => cat === 'revenue')?.[0] ?? null, [mapping]);
  const categoricalColumns = useMemo(() => activeDataset.columns.filter((c) => activeDataset.columnTypes[c] === 'categorical'), [activeDataset.columns, activeDataset.columnTypes]);
  const riskModel = useMemo(
    () => buildRiskModel(registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings, financeModel.periods, activeDataset.cleanedRows, categoricalColumns, revenueColumn),
    [registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings, financeModel.periods, activeDataset.cleanedRows, categoricalColumns, revenueColumn]
  );
  const riskImpact = findRiskImpact(problem.category, riskModel, kris);

  const canEstimate = current !== null && previous !== null;

  return (
    <div className="space-y-4">
      {datasetMismatch && (
        <p className="rounded border border-amber/30 bg-amber-soft px-3 py-2 text-xs text-amber">
          This problem is linked to "{linkedDatasetMeta?.name ?? problem.datasetId}", but Financial/Risk Impact below reflects the currently active dataset, "{activeDataset.name}
          ". Switch datasets via Analytics or Finance if you need the linked one specifically.
        </p>
      )}
      <div className="rounded border border-line bg-surface p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-ink">Financial Impact (from V3 Finance Engine)</p>
          <button
            disabled={!canEstimate}
            onClick={() => current && previous && onUpdate({ financialImpacts: estimateFinancialImpact(current, previous, problem.statement?.gapDescription ?? '') })}
            className="rounded border border-line bg-base px-3 py-1.5 text-xs text-ink-soft hover:bg-line/40 disabled:opacity-40"
          >
            Estimate from {activeDataset.name}
          </button>
        </div>
        {!canEstimate && <p className="mt-2 text-sm text-ink-faint">Need at least two periods of Finance Engine data for this dataset (map accounts in the Finance Center first).</p>}
        {problem.financialImpacts.length > 0 && (
          <div className="mt-3 space-y-2">
            {problem.financialImpacts.map((f, i) => (
              <div key={i} className="rounded border border-line/60 p-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-ink-soft">{f.metric}</span>
                  <span className={`tabular font-medium ${f.estimatedImpact >= 0 ? 'text-emerald' : 'text-rust'}`}>{formatCurrency(f.estimatedImpact)}</span>
                </div>
                <p className="mt-1 text-xs text-ink-faint">{f.method}</p>
                {f.assumptions.map((a, j) => (
                  <p key={j} className="text-xs italic text-amber">
                    Assumption: {a}
                  </p>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="text-sm font-medium text-ink">Risk Impact (from V4 Risk Engine)</p>
        <p className="mt-1 text-xs text-ink-faint">
          {riskImpact.relatedRisks.length} related risk(s), {riskImpact.relatedKris.length} related KRI(s), {riskImpact.activeFinancialSignalCount} active financial signal(s).
        </p>
        {riskImpact.relatedRisks.length > 0 && (
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-ink-soft">
            {riskImpact.relatedRisks.map((r) => (
              <li key={r.id}>{r.name} — {r.status}</li>
            ))}
          </ul>
        )}
        {riskImpact.relatedKris.length > 0 && (
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-ink-soft">
            {riskImpact.relatedKris.map(({ kri, status }) => (
              <li key={kri.id}>
                {kri.name}: {status}
              </li>
            ))}
          </ul>
        )}
        {riskImpact.relatedRisks.length === 0 && riskImpact.relatedKris.length === 0 && <p className="mt-2 text-sm text-ink-faint">No related risks or KRIs found for this category in the current register.</p>}
      </div>
    </div>
  );
}
