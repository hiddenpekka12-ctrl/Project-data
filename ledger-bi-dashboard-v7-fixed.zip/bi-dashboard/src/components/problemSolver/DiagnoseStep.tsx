import { useState } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { buildParetoAnalysis } from '../../problemSolver/pareto';
import { questionsFor, rootCausesFor } from '../../problemSolver/diagnosticQuestions';
import { BusinessProblem, ConfidenceLevel, FishboneCause, FiveWhysStep, FISHBONE_CATEGORIES } from '../../problemSolver/types';
import { LearnThis } from '../analytics/LearnThis';

const CONFIDENCE_OPTIONS: ConfidenceLevel[] = ['High', 'Medium', 'Low'];

export function DiagnoseStep({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const [subtab, setSubtab] = useState<'questions' | 'fivewhys' | 'fishbone' | 'pareto'>('questions');
  const questions = questionsFor(problem.category);
  const rootCauses = rootCausesFor(problem.category);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-1">
        {(['questions', 'fivewhys', 'fishbone', 'pareto'] as const).map((t) => (
          <button key={t} onClick={() => setSubtab(t)} className={`rounded px-3 py-1.5 text-xs ${subtab === t ? 'bg-emerald-soft text-emerald' : 'bg-surface text-ink-faint'}`}>
            {t === 'questions' ? 'Diagnostic Questions' : t === 'fivewhys' ? '5 Whys' : t === 'fishbone' ? 'Fishbone' : 'Pareto'}
          </button>
        ))}
      </div>

      {subtab === 'questions' && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Guided questions for {problem.category}</p>
          <ul className="list-disc space-y-1 pl-5 text-sm text-ink-soft">
            {questions.map((q) => (
              <li key={q}>{q}</li>
            ))}
          </ul>
          {rootCauses.length > 0 && (
            <>
              <p className="mb-1 mt-3 text-xs font-medium text-ink-soft">Root Cause Library for {problem.category} (a starting taxonomy, not a substitute for evidence)</p>
              <div className="flex flex-wrap gap-1">
                {rootCauses.map((c) => (
                  <span key={c} className="rounded-full border border-line px-2 py-0.5 text-[11px] text-ink-faint">
                    {c}
                  </span>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {subtab === 'fivewhys' && <FiveWhysEditor problem={problem} onUpdate={onUpdate} />}
      {subtab === 'fishbone' && <FishboneEditor problem={problem} onUpdate={onUpdate} />}
      {subtab === 'pareto' && <ParetoEditor problem={problem} onUpdate={onUpdate} />}
    </div>
  );
}

function FiveWhysEditor({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const [steps, setSteps] = useState<FiveWhysStep[]>(problem.fiveWhys.length ? problem.fiveWhys : [{ level: 1, question: `Why: ${problem.title}?`, answer: '', evidence: '', confidence: 'Low', notes: '' }]);

  const update = (i: number, updates: Partial<FiveWhysStep>) => {
    const next = [...steps];
    next[i] = { ...next[i], ...updates };
    setSteps(next);
  };

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="flex items-center text-sm font-medium text-ink">
        5 Whys
        <LearnThis conceptKey="fiveWhys" />
      </p>
      <p className="mb-3 text-xs text-ink-faint">Not forced to exactly five — stop when you reach evidence, or add more levels.</p>
      <div className="space-y-3">
        {steps.map((s, i) => (
          <div key={i} className="rounded border border-line/60 p-3">
            <p className="mb-1 text-xs text-ink-faint">Level {s.level}</p>
            <input value={s.question} onChange={(e) => update(i, { question: e.target.value })} placeholder="Why...?" className="mb-2 w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
            <textarea value={s.answer} onChange={(e) => update(i, { answer: e.target.value })} placeholder="Answer" rows={2} className="mb-2 w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <input value={s.evidence} onChange={(e) => update(i, { evidence: e.target.value })} placeholder="Evidence" className="rounded border border-line bg-base px-2 py-1.5 text-xs" />
              <select value={s.confidence} onChange={(e) => update(i, { confidence: e.target.value as ConfidenceLevel })} className="rounded border border-line bg-base px-2 py-1.5 text-xs">
                {CONFIDENCE_OPTIONS.map((c) => (
                  <option key={c} value={c}>{c} confidence</option>
                ))}
              </select>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        {steps.length < 8 && (
          <button
            onClick={() => setSteps([...steps, { level: steps.length + 1, question: '', answer: '', evidence: '', confidence: 'Low', notes: '' }])}
            className="rounded border border-line px-3 py-1.5 text-xs text-ink-soft hover:bg-base"
          >
            + Add level
          </button>
        )}
        <button onClick={() => onUpdate({ fiveWhys: steps })} className="rounded border border-emerald bg-emerald-soft px-3 py-1.5 text-xs text-emerald">
          Save 5 Whys
        </button>
      </div>
    </div>
  );
}

function FishboneEditor({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const [causes, setCauses] = useState<FishboneCause[]>(problem.fishbone);
  const [draft, setDraft] = useState<Omit<FishboneCause, 'id'>>({ category: 'People', cause: '', evidence: '', confidence: 'Low', impact: 'Medium', status: 'Potential Cause' });

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="mb-3 text-sm font-medium text-ink">Fishbone (Ishikawa) Analysis</p>
      <div className="mb-3 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-5">
        <select value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value })} className="rounded border border-line bg-base px-2 py-1.5 text-xs">
          {FISHBONE_CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <input value={draft.cause} onChange={(e) => setDraft({ ...draft, cause: e.target.value })} placeholder="Cause" className="rounded border border-line bg-base px-2 py-1.5 text-xs lg:col-span-2" />
        <input value={draft.evidence} onChange={(e) => setDraft({ ...draft, evidence: e.target.value })} placeholder="Evidence" className="rounded border border-line bg-base px-2 py-1.5 text-xs" />
        <button
          onClick={() => {
            if (!draft.cause.trim()) return;
            setCauses([...causes, { ...draft, id: `fb-${Date.now()}` }]);
            setDraft({ category: 'People', cause: '', evidence: '', confidence: 'Low', impact: 'Medium', status: 'Potential Cause' });
          }}
          className="rounded border border-line bg-base px-2 py-1.5 text-xs text-ink-soft hover:bg-line/40"
        >
          + Add cause
        </button>
      </div>
      <div className="space-y-2">
        {causes.map((c, i) => (
          <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded border border-line/60 p-2 text-sm">
            <span className="text-ink-soft">
              <strong className="text-ink">[{c.category}]</strong> {c.cause} — <span className="text-xs text-ink-faint">{c.evidence}</span>
            </span>
            <select
              value={c.status}
              onChange={(e) => {
                const next = [...causes];
                next[i] = { ...c, status: e.target.value as FishboneCause['status'] };
                setCauses(next);
              }}
              className="rounded border border-line bg-base px-2 py-1 text-xs"
            >
              <option value="Potential Cause">Potential Cause</option>
              <option value="Confirmed Root Cause">Confirmed Root Cause</option>
              <option value="Ruled Out">Ruled Out</option>
            </select>
          </div>
        ))}
        {causes.length === 0 && <p className="text-sm text-ink-faint">No causes logged yet.</p>}
      </div>
      <button onClick={() => onUpdate({ fishbone: causes })} className="mt-3 rounded border border-emerald bg-emerald-soft px-3 py-1.5 text-xs text-emerald">
        Save Fishbone
      </button>
    </div>
  );
}

function ParetoEditor({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const { activeDataset, datasets } = useDatasets();
  const [dimension, setDimension] = useState('');
  const [measure, setMeasure] = useState('');

  if (!problem.datasetId) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">Link a dataset to this problem (in Edit) to run a Pareto analysis.</p>;
  }

  const linkedDatasetMeta = datasets.find((d) => d.id === problem.datasetId);
  if (problem.datasetId !== activeDataset.id) {
    return (
      <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">
        This problem is linked to "{linkedDatasetMeta?.name ?? problem.datasetId}", but the currently active dataset (used for Pareto/Impact analysis throughout the app) is "
        {activeDataset.name}". Switch to it via Analytics or Finance's dataset switcher, then return here to run this analysis.
      </p>
    );
  }

  const dataset = activeDataset;
  const categoricalCols = dataset.columns.filter((c) => dataset.columnTypes[c] === 'categorical');
  const numericCols = dataset.columns.filter((c) => dataset.columnTypes[c] === 'numeric');

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="flex items-center text-sm font-medium text-ink">
        Pareto Analysis
        <LearnThis conceptKey="paretoPrinciple" />
      </p>
      <div className="mt-2 flex flex-wrap gap-2">
        <select value={dimension} onChange={(e) => setDimension(e.target.value)} className="rounded border border-line bg-base px-2 py-1.5 text-sm">
          <option value="">Dimension…</option>
          {categoricalCols.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <select value={measure} onChange={(e) => setMeasure(e.target.value)} className="rounded border border-line bg-base px-2 py-1.5 text-sm">
          <option value="">Measure…</option>
          {numericCols.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <button
          disabled={!dimension || !measure}
          onClick={() => {
            const result = buildParetoAnalysis(dataset.cleanedRows, dimension, measure);
            onUpdate({ paretoResults: [...problem.paretoResults.filter((r) => r.dimension !== dimension || r.measure !== measure), result] });
          }}
          className="rounded border border-line bg-base px-3 py-1.5 text-sm text-ink-soft hover:bg-line/40 disabled:opacity-40"
        >
          Run Pareto
        </button>
      </div>

      {problem.paretoResults.map((result) => (
        <div key={`${result.dimension}-${result.measure}`} className="mt-4 border-t border-line pt-3">
          <p className="text-sm text-ink-soft">
            {result.measure} by {result.dimension}: top {result.top20PctItemCount} of {result.items.length} categories drive {result.top20PctCumulativeShare.toFixed(1)}% of the total.
          </p>
          <p className={`mt-1 text-xs ${result.followsEightyTwenty ? 'text-emerald' : 'text-ink-faint'}`}>
            {result.followsEightyTwenty ? 'This follows an 80/20-like pattern.' : 'This does not clearly follow an 80/20 pattern — the contribution is more evenly spread.'}
          </p>
          <div className="mt-2 max-h-40 overflow-y-auto text-xs">
            {result.items.slice(0, 10).map((item) => (
              <div key={item.key} className="flex justify-between border-b border-line/60 py-1">
                <span className="text-ink-soft">{item.key}</span>
                <span className="tabular text-ink-faint">
                  {item.percentage.toFixed(1)}% (cum. {item.cumulativePercentage.toFixed(1)}%)
                </span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
