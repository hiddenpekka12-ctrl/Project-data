import { useState } from 'react';
import { BusinessProblem } from '../../problemSolver/types';
import { computeDataSufficiency, computeDecisionConfidence } from '../../problemSolver/decisionConfidence';
import { rankOptions } from '../../problemSolver/optionScoring';

type Mode = 'ceo' | 'consultant' | 'analyst';

export function ManagementSummaryView({ problem }: { problem: BusinessProblem }) {
  const [mode, setMode] = useState<Mode>('ceo');
  const sufficiency = computeDataSufficiency(problem);
  const confidence = computeDecisionConfidence(problem);
  const ranked = rankOptions(problem.optionScores);
  const topOption = problem.options.find((o) => o.id === ranked[0]?.optionId) ?? null;
  const confirmedCauses = problem.fishbone.filter((f) => f.status === 'Confirmed Root Cause');
  const potentialCauses = problem.fishbone.filter((f) => f.status === 'Potential Cause');
  const topImpact = problem.financialImpacts[0] ?? null;

  return (
    <div className="space-y-4">
      <div className="flex gap-1">
        {(['ceo', 'consultant', 'analyst'] as Mode[]).map((m) => (
          <button key={m} onClick={() => setMode(m)} className={`rounded px-3 py-1.5 text-xs capitalize ${mode === m ? 'bg-emerald-soft text-emerald' : 'bg-surface text-ink-faint'}`}>
            {m} mode
          </button>
        ))}
      </div>
      <p className="text-xs text-ink-faint">
        These three modes read the same underlying diagnosis, options, and decision data — they only change what's emphasized, not the calculation behind any of it.
      </p>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 font-serif text-lg text-ink">Executive Summary</p>
        <dl className="space-y-2 text-sm">
          <Row label="Problem" value={problem.title} />
          <Row label="Magnitude" value={problem.statement?.gapDescription || 'Not yet quantified'} />
          <Row label="Root Cause" value={confirmedCauses.length ? confirmedCauses.map((c) => c.cause).join('; ') : potentialCauses.length ? `${potentialCauses.map((c) => c.cause).join('; ')} (potential, not confirmed)` : 'Not yet diagnosed'} />
          <Row label="Financial Impact" value={topImpact ? `${topImpact.metric}: ${topImpact.estimatedImpact.toFixed(0)}` : 'Not yet quantified'} />
          <Row label="Best Option" value={topOption?.description || 'No options compared yet'} />
          <Row label="Expected Benefit" value={topOption?.expectedBenefit || 'Not specified'} />
          <Row label="Required Action" value={problem.actionPlan[0]?.action || 'No action plan yet'} />
          <Row label="KPI" value={problem.actionPlan[0]?.kpiName || 'Not specified'} />
          <Row label="Review Date" value={problem.decision?.reviewDate || 'Not scheduled'} />
        </dl>
      </div>

      {mode === 'ceo' && (
        <div className="rounded border border-slateblue/30 bg-slateblue-soft p-4 text-sm text-slateblue">
          <p className="font-medium">This week</p>
          <p className="mt-1">
            {topOption ? `Decide on: "${topOption.description}".` : 'No decision-ready option yet — more diagnosis needed.'}{' '}
            {problem.actionPlan.length > 0 ? `Watch: ${problem.actionPlan[0].kpiName || 'the linked KPI'}.` : ''}
          </p>
          <p className="mt-2 text-xs">Decision confidence: {confidence.level} · Data sufficiency: {sufficiency.pct}% ({sufficiency.label})</p>
        </div>
      )}

      {mode === 'consultant' && (
        <div className="rounded border border-line bg-surface p-4 text-sm text-ink-soft">
          <p className="font-medium text-ink">MECE issue tree status</p>
          <p className="mt-1">Confirmed causes: {confirmedCauses.length} · Potential causes under investigation: {potentialCauses.length}</p>
          <p className="mt-2">Hypothesis-driven analysis: {problem.fiveWhys.length} levels of 5 Whys logged, {problem.fishbone.length} fishbone causes captured.</p>
          <p className="mt-2">Options evaluated: {problem.options.length}, scored against {problem.scoringCriteria.length || 'default'} weighted criteria.</p>
        </div>
      )}

      {mode === 'analyst' && (
        <div className="rounded border border-line bg-surface p-4 text-sm text-ink-soft">
          <p className="font-medium text-ink">Data behind this analysis</p>
          <p className="mt-1">Dataset linked: {problem.datasetId ? 'Yes' : 'No'} · Pareto analyses run: {problem.paretoResults.length}</p>
          <p className="mt-2">Data sufficiency: {sufficiency.pct}% ({sufficiency.label}) — a heuristic based on how many diagnostic steps have been completed, not a statistical measure.</p>
          <p className="mt-2">Limitations: correlation-based findings are not treated as causal without confirmed evidence; unvalidated assumptions: {problem.assumptions.filter((a) => a.validationStatus === 'Unvalidated').length}.</p>
        </div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <dt className="w-32 shrink-0 text-ink-faint">{label}</dt>
      <dd className="text-right text-ink">{value}</dd>
    </div>
  );
}
