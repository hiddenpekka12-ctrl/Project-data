import { useState } from 'react';
import { useRisk } from '../../state/RiskContext';
import { ActionPlanItem, ActionStatus, BusinessProblem, Priority } from '../../problemSolver/types';

export function ActionStep({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const { kris } = useRisk();
  const [actions, setActions] = useState<ActionPlanItem[]>(problem.actionPlan);
  const today = new Date().toISOString().slice(0, 10);

  const addAction = () => {
    setActions([
      ...actions,
      {
        id: `action-${Date.now()}`,
        action: '',
        owner: '',
        priority: 'Medium',
        startDate: today,
        dueDate: '',
        dependency: '',
        status: 'Not Started',
        progressPct: 0,
        kpiName: '',
        kpiBaseline: null,
        kpiTarget: null,
        kpiCurrent: null,
        linkedKriId: null,
      },
    ]);
  };

  const update = (i: number, updates: Partial<ActionPlanItem>) => {
    const next = [...actions];
    next[i] = { ...next[i], ...updates };
    setActions(next);
  };

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Action Plan</p>
        <div className="space-y-3">
          {actions.map((a, i) => {
            const isOverdue = a.status !== 'Completed' && a.status !== 'Cancelled' && a.dueDate && a.dueDate < today;
            return (
              <div key={a.id} className={`rounded border p-3 ${isOverdue ? 'border-rust/40 bg-rust-soft/40' : 'border-line/60'}`}>
                <input value={a.action} onChange={(e) => update(i, { action: e.target.value })} placeholder="Action" className="mb-2 w-full rounded border border-line bg-base px-2 py-1.5 text-sm font-medium" />
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  <input value={a.owner} onChange={(e) => update(i, { owner: e.target.value })} placeholder="Owner" className="rounded border border-line bg-base px-2 py-1 text-xs" />
                  <select value={a.priority} onChange={(e) => update(i, { priority: e.target.value as Priority })} className="rounded border border-line bg-base px-2 py-1 text-xs">
                    {(['Critical', 'High', 'Medium', 'Low'] as Priority[]).map((p) => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                  <input type="date" value={a.dueDate} onChange={(e) => update(i, { dueDate: e.target.value })} className="rounded border border-line bg-base px-2 py-1 text-xs" />
                  <select value={a.status} onChange={(e) => update(i, { status: e.target.value as ActionStatus })} className="rounded border border-line bg-base px-2 py-1 text-xs">
                    {(['Not Started', 'In Progress', 'Blocked', 'Completed', 'Cancelled'] as ActionStatus[]).map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <p className="mb-1 mt-2 text-xs font-medium text-ink-soft">KPI link</p>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  <input value={a.kpiName} onChange={(e) => update(i, { kpiName: e.target.value })} placeholder="KPI name" className="rounded border border-line bg-base px-2 py-1 text-xs" />
                  <input type="number" value={a.kpiBaseline ?? ''} onChange={(e) => update(i, { kpiBaseline: e.target.value === '' ? null : Number(e.target.value) })} placeholder="Baseline" className="rounded border border-line bg-base px-2 py-1 text-xs" />
                  <input type="number" value={a.kpiTarget ?? ''} onChange={(e) => update(i, { kpiTarget: e.target.value === '' ? null : Number(e.target.value) })} placeholder="Target" className="rounded border border-line bg-base px-2 py-1 text-xs" />
                  <input type="number" value={a.kpiCurrent ?? ''} onChange={(e) => update(i, { kpiCurrent: e.target.value === '' ? null : Number(e.target.value) })} placeholder="Current" className="rounded border border-line bg-base px-2 py-1 text-xs" />
                </div>
                {kris.length > 0 && (
                  <select value={a.linkedKriId ?? ''} onChange={(e) => update(i, { linkedKriId: e.target.value || null })} className="mt-2 w-full rounded border border-line bg-base px-2 py-1 text-xs">
                    <option value="">No linked KRI</option>
                    {kris.map((k) => (
                      <option key={k.id} value={k.id}>{k.name}</option>
                    ))}
                  </select>
                )}
                {isOverdue && <p className="mt-1 text-xs font-medium text-rust">Overdue</p>}
              </div>
            );
          })}
        </div>
        <button onClick={addAction} className="mt-3 rounded border border-line px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
          + Add action
        </button>
      </div>

      <button onClick={() => onUpdate({ actionPlan: actions, status: 'Implementation' })} className="rounded border border-emerald bg-emerald-soft px-4 py-1.5 text-sm text-emerald">
        Save action plan & move to Implementation
      </button>
    </div>
  );
}
