import { ReactNode, useState } from 'react';
import { BusinessProblem, DecisionRecord } from '../../problemSolver/types';
import { computeDecisionConfidence } from '../../problemSolver/decisionConfidence';
import { rankOptions } from '../../problemSolver/optionScoring';

const RED_TEAM_QUESTIONS = [
  'What assumption could be wrong?',
  'What data might be missing?',
  'What alternative explanation exists?',
  'What could cause this recommendation to fail?',
  'What is the downside?',
  'What unintended consequence could occur?',
  'What happens if conditions change?',
];

export function DecisionStep({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const ranked = rankOptions(problem.optionScores);
  const topOption = problem.options.find((o) => o.id === ranked[0]?.optionId) ?? null;
  const confidence = computeDecisionConfidence(problem);

  const [decision, setDecision] = useState<DecisionRecord>(
    problem.decision ?? {
      id: `decision-${Date.now()}`,
      problemId: problem.id,
      date: new Date().toISOString().slice(0, 10),
      decisionMaker: '',
      selectedOptionId: topOption?.id ?? null,
      alternativesConsidered: problem.options.filter((o) => o.id !== topOption?.id).map((o) => o.description),
      reason: '',
      expectedOutcome: '',
      assumptions: problem.assumptions.map((a) => a.description),
      risksAccepted: '',
      actionOwner: '',
      reviewDate: '',
      actualOutcome: '',
      confidence: confidence.level,
      redTeamNotes: '',
    }
  );

  return (
    <div className="space-y-4">
      {topOption && (
        <div className="rounded border border-emerald/30 bg-emerald-soft p-4">
          <p className="text-sm font-medium text-emerald">Recommended Option</p>
          <p className="mt-1 text-sm text-ink">{topOption.description}</p>
          <p className="mt-1 text-xs text-ink-soft">Weighted score: {ranked[0].weightedTotal.toFixed(2)} · Addresses: {topOption.causeAddressed || 'not specified'}</p>
          <p className="mt-2 text-xs text-ink-soft">Expected benefit: {topOption.expectedBenefit || 'not specified'}</p>
          <p className="text-xs text-ink-soft">Expected cost: {topOption.estimatedCost}</p>
          <p className="text-xs text-ink-soft">Key risk: {topOption.risk}</p>
          <p className="text-xs text-ink-soft">Assumptions: {topOption.assumptions || 'none logged'}</p>
        </div>
      )}

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Decision Confidence: {confidence.level}</p>
        <p className="mb-2 text-xs text-ink-faint">Confidence reflects evidence strength, not probability of success.</p>
        {confidence.reasons.length > 0 && (
          <ul className="list-disc space-y-0.5 pl-5 text-xs text-ink-faint">
            {confidence.reasons.map((r, i) => (
              <li key={i}>{r}</li>
            ))}
          </ul>
        )}
      </div>

      <div className="rounded border border-rust/30 bg-rust-soft p-4">
        <p className="text-sm font-medium text-rust">Challenge This Decision (Red Team)</p>
        <p className="mb-2 text-xs text-rust">Mandatory before finalizing — this is essential for senior management decision-making.</p>
        <ul className="list-disc space-y-0.5 pl-5 text-xs text-ink-soft">
          {RED_TEAM_QUESTIONS.map((q) => (
            <li key={q}>{q}</li>
          ))}
        </ul>
        <textarea
          value={decision.redTeamNotes}
          onChange={(e) => setDecision({ ...decision, redTeamNotes: e.target.value })}
          placeholder="Notes addressing the questions above..."
          rows={3}
          className="mt-2 w-full rounded border border-line bg-base px-2 py-1.5 text-sm"
        />
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Decision Log</p>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Decision Maker"><input value={decision.decisionMaker} onChange={(e) => setDecision({ ...decision, decisionMaker: e.target.value })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
          <Field label="Action Owner"><input value={decision.actionOwner} onChange={(e) => setDecision({ ...decision, actionOwner: e.target.value })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
          <Field label="Reason" wide><textarea value={decision.reason} onChange={(e) => setDecision({ ...decision, reason: e.target.value })} rows={2} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
          <Field label="Expected Outcome" wide><input value={decision.expectedOutcome} onChange={(e) => setDecision({ ...decision, expectedOutcome: e.target.value })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
          <Field label="Risks Accepted" wide><input value={decision.risksAccepted} onChange={(e) => setDecision({ ...decision, risksAccepted: e.target.value })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
          <Field label="Review Date"><input type="date" value={decision.reviewDate} onChange={(e) => setDecision({ ...decision, reviewDate: e.target.value })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" /></Field>
        </div>
      </div>

      <button
        onClick={() => onUpdate({ decision: { ...decision, confidence: confidence.level }, status: 'Approved' })}
        className="rounded border border-emerald bg-emerald-soft px-4 py-1.5 text-sm text-emerald"
      >
        Log decision & move to Action Plan
      </button>
    </div>
  );
}

function Field({ label, children, wide }: { label: string; children: ReactNode; wide?: boolean }) {
  return (
    <label className={`block ${wide ? 'sm:col-span-2' : ''}`}>
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      {children}
    </label>
  );
}
