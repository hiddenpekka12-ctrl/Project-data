import { useState } from 'react';
import { BeforeAfterMetric, BusinessProblem, LessonsLearned } from '../../problemSolver/types';

export function MonitorReviewStep({ problem, onUpdate }: { problem: BusinessProblem; onUpdate: (updates: Partial<BusinessProblem>) => void }) {
  const [metrics, setMetrics] = useState<BeforeAfterMetric[]>(problem.beforeAfterMetrics);
  const [lessons, setLessons] = useState<LessonsLearned>(
    problem.lessonsLearned ?? { whatHappened: '', rootCause: '', wrongAssumption: '', actionThatWorked: '', actionThatFailed: '', whatToDoDifferently: '', kpiToMonitorEarlier: '', riskSignalThatCouldHaveHelped: '' }
  );

  const addMetric = () => setMetrics([...metrics, { label: '', before: 0, after: 0 }]);

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Before vs After</p>
        <p className="mb-3 text-xs text-ink-faint">"Change observed after implementation" — not claimed as proven causation unless separately confirmed.</p>
        <div className="space-y-2">
          {metrics.map((m, i) => {
            const change = m.before === 0 ? null : ((m.after - m.before) / Math.abs(m.before)) * 100;
            return (
              <div key={i} className="grid grid-cols-2 items-center gap-2 sm:grid-cols-5">
                <input
                  value={m.label}
                  onChange={(e) => {
                    const next = [...metrics];
                    next[i] = { ...m, label: e.target.value };
                    setMetrics(next);
                  }}
                  placeholder="Metric / KPI"
                  className="rounded border border-line bg-base px-2 py-1.5 text-sm sm:col-span-2"
                />
                <input
                  type="number"
                  value={m.before}
                  onChange={(e) => {
                    const next = [...metrics];
                    next[i] = { ...m, before: Number(e.target.value) };
                    setMetrics(next);
                  }}
                  placeholder="Before"
                  className="rounded border border-line bg-base px-2 py-1.5 text-sm"
                />
                <input
                  type="number"
                  value={m.after}
                  onChange={(e) => {
                    const next = [...metrics];
                    next[i] = { ...m, after: Number(e.target.value) };
                    setMetrics(next);
                  }}
                  placeholder="After"
                  className="rounded border border-line bg-base px-2 py-1.5 text-sm"
                />
                <span className={`tabular text-sm ${change === null ? 'text-ink-faint' : change >= 0 ? 'text-emerald' : 'text-rust'}`}>{change === null ? 'n/a' : `${change >= 0 ? '+' : ''}${change.toFixed(1)}%`}</span>
              </div>
            );
          })}
        </div>
        <button onClick={addMetric} className="mt-2 rounded border border-line px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
          + Add metric
        </button>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Lessons Learned</p>
        <div className="space-y-2">
          {(
            [
              ['whatHappened', 'What happened?'],
              ['rootCause', 'What was the root cause?'],
              ['wrongAssumption', 'Which assumption was wrong?'],
              ['actionThatWorked', 'Which action worked?'],
              ['actionThatFailed', 'Which action failed?'],
              ['whatToDoDifferently', 'What should management do differently next time?'],
              ['kpiToMonitorEarlier', 'Which KPI should be monitored earlier?'],
              ['riskSignalThatCouldHaveHelped', 'Which risk signal could have detected this sooner?'],
            ] as [keyof LessonsLearned, string][]
          ).map(([key, label]) => (
            <label key={key} className="block">
              <span className="mb-1 block text-xs text-ink-faint">{label}</span>
              <input value={lessons[key]} onChange={(e) => setLessons({ ...lessons, [key]: e.target.value })} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
            </label>
          ))}
        </div>
      </div>

      <button
        onClick={() => onUpdate({ beforeAfterMetrics: metrics, lessonsLearned: lessons, status: 'Closed' })}
        className="rounded border border-emerald bg-emerald-soft px-4 py-1.5 text-sm text-emerald"
      >
        Save review & close problem
      </button>
    </div>
  );
}
