import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useProblemSolver } from '../../state/ProblemSolverContext';
import { buildProblemSolverModel } from '../../problemSolver/buildProblemSolverModel';
import { BusinessProblem } from '../../problemSolver/types';

const PIE_COLORS = ['#1F6F54', '#4A5B68', '#A9782E', '#B3452C', '#8A968F', '#2F9E7A', '#6B7F8C'];

export function ProblemSolverHome({ onOpen, onNew }: { onOpen: (id: string) => void; onNew: () => void }) {
  const { problems, loadDemoProblem } = useProblemSolver();
  const model = buildProblemSolverModel(problems);

  const today = new Date().toISOString().slice(0, 10);
  const recent = [...problems].sort((a, b) => (a.dateIdentified < b.dateIdentified ? 1 : -1)).slice(0, 5);
  const active = problems.filter((p) => !['Resolved', 'Closed'].includes(p.status));
  const resolved = problems.filter((p) => ['Resolved', 'Closed'].includes(p.status));
  const highImpact = problems.filter((p) => p.priority === 'Critical' || p.priority === 'High');
  const awaitingDecision = problems.filter((p) => p.status === 'Decision Pending');
  const overdueActionProblems = problems.filter((p) => p.actionPlan.some((a) => a.status !== 'Completed' && a.status !== 'Cancelled' && a.dueDate < today));

  const kpis: { label: string; value: number | string }[] = [
    { label: 'Active Problems', value: model.kpis.activeProblems },
    { label: 'Critical Problems', value: model.kpis.criticalProblems },
    { label: 'High-impact Problems', value: model.kpis.highImpactProblems },
    { label: 'Awaiting Decision', value: model.kpis.problemsAwaitingDecision },
    { label: 'In Implementation', value: model.kpis.problemsInImplementation },
    { label: 'Overdue Actions', value: model.kpis.overdueActions },
    { label: 'Resolved Problems', value: model.kpis.resolvedProblems },
    { label: 'Avg. Resolution Time', value: model.kpis.averageResolutionDays === null ? 'n/a' : `${model.kpis.averageResolutionDays}d` },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex gap-2">
          <button onClick={onNew} className="rounded border border-emerald bg-emerald-soft px-3 py-1.5 text-sm text-emerald">
            + Analyze New Business Problem
          </button>
          {problems.length === 0 && (
            <button onClick={loadDemoProblem} className="rounded border border-line bg-surface px-3 py-1.5 text-sm text-ink-soft hover:bg-base">
              Load demo problem
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {kpis.map((k) => (
          <div key={k.label} className="rounded border border-line bg-surface p-3">
            <p className="text-xs text-ink-faint">{k.label}</p>
            <p className="mt-1 font-serif text-xl tabular text-ink">{k.value}</p>
          </div>
        ))}
      </div>

      {problems.length > 0 && (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <div className="rounded border border-line bg-surface p-4">
            <p className="mb-2 text-sm font-medium text-ink">Problems by Category</p>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={model.categoryDistribution.map((c) => ({ name: c.category, value: c.count }))} dataKey="value" nameKey="name" outerRadius={80} innerRadius={44}>
                    {model.categoryDistribution.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="rounded border border-line bg-surface p-4">
            <p className="mb-2 text-sm font-medium text-ink">Problem Lifecycle</p>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={model.lifecycleDistribution.map((s) => ({ name: s.status, count: s.count }))} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="name" type="category" width={110} tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
                  <Bar dataKey="count" fill="#4A5B68" radius={[0, 2, 2, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {model.recurring.length > 0 && (
        <div className="rounded border border-amber/30 bg-amber-soft p-4">
          <p className="text-sm font-medium text-amber">Recurring problem pattern detected</p>
          {model.recurring.map((r, i) => (
            <p key={i} className="mt-1 text-xs text-amber">
              "{r.titleKeyword}" appears in {r.occurrences.length} {r.category} problems: {r.occurrences.map((o) => o.title).join(', ')}. Worth investigating whether this is the
              same root cause recurring — not assumed automatically.
            </p>
          ))}
        </div>
      )}

      <ProblemList title="Recent Problems" problems={recent} onOpen={onOpen} />
      <ProblemList title="Active Problems" problems={active} onOpen={onOpen} />
      <ProblemList title="High-impact Problems" problems={highImpact} onOpen={onOpen} />
      <ProblemList title="Problems Awaiting Decision" problems={awaitingDecision} onOpen={onOpen} />
      <ProblemList title="Problems with Overdue Actions" problems={overdueActionProblems} onOpen={onOpen} />
      <ProblemList title="Resolved Problems" problems={resolved} onOpen={onOpen} />
    </div>
  );
}

function ProblemList({ title, problems, onOpen }: { title: string; problems: BusinessProblem[]; onOpen: (id: string) => void }) {
  if (problems.length === 0) return null;
  return (
    <div>
      <p className="mb-2 text-sm font-medium text-ink">{title}</p>
      <div className="overflow-x-auto rounded border border-line bg-surface">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-ink-faint">
              <th className="px-3 py-2 font-normal">Title</th>
              <th className="px-3 py-2 font-normal">Category</th>
              <th className="px-3 py-2 font-normal">Priority</th>
              <th className="px-3 py-2 font-normal">Status</th>
              <th className="px-3 py-2 font-normal">Owner</th>
            </tr>
          </thead>
          <tbody>
            {problems.map((p) => (
              <tr key={p.id} onClick={() => onOpen(p.id)} className="cursor-pointer border-b border-line/60 last:border-0 hover:bg-base">
                <td className="px-3 py-2 text-ink">{p.title || '(untitled)'}</td>
                <td className="px-3 py-2 text-ink-soft">{p.category}</td>
                <td className="px-3 py-2 text-ink-soft">{p.priority}</td>
                <td className="px-3 py-2 text-ink-soft">{p.status}</td>
                <td className="px-3 py-2 text-ink-soft">{p.owner || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
