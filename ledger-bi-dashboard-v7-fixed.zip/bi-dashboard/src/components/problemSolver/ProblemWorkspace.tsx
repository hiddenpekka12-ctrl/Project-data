import { useState } from 'react';
import { useProblemSolver } from '../../state/ProblemSolverContext';
import { BusinessProblem, LIFECYCLE_STATUSES } from '../../problemSolver/types';
import { DefineStep } from './DefineStep';
import { DiagnoseStep } from './DiagnoseStep';
import { ImpactStep } from './ImpactStep';
import { OptionsStep } from './OptionsStep';
import { DecisionStep } from './DecisionStep';
import { ActionStep } from './ActionStep';
import { MonitorReviewStep } from './MonitorReviewStep';
import { ManagementSummaryView } from './ManagementSummaryView';

type WorkspaceTab = 'define' | 'diagnose' | 'impact' | 'options' | 'decision' | 'action' | 'review' | 'summary';

const TABS: { key: WorkspaceTab; label: string }[] = [
  { key: 'define', label: '1. Define' },
  { key: 'diagnose', label: '2. Diagnose' },
  { key: 'impact', label: '3. Impact' },
  { key: 'options', label: '4. Options' },
  { key: 'decision', label: '5. Decision' },
  { key: 'action', label: '6. Action' },
  { key: 'review', label: '7. Monitor & Review' },
  { key: 'summary', label: 'Summary' },
];

export function ProblemWorkspace({ problemId, onBack }: { problemId: string; onBack: () => void }) {
  const { problems, updateProblem, deleteProblem } = useProblemSolver();
  const problem = problems.find((p) => p.id === problemId);
  const [tab, setTab] = useState<WorkspaceTab>('define');

  if (!problem) return <p className="text-sm text-ink-faint">Problem not found.</p>;

  const onUpdate = (updates: Partial<BusinessProblem>) => updateProblem(problem.id, updates);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="text-xs text-ink-faint hover:text-ink-soft">
          ← Back to Problem Solver
        </button>
        <button
          onClick={() => {
            deleteProblem(problem.id);
            onBack();
          }}
          className="text-xs text-ink-faint hover:text-rust"
        >
          Delete problem
        </button>
      </div>

      <div>
        <h1 className="font-serif text-xl text-ink">{problem.title}</h1>
        <p className="text-sm text-ink-faint">
          {problem.category} · {problem.priority} priority · Owner: {problem.owner || '—'}
        </p>
      </div>

      <LifecycleBar status={problem.status} onSetStatus={(s) => onUpdate({ status: s, history: [...problem.history, { date: new Date().toISOString().slice(0, 10), status: s }] })} />

      <div className="flex flex-wrap gap-1 border-b border-line">
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)} className={`rounded-t px-3 py-2 text-sm ${tab === t.key ? 'border-b-2 border-emerald text-emerald' : 'text-ink-faint hover:text-ink-soft'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'define' && <DefineStep problem={problem} onUpdate={onUpdate} />}
      {tab === 'diagnose' && <DiagnoseStep problem={problem} onUpdate={onUpdate} />}
      {tab === 'impact' && <ImpactStep problem={problem} onUpdate={onUpdate} />}
      {tab === 'options' && <OptionsStep problem={problem} onUpdate={onUpdate} />}
      {tab === 'decision' && <DecisionStep problem={problem} onUpdate={onUpdate} />}
      {tab === 'action' && <ActionStep problem={problem} onUpdate={onUpdate} />}
      {tab === 'review' && <MonitorReviewStep problem={problem} onUpdate={onUpdate} />}
      {tab === 'summary' && <ManagementSummaryView problem={problem} />}
    </div>
  );
}

function LifecycleBar({ status, onSetStatus }: { status: BusinessProblem['status']; onSetStatus: (s: BusinessProblem['status']) => void }) {
  const currentIndex = LIFECYCLE_STATUSES.indexOf(status);
  return (
    <div className="overflow-x-auto rounded border border-line bg-surface p-3">
      <div className="flex min-w-max gap-1">
        {LIFECYCLE_STATUSES.map((s, i) => (
          <button
            key={s}
            onClick={() => onSetStatus(s)}
            className={`whitespace-nowrap rounded px-2 py-1 text-[11px] ${
              i === currentIndex ? 'bg-emerald text-white' : i < currentIndex ? 'bg-emerald-soft text-emerald' : 'bg-base text-ink-faint'
            }`}
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}
