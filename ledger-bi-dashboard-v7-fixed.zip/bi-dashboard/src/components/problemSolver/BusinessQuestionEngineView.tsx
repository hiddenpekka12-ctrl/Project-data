import { useMemo, useState } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { useFinance } from '../../state/FinanceContext';
import { useRisk } from '../../state/RiskContext';
import { useProblemSolver } from '../../state/ProblemSolverContext';
import { buildFinanceModel } from '../../finance/buildFinanceModel';
import { buildRiskModel } from '../../risk/buildRiskModel';
import { answerBusinessQuestionStructured, StructuredAnswer } from '../../problemSolver/businessQuestionEngine';

const EXAMPLES = [
  'Why did profit decrease?',
  'Why are expenses increasing?',
  'Why is cash flow weak?',
  'What is causing margin compression?',
  'What are my highest-risk problems?',
];

export function BusinessQuestionEngineView() {
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const { registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings } = useRisk();
  const { problems } = useProblemSolver();
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<StructuredAnswer | null>(null);

  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);
  const revenueColumn = useMemo(() => Object.entries(mapping).find(([, cat]) => cat === 'revenue')?.[0] ?? null, [mapping]);
  const categoricalColumns = useMemo(() => activeDataset.columns.filter((c) => activeDataset.columnTypes[c] === 'categorical'), [activeDataset.columns, activeDataset.columnTypes]);
  const riskModel = useMemo(
    () => buildRiskModel(registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings, financeModel.periods, activeDataset.cleanedRows, categoricalColumns, revenueColumn),
    [registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings, financeModel.periods, activeDataset.cleanedRows, categoricalColumns, revenueColumn]
  );

  const allCauses = problems.flatMap((p) => p.fishbone);

  const ask = (q: string) => {
    setQuestion(q);
    const current = financeModel.periods[financeModel.periods.length - 1];
    const financeCtx = current
      ? { incomeSeries: financeModel.periods.map((p) => ({ label: p.label, income: p.income })), solvencyRatios: current.solvencyRatios, workingCapitalSeries: financeModel.periods.map((p) => ({ label: p.label, wc: p.workingCapital })), health: financeModel.health ?? { score: 0, status: 'Watch' as const, components: [] }, cashFlowNetProfit: current.income.netProfit, cashFlowActualChange: current.cashFlow.actualNetChangeInCash }
      : null;
    const riskCtx = { registerItems, kris, mitigations, appetiteSettings, financialSignals: riskModel.financialSignals };
    setAnswer(answerBusinessQuestionStructured(q, financeCtx, riskCtx, allCauses));
  };

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Business Question Engine</p>
        <div className="flex gap-2">
          <input
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && ask(question)}
            placeholder="Ask a business question..."
            className="flex-1 rounded border border-line bg-base px-3 py-2 text-sm outline-none focus:border-emerald"
          />
          <button onClick={() => ask(question)} className="rounded border border-line bg-base px-4 py-2 text-sm text-ink-soft hover:bg-line/40">
            Ask
          </button>
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          {EXAMPLES.map((ex) => (
            <button key={ex} onClick={() => ask(ex)} className="rounded-full border border-line px-2.5 py-1 text-xs text-ink-faint hover:text-ink-soft">
              {ex}
            </button>
          ))}
        </div>
      </div>

      {answer && (
        <div className="rounded border border-line bg-surface p-4">
          {answer.insufficientData ? (
            <p className="text-sm text-ink-soft">{answer.action}</p>
          ) : (
            <dl className="space-y-2 text-sm">
              <QA label="1. Question" value={answer.question} />
              <QA label="2. Data Used" value={answer.dataUsed} />
              <QA label="3. Finding" value={answer.finding} />
              <QA label="4. Evidence" value={answer.evidence || 'None available'} />
              <QA label="5. Diagnosis" value={answer.diagnosis} />
              <QA label="6. Risk" value={answer.risk} />
              <QA label="7. Options" value={answer.options.length ? answer.options.join(', ') : 'None generated yet'} />
              <QA label="8. Recommendation" value={answer.recommendation} />
              <QA label="9. Assumptions" value={answer.assumptions} />
              <QA label="10. Action" value={answer.action} />
              <QA label="11. KPI" value={answer.kpi || 'Not specified yet'} />
            </dl>
          )}
        </div>
      )}
    </div>
  );
}

function QA({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs font-medium text-ink-faint">{label}</dt>
      <dd className="text-ink-soft">{value}</dd>
    </div>
  );
}
