import { ReactNode } from 'react';
import { Resource } from '../../types';

/**
 * Every panel that depends on data should route through <ResourcePanel>
 * so loading / empty / error / invalid states are handled consistently
 * instead of each component inventing its own fallback UI.
 */
export function ResourcePanel<T>({
  resource,
  render,
  emptyLabel = 'No data available yet.',
}: {
  resource: Resource<T>;
  render: (data: T) => ReactNode;
  emptyLabel?: string;
}) {
  if (resource.status === 'loading') {
    return (
      <div className="animate-pulse space-y-2" role="status" aria-label="Loading">
        <div className="h-4 w-1/3 rounded bg-line" />
        <div className="h-8 w-2/3 rounded bg-line" />
      </div>
    );
  }
  if (resource.status === 'error') {
    return (
      <div className="rounded border border-rust/30 bg-rust-soft px-4 py-3 text-sm text-rust">
        Something went wrong loading this data: {resource.message}
      </div>
    );
  }
  if (resource.status === 'empty') {
    return <p className="text-sm text-ink-faint">{emptyLabel}</p>;
  }
  try {
    return <>{render(resource.data)}</>;
  } catch {
    return (
      <div className="rounded border border-rust/30 bg-rust-soft px-4 py-3 text-sm text-rust">
        This data looks invalid and could not be displayed.
      </div>
    );
  }
}

export function SectionHeading({ title, description }: { title: string; description?: string }) {
  return (
    <div className="mb-4">
      <h2 className="font-serif text-lg text-ink">{title}</h2>
      {description && <p className="mt-0.5 text-sm text-ink-faint">{description}</p>}
    </div>
  );
}

export function DemoDataTag() {
  return (
    <span className="inline-flex items-center gap-1 rounded-sm border border-line bg-base px-1.5 py-0.5 text-[11px] tracking-wide text-ink-faint">
      Demo data
    </span>
  );
}
