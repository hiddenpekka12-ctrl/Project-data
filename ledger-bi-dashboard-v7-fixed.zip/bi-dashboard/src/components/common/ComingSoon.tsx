export function ComingSoon({ moduleName, version }: { moduleName: string; version: string }) {
  return (
    <div className="flex h-full min-h-[60vh] flex-col items-center justify-center rounded border border-dashed border-line px-6 text-center">
      <p className="font-serif text-xl text-ink">{moduleName}</p>
      <p className="mt-2 max-w-sm text-sm text-ink-faint">
        Coming in a future version ({version}). This section is intentionally not built yet
        so V1 stays focused and stable.
      </p>
    </div>
  );
}
