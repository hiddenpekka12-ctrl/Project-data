import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { ForecastRun } from '../../forecast/types';

export function HistoricalAnalysisView({ run, series }: { run: ForecastRun; series: { date: string; value: number }[] }) {
  const { historical, validation } = run;
  const chartData = series.map((p) => ({ date: new Date(p.date).toLocaleDateString(), value: p.value }));

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Forecast Readiness: {validation.readinessPct}% ({validation.readinessLabel})</p>
        <p className="mb-2 text-xs text-ink-faint">A heuristic based on observation count, gaps, and missing values — not a statistical certainty.</p>
        {validation.issues.length > 0 && (
          <ul className="list-disc space-y-0.5 pl-5 text-xs text-amber">
            {validation.issues.map((issue, i) => (
              <li key={i}>{issue}</li>
            ))}
          </ul>
        )}
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Historical values</p>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
              <Line type="monotone" dataKey="value" stroke="#4A5B68" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Metric label="Mean" value={historical.mean.toFixed(1)} />
        <Metric label="Median" value={historical.median.toFixed(1)} />
        <Metric label="Min / Max" value={`${historical.min.toFixed(0)} / ${historical.max.toFixed(0)}`} />
        <Metric label="Std Dev" value={historical.stdDev.toFixed(1)} />
        <Metric label="Growth (first→last)" value={historical.growthPct === null ? 'n/a' : `${historical.growthPct.toFixed(1)}%`} />
        <Metric label="Trend" value={historical.trend.direction} sub={`${historical.trend.strengthLabel} strength`} />
        <Metric label="Volatility" value={historical.volatility.level} sub={historical.volatility.coefficientOfVariation !== null ? `CV: ${(historical.volatility.coefficientOfVariation * 100).toFixed(0)}%` : undefined} />
        <Metric label="Outliers" value={String(historical.outlierIndexes.length)} sub="IQR method (V2)" />
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="text-sm font-medium text-ink">Seasonality</p>
        <p className="mt-1 text-sm text-ink-soft">{historical.seasonality.description}</p>
      </div>

      {historical.structuralBreaks.length > 0 && (
        <div className="rounded border border-amber/30 bg-amber-soft p-4">
          <p className="text-sm font-medium text-amber">Potential structural break detected</p>
          {historical.structuralBreaks.map((b, i) => (
            <p key={i} className="mt-1 text-xs text-amber">{b.description}</p>
          ))}
        </div>
      )}
    </div>
  );
}

function Metric({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className="mt-1 font-serif text-lg tabular text-ink">{value}</p>
      {sub && <p className="mt-0.5 text-xs text-ink-faint">{sub}</p>}
    </div>
  );
}
