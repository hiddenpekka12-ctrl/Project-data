import { BacktestResult } from '../../forecast/types';
import { MODEL_LABELS } from '../../forecast/types';
import { LearnThis } from '../analytics/LearnThis';

export function ModelComparisonView({ backtests, selectedModel }: { backtests: BacktestResult[]; selectedModel: string }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="flex items-center text-sm font-medium text-ink">
        Model Comparison (ranked by validation RMSE)
        <LearnThis conceptKey="backtestingConcept" />
      </p>
      <p className="mb-3 text-xs text-ink-faint">Chronological backtesting — models are never validated with a random shuffle.</p>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-ink-faint">
              <th className="px-2 py-1.5 font-normal">Model</th>
              <th className="px-2 py-1.5 font-normal">MAE</th>
              <th className="px-2 py-1.5 font-normal">RMSE</th>
              <th className="px-2 py-1.5 font-normal">MAPE</th>
              <th className="px-2 py-1.5 font-normal">Bias</th>
              <th className="px-2 py-1.5 font-normal">Windows</th>
              <th className="px-2 py-1.5 font-normal">Flags</th>
            </tr>
          </thead>
          <tbody>
            {backtests.map((b) => (
              <tr key={b.model} className={`border-b border-line/60 last:border-0 ${b.model === selectedModel ? 'bg-emerald-soft/40' : ''}`}>
                <td className="px-2 py-1.5 text-ink">
                  {MODEL_LABELS[b.model]} {b.model === selectedModel && <span className="text-emerald">★ selected</span>}
                </td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{b.metrics.mae.toFixed(2)}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{b.metrics.rmse.toFixed(2)}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{b.metrics.mape === null ? 'n/a (near-zero actuals)' : `${b.metrics.mape.toFixed(1)}%`}</td>
                <td className="px-2 py-1.5 text-ink-soft">{b.metrics.biasLabel}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{b.windowCount}</td>
                <td className="px-2 py-1.5 text-xs">
                  {b.overfittingFlag && <span className="mr-1 rounded-sm bg-rust-soft px-1 py-0.5 text-rust">Overfit</span>}
                  {b.underfittingFlag && <span className="rounded-sm bg-amber-soft px-1 py-0.5 text-amber">Underfit</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-xs text-ink-faint">RMSE is used for ranking since it penalizes large errors more heavily; MAPE is shown for interpretability but can be undefined when actuals are near zero.</p>
    </div>
  );
}
