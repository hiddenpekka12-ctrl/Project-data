import { useState } from 'react';
import { useForecast } from '../../state/ForecastContext';
import { MODEL_LABELS } from '../../forecast/types';
import { computeErrorMetrics } from '../../forecast/errorMetrics';

export function ForecastHistoryView() {
  const { savedForecasts, deleteForecast, recordActual } = useForecast();

  if (savedForecasts.length === 0) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">No saved forecasts yet. Save one from the Forecast Result tab.</p>;
  }

  return (
    <div className="space-y-4">
      {savedForecasts.map((f) => (
        <SavedForecastCard key={f.id} forecastId={f.id} name={f.run.config.name} model={f.run.selectedModel} createdDate={f.createdDate} basePoints={f.run.scenario.base} actuals={f.actuals} onDelete={() => deleteForecast(f.id)} onRecordActual={recordActual} />
      ))}
    </div>
  );
}

function SavedForecastCard({
  forecastId,
  name,
  model,
  createdDate,
  basePoints,
  actuals,
  onDelete,
  onRecordActual,
}: {
  forecastId: string;
  name: string;
  model: keyof typeof MODEL_LABELS;
  createdDate: string;
  basePoints: { date: string; pointForecast: number }[];
  actuals: { date: string; forecast: number; actual: number; absoluteError: number; pctError: number | null }[];
  onDelete: () => void;
  onRecordActual: (forecastId: string, point: { date: string; forecast: number; actual: number; absoluteError: number; pctError: number | null }) => void;
}) {
  const [actualInputs, setActualInputs] = useState<Record<string, string>>({});

  const accuracy = actuals.length
    ? computeErrorMetrics(actuals.map((a) => a.actual), actuals.map((a) => a.forecast))
    : null;

  return (
    <div className="rounded border border-line bg-surface p-4">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-ink">
          {name} — {MODEL_LABELS[model]}
        </p>
        <button onClick={onDelete} className="text-xs text-ink-faint hover:text-rust">
          Delete
        </button>
      </div>
      <p className="text-xs text-ink-faint">Created {createdDate}</p>

      <div className="mt-3 space-y-2">
        {basePoints.map((p) => {
          const existingActual = actuals.find((a) => a.date === p.date);
          return (
            <div key={p.date} className="flex flex-wrap items-center justify-between gap-2 rounded border border-line/60 p-2 text-sm">
              <span className="text-ink-soft">{new Date(p.date).toLocaleDateString()}</span>
              <span className="tabular text-ink-faint">Forecast: {p.pointForecast.toFixed(0)}</span>
              {existingActual ? (
                <span className="tabular text-ink">
                  Actual: {existingActual.actual.toFixed(0)} (error {existingActual.absoluteError.toFixed(0)}
                  {existingActual.pctError !== null ? `, ${existingActual.pctError.toFixed(1)}%` : ''})
                </span>
              ) : (
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    placeholder="Actual"
                    value={actualInputs[p.date] ?? ''}
                    onChange={(e) => setActualInputs((prev) => ({ ...prev, [p.date]: e.target.value }))}
                    className="w-24 rounded border border-line bg-base px-2 py-1 text-xs"
                  />
                  <button
                    onClick={() => {
                      const actualValue = Number(actualInputs[p.date]);
                      if (isNaN(actualValue)) return;
                      const absoluteError = Math.abs(p.pointForecast - actualValue);
                      const pctError = actualValue !== 0 ? (absoluteError / Math.abs(actualValue)) * 100 : null;
                      onRecordActual(forecastId, { date: p.date, forecast: p.pointForecast, actual: actualValue, absoluteError, pctError });
                    }}
                    className="rounded border border-line px-2 py-1 text-xs text-ink-soft hover:bg-base"
                  >
                    Record
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {accuracy && (
        <p className="mt-3 text-xs text-ink-faint">
          Forecast accuracy so far: MAE {accuracy.mae.toFixed(1)}, RMSE {accuracy.rmse.toFixed(1)}, {accuracy.biasLabel.toLowerCase()}.
        </p>
      )}
    </div>
  );
}
