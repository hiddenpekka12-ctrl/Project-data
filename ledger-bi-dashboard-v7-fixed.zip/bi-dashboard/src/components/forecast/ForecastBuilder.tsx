import { ReactNode, useState } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { ForecastConfig, ForecastFrequency } from '../../forecast/types';

export function ForecastBuilder({ onRun }: { onRun: (config: ForecastConfig) => void }) {
  const { activeDataset } = useDatasets();
  const dateColumns = activeDataset.columns.filter((c) => activeDataset.columnTypes[c] === 'date');
  const numericColumns = activeDataset.columns.filter((c) => activeDataset.columnTypes[c] === 'numeric');

  const [name, setName] = useState('');
  const [target, setTarget] = useState(numericColumns[0] ?? '');
  const [dateCol, setDateCol] = useState(dateColumns[0] ?? '');
  const [frequency, setFrequency] = useState<ForecastFrequency>('monthly');
  const [horizon, setHorizon] = useState(3);

  const canRun = target && dateCol;

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="mb-1 text-sm font-medium text-ink">New Forecast</p>
      <p className="mb-3 text-xs text-ink-faint">Working from "{activeDataset.name}". Switch datasets via Analytics or Finance if needed.</p>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Field label="Forecast Name">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Monthly Revenue Forecast" className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
        </Field>
        <Field label="Target Variable">
          <select value={target} onChange={(e) => setTarget(e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            <option value="">Select…</option>
            {numericColumns.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="Date Variable">
          <select value={dateCol} onChange={(e) => setDateCol(e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            <option value="">Select…</option>
            {dateColumns.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="Frequency">
          <select value={frequency} onChange={(e) => setFrequency(e.target.value as ForecastFrequency)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="quarterly">Quarterly</option>
            <option value="annual">Annual</option>
          </select>
        </Field>
        <Field label="Forecast Horizon (periods)">
          <input type="number" min={1} max={24} value={horizon} onChange={(e) => setHorizon(Number(e.target.value))} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
        </Field>
      </div>
      <button
        disabled={!canRun}
        onClick={() =>
          onRun({
            id: `forecast-${Date.now()}`,
            name: name || `${target} forecast`,
            datasetId: activeDataset.id,
            targetColumn: target,
            dateColumn: dateCol,
            frequency,
            horizon,
            filters: {},
            currency: 'USD',
            unit: 'count',
            createdDate: new Date().toISOString().slice(0, 10),
            createdBy: '',
            status: 'Active',
          })
        }
        className="mt-3 rounded border border-emerald bg-emerald-soft px-4 py-1.5 text-sm text-emerald disabled:opacity-40"
      >
        Run Forecast
      </button>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      {children}
    </label>
  );
}
