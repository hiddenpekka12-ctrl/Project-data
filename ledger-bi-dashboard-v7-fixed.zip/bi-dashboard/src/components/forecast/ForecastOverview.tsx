import { useFinance } from '../../state/FinanceContext';
import { useForecast } from '../../state/ForecastContext';
import { generateForecastAlerts } from '../../forecast/alerts';
import { MODEL_LABELS } from '../../forecast/types';

export function ForecastOverview() {
  const { loadAbcDemoCompany } = useFinance();
  const { savedForecasts } = useForecast();

  const today = new Date().toISOString().slice(0, 10);
  const upcomingPeriods = savedForecasts.flatMap((f) => f.run.scenario.base.filter((p) => p.date.slice(0, 10) >= today).map((p) => ({ forecastName: f.run.config.name, date: p.date })));
  const allAlerts = savedForecasts.flatMap((f) => generateForecastAlerts(f.run));

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Quick start</p>
        <button onClick={loadAbcDemoCompany} className="rounded border border-emerald bg-emerald-soft px-3 py-1.5 text-xs text-emerald">
          Load demo company (ABC Manufacturing Ltd.)
        </button>
        <p className="mt-2 text-xs text-ink-faint">Then go to "New Forecast" to build one against its 24 months of demo financial history.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Metric label="Active Forecasts" value={String(savedForecasts.length)} />
        <Metric label="Upcoming Forecast Periods" value={String(upcomingPeriods.length)} />
        <Metric label="Active Alerts" value={String(allAlerts.length)} />
        <Metric
          label="Avg. Confidence"
          value={savedForecasts.length ? mostCommon(savedForecasts.map((f) => f.run.confidence)) : 'n/a'}
        />
      </div>

      {savedForecasts.length > 0 && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Model Performance History</p>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line text-xs text-ink-faint">
                  <th className="px-2 py-1.5 font-normal">Forecast</th>
                  <th className="px-2 py-1.5 font-normal">Target</th>
                  <th className="px-2 py-1.5 font-normal">Frequency</th>
                  <th className="px-2 py-1.5 font-normal">Model</th>
                  <th className="px-2 py-1.5 font-normal">Confidence</th>
                </tr>
              </thead>
              <tbody>
                {savedForecasts.map((f) => (
                  <tr key={f.id} className="border-b border-line/60 last:border-0">
                    <td className="px-2 py-1.5 text-ink">{f.run.config.name}</td>
                    <td className="px-2 py-1.5 text-ink-soft">{f.run.config.targetColumn}</td>
                    <td className="px-2 py-1.5 text-ink-soft">{f.run.config.frequency}</td>
                    <td className="px-2 py-1.5 text-ink-soft">{MODEL_LABELS[f.run.selectedModel]}</td>
                    <td className="px-2 py-1.5 text-ink-soft">{f.run.confidence}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-xs text-ink-faint">Model performance is tracked per dataset/target — one model performing well here doesn't generalize to every dataset.</p>
        </div>
      )}

      {allAlerts.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-medium text-ink">Forecast Alerts</p>
          {allAlerts.map((a) => (
            <div key={a.id} className={`rounded border px-3 py-2 text-sm ${a.severity === 'critical' ? 'border-rust/40 bg-rust-soft text-rust' : 'border-amber/40 bg-amber-soft text-amber'}`}>
              <p className="font-medium">{a.label}</p>
              <p className="mt-0.5 text-xs">
                {a.metric}: {a.currentValue} → {a.forecastValue} (threshold: {a.threshold}) over {a.horizon}, model: {a.model}
              </p>
              <p className="mt-0.5 text-xs">{a.uncertaintyNote}</p>
              <p className="mt-0.5 text-xs">Recommended: {a.recommendedInvestigation}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function mostCommon(values: string[]): string {
  const counts = new Map<string, number>();
  values.forEach((v) => counts.set(v, (counts.get(v) ?? 0) + 1));
  return Array.from(counts.entries()).sort((a, b) => b[1] - a[1])[0][0];
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className="mt-1 font-serif text-xl tabular text-ink">{value}</p>
    </div>
  );
}
