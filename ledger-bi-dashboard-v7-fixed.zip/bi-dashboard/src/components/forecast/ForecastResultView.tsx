import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { ForecastRun } from '../../forecast/types';
import { MODEL_LABELS } from '../../forecast/types';
import { LearnThis } from '../analytics/LearnThis';

export function ForecastResultView({ run, series }: { run: ForecastRun; series: { date: string; value: number }[] }) {
  const historicalData = series.map((p) => ({ date: new Date(p.date).toLocaleDateString(), Historical: p.value }));
  const forecastData = run.scenario.base.map((p, i) => ({
    date: new Date(p.date).toLocaleDateString(),
    Base: p.pointForecast,
    Upside: run.scenario.upside[i]?.pointForecast,
    Downside: run.scenario.downside[i]?.pointForecast,
    Lower: p.lowerBound ?? undefined,
    Upper: p.upperBound ?? undefined,
  }));
  const combined = [...historicalData, ...forecastData];

  return (
    <div className="space-y-4">
      <div className="rounded border border-amber/30 bg-amber-soft px-3 py-2 text-xs text-amber">
        Everything after the historical line is labeled <strong>FORECAST</strong> — a model estimate under stated assumptions, not an observed fact.
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">
          Forecast — {MODEL_LABELS[run.selectedModel]}, {run.config.horizon} {run.config.frequency} period(s) ahead
        </p>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={combined}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 9, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Line type="monotone" dataKey="Historical" stroke="#4A5B68" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="Base" stroke="#1F6F54" strokeWidth={2} dot={false} strokeDasharray="4 2" />
              <Line type="monotone" dataKey="Upside" stroke="#2F9E7A" strokeWidth={1} dot={false} strokeDasharray="2 2" />
              <Line type="monotone" dataKey="Downside" stroke="#B3452C" strokeWidth={1} dot={false} strokeDasharray="2 2" />
              <Line type="monotone" dataKey="Upper" stroke="#A9782E" strokeWidth={1} dot={false} strokeOpacity={0.5} />
              <Line type="monotone" dataKey="Lower" stroke="#A9782E" strokeWidth={1} dot={false} strokeOpacity={0.5} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <p className="mt-2 text-xs text-ink-faint">
          Base = model estimate. Upside/Downside = {run.scenario.upsideAssumption} / {run.scenario.downsideAssumption} Upper/Lower = ~80% prediction interval derived from backtest
          error — not a guarantee.
        </p>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="flex items-center text-sm font-medium text-ink">
          Why this forecast?
          <LearnThis conceptKey="forecastIntervalConcept" />
        </p>
        <p className="mt-1 text-sm text-ink-soft">
          Model estimates {run.config.targetColumn} around {run.scenario.base[run.scenario.base.length - 1]?.pointForecast.toFixed(0)} by the end of the horizon
          {run.scenario.base[run.scenario.base.length - 1]?.lowerBound !== null
            ? `, with an uncertainty range of roughly ${run.scenario.base[run.scenario.base.length - 1]?.lowerBound?.toFixed(0)}–${run.scenario.base[run.scenario.base.length - 1]?.upperBound?.toFixed(0)}`
            : ''}
          , based on a {run.historical.trend.direction.toLowerCase()} historical trend
          {run.historical.seasonality.detected ? ' and an observed seasonal pattern' : ''}.
        </p>
        <p className="mt-2 text-sm font-medium text-ink">Forecast Confidence: {run.confidence}</p>
        {run.confidenceReasons.length > 0 && (
          <ul className="mt-1 list-disc space-y-0.5 pl-5 text-xs text-ink-faint">
            {run.confidenceReasons.map((r, i) => (
              <li key={i}>{r}</li>
            ))}
          </ul>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-1 text-sm font-medium text-ink">Assumptions</p>
          <ul className="list-disc space-y-0.5 pl-5 text-xs text-ink-soft">
            {run.assumptions.map((a, i) => (
              <li key={i}>{a}</li>
            ))}
          </ul>
        </div>
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-1 text-sm font-medium text-ink">Limitations</p>
          {run.limitations.length === 0 ? (
            <p className="text-xs text-ink-faint">No specific limitations flagged for this forecast.</p>
          ) : (
            <ul className="list-disc space-y-0.5 pl-5 text-xs text-amber">
              {run.limitations.map((l, i) => (
                <li key={i}>{l}</li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
