import { useState } from 'react';
import { ForecastRun } from '../../forecast/types';
import { applyWhatIfGrowthAdjustment } from '../../forecast/whatIf';
import { formatCurrency } from '../../lib/format';

export function WhatIfView({ run }: { run: ForecastRun }) {
  const [adjustmentPct, setAdjustmentPct] = useState(0);
  const adjusted = applyWhatIfGrowthAdjustment(run.scenario.base, adjustmentPct);

  const baseLast = run.scenario.base[run.scenario.base.length - 1];
  const adjustedLast = adjusted[adjusted.length - 1];

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="mb-1 text-sm font-medium text-ink">What-If: {run.config.targetColumn} growth adjustment</p>
      <p className="mb-3 text-xs text-ink-faint">A single transparent adjustment to the base forecast. Full multi-variable scenario/stress testing is a future capability (V7).</p>
      <label className="block">
        <span className="mb-1 flex justify-between text-xs text-ink-faint">
          <span>Adjustment vs base case</span>
          <span className="tabular">{adjustmentPct >= 0 ? '+' : ''}{adjustmentPct}%</span>
        </span>
        <input type="range" min={-30} max={30} value={adjustmentPct} onChange={(e) => setAdjustmentPct(Number(e.target.value))} className="w-full" />
      </label>

      {baseLast && adjustedLast && (
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Metric label="Base case (end of horizon)" value={formatCurrency(baseLast.pointForecast)} />
          <Metric label={`Adjusted (${adjustmentPct >= 0 ? '+' : ''}${adjustmentPct}%)`} value={formatCurrency(adjustedLast.pointForecast)} />
          <Metric label="Difference" value={formatCurrency(adjustedLast.pointForecast - baseLast.pointForecast)} />
        </div>
      )}
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border border-line bg-base p-3">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className="mt-1 font-serif text-lg tabular text-ink">{value}</p>
    </div>
  );
}
