import { useMemo } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { useFinance } from '../../state/FinanceContext';
import { useRisk } from '../../state/RiskContext';
import { buildFinanceModel } from '../../finance/buildFinanceModel';
import { buildFinancialForecast } from '../../forecast/financialForecast';
import { buildCashForecast } from '../../forecast/cashFlowForecast';
import { deriveForecastRiskSignals } from '../../forecast/riskIntegration';
import { ForecastFrequency } from '../../forecast/types';

export function ForecastRiskView({ horizon, frequency }: { horizon: number; frequency: ForecastFrequency }) {
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const { kris } = useRisk();
  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);
  const result = useMemo(() => buildFinancialForecast(financeModel.periods, horizon, frequency), [financeModel.periods, horizon, frequency]);

  if ('insufficientData' in result) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">Run a Financial Forecast first to generate risk signals from it.</p>;
  }

  const lastActual = financeModel.periods[financeModel.periods.length - 1];
  const cashLines = buildCashForecast(lastActual.balanceSheet.cash, result.lines);
  const signals = deriveForecastRiskSignals(result.lines, cashLines, kris);

  return (
    <div className="space-y-3">
      <p className="text-xs text-ink-faint">Forecast signals are read from the Financial Forecast above and V4's KRIs — never claimed as proof of a future risk event.</p>
      {signals.length === 0 ? (
        <p className="rounded border border-emerald/30 bg-emerald-soft p-4 text-sm text-emerald">No forecast-driven risk signals detected.</p>
      ) : (
        signals.map((s, i) => (
          <div key={i} className="rounded border border-amber/30 bg-amber-soft p-4">
            <p className="text-sm font-medium text-amber">{s.forecastLabel}</p>
            <p className="mt-1 text-xs text-ink-soft">{s.potentialRisk}</p>
            {s.relatedKriName && <p className="mt-1 text-xs text-ink-faint">Related KRI: {s.relatedKriName}</p>}
            <p className="mt-1 text-xs text-ink-faint">Management attention: {s.managementAttention}</p>
          </div>
        ))
      )}
    </div>
  );
}
