import { useMemo } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { useFinance } from '../../state/FinanceContext';
import { buildFinanceModel } from '../../finance/buildFinanceModel';
import { buildFinancialForecast } from '../../forecast/financialForecast';
import { buildCashForecast, computeCashRunway } from '../../forecast/cashFlowForecast';
import { formatCurrency } from '../../lib/format';
import { ForecastFrequency } from '../../forecast/types';

export function FinancialForecastView({ horizon, frequency }: { horizon: number; frequency: ForecastFrequency }) {
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);

  const result = useMemo(() => buildFinancialForecast(financeModel.periods, horizon, frequency), [financeModel.periods, horizon, frequency]);

  if ('insufficientData' in result) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">{result.message}</p>;
  }

  const lastActual = financeModel.periods[financeModel.periods.length - 1];
  const cashLines = buildCashForecast(lastActual.balanceSheet.cash, result.lines);
  const runway = computeCashRunway(lastActual.balanceSheet.cash, financeModel.periods.slice(-3));

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Financial Forecast Method</p>
        <p className="text-xs text-ink-faint">{result.method}</p>
      </div>

      <div className="overflow-x-auto rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Projected Income Statement (FORECAST)</p>
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-ink-faint">
              <th className="px-2 py-1.5 font-normal">Period</th>
              <th className="px-2 py-1.5 font-normal">Revenue</th>
              <th className="px-2 py-1.5 font-normal">COGS</th>
              <th className="px-2 py-1.5 font-normal">Gross Profit</th>
              <th className="px-2 py-1.5 font-normal">OpEx</th>
              <th className="px-2 py-1.5 font-normal">EBITDA</th>
              <th className="px-2 py-1.5 font-normal">EBIT</th>
              <th className="px-2 py-1.5 font-normal">Net Profit</th>
            </tr>
          </thead>
          <tbody>
            {result.lines.map((l) => (
              <tr key={l.periodLabel} className="border-b border-line/60 last:border-0">
                <td className="px-2 py-1.5 text-ink">{l.periodLabel}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(l.revenue)}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(l.cogs)}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(l.grossProfit)}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(l.operatingExpenses)}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(l.ebitda)}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(l.ebit)}</td>
                <td className="px-2 py-1.5 tabular font-medium text-ink">{formatCurrency(l.netProfit)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="overflow-x-auto rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Projected Cash (FORECAST — operating activity only)</p>
        <p className="mb-2 text-xs text-ink-faint">Investing and financing activity are not forecasted — this app never invents future financing decisions.</p>
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-ink-faint">
              <th className="px-2 py-1.5 font-normal">Period</th>
              <th className="px-2 py-1.5 font-normal">Opening Cash</th>
              <th className="px-2 py-1.5 font-normal">Est. Operating CF</th>
              <th className="px-2 py-1.5 font-normal">Closing Cash</th>
            </tr>
          </thead>
          <tbody>
            {cashLines.map((l) => (
              <tr key={l.periodLabel} className={`border-b border-line/60 last:border-0 ${l.closingCash < 0 ? 'bg-rust-soft/40' : ''}`}>
                <td className="px-2 py-1.5 text-ink">{l.periodLabel}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(l.openingCash)}</td>
                <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(l.operatingCashFlowEstimate)}</td>
                <td className={`px-2 py-1.5 tabular font-medium ${l.closingCash < 0 ? 'text-rust' : 'text-ink'}`}>{formatCurrency(l.closingCash)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Cash Runway</p>
        <p className="text-sm text-ink-soft">{runway.applicable ? `Approximately ${runway.runwayPeriods?.toFixed(1)} periods.` : 'Not applicable.'}</p>
        <p className="mt-1 text-xs text-ink-faint">{runway.reason}</p>
      </div>
    </div>
  );
}
