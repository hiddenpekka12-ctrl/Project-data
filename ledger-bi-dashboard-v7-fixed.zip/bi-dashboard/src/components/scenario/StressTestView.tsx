import { useState } from 'react';
import { PeriodModel } from '../../finance/buildFinanceModel';
import { propagateScenario } from '../../scenario/driverModel';
import { STRESS_PRESETS, combinedStressDrivers } from '../../scenario/stressTesting';
import { computeResilienceScore } from '../../scenario/resilience';
import { computeSurvivalThresholds } from '../../scenario/survivalThresholds';
import { runBreakEvenScenario } from '../../scenario/breakEvenScenario';
import { NEUTRAL_DRIVERS } from '../../scenario/types';
import { formatCurrency } from '../../lib/format';
import { LearnThis } from '../analytics/LearnThis';

export function StressTestView({ base }: { base: PeriodModel }) {
  const [selectedPresets, setSelectedPresets] = useState<string[]>([]);

  const combinedDrivers = combinedStressDrivers(selectedPresets.map((key) => STRESS_PRESETS.find((p) => p.key === key)?.drivers ?? {}));
  const stressed = propagateScenario(base, selectedPresets.length ? combinedDrivers : NEUTRAL_DRIVERS);
  const resilienceBase = computeResilienceScore(base, null);
  const resilienceStressed = computeResilienceScore(stressed, null);
  const survivalThresholds = computeSurvivalThresholds(base);

  const beResult = runBreakEvenScenario(
    { fixedCosts: base.income.operatingExpenses, variableCostPerUnit: base.income.cogs / 1000 || 1, sellingPricePerUnit: base.income.revenue / 1000 || 1 },
    { fixedCosts: stressed.income.operatingExpenses, variableCostPerUnit: stressed.income.cogs / 1000 || 1, sellingPricePerUnit: stressed.income.revenue / 1000 || 1 },
    1000
  );

  return (
    <div className="space-y-4">
      <div className="rounded border border-rust/30 bg-rust-soft px-3 py-2 text-xs text-rust">
        Labeled <strong>STRESS TEST</strong> — severe but plausible adverse conditions, not a prediction of what will happen.
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Stress Presets (combinable)</p>
        <div className="space-y-2">
          {STRESS_PRESETS.map((preset) => (
            <label key={preset.key} className="flex items-start gap-2 rounded border border-line/60 p-2 text-sm">
              <input type="checkbox" checked={selectedPresets.includes(preset.key)} onChange={(e) => setSelectedPresets((prev) => (e.target.checked ? [...prev, preset.key] : prev.filter((k) => k !== preset.key)))} className="mt-1" />
              <span>
                <span className="font-medium text-ink">{preset.label}</span>
                <span className="ml-1 text-xs text-ink-faint">({preset.severity})</span>
                <p className="text-xs text-ink-faint">{preset.description}</p>
              </span>
            </label>
          ))}
        </div>
      </div>

      {selectedPresets.length > 0 && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Metric label="Revenue" value={formatCurrency(stressed.income.revenue)} sub={formatCurrency(base.income.revenue)} />
          <Metric label="EBITDA" value={formatCurrency(stressed.income.ebitda)} sub={formatCurrency(base.income.ebitda)} />
          <Metric label="Net Profit" value={formatCurrency(stressed.income.netProfit)} sub={formatCurrency(base.income.netProfit)} />
          <Metric label="Cash" value={formatCurrency(stressed.balanceSheet.cash)} sub={formatCurrency(base.balanceSheet.cash)} tone={stressed.balanceSheet.cash < 0 ? 'rust' : undefined} />
          <Metric label="Current Ratio" value={stressed.liquidityRatios.find((r) => r.key === 'currentRatio')?.value?.toFixed(2) ?? 'n/a'} />
          <Metric label="Interest Coverage" value={(() => { const v = stressed.solvencyRatios.find((r) => r.key === 'interestCoverage')?.value; return v !== null && v !== undefined ? `${v.toFixed(1)}×` : 'n/a'; })()} />
          <Metric label="Working Capital" value={formatCurrency(stressed.workingCapital.workingCapital)} />
          <Metric label="CCC" value={stressed.workingCapital.cashConversionCycle !== null ? `${stressed.workingCapital.cashConversionCycle.toFixed(0)}d` : 'n/a'} />
        </div>
      )}

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Resilience Score</p>
        <div className="flex items-center gap-6">
          <div>
            <p className="text-xs text-ink-faint">Base</p>
            <p className="font-serif text-2xl tabular text-ink">{resilienceBase.score}/100</p>
          </div>
          <div>
            <p className="text-xs text-ink-faint">Under selected stress</p>
            <p className={`font-serif text-2xl tabular ${resilienceStressed.score < resilienceBase.score ? 'text-rust' : 'text-ink'}`}>{resilienceStressed.score}/100</p>
          </div>
        </div>
        <p className="mt-2 text-xs text-ink-faint">A transparent heuristic — not a regulated rating or guarantee of resilience.</p>
        <div className="mt-2 space-y-1">
          {resilienceStressed.components.map((c) => (
            <div key={c.label} className="flex justify-between text-xs text-ink-soft">
              <span>{c.label}</span>
              <span className="tabular">{c.points}/{c.maxPoints} — {c.detail}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Survival Thresholds (calculated, not guessed)</p>
        {survivalThresholds.length === 0 ? (
          <p className="text-sm text-ink-faint">No threshold crossing found within the tested range for this base period.</p>
        ) : (
          <div className="space-y-2">
            {survivalThresholds.map((t, i) => (
              <div key={i} className="text-sm">
                <p className="text-ink-soft">
                  {t.label}: <strong className="tabular text-ink">{t.thresholdValue.toFixed(1)}{t.unit}</strong>
                </p>
                <p className="text-xs text-ink-faint">{t.method}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="flex items-center text-sm font-medium text-ink">
          Margin of Safety (illustrative, per 1,000 units)
          <LearnThis conceptKey="breakEven" />
        </p>
        <p className="mt-1 text-sm text-ink-soft">
          Base break-even: {beResult.base.breakEvenUnits?.toFixed(0) ?? 'n/a'} units. Stressed break-even: {beResult.scenario.breakEvenUnits?.toFixed(0) ?? 'n/a'} units.
        </p>
        {beResult.marginOfSafetyPct !== null && (
          <p className="mt-1 text-sm text-ink-soft">Margin of Safety under stress: {beResult.marginOfSafetyPct.toFixed(1)}% (assuming 1,000 units sold).</p>
        )}
        <p className="mt-2 text-xs text-ink-faint">This break-even view uses an illustrative unit price/cost derived from revenue and COGS divided by an assumed 1,000-unit volume — a real per-unit break-even needs actual unit economics data.</p>
      </div>
    </div>
  );
}

function Metric({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: 'rust' }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className={`mt-1 font-serif text-lg tabular ${tone === 'rust' ? 'text-rust' : 'text-ink'}`}>{value}</p>
      {sub && <p className="text-xs text-ink-faint">was {sub}</p>}
    </div>
  );
}
