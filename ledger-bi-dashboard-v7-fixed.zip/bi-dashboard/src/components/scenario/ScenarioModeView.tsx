import { useState } from 'react';
import { PeriodModel } from '../../finance/buildFinanceModel';
import { ScenarioResult } from '../../scenario/types';
import { computeSurvivalThresholds } from '../../scenario/survivalThresholds';
import { buildTornadoRanking } from '../../scenario/sensitivity';

type Mode = 'ceo' | 'cfo' | 'cro' | 'consultant';

export function ScenarioModeView({ base, result }: { base: PeriodModel; result: ScenarioResult }) {
  const [mode, setMode] = useState<Mode>('ceo');
  const tornado = buildTornadoRanking(base, ['revenueGrowthPct', 'cogsChangePct', 'opexChangePct', 'interestRateChangePct']);
  const survival = computeSurvivalThresholds(base);
  const biggestSensitivity = tornado[0];

  return (
    <div className="space-y-4">
      <div className="flex gap-1">
        {(['ceo', 'cfo', 'cro', 'consultant'] as Mode[]).map((m) => (
          <button key={m} onClick={() => setMode(m)} className={`rounded px-3 py-1.5 text-xs uppercase ${mode === m ? 'bg-emerald-soft text-emerald' : 'bg-surface text-ink-faint'}`}>
            {m} mode
          </button>
        ))}
      </div>
      <p className="text-xs text-ink-faint">All four modes read the same scenario result — only the framing changes.</p>

      {mode === 'ceo' && (
        <div className="rounded border border-line bg-surface p-4 text-sm text-ink-soft">
          <Row label="Base case" value={`Net Profit ${base.income.netProfit.toFixed(0)}`} />
          <Row label="What could go wrong" value={biggestSensitivity ? `${biggestSensitivity.label} has the largest swing on profit` : 'Not enough data'} />
          <Row label="How bad" value={`Under "${result.config.name}", net profit moves to ${result.financialSummary.netProfit.toFixed(0)}`} />
          <Row label="Biggest vulnerability" value={survival[0]?.label ?? 'Not calculable from current data'} />
          <Row label="Prepare now" value={result.redFlagCount > 0 ? 'Review red flags in the Risk Impact tab' : 'No immediate red flags under this scenario'} />
        </div>
      )}

      {mode === 'cfo' && (
        <div className="rounded border border-line bg-surface p-4 text-sm text-ink-soft">
          <Row label="Revenue" value={result.financialSummary.revenue.toFixed(0)} />
          <Row label="EBITDA" value={result.financialSummary.ebitda.toFixed(0)} />
          <Row label="Cash" value={result.financialSummary.closingCash.toFixed(0)} />
          <Row label="Working Capital" value={result.financialSummary.workingCapital.toFixed(0)} />
          <Row label="Interest Coverage" value={result.financialSummary.interestCoverage?.toFixed(1) ?? 'n/a'} />
          <Row label="Downside exposure" value={`${(result.financialSummary.netProfit - base.income.netProfit).toFixed(0)} vs base`} />
        </div>
      )}

      {mode === 'cro' && (
        <div className="rounded border border-line bg-surface p-4 text-sm text-ink-soft">
          <Row label="Red flags triggered" value={String(result.redFlagCount)} />
          <Row label="Health score change" value={result.riskScoreDelta !== null ? `${result.riskScoreDelta >= 0 ? '+' : ''}${result.riskScoreDelta}` : 'n/a'} />
          <Row label="Residual risk direction" value={result.riskScoreDelta !== null && result.riskScoreDelta < 0 ? 'Deteriorating' : 'Stable or improving'} />
          <Row label="Mitigation priority" value="See Risk Impact tab for specific red flags and thresholds breached." />
        </div>
      )}

      {mode === 'consultant' && (
        <div className="rounded border border-line bg-surface p-4 text-sm text-ink-soft">
          <Row label="Issue tree" value={`${result.chain.length} propagation steps traced from driver to cash`} />
          <Row label="Sensitivity" value={biggestSensitivity ? `${biggestSensitivity.label} dominates (swing: ${biggestSensitivity.swing.toFixed(0)})` : 'n/a'} />
          <Row label="Recommendation basis" value={`${result.assumptions.length} explicit assumption(s) logged`} />
          <Row label="Confidence caveat" value="Evidence-based, but every number here depends on the stated assumptions holding." />
        </div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-line/60 py-1.5 last:border-0">
      <span className="text-ink-faint">{label}</span>
      <span className="text-right text-ink">{value}</span>
    </div>
  );
}
