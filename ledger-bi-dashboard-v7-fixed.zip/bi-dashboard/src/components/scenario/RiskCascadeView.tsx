import { PeriodModel } from '../../finance/buildFinanceModel';
import { computeScenarioRiskImpact } from '../../scenario/riskCascade';
import { detectThresholdBreaches, DEFAULT_DECISION_THRESHOLDS } from '../../scenario/thresholds';
import { DEFAULT_DECISION_TRIGGERS, evaluateTriggers } from '../../scenario/decisionTriggers';

export function RiskCascadeView({ base, scenario, scenarioName }: { base: PeriodModel; scenario: PeriodModel; scenarioName: string }) {
  const impact = computeScenarioRiskImpact(base, scenario, scenarioName);
  const breaches = detectThresholdBreaches(base, scenario, DEFAULT_DECISION_THRESHOLDS, null).filter((b) => b.breached);

  const revenueChangePct = base.income.revenue !== 0 ? ((scenario.income.revenue - base.income.revenue) / base.income.revenue) * 100 : 0;
  const interestCoverage = scenario.solvencyRatios.find((r) => r.key === 'interestCoverage')?.value ?? null;
  const triggeredRules = evaluateTriggers(DEFAULT_DECISION_TRIGGERS, {
    revenueChangePct,
    cash: scenario.balanceSheet.cash,
    cashThreshold: DEFAULT_DECISION_THRESHOLDS.minCash,
    customerConcentrationPct: null,
    interestCoverage,
  });

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Risk Cascade</p>
        <div className="space-y-2">
          {impact.cascade.map((step, i) => (
            <div key={i} className="flex gap-3 text-sm">
              <span className="w-40 shrink-0 font-medium text-ink-soft">{step.label}</span>
              <span className="text-ink-soft">{step.detail}</span>
            </div>
          ))}
        </div>
        <p className="mt-2 text-xs text-ink-faint">Uses V4's own detectRedFlags/computeHealthScore on the shocked period — not a second risk engine.</p>
      </div>

      {impact.redFlags.length > 0 && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Red Flags Under This Scenario</p>
          <div className="space-y-2">
            {impact.redFlags.map((f) => (
              <div key={f.id} className={`rounded border px-3 py-2 text-xs ${f.severity === 'critical' ? 'border-rust/40 bg-rust-soft text-rust' : 'border-amber/40 bg-amber-soft text-amber'}`}>
                <p className="font-medium">{f.label}</p>
                <p className="mt-0.5">{f.whatHappened}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Threshold Breaches</p>
        {breaches.length === 0 ? (
          <p className="text-sm text-ink-faint">No configured thresholds breached under this scenario.</p>
        ) : (
          <div className="space-y-2">
            {breaches.map((b, i) => (
              <div key={i} className="rounded border border-rust/30 bg-rust-soft px-3 py-2 text-xs text-rust">
                <p className="font-medium">{b.metric}: Threshold Breach</p>
                <p>Base: {b.baseValue.toFixed(2)} → Scenario: {b.scenarioValue.toFixed(2)} (threshold: {b.threshold}, gap: {b.gap.toFixed(2)})</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Decision Triggers</p>
        <div className="space-y-2">
          {DEFAULT_DECISION_TRIGGERS.map((rule) => {
            const fired = triggeredRules.some((r) => r.id === rule.id);
            return (
              <div key={rule.id} className={`rounded border px-3 py-2 text-xs ${fired ? 'border-amber/40 bg-amber-soft text-amber' : 'border-line text-ink-faint'}`}>
                <p className="font-medium">IF {rule.conditionText}</p>
                <p>THEN {rule.actionText}</p>
                {fired && <p className="mt-1 font-medium">⚠ Triggered under this scenario</p>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
