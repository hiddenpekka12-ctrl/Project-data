import { useScenario } from '../../state/ScenarioContext';

export function ScenarioHistoryView() {
  const { scenarios, archiveScenario, deleteScenario, createNewVersion } = useScenario();

  if (scenarios.length === 0) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">No saved scenarios yet. Save one from the Builder tab.</p>;
  }

  return (
    <div className="overflow-x-auto rounded border border-line bg-surface">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-line text-xs text-ink-faint">
            <th className="px-3 py-2 font-normal">Name</th>
            <th className="px-3 py-2 font-normal">Type</th>
            <th className="px-3 py-2 font-normal">Version</th>
            <th className="px-3 py-2 font-normal">Created</th>
            <th className="px-3 py-2 font-normal">Status</th>
            <th className="px-3 py-2 font-normal">Actions</th>
          </tr>
        </thead>
        <tbody>
          {scenarios.map((s) => (
            <tr key={s.id} className="border-b border-line/60 last:border-0">
              <td className="px-3 py-2 text-ink">
                {s.name} {s.previousVersionId && <span className="text-xs text-ink-faint">(v{s.version})</span>}
              </td>
              <td className="px-3 py-2 text-ink-soft">{s.scenarioType}</td>
              <td className="px-3 py-2 tabular text-ink-soft">v{s.version}</td>
              <td className="px-3 py-2 text-ink-soft">{s.createdDate}</td>
              <td className="px-3 py-2 text-ink-soft">{s.status}</td>
              <td className="px-3 py-2">
                <div className="flex gap-2 text-xs">
                  <button onClick={() => createNewVersion(s, { notes: 'Duplicated' })} className="text-ink-soft hover:text-emerald">
                    Duplicate as new version
                  </button>
                  <button onClick={() => archiveScenario(s.id)} className="text-ink-soft hover:text-ink">
                    Archive
                  </button>
                  <button onClick={() => deleteScenario(s.id)} className="text-ink-soft hover:text-rust">
                    Delete
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
