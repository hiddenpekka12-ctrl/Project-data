import { ReactNode, useState } from 'react';
import { DriverChanges, NEUTRAL_DRIVERS, ScenarioConfig, ScenarioType } from '../../scenario/types';

const SCENARIO_TYPES: ScenarioType[] = ['Base Case', 'Upside', 'Downside', 'Optimistic', 'Conservative', 'Stress', 'Custom'];

export function ScenarioBuilder({ basePeriodLabel, datasetId, onRun }: { basePeriodLabel: string; datasetId: string; onRun: (config: ScenarioConfig) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [scenarioType, setScenarioType] = useState<ScenarioType>('Custom');
  const [drivers, setDrivers] = useState<DriverChanges>(NEUTRAL_DRIVERS);

  const set = <K extends keyof DriverChanges>(key: K, value: DriverChanges[K]) => setDrivers((prev) => ({ ...prev, [key]: value }));

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Scenario Builder</p>
        <p className="mb-3 text-xs text-ink-faint">Base period: {basePeriodLabel}. Every change below is a driver — final KPIs are always recalculated, never overwritten directly.</p>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Scenario Name">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Raw material cost shock" className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </Field>
          <Field label="Scenario Type">
            <select value={scenarioType} onChange={(e) => setScenarioType(e.target.value as ScenarioType)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm">
              {SCENARIO_TYPES.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </Field>
          <Field label="Description" wide>
            <input value={description} onChange={(e) => setDescription(e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </Field>
        </div>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Business Drivers</p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <p className="mb-2 text-xs font-medium text-ink-soft">Revenue</p>
            <SliderField label="Revenue Growth %" value={drivers.revenueGrowthPct ?? 0} onChange={(v) => set('revenueGrowthPct', v)} min={-50} max={50} disabled={drivers.priceChangePct !== null || drivers.volumeChangePct !== null} />
            <SliderField label="Price Change %" value={drivers.priceChangePct ?? 0} onChange={(v) => set('priceChangePct', v)} min={-30} max={30} />
            <SliderField label="Volume Change %" value={drivers.volumeChangePct ?? 0} onChange={(v) => set('volumeChangePct', v)} min={-30} max={30} />
            <p className="text-xs text-ink-faint">Revenue = Price × Volume when either is set; otherwise Revenue Growth % applies directly.</p>
          </div>
          <div>
            <p className="mb-2 text-xs font-medium text-ink-soft">Costs</p>
            <SliderField label="COGS Change %" value={drivers.cogsChangePct} onChange={(v) => set('cogsChangePct', v)} min={-30} max={50} />
            <SliderField label="Operating Expense Change %" value={drivers.opexChangePct} onChange={(v) => set('opexChangePct', v)} min={-30} max={50} />
          </div>
          <div>
            <p className="mb-2 text-xs font-medium text-ink-soft">Finance</p>
            <SliderField label="Interest Expense Change %" value={drivers.interestRateChangePct} onChange={(v) => set('interestRateChangePct', v)} min={-50} max={100} />
            <SliderField label="Tax Rate Override % (0 = use historical)" value={drivers.taxRateOverridePct ?? 0} onChange={(v) => set('taxRateOverridePct', v === 0 ? null : v)} min={0} max={50} />
          </div>
          <div>
            <p className="mb-2 text-xs font-medium text-ink-soft">Working Capital</p>
            <SliderField label="DSO Change (days)" value={drivers.dsoChangeDays} onChange={(v) => set('dsoChangeDays', v)} min={-30} max={60} />
            <SliderField label="DIO Change (days)" value={drivers.dioChangeDays} onChange={(v) => set('dioChangeDays', v)} min={-30} max={60} />
            <SliderField label="DPO Change (days)" value={drivers.dpoChangeDays} onChange={(v) => set('dpoChangeDays', v)} min={-30} max={60} />
            <SliderField label="Capex / Fixed Asset Change %" value={drivers.capexChangePct} onChange={(v) => set('capexChangePct', v)} min={-30} max={100} />
          </div>
        </div>
      </div>

      <button
        disabled={!name.trim()}
        onClick={() =>
          onRun({
            id: `scenario-${Date.now()}`,
            name,
            description,
            basePeriodLabel,
            datasetId,
            scenarioType,
            drivers,
            horizonNote: 'Single period (base period + drivers)',
            createdDate: new Date().toISOString().slice(0, 10),
            owner: '',
            status: 'Active',
            notes: '',
            version: 1,
            previousVersionId: null,
          })
        }
        className="rounded border border-emerald bg-emerald-soft px-4 py-1.5 text-sm text-emerald disabled:opacity-40"
      >
        Run Scenario
      </button>
    </div>
  );
}

function Field({ label, children, wide }: { label: string; children: ReactNode; wide?: boolean }) {
  return (
    <label className={`block ${wide ? 'sm:col-span-2 lg:col-span-3' : ''}`}>
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      {children}
    </label>
  );
}

function SliderField({ label, value, onChange, min, max, disabled }: { label: string; value: number; onChange: (v: number) => void; min: number; max: number; disabled?: boolean }) {
  return (
    <label className={`mb-2 block ${disabled ? 'opacity-40' : ''}`}>
      <span className="mb-0.5 flex justify-between text-xs text-ink-faint">
        <span>{label}</span>
        <span className="tabular">{value >= 0 ? '+' : ''}{value}</span>
      </span>
      <input type="range" min={min} max={max} value={value} disabled={disabled} onChange={(e) => onChange(Number(e.target.value))} className="w-full" />
    </label>
  );
}
