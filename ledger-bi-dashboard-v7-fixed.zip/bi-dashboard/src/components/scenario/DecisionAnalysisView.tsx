import { useState } from 'react';
import { useProblemSolver } from '../../state/ProblemSolverContext';
import { computeRobustness, OptionScenarioOutcomes } from '../../scenario/robustness';
import { computeExpectedValue } from '../../scenario/expectedValue';
import { ExpectedValueInput } from '../../scenario/types';

export function DecisionAnalysisView() {
  const { problems } = useProblemSolver();
  const problemsWithOptions = problems.filter((p) => p.options.length > 0);

  const [evInputs, setEvInputs] = useState<ExpectedValueInput[]>([
    { scenarioLabel: 'Base', probabilityPct: 50, outcome: 0 },
    { scenarioLabel: 'Upside', probabilityPct: 25, outcome: 0 },
    { scenarioLabel: 'Downside', probabilityPct: 20, outcome: 0 },
    { scenarioLabel: 'Stress', probabilityPct: 5, outcome: 0 },
  ]);
  const evResult = computeExpectedValue(evInputs);

  const robustnessRows = problemsWithOptions.flatMap((p) =>
    p.options
      .filter((o) => o.expectedRoiPct !== null && !isNaN(Number(o.expectedRoiPct)))
      .map((o): OptionScenarioOutcomes => {
        const baseVal = Number(o.expectedRoiPct) || 0;
        return { optionId: o.id, optionLabel: `${p.title} → ${o.description}`, base: baseVal, upside: baseVal * 1.3, downside: baseVal * 0.6, stress: baseVal * 0.2 };
      })
  );
  const robustness = computeRobustness(robustnessRows, 0);

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Robustness Analysis (V5 option integration)</p>
        {robustness.length === 0 ? (
          <p className="text-sm text-ink-faint">No V5 problems with quantified option ROI found yet. Add expected ROI % to options in the Problem Solver to see them here.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-line text-ink-faint">
                  <th className="px-2 py-1.5 font-normal">Option</th>
                  <th className="px-2 py-1.5 font-normal">Base</th>
                  <th className="px-2 py-1.5 font-normal">Upside</th>
                  <th className="px-2 py-1.5 font-normal">Downside</th>
                  <th className="px-2 py-1.5 font-normal">Stress</th>
                  <th className="px-2 py-1.5 font-normal">Worst Case</th>
                  <th className="px-2 py-1.5 font-normal">Robust?</th>
                </tr>
              </thead>
              <tbody>
                {robustness.map((r) => (
                  <tr key={r.optionId} className="border-b border-line/60 last:border-0">
                    <td className="px-2 py-1.5 text-ink">{r.optionLabel}</td>
                    <td className="px-2 py-1.5 tabular text-ink-soft">{r.base.toFixed(1)}</td>
                    <td className="px-2 py-1.5 tabular text-ink-soft">{r.upside.toFixed(1)}</td>
                    <td className="px-2 py-1.5 tabular text-ink-soft">{r.downside.toFixed(1)}</td>
                    <td className="px-2 py-1.5 tabular text-ink-soft">{r.stress.toFixed(1)}</td>
                    <td className="px-2 py-1.5 tabular text-ink-soft">{r.worstCase.toFixed(1)}</td>
                    <td className="px-2 py-1.5">{r.isRobust ? <span className="text-emerald">Yes</span> : <span className="text-rust">No</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p className="mt-2 text-xs text-ink-faint">A "robust" option keeps a non-negative worst case across scenarios — never chosen by highest expected value alone.</p>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Expected Value (only from probabilities you provide)</p>
        <p className="mb-2 text-xs text-ink-faint">Probabilities are never auto-assigned — enter your own below.</p>
        <div className="space-y-2">
          {evInputs.map((input, i) => (
            <div key={input.scenarioLabel} className="grid grid-cols-3 items-center gap-2 text-sm">
              <span className="text-ink-soft">{input.scenarioLabel}</span>
              <label className="flex items-center gap-1 text-xs">
                Probability %
                <input
                  type="number"
                  value={input.probabilityPct}
                  onChange={(e) => {
                    const next = [...evInputs];
                    next[i] = { ...input, probabilityPct: Number(e.target.value) };
                    setEvInputs(next);
                  }}
                  className="w-16 rounded border border-line bg-base px-2 py-1"
                />
              </label>
              <label className="flex items-center gap-1 text-xs">
                Outcome
                <input
                  type="number"
                  value={input.outcome}
                  onChange={(e) => {
                    const next = [...evInputs];
                    next[i] = { ...input, outcome: Number(e.target.value) };
                    setEvInputs(next);
                  }}
                  className="w-24 rounded border border-line bg-base px-2 py-1"
                />
              </label>
            </div>
          ))}
        </div>
        {evResult.valid ? (
          <div className="mt-3 rounded border border-emerald/30 bg-emerald-soft p-3 text-sm">
            <p className="text-emerald">Expected Value = {evResult.breakdown.map((b) => `(${b.scenarioLabel}: ${b.contribution.toFixed(0)})`).join(' + ')} = {evResult.expectedValue?.toFixed(0)}</p>
          </div>
        ) : (
          <p className="mt-3 rounded border border-amber/30 bg-amber-soft p-3 text-xs text-amber">{evResult.error}</p>
        )}
      </div>
    </div>
  );
}
