import { useState } from 'react';
import { useDatasets } from '../../state/DatasetContext';
import { useFinance } from '../../state/FinanceContext';
import { runFxScenario } from '../../scenario/fxScenario';
import { runChurnScenario } from '../../scenario/churnSupplierScenario';
import { formatCurrency } from '../../lib/format';

export function OtherScenariosView({ currentGrossMarginPct }: { currentGrossMarginPct: number }) {
  const { activeDataset } = useDatasets();
  const { mapping } = useFinance();
  const [exposure, setExposure] = useState(100000);
  const [baseRate, setBaseRate] = useState(83);
  const [fxChangePct, setFxChangePct] = useState(5);
  const [dimension, setDimension] = useState('');

  const fxResult = runFxScenario(exposure, baseRate, fxChangePct);
  const categoricalCols = activeDataset.columns.filter((c) => activeDataset.columnTypes[c] === 'categorical');
  const revenueColumn = Object.entries(mapping).find(([, cat]) => cat === 'revenue')?.[0] ?? null;
  const churnResult = dimension && revenueColumn ? runChurnScenario(activeDataset.cleanedRows, dimension, revenueColumn, currentGrossMarginPct) : null;

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">FX Scenario (illustrative)</p>
        <p className="mb-2 text-xs text-ink-faint">This app doesn't track real multi-currency exposure — this shows the mechanical effect of a rate change on a stated exposure amount only.</p>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          <label className="text-xs">
            <span className="mb-1 block text-ink-faint">Foreign exposure amount</span>
            <input type="number" value={exposure} onChange={(e) => setExposure(Number(e.target.value))} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </label>
          <label className="text-xs">
            <span className="mb-1 block text-ink-faint">Base FX rate</span>
            <input type="number" value={baseRate} onChange={(e) => setBaseRate(Number(e.target.value))} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </label>
          <label className="text-xs">
            <span className="mb-1 block text-ink-faint">Rate change %</span>
            <input type="number" value={fxChangePct} onChange={(e) => setFxChangePct(Number(e.target.value))} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </label>
        </div>
        <p className="mt-2 text-sm text-ink-soft">
          {formatCurrency(fxResult.baseAmountLocal)} → {formatCurrency(fxResult.scenarioAmountLocal)} (impact: {formatCurrency(fxResult.impactLocal)})
        </p>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Customer/Supplier Concentration Shock</p>
        <p className="mb-2 text-xs text-ink-faint">Simulates the top entity in a dimension "churning" — reuses V4's concentration analysis, no fabricated operational data.</p>
        <select value={dimension} onChange={(e) => setDimension(e.target.value)} className="rounded border border-line bg-base px-2 py-1.5 text-sm">
          <option value="">Select a categorical dimension…</option>
          {categoricalCols.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        {!revenueColumn && <p className="mt-2 text-xs text-amber">Map a Revenue column in the Finance Center first.</p>}
        {churnResult && (
          <div className="mt-3 text-sm text-ink-soft">
            <p>
              "{churnResult.churnedEntity}" represents {churnResult.churnedSharePct.toFixed(1)}% of revenue ({formatCurrency(churnResult.churnedRevenue)}).
            </p>
            <p className="mt-1">If this entity churned: estimated gross profit impact of {formatCurrency(churnResult.estimatedGrossProfitImpact)}.</p>
            <p className="mt-1 text-xs text-ink-faint">It is a stress scenario, not an assumption that this will happen.</p>
          </div>
        )}
      </div>
    </div>
  );
}
