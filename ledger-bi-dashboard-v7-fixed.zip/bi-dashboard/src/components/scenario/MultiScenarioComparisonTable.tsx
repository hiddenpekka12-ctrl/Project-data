import { PeriodModel } from '../../finance/buildFinanceModel';
import { propagateScenario } from '../../scenario/driverModel';
import { NEUTRAL_DRIVERS } from '../../scenario/types';
import { formatCurrency } from '../../lib/format';

const STANDARD_SCENARIOS = [
  { label: 'Base', drivers: NEUTRAL_DRIVERS },
  { label: 'Upside', drivers: { ...NEUTRAL_DRIVERS, revenueGrowthPct: 10, cogsChangePct: -3 } },
  { label: 'Downside', drivers: { ...NEUTRAL_DRIVERS, revenueGrowthPct: -10, cogsChangePct: 5 } },
  { label: 'Stress', drivers: { ...NEUTRAL_DRIVERS, revenueGrowthPct: -25, cogsChangePct: 12, dsoChangeDays: 15 } },
];

export function MultiScenarioComparisonTable({ base }: { base: PeriodModel }) {
  const runs = STANDARD_SCENARIOS.map((s) => ({ label: s.label, period: propagateScenario(base, s.drivers) }));

  const rows: { label: string; get: (p: PeriodModel) => string }[] = [
    { label: 'Revenue', get: (p) => formatCurrency(p.income.revenue) },
    { label: 'Gross Profit', get: (p) => formatCurrency(p.income.grossProfit) },
    { label: 'EBITDA', get: (p) => formatCurrency(p.income.ebitda) },
    { label: 'Net Profit', get: (p) => formatCurrency(p.income.netProfit) },
    { label: 'Cash', get: (p) => formatCurrency(p.balanceSheet.cash) },
    { label: 'Debt', get: (p) => formatCurrency(p.balanceSheet.longTermDebt) },
    { label: 'Current Ratio', get: (p) => p.liquidityRatios.find((r) => r.key === 'currentRatio')?.value?.toFixed(2) ?? 'n/a' },
    { label: 'Interest Coverage', get: (p) => { const v = p.solvencyRatios.find((r) => r.key === 'interestCoverage')?.value; return v !== null && v !== undefined ? `${v.toFixed(1)}×` : 'n/a'; } },
  ];

  return (
    <div className="overflow-x-auto rounded border border-line bg-surface p-4">
      <p className="mb-2 text-sm font-medium text-ink">Scenario Comparison</p>
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-line text-xs text-ink-faint">
            <th className="px-2 py-1.5 font-normal">Metric</th>
            {runs.map((r) => (
              <th key={r.label} className="px-2 py-1.5 font-normal">{r.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.label} className="border-b border-line/60 last:border-0">
              <td className="px-2 py-1.5 text-ink">{row.label}</td>
              {runs.map((r) => (
                <td key={r.label} className="px-2 py-1.5 tabular text-ink-soft">{row.get(r.period)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-2 text-xs text-ink-faint">Upside/Downside/Stress here use illustrative default assumptions — build a Custom scenario in the Builder tab for your own drivers.</p>
    </div>
  );
}
