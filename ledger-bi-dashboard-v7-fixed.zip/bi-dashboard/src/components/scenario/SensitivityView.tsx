import { useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { PeriodModel } from '../../finance/buildFinanceModel';
import { buildTornadoRanking, DRIVER_LABELS, runOneWaySensitivity, runTwoWaySensitivity } from '../../scenario/sensitivity';
import { SensitivityDriverKey } from '../../scenario/types';
import { formatCurrency } from '../../lib/format';

const ALL_DRIVERS: SensitivityDriverKey[] = ['revenueGrowthPct', 'cogsChangePct', 'opexChangePct', 'interestRateChangePct', 'dsoChangeDays', 'dioChangeDays', 'dpoChangeDays'];

export function SensitivityView({ base }: { base: PeriodModel }) {
  const [oneWayDriver, setOneWayDriver] = useState<SensitivityDriverKey>('revenueGrowthPct');
  const [driverA, setDriverA] = useState<SensitivityDriverKey>('revenueGrowthPct');
  const [driverB, setDriverB] = useState<SensitivityDriverKey>('cogsChangePct');

  const oneWay = runOneWaySensitivity(base, oneWayDriver);
  const tornado = buildTornadoRanking(base, ALL_DRIVERS);
  const twoWay = runTwoWaySensitivity(base, driverA, driverB);

  const twoWaySteps = Array.from(new Set(twoWay.cells.map((c) => c.driverAValue))).sort((a, b) => a - b);
  const twoWayStepsB = Array.from(new Set(twoWay.cells.map((c) => c.driverBValue))).sort((a, b) => a - b);

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">One-way Sensitivity: which assumption has the largest effect?</p>
        <select value={oneWayDriver} onChange={(e) => setOneWayDriver(e.target.value as SensitivityDriverKey)} className="mb-2 rounded border border-line bg-base px-2 py-1.5 text-sm">
          {ALL_DRIVERS.map((d) => (
            <option key={d} value={d}>{DRIVER_LABELS[d]}</option>
          ))}
        </select>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-line text-ink-faint">
                <th className="px-2 py-1.5 font-normal">Change</th>
                <th className="px-2 py-1.5 font-normal">Net Profit</th>
                <th className="px-2 py-1.5 font-normal">Cash</th>
                <th className="px-2 py-1.5 font-normal">Resilience Score</th>
              </tr>
            </thead>
            <tbody>
              {oneWay.points.map((p) => (
                <tr key={p.driverValue} className={`border-b border-line/60 last:border-0 ${p.driverValue === 0 ? 'bg-emerald-soft/40' : ''}`}>
                  <td className="px-2 py-1.5 tabular text-ink">{p.driverValue >= 0 ? '+' : ''}{p.driverValue}</td>
                  <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(p.netProfit)}</td>
                  <td className="px-2 py-1.5 tabular text-ink-soft">{formatCurrency(p.cash)}</td>
                  <td className="px-2 py-1.5 tabular text-ink-soft">{p.riskScore}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Tornado Chart — highest-impact drivers (±10% swing on Net Profit)</p>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={tornado.map((t) => ({ name: t.label, range: [t.lowOutcome, t.highOutcome] }))} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} tickFormatter={(v) => formatCurrency(v)} />
              <YAxis dataKey="name" type="category" width={110} tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={false} tickLine={false} />
              <Tooltip formatter={(v: [number, number]) => `${formatCurrency(v[0])} to ${formatCurrency(v[1])}`} contentStyle={{ fontSize: 12, borderRadius: 4 }} />
              <Bar dataKey="range" fill="#4A5B68" radius={[0, 2, 2, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <p className="mt-2 text-xs text-ink-faint">Ranked by actual calculated swing in net profit — never a fabricated order.</p>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Two-way Sensitivity: {DRIVER_LABELS[driverA]} × {DRIVER_LABELS[driverB]} → Net Profit</p>
        <div className="mb-2 flex gap-2">
          <select value={driverA} onChange={(e) => setDriverA(e.target.value as SensitivityDriverKey)} className="rounded border border-line bg-base px-2 py-1.5 text-xs">
            {ALL_DRIVERS.map((d) => (
              <option key={d} value={d}>{DRIVER_LABELS[d]}</option>
            ))}
          </select>
          <select value={driverB} onChange={(e) => setDriverB(e.target.value as SensitivityDriverKey)} className="rounded border border-line bg-base px-2 py-1.5 text-xs">
            {ALL_DRIVERS.map((d) => (
              <option key={d} value={d}>{DRIVER_LABELS[d]}</option>
            ))}
          </select>
        </div>
        <div className="overflow-x-auto">
          <table className="text-xs">
            <thead>
              <tr>
                <th className="p-1" />
                {twoWayStepsB.map((b) => (
                  <th key={b} className="p-1 text-ink-faint">{b >= 0 ? '+' : ''}{b}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {twoWaySteps.map((a) => (
                <tr key={a}>
                  <th className="p-1 text-right text-ink-faint">{a >= 0 ? '+' : ''}{a}</th>
                  {twoWayStepsB.map((b) => {
                    const cell = twoWay.cells.find((c) => c.driverAValue === a && c.driverBValue === b);
                    const intensity = cell && cell.outcome >= 0 ? 'bg-emerald-soft text-emerald' : 'bg-rust-soft text-rust';
                    return (
                      <td key={b} className={`p-1 text-center tabular ${intensity}`}>
                        {cell ? (cell.outcome / 1000).toFixed(0) + 'k' : '—'}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
