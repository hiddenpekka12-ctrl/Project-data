import { ScenarioResult } from '../../scenario/types';
import { formatCurrency } from '../../lib/format';

export function ScenarioComparisonView({ result }: { result: ScenarioResult }) {
  return (
    <div className="space-y-4">
      <div className="rounded border border-amber/30 bg-amber-soft px-3 py-2 text-xs text-amber">
        Labeled <strong>SCENARIO</strong>, not a forecast or actual — "what would happen if we assume this," not "what is likely to happen."
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Propagation Chain — {result.config.name}</p>
        <div className="space-y-1.5">
          {result.chain.map((step, i) => (
            <div key={i} className="flex items-center justify-between border-b border-line/60 py-1.5 text-sm last:border-0">
              <span className="text-ink-soft">{step.label}</span>
              <span className="tabular text-ink-faint">
                {formatCurrency(step.baseValue)} → <span className="font-medium text-ink">{formatCurrency(step.scenarioValue)}</span>{' '}
                <span className={step.scenarioValue >= step.baseValue ? 'text-emerald' : 'text-rust'}>({step.changeDescription})</span>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Assumption Transparency</p>
        {result.assumptions.length === 0 ? (
          <p className="text-sm text-ink-faint">No drivers changed — this is the base case.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-line text-ink-faint">
                  <th className="px-2 py-1.5 font-normal">Input</th>
                  <th className="px-2 py-1.5 font-normal">Base</th>
                  <th className="px-2 py-1.5 font-normal">Scenario</th>
                  <th className="px-2 py-1.5 font-normal">Change</th>
                  <th className="px-2 py-1.5 font-normal">Source</th>
                </tr>
              </thead>
              <tbody>
                {result.assumptions.map((a, i) => (
                  <tr key={i} className="border-b border-line/60 last:border-0">
                    <td className="px-2 py-1.5 text-ink">{a.input}</td>
                    <td className="px-2 py-1.5 tabular text-ink-soft">{a.baseValue}</td>
                    <td className="px-2 py-1.5 tabular text-ink-soft">{a.scenarioValue}</td>
                    <td className="px-2 py-1.5 tabular text-ink-soft">{a.change}</td>
                    <td className="px-2 py-1.5 text-ink-faint">{a.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Metric label="Revenue" value={formatCurrency(result.financialSummary.revenue)} />
        <Metric label="EBITDA" value={formatCurrency(result.financialSummary.ebitda)} />
        <Metric label="Net Profit" value={formatCurrency(result.financialSummary.netProfit)} />
        <Metric label="Closing Cash" value={formatCurrency(result.financialSummary.closingCash)} tone={result.financialSummary.closingCash < 0 ? 'rust' : undefined} />
        <Metric label="Current Ratio" value={result.financialSummary.currentRatio?.toFixed(2) ?? 'n/a'} />
        <Metric label="Interest Coverage" value={result.financialSummary.interestCoverage !== null ? `${result.financialSummary.interestCoverage.toFixed(1)}×` : 'n/a'} />
        <Metric label="Working Capital" value={formatCurrency(result.financialSummary.workingCapital)} />
        <Metric label="Health Score Δ" value={result.riskScoreDelta !== null ? `${result.riskScoreDelta >= 0 ? '+' : ''}${result.riskScoreDelta}` : 'n/a'} tone={result.riskScoreDelta !== null && result.riskScoreDelta < 0 ? 'rust' : undefined} />
      </div>

      {result.redFlagCount > 0 && (
        <p className="rounded border border-rust/30 bg-rust-soft px-3 py-2 text-xs text-rust">{result.redFlagCount} red flag(s) triggered under this scenario — see the Risk Impact tab for detail.</p>
      )}
    </div>
  );
}

function Metric({ label, value, tone }: { label: string; value: string; tone?: 'rust' }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className={`mt-1 font-serif text-lg tabular ${tone === 'rust' ? 'text-rust' : 'text-ink'}`}>{value}</p>
    </div>
  );
}
