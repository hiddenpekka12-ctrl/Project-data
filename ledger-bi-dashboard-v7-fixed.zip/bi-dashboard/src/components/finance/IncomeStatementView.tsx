import { IncomeStatementLine } from '../../finance/types';
import { formatCurrency } from '../../lib/format';

function Line({ label, value, revenue, isSubtotal, indent }: { label: string; value: number; revenue: number; isSubtotal?: boolean; indent?: boolean }) {
  const pctOfRevenue = revenue === 0 ? 0 : (value / revenue) * 100;
  return (
    <div className={`flex items-center justify-between py-1.5 text-sm ${isSubtotal ? 'border-t border-line font-medium text-ink' : 'text-ink-soft'} ${indent ? 'pl-4' : ''}`}>
      <span>{label}</span>
      <span className="tabular">
        {formatCurrency(value)} <span className="text-xs text-ink-faint">({pctOfRevenue.toFixed(1)}%)</span>
      </span>
    </div>
  );
}

export function IncomeStatementView({ income, label }: { income: IncomeStatementLine; label: string }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="mb-1 text-sm font-medium text-ink">Income Statement — {label}</p>
      <p className="mb-3 text-xs text-ink-faint">Absolute values shown with % of revenue alongside.</p>
      <div className="divide-y divide-line/60">
        <Line label="Revenue" value={income.revenue} revenue={income.revenue} isSubtotal />
        <Line label="− COGS" value={-income.cogs} revenue={income.revenue} indent />
        <Line label="= Gross Profit" value={income.grossProfit} revenue={income.revenue} isSubtotal />
        <Line label="− Operating Expenses" value={-income.operatingExpenses} revenue={income.revenue} indent />
        <Line label="= EBITDA" value={income.ebitda} revenue={income.revenue} isSubtotal />
        <Line label="− Depreciation & Amortization" value={-income.depreciation} revenue={income.revenue} indent />
        <Line label="= EBIT" value={income.ebit} revenue={income.revenue} isSubtotal />
        <Line label="− Interest" value={-income.interest} revenue={income.revenue} indent />
        <Line label="+ Other Income" value={income.otherIncome} revenue={income.revenue} indent />
        <Line label="− Other Expenses" value={-income.otherExpenses} revenue={income.revenue} indent />
        <Line label="= Profit Before Tax" value={income.profitBeforeTax} revenue={income.revenue} isSubtotal />
        <Line label="− Tax" value={-income.tax} revenue={income.revenue} indent />
        <Line label="= Net Profit" value={income.netProfit} revenue={income.revenue} isSubtotal />
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2 border-t border-line pt-3 text-xs text-ink-faint sm:grid-cols-4">
        <Growth label="Revenue MoM" value={income.momRevenueGrowthPct} />
        <Growth label="Revenue YoY" value={income.yoyRevenueGrowthPct} />
        <Growth label="Net Profit MoM" value={income.momNetProfitGrowthPct} />
        <Growth label="Net Profit YoY" value={income.yoyNetProfitGrowthPct} />
      </div>
    </div>
  );
}

function Growth({ label, value }: { label: string; value: number | null }) {
  return (
    <div>
      <p>{label}</p>
      <p className={`tabular ${value === null ? 'text-ink-faint' : value >= 0 ? 'text-emerald' : 'text-rust'}`}>{value === null ? 'n/a' : `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`}</p>
    </div>
  );
}
