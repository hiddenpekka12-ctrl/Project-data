import { DuPontResult } from '../../finance/types';
import { LearnThis } from '../analytics/LearnThis';

export function DuPontView({ dupont }: { dupont: DuPontResult }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="flex items-center text-sm font-medium text-ink">
        DuPont Analysis
        <LearnThis conceptKey="dupont" />
      </p>
      <p className="mt-1 text-xs text-ink-faint">Is ROE high because of profitability, asset efficiency, or leverage?</p>

      <div className="mt-3 flex flex-wrap items-center gap-3">
        <Driver label="Net Profit Margin" value={dupont.netMargin === null ? null : dupont.netMargin * 100} suffix="%" />
        <span className="text-ink-faint">×</span>
        <Driver label="Asset Turnover" value={dupont.assetTurnover} suffix="×" />
        <span className="text-ink-faint">×</span>
        <Driver label="Equity Multiplier" value={dupont.equityMultiplier} suffix="×" />
        <span className="text-ink-faint">=</span>
        <Driver label="ROE" value={dupont.roe === null ? null : dupont.roe * 100} suffix="%" highlight />
      </div>

      {dupont.roe !== null && dupont.netMargin !== null && dupont.assetTurnover !== null && dupont.equityMultiplier !== null && (
        <p className="mt-3 text-xs text-ink-soft">
          {dupont.netMargin > 0.1
            ? 'A strong net margin is a meaningful driver of ROE here.'
            : dupont.equityMultiplier > 2.5
            ? 'Leverage (the equity multiplier) is doing a lot of the work in this ROE — that raises risk alongside return.'
            : 'ROE here reflects a moderate mix of margin, efficiency, and leverage — no single driver dominates.'}
        </p>
      )}
    </div>
  );
}

function Driver({ label, value, suffix, highlight }: { label: string; value: number | null; suffix: string; highlight?: boolean }) {
  return (
    <div className={`rounded border px-3 py-2 text-center ${highlight ? 'border-emerald bg-emerald-soft' : 'border-line bg-base'}`}>
      <p className="text-[10px] text-ink-faint">{label}</p>
      <p className={`font-serif text-lg tabular ${highlight ? 'text-emerald' : 'text-ink'}`}>{value === null ? 'n/a' : `${value.toFixed(2)}${suffix}`}</p>
    </div>
  );
}
