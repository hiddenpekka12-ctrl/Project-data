import { useDatasets } from '../../state/DatasetContext';
import { useFinance } from '../../state/FinanceContext';
import { CATEGORY_LABELS } from '../../finance/accountMapping';
import { FinanceCategory, PeriodGranularity } from '../../finance/types';

const CATEGORY_OPTIONS: FinanceCategory[] = [
  'unmapped',
  'revenue',
  'cogs',
  'operatingExpenses',
  'depreciation',
  'interest',
  'tax',
  'cash',
  'receivables',
  'inventory',
  'fixedAssets',
  'currentLiabilities',
  'longTermDebt',
  'equity',
  'otherIncome',
  'otherExpenses',
];

export function AccountMappingPanel() {
  const { activeDataset } = useDatasets();
  const { mapping, setMapping, settings, setSettings } = useFinance();

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Finance settings</p>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <label className="block">
            <span className="mb-1 block text-xs text-ink-faint">Date column</span>
            <select
              value={settings.dateColumn ?? ''}
              onChange={(e) => setSettings({ ...settings, dateColumn: e.target.value || null })}
              className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm text-ink-soft"
            >
              <option value="">None selected</option>
              {activeDataset.columns.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="mb-1 block text-xs text-ink-faint">Reporting period</span>
            <select
              value={settings.granularity}
              onChange={(e) => setSettings({ ...settings, granularity: e.target.value as PeriodGranularity })}
              className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm text-ink-soft"
            >
              <option value="month">Monthly</option>
              <option value="quarter">Quarterly</option>
              <option value="year">Annual</option>
            </select>
          </label>
          <label className="block">
            <span className="mb-1 block text-xs text-ink-faint">Currency</span>
            <input
              value={settings.currency}
              onChange={(e) => setSettings({ ...settings, currency: e.target.value.toUpperCase().slice(0, 3) })}
              className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm text-ink-soft"
            />
          </label>
        </div>
        <p className="mt-2 text-xs text-ink-faint">
          Multi-currency conversion isn't implemented yet — this just records which currency the figures are in so they're never silently mixed with another dataset's currency.
        </p>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-1 text-sm font-medium text-ink">Account mapping</p>
        <p className="mb-3 text-xs text-ink-faint">
          Map each column to a financial category. Auto-detected by column name — override anything that's wrong. Unmapped columns are ignored by the Finance Engine.
        </p>
        <div className="space-y-2">
          {activeDataset.columns
            .filter((c) => c !== settings.dateColumn)
            .map((c) => (
              <div key={c} className="flex items-center justify-between gap-2 border-b border-line/60 pb-2 last:border-0">
                <span className="text-sm text-ink-soft">{c}</span>
                <select
                  value={mapping[c] ?? 'unmapped'}
                  onChange={(e) => setMapping({ ...mapping, [c]: e.target.value as FinanceCategory })}
                  className="rounded border border-line bg-base px-2 py-1 text-xs text-ink-soft"
                >
                  {CATEGORY_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>
                      {CATEGORY_LABELS[opt]}
                    </option>
                  ))}
                </select>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
