import { CashFlowLine } from '../../finance/types';
import { formatCurrency } from '../../lib/format';

function Row({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center justify-between border-b border-line/60 py-1.5 text-sm text-ink-soft last:border-0">
      <span>{label}</span>
      <span className="tabular">{formatCurrency(value)}</span>
    </div>
  );
}

export function CashFlowView({ cf }: { cf: CashFlowLine }) {
  return (
    <div className="space-y-4">
      <div className="rounded border border-amber/30 bg-amber-soft px-4 py-3 text-xs text-amber">
        <strong>Profit ≠ Cash Flow.</strong> Profit is an accounting measure that includes non-cash items (like depreciation) and counts revenue when earned, not when collected.
        Cash flow tracks money actually moving. A business can be profitable and still run out of cash if that profit is tied up in receivables or inventory.
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Operating Cash Flow (estimated, indirect method)</p>
        <Row label="Net Profit" value={cf.netProfit} />
        <Row label="+ Depreciation add-back" value={cf.depreciationAddBack} />
        <Row label="− Increase in Receivables" value={-cf.changeInReceivables} />
        <Row label="− Increase in Inventory" value={-cf.changeInInventory} />
        <Row label="+ Increase in Current Liabilities" value={cf.changeInCurrentLiabilities} />
        <div className="mt-2 flex items-center justify-between border-t border-line pt-2 text-sm font-medium text-ink">
          <span>= Operating Cash Flow</span>
          <span className="tabular">{formatCurrency(cf.operatingCashFlow)}</span>
        </div>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Free Cash Flow (estimated)</p>
        <Row label="Operating Cash Flow" value={cf.operatingCashFlow} />
        <Row label="− Estimated Capital Expenditure (increase in Fixed Assets)" value={-Math.max(0, cf.changeInFixedAssets)} />
        <div className="mt-2 flex items-center justify-between border-t border-line pt-2 text-sm font-medium text-ink">
          <span>= Free Cash Flow</span>
          <span className="tabular">{formatCurrency(cf.freeCashFlow)}</span>
        </div>
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Actual Net Change in Cash</p>
        <Row label="Actual change in cash balance" value={cf.actualNetChangeInCash} />
        <Row label="Operating Cash Flow (above)" value={cf.operatingCashFlow} />
        <div className="mt-2 flex items-center justify-between border-t border-line pt-2 text-sm font-medium text-ink">
          <span>= Implied Investing + Financing Cash Flow</span>
          <span className="tabular">{formatCurrency(cf.impliedInvestingPlusFinancing)}</span>
        </div>
        <p className="mt-2 text-xs text-ink-faint">
          Shown as one combined line because the account mapping doesn't separate investing from financing activity (e.g. capex vs. debt issuance/repayment vs. dividends) —
          splitting it further would mean guessing, not calculating.
        </p>
      </div>
    </div>
  );
}
