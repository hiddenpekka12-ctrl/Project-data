import { useState } from 'react';
import { useFinance } from '../../state/FinanceContext';
import { useDatasets, DEMO_DATASET_ID } from '../../state/DatasetContext';
import { CATEGORY_LABELS } from '../../finance/accountMapping';
import { FinanceCategory } from '../../finance/types';

const MANUAL_FIELDS: FinanceCategory[] = [
  'revenue',
  'cogs',
  'operatingExpenses',
  'depreciation',
  'interest',
  'tax',
  'cash',
  'receivables',
  'inventory',
  'fixedAssets',
  'currentLiabilities',
  'longTermDebt',
  'equity',
  'otherIncome',
  'otherExpenses',
];

export function DataSourcePanel() {
  const { datasets, activeId, setActiveId } = useDatasets();
  const { loadAbcDemoCompany, addManualEntryPeriod } = useFinance();
  const [manualValues, setManualValues] = useState<Record<string, string>>({});
  const [periodLabel, setPeriodLabel] = useState(new Date().toISOString().slice(0, 7));
  const [showManual, setShowManual] = useState(false);

  const financeDatasets = datasets.filter((d) => d.id !== DEMO_DATASET_ID);

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-2 text-sm font-medium text-ink">Choose a data source</p>
        <div className="flex flex-wrap gap-2">
          <button onClick={loadAbcDemoCompany} className="rounded border border-line bg-base px-3 py-1.5 text-sm text-ink-soft hover:border-emerald hover:text-emerald">
            Load demo company (ABC Manufacturing Ltd.)
          </button>
          <button onClick={() => setShowManual((s) => !s)} className="rounded border border-line bg-base px-3 py-1.5 text-sm text-ink-soft hover:bg-line/40">
            {showManual ? 'Hide manual entry' : 'Enter figures manually'}
          </button>
        </div>
        <p className="mt-2 text-xs text-ink-faint">
          Or go to Analytics → Import to upload a CSV/XLSX/JSON dataset, then map its columns below.
        </p>
      </div>

      {showManual && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-1 text-sm font-medium text-ink">Manual entry — one period</p>
          <p className="mb-3 text-xs text-ink-faint">Creates a small dataset from these figures so it flows through the same Finance Engine as an upload.</p>
          <label className="mb-3 block max-w-xs">
            <span className="mb-1 block text-xs text-ink-faint">Period label (YYYY-MM)</span>
            <input value={periodLabel} onChange={(e) => setPeriodLabel(e.target.value)} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm" />
          </label>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {MANUAL_FIELDS.map((f) => (
              <label key={f} className="block">
                <span className="mb-1 block text-xs text-ink-faint">{CATEGORY_LABELS[f]}</span>
                <input
                  type="number"
                  value={manualValues[f] ?? ''}
                  onChange={(e) => setManualValues((prev) => ({ ...prev, [f]: e.target.value }))}
                  className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm tabular"
                />
              </label>
            ))}
          </div>
          <button
            onClick={() => {
              const values: Record<string, number> = {};
              MANUAL_FIELDS.forEach((f) => {
                values[f] = Number(manualValues[f] ?? 0);
              });
              addManualEntryPeriod(values, periodLabel);
              setShowManual(false);
            }}
            className="mt-3 rounded border border-emerald bg-emerald-soft px-3 py-1.5 text-sm text-emerald"
          >
            Save this period
          </button>
        </div>
      )}

      {financeDatasets.length > 0 && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Or switch to an existing dataset</p>
          <div className="flex flex-wrap gap-2">
            {financeDatasets.map((d) => (
              <button
                key={d.id}
                onClick={() => setActiveId(d.id)}
                className={`rounded border px-3 py-1.5 text-xs ${activeId === d.id ? 'border-emerald bg-emerald-soft text-emerald' : 'border-line text-ink-soft hover:bg-base'}`}
              >
                {d.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
