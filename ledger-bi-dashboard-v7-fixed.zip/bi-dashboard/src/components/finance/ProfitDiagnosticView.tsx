import { ProfitDiagnosticResult } from '../../finance/types';
import { formatCurrency } from '../../lib/format';

interface Bar {
  label: string;
  start: number;
  end: number;
  isTotal?: boolean;
  value: number;
}

function buildBars(d: ProfitDiagnosticResult): Bar[] {
  let running = d.startingProfit;
  const steps: Bar[] = [{ label: d.fromLabel, start: 0, end: d.startingProfit, isTotal: true, value: d.startingProfit }];
  const effects: [string, number][] = [
    ['Revenue effect', d.revenueEffect],
    ['COGS effect', d.cogsEffect],
    ['Operating expense effect', d.opexEffect],
    ['Other (interest, tax, D&A, other income/expense)', d.otherEffect],
  ];
  effects.forEach(([label, value]) => {
    const start = running;
    running += value;
    steps.push({ label, start: Math.min(start, running), end: Math.max(start, running), value });
  });
  steps.push({ label: d.toLabel, start: 0, end: d.endingProfit, isTotal: true, value: d.endingProfit });
  return steps;
}

export function ProfitDiagnosticView({ diagnostic }: { diagnostic: ProfitDiagnosticResult }) {
  const bars = buildBars(diagnostic);
  const allValues = bars.flatMap((b) => [b.start, b.end]);
  const min = Math.min(0, ...allValues);
  const max = Math.max(...allValues);
  const range = max - min || 1;

  const width = 760;
  const height = 280;
  const padding = 50;
  const plotHeight = height - padding * 2;
  const bandWidth = (width - padding * 2) / bars.length;

  const scaleY = (v: number) => padding + plotHeight - ((v - min) / range) * plotHeight;

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="mb-1 text-sm font-medium text-ink">
        Profit Diagnostic — why did profit change from {diagnostic.fromLabel} to {diagnostic.toLabel}?
      </p>
      <p className="mb-3 text-xs text-ink-faint">Each bar shows one effect's contribution; the four effects sum exactly to the total change.</p>
      <div className="overflow-x-auto">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ minWidth: 560 }}>
          <line x1={padding} y1={scaleY(0)} x2={width - padding} y2={scaleY(0)} stroke="#E2E5E1" />
          {bars.map((b, i) => {
            const x = padding + bandWidth * i + bandWidth * 0.15;
            const barWidth = bandWidth * 0.7;
            const color = b.isTotal ? '#4A5B68' : b.value >= 0 ? '#1F6F54' : '#B3452C';
            return (
              <g key={i}>
                <rect x={x} y={scaleY(b.end)} width={barWidth} height={Math.max(1, Math.abs(scaleY(b.start) - scaleY(b.end)))} fill={color} opacity={b.isTotal ? 1 : 0.85} />
                <text x={x + barWidth / 2} y={scaleY(Math.max(b.start, b.end)) - 6} textAnchor="middle" fontSize="10" fill="#4B5A55" className="tabular">
                  {formatCurrency(b.isTotal ? b.value : b.value)}
                </text>
                <text x={x + barWidth / 2} y={height - padding + 16} textAnchor="middle" fontSize="9" fill="#8A968F">
                  {b.label.length > 14 ? `${b.label.slice(0, 13)}…` : b.label}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}
