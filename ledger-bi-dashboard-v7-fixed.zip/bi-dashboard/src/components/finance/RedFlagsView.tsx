import { RedFlag } from '../../finance/types';

export function RedFlagsView({ flags }: { flags: RedFlag[] }) {
  if (flags.length === 0) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">No red flags detected from the available data for the current period.</p>;
  }

  return (
    <div className="space-y-3">
      <p className="text-xs text-ink-faint">A red flag identifies a pattern worth investigating — it does not automatically mean financial distress.</p>
      {flags.map((f) => (
        <div key={f.id} className={`rounded border p-4 ${f.severity === 'critical' ? 'border-rust/40 bg-rust-soft' : 'border-amber/40 bg-amber-soft'}`}>
          <p className={`text-sm font-medium ${f.severity === 'critical' ? 'text-rust' : 'text-amber'}`}>
            {f.severity === 'critical' ? '🔴' : '🟠'} {f.label}
          </p>
          <dl className="mt-2 space-y-1.5 text-xs">
            <div>
              <dt className="font-medium text-ink">What happened</dt>
              <dd className="text-ink-soft">{f.whatHappened}</dd>
            </div>
            <div>
              <dt className="font-medium text-ink">Supporting metric</dt>
              <dd className="tabular text-ink-soft">{f.supportingMetric}</dd>
            </div>
            <div>
              <dt className="font-medium text-ink">Why it matters</dt>
              <dd className="text-ink-soft">{f.whyItMatters}</dd>
            </div>
            <div>
              <dt className="font-medium text-ink">Possible explanation</dt>
              <dd className="text-ink-soft">{f.possibleExplanation}</dd>
            </div>
            <div>
              <dt className="font-medium text-ink">Suggested investigation</dt>
              <dd className="text-ink-soft">{f.suggestedInvestigation}</dd>
            </div>
          </dl>
        </div>
      ))}
    </div>
  );
}
