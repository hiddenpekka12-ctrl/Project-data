import { useState } from 'react';
import { RatioResult } from '../../finance/types';

function formatValue(v: number): string {
  return new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(v);
}

const BAND_STYLES: Record<RatioResult['band'], string> = {
  strong: 'text-emerald',
  adequate: 'text-amber',
  weak: 'text-rust',
  unavailable: 'text-ink-faint',
};

export function RatioCard({ ratio }: { ratio: RatioResult }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded border border-line bg-surface p-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-ink-soft">{ratio.label}</p>
        <button onClick={() => setOpen((o) => !o)} className="text-[10px] text-ink-faint hover:text-emerald">
          {open ? 'Hide formula' : 'Show formula'}
        </button>
      </div>
      <p className={`mt-1 font-serif text-xl tabular ${BAND_STYLES[ratio.band]}`}>
        {ratio.value === null ? 'n/a' : `${formatValue(ratio.value)}${ratio.unit === '%' ? '%' : ratio.unit === 'x' ? '×' : ''}`}
      </p>
      <p className="mt-1 text-xs text-ink-faint">{ratio.interpretation}</p>
      {ratio.caveat && <p className="mt-1 text-xs italic text-amber">{ratio.caveat}</p>}
      {open && (
        <div className="mt-2 space-y-1 border-t border-line pt-2 text-xs text-ink-soft">
          <p>
            <span className="text-ink-faint">Formula: </span>
            {ratio.formula}
          </p>
          {Object.entries(ratio.inputs).map(([k, v]) => (
            <p key={k}>
              <span className="text-ink-faint">{k}: </span>
              {formatValue(v)}
            </p>
          ))}
        </div>
      )}
    </div>
  );
}

export function RatioGrid({ ratios }: { ratios: RatioResult[] }) {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {ratios.map((r) => (
        <RatioCard key={r.key} ratio={r} />
      ))}
    </div>
  );
}
