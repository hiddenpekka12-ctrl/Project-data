import { FinancialInsight } from '../../finance/types';

export function FinancialInsightsView({ insights }: { insights: FinancialInsight[] }) {
  if (insights.length === 0) {
    return <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">Not enough periods yet to generate financial insights — need at least two periods of income statement data.</p>;
  }

  return (
    <div className="space-y-3">
      {insights.map((insight) => (
        <div key={insight.id} className="rounded border border-line bg-surface p-4">
          <p className="text-sm text-ink">{insight.finding}</p>
          <p className="mt-1 text-xs text-ink-faint">Supporting data: {insight.supportingData}</p>
          <p className="mt-2 text-xs font-medium text-ink-soft">Management implication</p>
          <p className="text-xs text-ink-soft">{insight.managementImplication}</p>
          <p className="mt-2 text-xs font-medium text-ink-soft">Suggested investigation</p>
          <p className="text-xs text-ink-soft">{insight.suggestedInvestigation}</p>
        </div>
      ))}
    </div>
  );
}
