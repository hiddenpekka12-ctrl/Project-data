import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { WorkingCapitalLine } from '../../finance/types';
import { formatCurrency } from '../../lib/format';
import { LearnThis } from '../analytics/LearnThis';

export function WorkingCapitalView({
  wc,
  label,
  series,
}: {
  wc: WorkingCapitalLine;
  label: string;
  series: { label: string; ccc: number | null }[];
}) {
  const chartData = series.filter((s) => s.ccc !== null).map((s) => ({ label: s.label, CCC: s.ccc as number }));
  const trend = series.length > 1 && series[series.length - 1].ccc !== null && series[series.length - 2].ccc !== null
    ? (series[series.length - 1].ccc as number) - (series[series.length - 2].ccc as number)
    : null;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Metric label="Working Capital" value={formatCurrency(wc.workingCapital)} />
        <Metric label="Days Sales Outstanding (DSO)" value={wc.dso === null ? 'n/a' : `${wc.dso.toFixed(0)} days`} />
        <Metric label="Days Inventory Outstanding (DIO)" value={wc.dio === null ? 'n/a' : `${wc.dio.toFixed(0)} days`} />
        <Metric label="Days Payable Outstanding (DPO)" value={wc.dpo === null ? 'n/a' : `${wc.dpo.toFixed(0)} days`} />
      </div>

      <div className="rounded border border-line bg-surface p-4">
        <p className="flex items-center text-sm font-medium text-ink">
          Cash Conversion Cycle — {label}
          <LearnThis conceptKey="cashConversionCycle" />
        </p>
        <p className="mt-1 text-2xl font-serif tabular text-ink">{wc.cashConversionCycle === null ? 'n/a' : `${wc.cashConversionCycle.toFixed(0)} days`}</p>
        <p className="mt-1 text-xs text-ink-faint">How long cash remains tied up in the operating cycle: DSO + DIO − DPO.</p>
        {trend !== null && (
          <p className={`mt-1 text-xs ${trend < 0 ? 'text-emerald' : trend > 0 ? 'text-rust' : 'text-ink-faint'}`}>
            {trend < 0 ? 'Improving' : trend > 0 ? 'Deteriorating' : 'Unchanged'} vs. the prior period ({trend >= 0 ? '+' : ''}
            {trend.toFixed(0)} days).
          </p>
        )}
        {chartData.length > 1 && (
          <div className="mt-3 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
                <Line type="monotone" dataKey="CCC" stroke="#A9782E" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
        <p className="mt-2 text-xs italic text-ink-faint">DPO uses total Current Liabilities as a proxy for payables, since payables aren't separately mapped.</p>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className="mt-1 font-serif text-lg tabular text-ink">{value}</p>
    </div>
  );
}
