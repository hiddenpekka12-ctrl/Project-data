import { useState } from 'react';
import { answerFinancialQuestion, FinanceQAContext } from '../../finance/financeQuestions';
import { FinancialQuestionAnswer } from '../../finance/types';

const EXAMPLES = [
  'Why is profit declining?',
  'Is the company financially healthy?',
  'Is debt becoming dangerous?',
  'Why is cash falling despite profit?',
  'Which cost is increasing fastest?',
  'Is working capital improving?',
  'What is causing margin compression?',
];

export function FinancialDecisionBox({ ctx }: { ctx: FinanceQAContext }) {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<FinancialQuestionAnswer | null>(null);

  const ask = (q: string) => {
    setQuestion(q);
    setAnswer(answerFinancialQuestion(q, ctx));
  };

  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-sm font-medium text-ink">Financial Decision Support</p>
      <p className="mb-2 text-xs text-ink-faint">Answers only from the data currently mapped — never a guess.</p>
      <div className="mt-2 flex gap-2">
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && ask(question)}
          placeholder="e.g. Why is profit declining?"
          className="flex-1 rounded border border-line bg-base px-3 py-2 text-sm text-ink outline-none focus:border-emerald"
        />
        <button onClick={() => ask(question)} className="rounded border border-line bg-base px-4 py-2 text-sm text-ink-soft hover:bg-line/40">
          Ask
        </button>
      </div>
      <div className="mt-2 flex flex-wrap gap-2">
        {EXAMPLES.map((ex) => (
          <button key={ex} onClick={() => ask(ex)} className="rounded-full border border-line px-2.5 py-1 text-xs text-ink-faint hover:text-ink-soft">
            {ex}
          </button>
        ))}
      </div>
      {answer && (
        <div className="mt-3 rounded border border-line bg-base p-3 text-sm">
          {answer.answered ? (
            <>
              <p className="text-ink">{answer.answer}</p>
              {answer.supporting && <p className="mt-1 text-xs text-ink-faint">{answer.supporting}</p>}
            </>
          ) : (
            <>
              <p className="font-medium text-ink-soft">Missing Information</p>
              <p className="mt-1 text-ink-soft">{answer.missingRequirement}</p>
            </>
          )}
        </div>
      )}
    </div>
  );
}
