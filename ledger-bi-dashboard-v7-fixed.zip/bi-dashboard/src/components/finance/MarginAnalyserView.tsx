import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { PeriodModel } from '../../finance/buildFinanceModel';

export function MarginAnalyserView({ periods }: { periods: PeriodModel[] }) {
  const chartData = periods.map((p) => ({
    label: p.label,
    Gross: p.income.grossMarginPct,
    EBITDA: p.income.ebitdaMarginPct,
    EBIT: p.income.ebitMarginPct,
    Net: p.income.netMarginPct,
  }));

  const current = periods[periods.length - 1];
  const previous = periods.length > 1 ? periods[periods.length - 2] : null;

  const revGrowth = previous && previous.income.revenue !== 0 ? ((current.income.revenue - previous.income.revenue) / previous.income.revenue) * 100 : null;
  const cogsGrowth = previous && previous.income.cogs !== 0 ? ((current.income.cogs - previous.income.cogs) / previous.income.cogs) * 100 : null;
  const marginDelta = previous ? current.income.grossMarginPct - previous.income.grossMarginPct : null;

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Margin trend</p>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} formatter={(v: number) => `${v.toFixed(1)}%`} />
              <Line type="monotone" dataKey="Gross" stroke="#1F6F54" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="EBITDA" stroke="#4A5B68" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="EBIT" stroke="#A9782E" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="Net" stroke="#B3452C" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {previous && marginDelta !== null && revGrowth !== null && cogsGrowth !== null && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">{marginDelta < -0.5 ? 'Margin contraction detected' : marginDelta > 0.5 ? 'Margin expansion detected' : 'Margin roughly stable'}</p>
          <p className="text-sm text-ink-soft">
            Revenue {revGrowth >= 0 ? '↑' : '↓'} {Math.abs(revGrowth).toFixed(1)}%, COGS {cogsGrowth >= 0 ? '↑' : '↓'} {Math.abs(cogsGrowth).toFixed(1)}%, Gross margin{' '}
            {marginDelta >= 0 ? '↑' : '↓'} {Math.abs(marginDelta).toFixed(1)} points.
          </p>
          {marginDelta < -0.5 && cogsGrowth > revGrowth && (
            <p className="mt-2 rounded border border-amber/30 bg-amber-soft px-3 py-2 text-xs text-amber">
              <strong>Possible driver (hypothesis, not confirmed):</strong> cost growth exceeding revenue growth. This is a pattern in the data, not a diagnosed root cause —
              investigate which cost line is behind the COGS increase before concluding why.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
