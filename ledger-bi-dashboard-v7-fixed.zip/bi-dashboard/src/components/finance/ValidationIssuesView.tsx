import { ValidationIssue } from '../../finance/types';

export function ValidationIssuesView({ issues }: { issues: ValidationIssue[] }) {
  if (issues.length === 0) {
    return <p className="rounded border border-emerald/30 bg-emerald-soft p-4 text-sm text-emerald">No validation issues detected.</p>;
  }

  return (
    <div className="space-y-2">
      {issues.map((issue, i) => (
        <div key={i} className={`rounded border px-3 py-2 text-sm ${issue.severity === 'error' ? 'border-rust/40 bg-rust-soft text-rust' : 'border-amber/40 bg-amber-soft text-amber'}`}>
          <p className="font-medium">{issue.label}</p>
          <p className="mt-0.5 text-xs">{issue.detail}</p>
        </div>
      ))}
      <p className="text-xs text-ink-faint">Issues are flagged for review, never auto-corrected — fix them at the source data or account mapping.</p>
    </div>
  );
}
