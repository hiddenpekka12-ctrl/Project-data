import { BalanceSheetLine } from '../../finance/types';
import { formatCurrency } from '../../lib/format';

function Row({ label, value, bold }: { label: string; value: number; bold?: boolean }) {
  return (
    <div className={`flex items-center justify-between py-1.5 text-sm ${bold ? 'border-t border-line font-medium text-ink' : 'pl-4 text-ink-soft'}`}>
      <span>{label}</span>
      <span className="tabular">{formatCurrency(value)}</span>
    </div>
  );
}

export function BalanceSheetView({ bs, label }: { bs: BalanceSheetLine; label: string }) {
  return (
    <div className="space-y-4">
      {!bs.balances && (
        <div className="rounded border border-rust/40 bg-rust-soft px-4 py-3 text-sm text-rust">
          <p className="font-medium">BALANCE SHEET ERROR</p>
          <p className="mt-1 text-xs">
            Assets ({formatCurrency(bs.totalAssets)}) do not equal Liabilities + Equity ({formatCurrency(bs.totalLiabilities + bs.equity)}). Difference:{' '}
            {formatCurrency(bs.imbalanceAmount)}. Figures have not been auto-adjusted — check your account mapping and source data.
          </p>
        </div>
      )}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Assets — {label}</p>
          <p className="mb-1 mt-2 text-xs uppercase text-ink-faint">Current Assets</p>
          <Row label="Cash" value={bs.cash} />
          <Row label="Receivables" value={bs.receivables} />
          <Row label="Inventory" value={bs.inventory} />
          <Row label="Total Current Assets" value={bs.currentAssets} bold />
          <p className="mb-1 mt-3 text-xs uppercase text-ink-faint">Non-current Assets</p>
          <Row label="Fixed Assets (Property, Plant, Equipment & other — combined; not separately mapped)" value={bs.fixedAssets} />
          <Row label="Total Non-current Assets" value={bs.nonCurrentAssets} bold />
          <Row label="Total Assets" value={bs.totalAssets} bold />
        </div>
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Liabilities & Equity — {label}</p>
          <p className="mb-1 mt-2 text-xs uppercase text-ink-faint">Current Liabilities</p>
          <Row label="Current Liabilities (combined — payables, short-term debt, other; not separately mapped)" value={bs.currentLiabilities} />
          <Row label="Total Current Liabilities" value={bs.currentLiabilities} bold />
          <p className="mb-1 mt-3 text-xs uppercase text-ink-faint">Non-current Liabilities</p>
          <Row label="Long-term Debt" value={bs.longTermDebt} />
          <Row label="Total Non-current Liabilities" value={bs.nonCurrentLiabilities} bold />
          <Row label="Total Liabilities" value={bs.totalLiabilities} bold />
          <p className="mb-1 mt-3 text-xs uppercase text-ink-faint">Equity</p>
          <Row label="Equity (combined — not separately split into share capital/retained earnings)" value={bs.equity} />
          <Row label="Total Liabilities + Equity" value={bs.totalLiabilities + bs.equity} bold />
        </div>
      </div>
    </div>
  );
}
