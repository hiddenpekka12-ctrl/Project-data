import { useState } from 'react';
import { Area, CartesianGrid, ComposedChart, Line, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { breakEvenChartData, computeBreakEven } from '../../finance/breakEven';
import { LearnThis } from '../analytics/LearnThis';

export function BreakEvenView() {
  const [fixedCosts, setFixedCosts] = useState(50000);
  const [variableCost, setVariableCost] = useState(30);
  const [sellingPrice, setSellingPrice] = useState(60);

  const result = computeBreakEven({ fixedCosts, variableCostPerUnit: variableCost, sellingPricePerUnit: sellingPrice });
  const chartData = breakEvenChartData({ fixedCosts, variableCostPerUnit: variableCost, sellingPricePerUnit: sellingPrice }, result);

  return (
    <div className="space-y-4">
      <div className="rounded border border-line bg-surface p-4">
        <p className="mb-3 text-sm font-medium text-ink">Inputs</p>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Field label="Fixed Costs" value={fixedCosts} onChange={setFixedCosts} />
          <Field label="Variable Cost per Unit" value={variableCost} onChange={setVariableCost} />
          <Field label="Selling Price per Unit" value={sellingPrice} onChange={setSellingPrice} />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Metric label="Contribution per Unit" value={result.contributionPerUnit.toFixed(2)} />
        <Metric label="Contribution Margin" value={`${result.contributionMarginPct.toFixed(1)}%`} />
        <Metric label="Break-even Units" value={result.breakEvenUnits === null ? 'n/a' : Math.ceil(result.breakEvenUnits).toLocaleString()} />
        <Metric label="Break-even Revenue" value={result.breakEvenRevenue === null ? 'n/a' : result.breakEvenRevenue.toFixed(0)} />
      </div>

      {result.contributionPerUnit <= 0 && (
        <p className="rounded border border-rust/30 bg-rust-soft px-3 py-2 text-xs text-rust">
          Selling price must exceed variable cost per unit for a break-even point to exist.
        </p>
      )}

      {result.breakEvenUnits !== null && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="flex items-center text-sm font-medium text-ink">
            Break-even chart
            <LearnThis conceptKey="breakEven" />
          </p>
          <div className="mt-2 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
                <XAxis dataKey="units" tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} label={{ value: 'Units', position: 'insideBottom', offset: -2, fontSize: 10, fill: '#8A968F' }} />
                <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 4 }} />
                <Area type="monotone" dataKey="totalCost" stroke="#B3452C" fill="#B3452C" fillOpacity={0.08} name="Total Cost" />
                <Line type="monotone" dataKey="totalRevenue" stroke="#1F6F54" strokeWidth={2} dot={false} name="Total Revenue" />
                <ReferenceLine x={Math.round(result.breakEvenUnits)} stroke="#4A5B68" strokeDasharray="4 4" label={{ value: 'Break-even', fontSize: 10, fill: '#4A5B68' }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-ink-faint">{label}</span>
      <input type="number" value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full rounded border border-line bg-base px-2 py-1.5 text-sm tabular" />
    </label>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border border-line bg-surface p-3">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className="mt-1 font-serif text-lg tabular text-ink">{value}</p>
    </div>
  );
}
