import { FinanceModel } from '../../finance/buildFinanceModel';

function downloadBlob(content: BlobPart, filename: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function FinanceExportButtons({ model, datasetName }: { model: FinanceModel; datasetName: string }) {
  const exportReport = () => {
    const last = model.periods[model.periods.length - 1];
    if (!last) return;

    const lines = [
      `# Financial Management Report — ${datasetName}`,
      '',
      `Generated ${new Date().toLocaleString()} · Period: ${last.label}`,
      '',
      '**This report is generated from a decision-support tool, not a substitute for a chartered accountant, auditor, or financial advisor.**',
      '',
      '## Executive Summary',
      `Revenue: ${last.income.revenue.toFixed(0)} · Net Profit: ${last.income.netProfit.toFixed(0)} (${last.income.netMarginPct.toFixed(1)}% margin)`,
      model.health ? `Financial Health Score: ${model.health.score}/100 (${model.health.status}) — a heuristic, not a credit rating.` : 'Financial Health Score: not available (balance sheet data incomplete).',
      '',
      '## Revenue',
      `Revenue: ${last.income.revenue.toFixed(0)}${last.income.yoyRevenueGrowthPct !== null ? ` (${last.income.yoyRevenueGrowthPct.toFixed(1)}% YoY)` : ''}`,
      '',
      '## Profitability',
      `Gross Margin: ${last.income.grossMarginPct.toFixed(1)}% · EBITDA Margin: ${last.income.ebitdaMarginPct.toFixed(1)}% · Net Margin: ${last.income.netMarginPct.toFixed(1)}%`,
      '',
      '## Cash Flow',
      `Estimated Operating Cash Flow: ${last.cashFlow.operatingCashFlow.toFixed(0)} · Estimated Free Cash Flow: ${last.cashFlow.freeCashFlow.toFixed(0)}`,
      '',
      '## Liquidity',
      ...last.liquidityRatios.map((r) => `${r.label}: ${r.value === null ? 'n/a' : r.value.toFixed(2)}`),
      '',
      '## Solvency',
      ...last.solvencyRatios.map((r) => `${r.label}: ${r.value === null ? 'n/a' : r.value.toFixed(2)}`),
      '',
      '## Working Capital',
      `Working Capital: ${last.workingCapital.workingCapital.toFixed(0)} · Cash Conversion Cycle: ${last.workingCapital.cashConversionCycle?.toFixed(0) ?? 'n/a'} days`,
      '',
      `## Major Red Flags (${model.redFlags.length})`,
      ...(model.redFlags.length ? model.redFlags.map((f) => `- [${f.severity}] ${f.label}: ${f.whatHappened}`) : ['None detected for the current period.']),
      '',
      `## Key Insights (${model.insights.length})`,
      ...(model.insights.length ? model.insights.map((i) => `- ${i.finding} → ${i.managementImplication}`) : ['Not enough periods for insights yet.']),
      '',
      '## Recommended Areas for Investigation',
      ...(model.redFlags.length ? model.redFlags.map((f) => `- ${f.suggestedInvestigation}`) : ['No specific areas flagged from the current data.']),
      '',
      '_Recommendations above are areas to investigate, not guaranteed outcomes or professional financial advice._',
    ];

    downloadBlob(lines.join('\n'), `${datasetName}-financial-report.md`, 'text/markdown');
  };

  const exportRatios = () => {
    const last = model.periods[model.periods.length - 1];
    if (!last) return;
    const allRatios = [...last.liquidityRatios, ...last.profitabilityRatios, ...last.solvencyRatios, ...last.efficiencyRatios];
    const csv = [
      'Category,Metric,Value,Formula,Interpretation',
      ...allRatios.map((r) => `"${r.key}","${r.label}",${r.value ?? ''},"${r.formula}","${r.interpretation.replace(/"/g, "'")}"`),
    ].join('\n');
    downloadBlob(csv, `${datasetName}-ratio-analysis.csv`, 'text/csv');
  };

  return (
    <div className="flex flex-wrap gap-2">
      <button onClick={exportReport} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
        Export financial report
      </button>
      <button onClick={exportRatios} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
        Export ratio analysis (CSV)
      </button>
    </div>
  );
}
