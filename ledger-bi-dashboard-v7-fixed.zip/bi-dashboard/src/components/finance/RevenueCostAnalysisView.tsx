import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Row } from '../../types/analytics';
import { groupSum } from '../../lib/autoEda';
import { AccountMapping } from '../../finance/types';
import { formatCurrency } from '../../lib/format';

function findMappedColumn(mapping: AccountMapping, category: string): string | null {
  return Object.entries(mapping).find(([, cat]) => cat === category)?.[0] ?? null;
}

export function RevenueCostAnalysisView({
  rows,
  mapping,
  columnTypes,
}: {
  rows: Row[];
  mapping: AccountMapping;
  columnTypes: Record<string, string>;
}) {
  const revenueCol = findMappedColumn(mapping, 'revenue');
  const cogsCol = findMappedColumn(mapping, 'cogs');
  const opexCol = findMappedColumn(mapping, 'operatingExpenses');
  const categoricalCols = Object.keys(columnTypes).filter((c) => columnTypes[c] === 'categorical');

  if (!revenueCol || categoricalCols.length === 0) {
    return (
      <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">
        Revenue-by-dimension analysis needs a categorical column (product, region, customer, channel...) alongside a mapped Revenue column in the raw dataset. This dataset doesn't have both.
      </p>
    );
  }

  return (
    <div className="space-y-4">
      {categoricalCols.slice(0, 3).map((dim) => {
        const revenueByDim = groupSum(rows, dim, revenueCol).slice(0, 10);
        const total = revenueByDim.reduce((s, r) => s + r.total, 0);
        const top = revenueByDim[0];
        const bottom = revenueByDim[revenueByDim.length - 1];

        return (
          <div key={dim} className="rounded border border-line bg-surface p-4">
            <p className="mb-2 text-sm font-medium text-ink">Revenue by {dim}</p>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={revenueByDim.map((r) => ({ key: r.key, value: r.total }))}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E5E1" vertical={false} />
                  <XAxis dataKey="key" tick={{ fontSize: 10, fill: '#8A968F' }} axisLine={{ stroke: '#E2E5E1' }} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#8A968F' }} axisLine={false} tickLine={false} tickFormatter={(v) => formatCurrency(v)} width={64} />
                  <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ fontSize: 12, borderRadius: 4 }} />
                  <Bar dataKey="value" fill="#1F6F54" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            {top && bottom && total > 0 && (
              <p className="mt-2 text-xs text-ink-faint">
                Fastest-growing/largest: <strong className="text-ink-soft">{top.key}</strong> ({((top.total / total) * 100).toFixed(1)}% of total). Lowest:{' '}
                <strong className="text-ink-soft">{bottom.key}</strong>.
              </p>
            )}
          </div>
        );
      })}

      {(cogsCol || opexCol) && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Cost analyser</p>
          <p className="text-xs text-ink-faint">
            {cogsCol && `COGS is mapped from "${cogsCol}". `}
            {opexCol && `Operating Expenses is mapped from "${opexCol}". `}
            Both are tracked as single combined totals in the account mapping — for a category-level cost breakdown (e.g. by expense type), that dimension needs its own column in the
            raw dataset.
          </p>
        </div>
      )}
    </div>
  );
}
