import { HealthScoreResult } from '../../finance/types';

const STATUS_STYLES: Record<HealthScoreResult['status'], string> = {
  Excellent: 'text-emerald',
  Healthy: 'text-emerald',
  Watch: 'text-amber',
  Warning: 'text-rust',
  Critical: 'text-rust',
};

export function FinancialHealthView({ health }: { health: HealthScoreResult }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-sm text-ink-soft">Financial Health Score</p>
      <div className="mt-1 flex items-baseline gap-3">
        <span className="font-serif text-4xl tabular text-ink">{health.score}/100</span>
        <span className={`text-lg ${STATUS_STYLES[health.status]}`}>{health.status}</span>
      </div>
      <p className="mt-1 text-xs text-ink-faint">A decision-support heuristic, not a regulated credit rating or professional investment rating.</p>

      <div className="mt-4 space-y-3">
        {health.components.map((c) => (
          <div key={c.label}>
            <div className="flex items-center justify-between text-sm">
              <span className="text-ink-soft">{c.label}</span>
              <span className="tabular text-ink">
                {c.points}/{c.maxPoints}
              </span>
            </div>
            <div className="mt-1 h-1.5 w-full rounded-full bg-line">
              <div
                className={`h-1.5 rounded-full ${c.points / c.maxPoints >= 0.7 ? 'bg-emerald' : c.points / c.maxPoints >= 0.4 ? 'bg-amber' : 'bg-rust'}`}
                style={{ width: `${(c.points / c.maxPoints) * 100}%` }}
              />
            </div>
            <p className="mt-1 text-xs text-ink-faint">{c.detail}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
