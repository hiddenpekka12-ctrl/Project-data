/**
 * V2 ANALYTICS TYPES
 * ------------------
 * Extends the V1 model (types/index.ts) rather than replacing it.
 * A Dataset is deliberately separate from FinancialPeriod: not every
 * uploaded dataset is financial, and the dashboard has to detect fit
 * rather than assume it (see lib/datasetToFinancials.ts).
 */

export type ColumnType = 'numeric' | 'categorical' | 'date' | 'boolean' | 'text';

export type Row = Record<string, string | number | boolean | null>;

export interface DatasetMeta {
  id: string;
  name: string;
  source: 'demo' | 'user';
  fileType: 'csv' | 'xlsx' | 'json';
  uploadedAt: string;
  rowCount: number;
  columns: string[];
  columnTypes: Record<string, ColumnType>;
}

export interface CleaningLogEntry {
  id: string;
  timestamp: string;
  operation: string;
  column: string | null;
  affectedRows: number;
  before: string;
  after: string;
}

export interface Dataset extends DatasetMeta {
  originalRows: Row[];
  cleanedRows: Row[];
  cleaningLog: CleaningLogEntry[];
}

export interface NumericProfile {
  type: 'numeric';
  count: number;
  missing: number;
  missingPct: number;
  mean: number;
  median: number;
  min: number;
  max: number;
  std: number;
  q1: number;
  q3: number;
  unique: number;
}

export interface CategoricalProfile {
  type: 'categorical';
  count: number;
  missing: number;
  missingPct: number;
  unique: number;
  mostCommon: string;
  mostCommonCount: number;
  topValues: { value: string; count: number }[];
}

export interface DateProfile {
  type: 'date';
  count: number;
  missing: number;
  missingPct: number;
  min: string;
  max: string;
  rangeDays: number;
}

export interface TextProfile {
  type: 'text';
  count: number;
  missing: number;
  missingPct: number;
  unique: number;
}

export type ColumnProfile = NumericProfile | CategoricalProfile | DateProfile | TextProfile;

export interface DatasetOverview {
  rows: number;
  columns: number;
  numericColumns: number;
  textColumns: number;
  dateColumns: number;
  categoricalColumns: number;
  missingValues: number;
  duplicateRows: number;
}

export interface DataQualityBreakdownItem {
  label: string;
  detail: string;
  pointsDeducted: number;
}

export interface DataQualityResult {
  score: number;
  status: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  breakdown: DataQualityBreakdownItem[];
}

export type OutlierMethod = 'iqr' | 'zscore';

export interface OutlierResult {
  method: OutlierMethod;
  column: string;
  lowerBound: number;
  upperBound: number;
  outlierRowIndexes: number[];
}

export type InsightCategory = 'descriptive' | 'diagnostic' | 'predictive' | 'prescriptive';
export type InsightConfidence = 'High' | 'Medium' | 'Low';

export interface AnalyticsInsight {
  id: string;
  category: InsightCategory;
  finding: string;
  supportingData: string;
  businessMeaning: string;
  confidence: InsightConfidence;
}

export interface CorrelationCell {
  columnA: string;
  columnB: string;
  r: number;
  strength: 'weak' | 'moderate' | 'strong';
  direction: 'positive' | 'negative' | 'none';
}

export interface BusinessQuestionAnswer {
  question: string;
  answered: boolean;
  answer?: string;
  supporting?: string;
  missingRequirement?: string;
}

export type ChartType = 'bar' | 'line' | 'histogram' | 'scatter' | 'pie' | 'box' | 'area';

export interface EdaSelection {
  xColumn: string | null;
  yColumn: string | null;
  groupBy: string | null;
  chartType: ChartType;
}
