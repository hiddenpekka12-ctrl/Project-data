/**
 * CORE DATA MODEL
 * ----------------
 * This file defines the entities the whole platform is built around.
 * V1 only populates Organization, FinancialPeriod, Kpi, RiskFactor and
 * Alert/Insight with demo data — but every future module (forecasting,
 * scenarios, AI assistant, etc.) is expected to read and write against
 * these same shapes, extended rather than replaced.
 */

export type Id = string;

export interface Organization {
  id: Id;
  name: string;
  currency: string; // ISO 4217, e.g. "USD"
  fiscalYearStartMonth: number; // 1-12
}

/** A single reporting period's raw financial inputs. Everything else
 * (profit, margin, KPI cards) is DERIVED from these via lib/calculations.ts —
 * never hard-coded in a component. */
export interface FinancialPeriod {
  id: Id;
  orgId: Id;
  label: string; // e.g. "Jul 2026"
  periodStart: string; // ISO date
  periodEnd: string; // ISO date
  revenue: number;
  expenses: number;
  cash: number;
  assets: number;
  liabilities: number;
  debt: number;
}

export type TrendDirection = 'up' | 'down' | 'flat';

/** A computed KPI card value — the RESULT of a calculation, not raw input.
 * `sourcePeriodIds` preserves the input -> calculation -> result trail
 * requested for data transparency. */
export interface KpiResult {
  key: string;
  label: string;
  value: number;
  previousValue: number;
  percentChange: number;
  direction: TrendDirection;
  unit: 'currency' | 'number' | 'score';
  explanation: string;
  sourcePeriodIds: Id[];
}

export type RiskCategory = 'financial' | 'operational' | 'market' | 'strategic';
export type RiskLevel = 'low' | 'moderate' | 'high' | 'critical';

export interface RiskFactor {
  id: Id;
  category: RiskCategory;
  label: string;
  score: number; // 0-100
  level: RiskLevel;
  note: string;
}

export interface RiskSnapshot {
  overallScore: number;
  overallLevel: RiskLevel;
  factors: RiskFactor[];
}

export type AlertSeverity = 'info' | 'warning' | 'critical' | 'positive';

export interface AlertItem {
  id: Id;
  severity: AlertSeverity;
  message: string;
  createdAt: string;
}

export interface Insight {
  id: Id;
  message: string;
  basedOn: string[]; // human-readable trail of which figures drove this insight
}

/** Reserved shapes for future modules. V1 does not implement these,
 * but downstream code can already import the types without a breaking
 * change later. */
export interface Transaction {
  id: Id;
  orgId: Id;
  date: string;
  category: string;
  amount: number;
  type: 'income' | 'expense';
}

export interface Scenario {
  id: Id;
  name: string;
  assumptions: Record<string, number>;
}

export interface ForecastPoint {
  periodLabel: string;
  projectedValue: number;
  confidenceLow: number;
  confidenceHigh: number;
}

export interface Report {
  id: Id;
  title: string;
  generatedAt: string;
  sections: string[];
}

/** Generic async-resource wrapper so every panel handles
 * loading / empty / error / data the same way. */
export type Resource<T> =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'empty' }
  | { status: 'ready'; data: T };
