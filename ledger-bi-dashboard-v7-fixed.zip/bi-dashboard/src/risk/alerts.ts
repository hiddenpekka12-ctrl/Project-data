import { KeyRiskIndicator, MitigationAction, RiskAlert, RiskAppetiteSettings, RiskItem, RiskSignal } from './types';
import { computeKriStatus } from './kri';
import { computeRiskScore } from './scoring';
import { evaluateAppetite } from './appetite';

let counter = 0;
function id(prefix: string): string {
  counter += 1;
  return `${prefix}-${counter}`;
}

export function generateRiskAlerts(
  registerItems: RiskItem[],
  kris: KeyRiskIndicator[],
  mitigations: MitigationAction[],
  appetiteSettings: RiskAppetiteSettings,
  financialSignals: RiskSignal[]
): RiskAlert[] {
  counter = 0;
  const alerts: RiskAlert[] = [];
  const today = new Date().toISOString().slice(0, 10);

  registerItems.forEach((r) => {
    const score = computeRiskScore(r.residualProbability, r.residualImpact);
    const appetite = evaluateAppetite(score, appetiteSettings);
    if (appetite.status === 'Escalation — above appetite') {
      alerts.push({
        id: id('appetite'),
        label: `"${r.name}" is above risk appetite`,
        severity: 'critical',
        metric: 'Residual Risk Score',
        currentValue: String(score),
        threshold: String(appetiteSettings.escalationThreshold),
        date: today,
        source: 'Risk Register',
        recommendedAction: 'Escalate per the configured treatment strategy and review mitigation timeline.',
      });
    }
    if (score >= 20) {
      alerts.push({
        id: id('critical'),
        label: `Critical risk score: "${r.name}"`,
        severity: 'critical',
        metric: 'Residual Risk Score',
        currentValue: String(score),
        threshold: '20',
        date: today,
        source: 'Risk Register',
        recommendedAction: 'Review immediately — this is in the Critical band.',
      });
    }
  });

  kris.forEach((k) => {
    const status = computeKriStatus(k);
    if (status === 'Critical' || status === 'Warning') {
      alerts.push({
        id: id('kri'),
        label: `KRI threshold breach: ${k.name}`,
        severity: status === 'Critical' ? 'critical' : 'warning',
        metric: k.metric,
        currentValue: k.currentValue === null ? 'n/a' : String(k.currentValue),
        threshold: status === 'Critical' ? String(k.criticalLevel) : String(k.warningLevel),
        date: k.lastUpdated,
        source: `KRI · ${k.sourceDataset}`,
        recommendedAction: `Review with ${k.owner || 'the assigned owner'}.`,
      });
    }
  });

  mitigations.forEach((m) => {
    if (m.status !== 'Completed' && m.status !== 'Cancelled' && m.dueDate < today) {
      alerts.push({
        id: id('overdue'),
        label: `Overdue mitigation action: ${m.action}`,
        severity: 'warning',
        metric: 'Due Date',
        currentValue: m.dueDate,
        threshold: today,
        date: today,
        source: 'Mitigation Tracker',
        recommendedAction: `Follow up with ${m.owner || 'the assigned owner'} on status.`,
      });
    }
  });

  financialSignals.forEach((s) => {
    alerts.push({
      id: id('financial'),
      label: s.label,
      severity: 'warning',
      metric: s.metric,
      currentValue: String(s.currentValue),
      threshold: s.threshold === null ? 'n/a' : String(s.threshold),
      date: today,
      source: 'Finance Engine (V3)',
      recommendedAction: s.recommendedInvestigation,
    });
  });

  return alerts;
}
