import { ConcentrationResult, RiskInsight, RiskItem, RiskSignal } from './types';
import { computeRiskScore } from './scoring';

let counter = 0;
function id(prefix: string): string {
  counter += 1;
  return `${prefix}-${counter}`;
}

export function generateRiskInsights(signals: RiskSignal[], concentrations: ConcentrationResult[], registerItems: RiskItem[]): RiskInsight[] {
  counter = 0;
  const insights: RiskInsight[] = [];

  // Compound financial signal: two or more signals firing together is
  // worth surfacing as a single insight rather than N separate alerts.
  if (signals.length >= 2) {
    insights.push({
      id: id('compound'),
      finding: `${signals.length} financial risk signals are active simultaneously: ${signals.map((s) => s.metric).join(', ')}.`,
      evidence: signals.map((s) => `${s.metric}: ${s.changeDescription}`).join(' · '),
      riskMeaning: 'Multiple concurrent signals can compound each other — e.g. declining liquidity alongside rising leverage reduces flexibility to respond to either.',
      confidence: 'Medium',
      recommendedInvestigation: 'Review the Financial Risk tab for each signal\'s individual evidence before drawing a combined conclusion.',
    });
  }

  concentrations.forEach((c) => {
    if (c.topSharePct > 40) {
      insights.push({
        id: id('concentration'),
        finding: `"${c.topEntity}" represents ${c.topSharePct.toFixed(1)}% of total ${c.dimension}.`,
        evidence: `Computed from the raw dataset grouped by ${c.dimension}.`,
        riskMeaning: 'High concentration in a single entity creates dependency exposure — if that relationship weakens, the impact is disproportionate.',
        confidence: 'High',
        recommendedInvestigation: `Assess the stability of the relationship with "${c.topEntity}" and whether diversification is feasible.`,
      });
    }
  });

  const topRisks = [...registerItems]
    .map((r) => ({ risk: r, score: computeRiskScore(r.residualProbability, r.residualImpact) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 1);
  if (topRisks.length && topRisks[0].score >= 15) {
    const { risk, score } = topRisks[0];
    insights.push({
      id: id('topRisk'),
      finding: `"${risk.name}" is the highest-scoring residual risk in the register (score ${score}).`,
      evidence: `Residual Probability ${risk.residualProbability} × Residual Impact ${risk.residualImpact} = ${score}.`,
      riskMeaning: 'This risk carries the largest combination of likelihood and consequence among everything currently tracked.',
      confidence: 'High',
      recommendedInvestigation: `Review "${risk.name}"'s existing controls (${risk.controlEffectiveness}) and whether the mitigation action is on track.`,
    });
  }

  return insights;
}
