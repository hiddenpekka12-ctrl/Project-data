import { KeyRiskIndicator, MitigationAction, RiskAppetiteSettings, RiskItem, RiskSignal } from './types';
import { computeRiskScore } from './scoring';
import { evaluateAppetite } from './appetite';
import { computeKriStatus } from './kri';

export interface RiskQAAnswer {
  question: string;
  answered: boolean;
  answer?: string;
  missingRequirement?: string;
}

export interface RiskQAContext {
  registerItems: RiskItem[];
  kris: KeyRiskIndicator[];
  mitigations: MitigationAction[];
  appetiteSettings: RiskAppetiteSettings;
  financialSignals: RiskSignal[];
}

export function answerRiskQuestion(question: string, ctx: RiskQAContext): RiskQAAnswer {
  const q = question.toLowerCase();
  const { registerItems, kris, mitigations, appetiteSettings, financialSignals } = ctx;
  const scored = registerItems.map((r) => ({ risk: r, score: computeRiskScore(r.residualProbability, r.residualImpact) }));

  if (registerItems.length === 0 && kris.length === 0 && financialSignals.length === 0) {
    return { question, answered: false, missingRequirement: 'No risk register entries, KRIs, or financial signals are available yet. Load the demo risk data or add risks to the register.' };
  }

  if (/most important|highest.priority|need.*(immediate|urgent)/.test(q)) {
    const top = [...scored].sort((a, b) => b.score - a.score).slice(0, 3);
    if (top.length === 0) return { question, answered: false, missingRequirement: 'No risks in the register yet.' };
    return {
      question,
      answered: true,
      answer: `Highest residual-score risks: ${top.map((t) => `"${t.risk.name}" (${t.score})`).join(', ')}.`,
    };
  }

  if (/above appetite/.test(q)) {
    const above = scored.filter((s) => evaluateAppetite(s.score, appetiteSettings).status === 'Escalation — above appetite');
    if (above.length === 0) return { question, answered: true, answer: 'No risks are currently above the configured escalation threshold.' };
    return { question, answered: true, answer: `${above.length} risk(s) above appetite: ${above.map((s) => s.risk.name).join(', ')}.` };
  }

  if (/financial risk.*increasing|increasing.*financial/.test(q)) {
    if (financialSignals.length === 0) return { question, answered: true, answer: 'No active financial risk signals from the current Finance Engine data.' };
    return { question, answered: true, answer: `${financialSignals.length} financial risk signal(s) active: ${financialSignals.map((s) => s.metric).join(', ')}.` };
  }

  if (/weak controls?/.test(q)) {
    const weak = registerItems.filter((r) => r.controlEffectiveness === 'Weak' || r.controlEffectiveness === 'Unknown' || r.controlEffectiveness === 'Not Assessed');
    if (weak.length === 0) return { question, answered: true, answer: 'No risks are currently flagged with weak, unknown, or unassessed controls.' };
    return { question, answered: true, answer: `${weak.length} risk(s) with weak/unassessed controls: ${weak.map((r) => r.name).join(', ')}.` };
  }

  if (/overdue action/.test(q)) {
    const today = new Date().toISOString().slice(0, 10);
    const overdue = mitigations.filter((m) => m.status !== 'Completed' && m.status !== 'Cancelled' && m.dueDate < today);
    if (overdue.length === 0) return { question, answered: true, answer: 'No overdue mitigation actions.' };
    return { question, answered: true, answer: `${overdue.length} overdue action(s): ${overdue.map((m) => m.action).join(', ')}.` };
  }

  if (/biggest concentration/.test(q)) {
    return {
      question,
      answered: false,
      missingRequirement: 'Concentration risk is computed on the Concentration Risk tab from the active dataset\'s categorical columns — ask there, or check that tab directly, since this Q&A only has register/KRI/financial-signal context.',
    };
  }

  if (/largest risk signal|which financial metric/.test(q)) {
    if (financialSignals.length === 0) return { question, answered: true, answer: 'No financial risk signals are currently active.' };
    return { question, answered: true, answer: `Active signals, in order detected: ${financialSignals.map((s) => s.metric).join(', ')}. Each has its own evidence on the Financial Risk tab — none is ranked above another without a defined weighting.` };
  }

  if (/where should.*investigat|investigate first/.test(q)) {
    const topScore = [...scored].sort((a, b) => b.score - a.score)[0];
    const parts: string[] = [];
    if (topScore) parts.push(`the highest-scoring register risk ("${topScore.risk.name}", score ${topScore.score})`);
    const criticalKri = kris.find((k) => computeKriStatus(k) === 'Critical');
    if (criticalKri) parts.push(`the "${criticalKri.name}" KRI (currently Critical)`);
    if (financialSignals.length) parts.push(`the ${financialSignals.length} active financial risk signal(s)`);
    if (parts.length === 0) return { question, answered: true, answer: 'No significant risks, KRI breaches, or financial signals are currently flagged.' };
    return { question, answered: true, answer: `Based on current data, start with: ${parts.join('; ')}.` };
  }

  return {
    question,
    answered: false,
    missingRequirement: 'This question doesn\'t match a supported pattern yet. Try asking about the most important risks, risks above appetite, increasing financial risks, weak controls, overdue actions, or where to investigate first.',
  };
}
