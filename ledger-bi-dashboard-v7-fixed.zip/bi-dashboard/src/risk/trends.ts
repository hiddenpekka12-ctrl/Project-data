import { RiskItem, RiskTrendDirection } from './types';
import { computeRiskScore } from './scoring';

export function classifyRiskTrend(risk: RiskItem): RiskTrendDirection {
  if (risk.history.length < 2) return risk.history.length === 0 ? 'New' : 'Insufficient data';

  const sorted = [...risk.history].sort((a, b) => (a.date < b.date ? -1 : 1));
  const first = sorted[0];
  const last = sorted[sorted.length - 1];
  const firstScore = computeRiskScore(first.residualProbability, first.residualImpact);
  const lastScore = computeRiskScore(last.residualProbability, last.residualImpact);

  if (risk.status === 'Closed') return 'Resolved';
  if (lastScore > firstScore) return 'Increasing';
  if (lastScore < firstScore) return 'Decreasing';
  return 'Stable';
}
