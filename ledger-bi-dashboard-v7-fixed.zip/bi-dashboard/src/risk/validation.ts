import { RiskItem } from './types';

export interface RiskValidationIssue {
  severity: 'error' | 'warning';
  label: string;
  detail: string;
}

export function validateRiskRegister(items: RiskItem[]): RiskValidationIssue[] {
  const issues: RiskValidationIssue[] = [];

  items.forEach((r) => {
    [
      ['inherentProbability', r.inherentProbability],
      ['inherentImpact', r.inherentImpact],
      ['residualProbability', r.residualProbability],
      ['residualImpact', r.residualImpact],
    ].forEach(([field, value]) => {
      const v = value as number;
      if (v < 1 || v > 5 || !Number.isFinite(v)) {
        issues.push({ severity: 'error', label: 'Invalid probability/impact score', detail: `"${r.name}": ${field} = ${v}. Scores must be between 1 and 5.` });
      }
    });

    if (r.residualProbability > r.inherentProbability || r.residualImpact > r.inherentImpact) {
      issues.push({
        severity: 'warning',
        label: 'Residual risk exceeds inherent risk',
        detail: `"${r.name}": residual score is higher than inherent — controls should reduce risk, not increase it. Confirm this is intentional.`,
      });
    }

    if (!r.dateIdentified) {
      issues.push({ severity: 'warning', label: 'Missing date identified', detail: `"${r.name}" has no date identified.` });
    }
    if (r.reviewDate && r.dateIdentified && r.reviewDate < r.dateIdentified) {
      issues.push({ severity: 'error', label: 'Invalid dates', detail: `"${r.name}": review date is before the date identified.` });
    }
    if (r.status === 'Open' && !r.owner) {
      issues.push({ severity: 'warning', label: 'Missing risk owner', detail: `"${r.name}" is open but has no assigned owner.` });
    }
  });

  const seen = new Map<string, number>();
  items.forEach((r) => {
    const key = r.name.trim().toLowerCase();
    seen.set(key, (seen.get(key) ?? 0) + 1);
  });
  seen.forEach((count, name) => {
    if (count > 1) issues.push({ severity: 'warning', label: 'Possible duplicate risk', detail: `"${name}" appears ${count} times in the register.` });
  });

  return issues;
}
