import { RiskAppetiteSettings } from './types';

export const DEFAULT_APPETITE_SETTINGS: RiskAppetiteSettings = {
  toleranceThreshold: 9,
  managementAttentionThreshold: 14,
  escalationThreshold: 15,
};

export type AppetiteStatus = 'Within tolerance' | 'Management attention' | 'Escalation — above appetite';

export interface AppetiteResult {
  status: AppetiteStatus;
  gap: number; // positive = above tolerance limit
}

/**
 * Compares a risk score against the configured appetite. Returns a gap
 * and a status label — never a verdict like "the business is unsafe".
 * That judgment is left to the person reading the number.
 */
export function evaluateAppetite(score: number, settings: RiskAppetiteSettings = DEFAULT_APPETITE_SETTINGS): AppetiteResult {
  const gap = score - settings.toleranceThreshold;
  if (score >= settings.escalationThreshold) return { status: 'Escalation — above appetite', gap };
  if (score > settings.toleranceThreshold) return { status: 'Management attention', gap };
  return { status: 'Within tolerance', gap };
}
