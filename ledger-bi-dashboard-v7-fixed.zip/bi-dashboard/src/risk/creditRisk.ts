import { CreditRiskInput, CreditRiskResult, ScorecardVariable } from './types';

/**
 * Expected Loss = PD × LGD × EAD. This is an educational/analytical
 * foundation, not a validated, regulator-approved credit model. No claim
 * of Basel/IFRS 9 compliance is made anywhere in the UI for this.
 */
export function computeExpectedLoss(input: CreditRiskInput): CreditRiskResult {
  return { expectedLoss: input.pd * input.lgd * input.ead };
}

export const DEFAULT_SCORECARD_VARIABLES: ScorecardVariable[] = [
  { key: 'paymentHistory', label: 'Payment History', weight: 0.25, score: 70 },
  { key: 'dso', label: 'Days Sales Outstanding', weight: 0.15, score: 70 },
  { key: 'leverage', label: 'Leverage (Debt-to-Equity)', weight: 0.15, score: 70 },
  { key: 'liquidity', label: 'Liquidity (Current Ratio)', weight: 0.15, score: 70 },
  { key: 'profitability', label: 'Profitability (Net Margin)', weight: 0.15, score: 70 },
  { key: 'revenueTrend', label: 'Revenue Trend', weight: 0.1, score: 70 },
  { key: 'concentration', label: 'Customer Concentration', weight: 0.05, score: 70 },
];

export function computeScorecardTotal(variables: ScorecardVariable[]): number {
  const totalWeight = variables.reduce((s, v) => s + v.weight, 0) || 1;
  return variables.reduce((sum, v) => sum + (v.score * v.weight) / totalWeight, 0);
}

export function scorecardRiskLevel(total: number): 'Low Risk' | 'Moderate Risk' | 'High Risk' {
  if (total >= 70) return 'Low Risk';
  if (total >= 45) return 'Moderate Risk';
  return 'High Risk';
}
