import { Row } from '../types/analytics';
import { groupSum } from '../lib/autoEda';
import { ConcentrationResult } from './types';

/** Never assumes a dimension is dangerous — just reports the share.
 * Interpretation ("potential exposure") is left to the UI layer, which
 * frames it as evidence to investigate, not a verdict. */
export function computeConcentration(rows: Row[], dimensionColumn: string, valueColumn: string): ConcentrationResult | null {
  const totals = groupSum(rows, dimensionColumn, valueColumn);
  if (totals.length === 0) return null;
  const total = totals.reduce((s, t) => s + t.total, 0);
  if (total === 0) return null;
  const top = totals[0];
  const top5 = totals.slice(0, 5).reduce((s, t) => s + t.total, 0);

  return {
    dimension: dimensionColumn,
    topEntity: top.key,
    topSharePct: (top.total / total) * 100,
    top5SharePct: totals.length > 1 ? (top5 / total) * 100 : null,
    total,
  };
}
