import { KeyRiskIndicator, KriStatus } from './types';

/**
 * Direction is configurable per-KRI (Section 14): a debt ratio getting
 * worse means "higher", a cash balance getting worse means "lower". This
 * function never assumes one direction — it reads it from the KRI itself.
 */
export function computeKriStatus(kri: KeyRiskIndicator): KriStatus {
  if (kri.currentValue === null) return 'No Data';
  const { currentValue, warningLevel, criticalLevel, direction } = kri;

  if (direction === 'higherIsWorse') {
    if (currentValue >= criticalLevel) return 'Critical';
    if (currentValue >= warningLevel) return 'Warning';
    if (currentValue >= warningLevel * 0.85) return 'Watch';
    return 'Normal';
  }
  // lowerIsWorse
  if (currentValue <= criticalLevel) return 'Critical';
  if (currentValue <= warningLevel) return 'Warning';
  if (currentValue <= warningLevel * 1.15) return 'Watch';
  return 'Normal';
}
