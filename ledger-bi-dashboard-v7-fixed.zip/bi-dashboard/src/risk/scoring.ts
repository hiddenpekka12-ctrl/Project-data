import { RiskLevelBand, RiskScoringSettings } from './types';

export const DEFAULT_RISK_LEVELS: RiskLevelBand[] = [
  { label: 'Low', min: 1, max: 4, color: '#1F6F54' },
  { label: 'Moderate', min: 5, max: 9, color: '#A9782E' },
  { label: 'High', min: 10, max: 14, color: '#B3452C' },
  { label: 'Very High', min: 15, max: 19, color: '#8B2F1D' },
  { label: 'Critical', min: 20, max: 25, color: '#5C1610' },
];

export const DEFAULT_SCORING_SETTINGS: RiskScoringSettings = { levels: DEFAULT_RISK_LEVELS };

export const PROBABILITY_DEFINITIONS: { value: number; label: string; description: string }[] = [
  { value: 1, label: 'Rare', description: 'Very unlikely.' },
  { value: 2, label: 'Unlikely', description: 'Could occur but not expected frequently.' },
  { value: 3, label: 'Possible', description: 'Reasonably possible.' },
  { value: 4, label: 'Likely', description: 'Expected to occur.' },
  { value: 5, label: 'Almost Certain', description: 'Highly likely.' },
];

export const IMPACT_DEFINITIONS: { value: number; label: string; description: string }[] = [
  { value: 1, label: 'Minimal', description: 'Negligible effect.' },
  { value: 2, label: 'Minor', description: 'Small, manageable effect.' },
  { value: 3, label: 'Moderate', description: 'Noticeable effect requiring management attention.' },
  { value: 4, label: 'Major', description: 'Significant effect on the business.' },
  { value: 5, label: 'Severe', description: 'Critical effect threatening core operations.' },
];

export function computeRiskScore(probability: number, impact: number): number {
  return probability * impact;
}

export function riskLevelFor(score: number, settings: RiskScoringSettings = DEFAULT_SCORING_SETTINGS): RiskLevelBand {
  const band = settings.levels.find((l) => score >= l.min && score <= l.max);
  return band ?? settings.levels[settings.levels.length - 1];
}
