import { Row } from '../types/analytics';
import { PeriodModel } from '../finance/buildFinanceModel';
import { Control, KeyRiskIndicator, MitigationAction, RiskAppetiteSettings, RiskItem, RiskScoringSettings, RiskSignal } from './types';
import { computeRiskScore, riskLevelFor } from './scoring';
import { evaluateAppetite } from './appetite';
import { computeKriStatus } from './kri';
import { buildFinancialRiskSignals } from './financialRisk';
import { computeConcentration } from './concentration';
import { generateRiskInsights } from './insights';
import { generateRiskAlerts } from './alerts';
import { validateRiskRegister, RiskValidationIssue } from './validation';
import { classifyRiskTrend } from './trends';
import { ConcentrationResult, RiskInsight, RiskAlert, RiskTrendDirection } from './types';

export interface ScoredRisk {
  risk: RiskItem;
  inherentScore: number;
  residualScore: number;
  level: ReturnType<typeof riskLevelFor>;
  appetite: ReturnType<typeof evaluateAppetite>;
  trend: RiskTrendDirection;
}

export interface RiskOverviewKpis {
  overallScore: number; // average residual score across open risks
  totalRisks: number;
  criticalRisks: number;
  veryHighRisks: number;
  highRisks: number;
  openRisks: number;
  overdueMitigationActions: number;
  risksIncreasing: number;
  risksDecreasing: number;
  risksWithoutControls: number;
  risksAboveAppetite: number;
}

export interface RiskModel {
  scoredRisks: ScoredRisk[];
  overview: RiskOverviewKpis;
  financialSignals: RiskSignal[];
  concentrations: ConcentrationResult[];
  insights: RiskInsight[];
  alerts: RiskAlert[];
  validation: RiskValidationIssue[];
  categoryDistribution: { category: string; count: number }[];
}

export function buildRiskModel(
  registerItems: RiskItem[],
  kris: KeyRiskIndicator[],
  controls: Control[],
  mitigations: MitigationAction[],
  appetiteSettings: RiskAppetiteSettings,
  scoringSettings: RiskScoringSettings,
  financePeriods: PeriodModel[],
  rawRows: Row[],
  categoricalColumns: string[],
  revenueColumn: string | null
): RiskModel {
  const scoredRisks: ScoredRisk[] = registerItems.map((risk) => {
    const inherentScore = computeRiskScore(risk.inherentProbability, risk.inherentImpact);
    const residualScore = computeRiskScore(risk.residualProbability, risk.residualImpact);
    return {
      risk,
      inherentScore,
      residualScore,
      level: riskLevelFor(residualScore, scoringSettings),
      appetite: evaluateAppetite(residualScore, appetiteSettings),
      trend: classifyRiskTrend(risk),
    };
  });

  const today = new Date().toISOString().slice(0, 10);
  const overdueMitigationActions = mitigations.filter((m) => m.status !== 'Completed' && m.status !== 'Cancelled' && m.dueDate < today).length;
  const linkedRiskIds = new Set(controls.map((c) => c.linkedRiskId).filter(Boolean));
  const risksWithoutControls = registerItems.filter((r) => !r.existingControls.trim() && !linkedRiskIds.has(r.id)).length;

  const openScored = scoredRisks.filter((s) => s.risk.status === 'Open' || s.risk.status === 'Monitoring');
  const overview: RiskOverviewKpis = {
    overallScore: openScored.length ? Math.round((openScored.reduce((s, r) => s + r.residualScore, 0) / openScored.length) * 10) / 10 : 0,
    totalRisks: registerItems.length,
    criticalRisks: scoredRisks.filter((s) => s.level.label === 'Critical').length,
    veryHighRisks: scoredRisks.filter((s) => s.level.label === 'Very High').length,
    highRisks: scoredRisks.filter((s) => s.level.label === 'High').length,
    openRisks: registerItems.filter((r) => r.status === 'Open').length,
    overdueMitigationActions,
    risksIncreasing: scoredRisks.filter((s) => s.trend === 'Increasing').length,
    risksDecreasing: scoredRisks.filter((s) => s.trend === 'Decreasing').length,
    risksWithoutControls,
    risksAboveAppetite: scoredRisks.filter((s) => s.appetite.status === 'Escalation — above appetite').length,
  };

  const current = financePeriods[financePeriods.length - 1] ?? null;
  const previous = financePeriods.length > 1 ? financePeriods[financePeriods.length - 2] : null;
  const financialSignals = current ? buildFinancialRiskSignals(current, previous) : [];

  const concentrations: ConcentrationResult[] = [];
  if (revenueColumn) {
    categoricalColumns.slice(0, 3).forEach((col) => {
      const result = computeConcentration(rawRows, col, revenueColumn);
      if (result) concentrations.push(result);
    });
  }

  const insights = generateRiskInsights(financialSignals, concentrations, registerItems);
  const alerts = generateRiskAlerts(registerItems, kris, mitigations, appetiteSettings, financialSignals);
  const validation = validateRiskRegister(registerItems);

  const categoryCounts = new Map<string, number>();
  registerItems.forEach((r) => categoryCounts.set(r.category, (categoryCounts.get(r.category) ?? 0) + 1));
  const categoryDistribution = Array.from(categoryCounts.entries()).map(([category, count]) => ({ category, count }));

  return { scoredRisks, overview, financialSignals, concentrations, insights, alerts, validation, categoryDistribution };
}

export { computeKriStatus };
