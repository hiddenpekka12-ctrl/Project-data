/**
 * RISK ENGINE TYPES
 * -----------------
 * The Risk Register is qualitative and company-level — independent of
 * which dataset is active. Financial Risk signals, by contrast, read
 * directly from V3's FinanceModel (PeriodModel), never recomputing a
 * ratio V3 already owns.
 */

export type RiskCategory =
  | 'financial'
  | 'strategic'
  | 'operational'
  | 'technology'
  | 'compliance'
  | 'supplyChain'
  | 'reputational';

export const RISK_CATEGORY_LABELS: Record<RiskCategory, string> = {
  financial: 'Financial Risk',
  strategic: 'Strategic / Business Risk',
  operational: 'Operational Risk',
  technology: 'Technology / Cyber Risk',
  compliance: 'Compliance / Regulatory Risk',
  supplyChain: 'Supply Chain Risk',
  reputational: 'Reputational Risk',
};

/** Subcategories are free-form suggestions per category, not a closed
 * enum — Section 4 asks for "configurable", so the register lets a user
 * type any subcategory; these are just autocomplete-style defaults. */
export const RISK_SUBCATEGORY_SUGGESTIONS: Record<RiskCategory, string[]> = {
  financial: ['Liquidity risk', 'Credit risk', 'Market risk', 'Interest-rate risk', 'Foreign-exchange risk', 'Leverage risk', 'Cash-flow risk', 'Working-capital risk', 'Profitability risk', 'Concentration risk'],
  strategic: ['Competitive risk', 'Business-model risk', 'Demand risk', 'Pricing risk', 'Growth risk', 'Customer concentration', 'Product concentration', 'Geographic concentration', 'Strategic execution risk'],
  operational: ['Process failure', 'Human error', 'Equipment failure', 'Quality failure', 'Capacity risk', 'Productivity risk', 'Vendor failure', 'Logistics disruption', 'Inventory disruption'],
  technology: ['System downtime', 'Data loss', 'Cybersecurity incident', 'Ransomware', 'Unauthorized access', 'Software failure', 'Infrastructure failure', 'Third-party technology dependency'],
  compliance: ['Regulatory violation', 'Legal risk', 'Reporting failure', 'Licensing risk', 'Policy violation', 'Audit finding', 'Contractual risk'],
  supplyChain: ['Supplier dependency', 'Single-source dependency', 'Raw-material price risk', 'Transportation disruption', 'Geopolitical disruption', 'Inventory shortage', 'Supplier quality failure'],
  reputational: ['Customer complaints', 'Product/service failure', 'Negative publicity', 'Social-media crisis', 'Ethical issues', 'Stakeholder trust damage'],
};

export type ImpactDimension = 'financial' | 'operational' | 'customer' | 'strategic' | 'regulatory' | 'reputational' | 'technology';

export type RiskStatus = 'Open' | 'Monitoring' | 'Mitigated' | 'Closed';
export type RiskTrendDirection = 'Increasing' | 'Stable' | 'Decreasing' | 'New' | 'Resolved' | 'Insufficient data';
export type TreatmentStrategy = 'Avoid' | 'Reduce' | 'Transfer' | 'Accept';
export type ControlEffectiveness = 'Strong' | 'Adequate' | 'Weak' | 'Unknown' | 'Not Assessed';

export interface RiskItem {
  id: string;
  name: string;
  category: RiskCategory;
  subcategory: string;
  description: string;
  cause: string;
  riskEvent: string;
  consequence: string;
  owner: string;
  department: string;
  dateIdentified: string;
  reviewDate: string;
  impactDimension: ImpactDimension;

  inherentProbability: number; // 1-5
  inherentImpact: number; // 1-5

  existingControls: string;
  controlEffectiveness: ControlEffectiveness;

  residualProbability: number; // 1-5
  residualImpact: number; // 1-5

  treatmentStrategy: TreatmentStrategy;
  mitigationAction: string;
  actionOwner: string;
  targetDate: string;

  status: RiskStatus;
  evidenceSource: string;
  notes: string;

  history: { date: string; residualProbability: number; residualImpact: number }[];
}

export interface RiskLevelBand {
  label: string;
  min: number;
  max: number;
  color: string;
}

export interface RiskScoringSettings {
  levels: RiskLevelBand[]; // configurable thresholds, not hard-coded
}

export interface RiskAppetiteSettings {
  toleranceThreshold: number; // score at/below = within tolerance
  managementAttentionThreshold: number; // score above tolerance, below escalation
  escalationThreshold: number; // score at/above = escalation
}

export type KriDirection = 'higherIsWorse' | 'lowerIsWorse';
export type KriStatus = 'Normal' | 'Watch' | 'Warning' | 'Critical' | 'No Data';

export interface KeyRiskIndicator {
  id: string;
  name: string;
  category: RiskCategory;
  metric: string;
  currentValue: number | null;
  warningLevel: number;
  criticalLevel: number;
  direction: KriDirection;
  frequency: string;
  owner: string;
  sourceDataset: string;
  lastUpdated: string;
}

export interface Control {
  id: string;
  name: string;
  linkedRiskId: string | null;
  controlType: string;
  natureType: 'Preventive' | 'Detective';
  owner: string;
  frequency: string;
  effectiveness: ControlEffectiveness;
  evidence: string;
  lastReview: string;
  nextReview: string;
  status: 'Active' | 'Inactive';
}

export type MitigationStatus = 'Not Started' | 'In Progress' | 'Completed' | 'Delayed' | 'Cancelled';

export interface MitigationAction {
  id: string;
  riskId: string;
  action: string;
  owner: string;
  priority: 'Priority 1' | 'Priority 2' | 'Priority 3' | 'Priority 4';
  startDate: string;
  dueDate: string;
  status: MitigationStatus;
  progressPct: number;
  expectedImpact: string;
  actualImpact: string;
  notes: string;
}

export type RiskEvidenceType = 'FACT' | 'INFERENCE' | 'ASSUMPTION' | 'FORECAST' | 'RECOMMENDATION';

export interface RiskSignal {
  id: string;
  category: RiskCategory;
  label: string;
  metric: string;
  currentValue: number | string;
  previousValue: number | string | null;
  threshold: number | string | null;
  changeDescription: string;
  interpretation: string;
  evidenceType: RiskEvidenceType;
  recommendedInvestigation: string;
}

export interface RiskInsight {
  id: string;
  finding: string;
  evidence: string;
  riskMeaning: string;
  confidence: 'High' | 'Medium' | 'Low';
  recommendedInvestigation: string;
}

export type AlertSeverity = 'critical' | 'warning' | 'info';

export interface RiskAlert {
  id: string;
  label: string;
  severity: AlertSeverity;
  metric: string;
  currentValue: string;
  threshold: string;
  date: string;
  source: string;
  recommendedAction: string;
}

export interface CreditRiskInput {
  pd: number; // 0-1
  lgd: number; // 0-1
  ead: number; // currency amount
}

export interface CreditRiskResult {
  expectedLoss: number;
}

export interface ScorecardVariable {
  key: string;
  label: string;
  weight: number; // 0-1, all variables should sum to 1
  score: number; // 0-100, user or auto-derived
}

export interface ConcentrationResult {
  dimension: string;
  topEntity: string;
  topSharePct: number;
  top5SharePct: number | null;
  total: number;
}
