import { PeriodModel } from '../finance/buildFinanceModel';
import { RiskSignal } from './types';

let counter = 0;
function id(prefix: string): string {
  counter += 1;
  return `${prefix}-${counter}`;
}

function ratioValue(period: PeriodModel, group: 'liquidityRatios' | 'solvencyRatios', key: string): number | null {
  return period[group].find((r) => r.key === key)?.value ?? null;
}

/**
 * Reads V3's already-computed ratios and balance/cash-flow figures and
 * turns them into risk signals: metric, current vs previous, a threshold,
 * and an interpretation that is explicitly a signal, not proof of failure.
 */
export function buildFinancialRiskSignals(current: PeriodModel, previous: PeriodModel | null): RiskSignal[] {
  counter = 0;
  const signals: RiskSignal[] = [];

  // Liquidity risk
  const currentRatioNow = ratioValue(current, 'liquidityRatios', 'currentRatio');
  const currentRatioPrev = previous ? ratioValue(previous, 'liquidityRatios', 'currentRatio') : null;
  if (currentRatioNow !== null && currentRatioNow < 1.5) {
    signals.push({
      id: id('liquidity'),
      category: 'financial',
      label: 'Liquidity risk signal detected',
      metric: 'Current Ratio',
      currentValue: currentRatioNow.toFixed(2),
      previousValue: currentRatioPrev !== null ? currentRatioPrev.toFixed(2) : null,
      threshold: '1.50',
      changeDescription: currentRatioPrev !== null ? `${currentRatioPrev.toFixed(2)} → ${currentRatioNow.toFixed(2)}` : 'No prior period available',
      interpretation: 'Current ratio below 1.5 suggests thinner short-term coverage of obligations than a common comfort threshold.',
      evidenceType: 'INFERENCE',
      recommendedInvestigation: 'Review the Working Capital breakdown for which component (receivables, inventory, current liabilities) is driving this.',
    });
  }

  // Leverage risk
  const debtToEquityNow = ratioValue(current, 'solvencyRatios', 'debtToEquity');
  const debtToEquityPrev = previous ? ratioValue(previous, 'solvencyRatios', 'debtToEquity') : null;
  if (debtToEquityNow !== null && debtToEquityPrev !== null && debtToEquityNow > debtToEquityPrev * 1.1) {
    signals.push({
      id: id('leverage'),
      category: 'financial',
      label: 'Leverage risk signal detected',
      metric: 'Debt-to-Equity',
      currentValue: `${debtToEquityNow.toFixed(2)}×`,
      previousValue: `${debtToEquityPrev.toFixed(2)}×`,
      threshold: null,
      changeDescription: `${debtToEquityPrev.toFixed(2)}× → ${debtToEquityNow.toFixed(2)}×`,
      interpretation: 'Rising leverage increases sensitivity to interest rate changes and earnings shocks.',
      evidenceType: 'INFERENCE',
      recommendedInvestigation: 'Check whether the increase is from new borrowing or from equity erosion (accumulated losses).',
    });
  }

  // Debt-servicing risk
  const interestCoverageNow = ratioValue(current, 'solvencyRatios', 'interestCoverage');
  const interestCoveragePrev = previous ? ratioValue(previous, 'solvencyRatios', 'interestCoverage') : null;
  if (interestCoverageNow !== null && interestCoveragePrev !== null && interestCoverageNow < interestCoveragePrev) {
    signals.push({
      id: id('coverage'),
      category: 'financial',
      label: 'Debt servicing risk signal detected',
      metric: 'Interest Coverage',
      currentValue: `${interestCoverageNow.toFixed(1)}×`,
      previousValue: `${interestCoveragePrev.toFixed(1)}×`,
      threshold: '2.0×',
      changeDescription: `${interestCoveragePrev.toFixed(1)}× → ${interestCoverageNow.toFixed(1)}×`,
      interpretation: interestCoverageNow < 2 ? 'Interest coverage below 2× combined with a declining trend warrants attention.' : 'Coverage declined but remains above a common comfort threshold.',
      evidenceType: 'INFERENCE',
      recommendedInvestigation: 'Review whether the decline is from rising interest expense, falling EBIT, or both.',
    });
  }

  // Working capital / receivables risk
  const dsoNow = current.workingCapital.dso;
  const dsoPrev = previous?.workingCapital.dso ?? null;
  if (dsoNow !== null && dsoPrev !== null && dsoNow > dsoPrev * 1.15) {
    signals.push({
      id: id('dso'),
      category: 'financial',
      label: 'Receivables / working-capital risk signal detected',
      metric: 'Days Sales Outstanding',
      currentValue: `${dsoNow.toFixed(0)} days`,
      previousValue: `${dsoPrev.toFixed(0)} days`,
      threshold: null,
      changeDescription: `${dsoPrev.toFixed(0)} → ${dsoNow.toFixed(0)} days`,
      interpretation: 'Slower collections tie up cash even when reported sales look healthy.',
      evidenceType: 'INFERENCE',
      recommendedInvestigation: 'Review individual receivable aging if available outside this tool.',
    });
  }

  // Cash flow risk
  if (current.cashFlow.operatingCashFlow < 0) {
    signals.push({
      id: id('ocf'),
      category: 'financial',
      label: 'Cash flow risk signal detected',
      metric: 'Estimated Operating Cash Flow',
      currentValue: current.cashFlow.operatingCashFlow.toFixed(0),
      previousValue: previous ? previous.cashFlow.operatingCashFlow.toFixed(0) : null,
      threshold: '0',
      changeDescription: previous ? `${previous.cashFlow.operatingCashFlow.toFixed(0)} → ${current.cashFlow.operatingCashFlow.toFixed(0)}` : 'No prior period available',
      interpretation: 'Negative operating cash flow means the business is consuming cash from operations, regardless of reported profit.',
      evidenceType: 'FACT',
      recommendedInvestigation: 'Check the Cash Flow view to see whether working-capital buildup or an actual operating loss is responsible.',
    });
  }

  // Profitability risk
  if (previous && current.income.netMarginPct < previous.income.netMarginPct - 2) {
    signals.push({
      id: id('profitability'),
      category: 'financial',
      label: 'Profitability risk signal detected',
      metric: 'Net Margin',
      currentValue: `${current.income.netMarginPct.toFixed(1)}%`,
      previousValue: `${previous.income.netMarginPct.toFixed(1)}%`,
      threshold: null,
      changeDescription: `${previous.income.netMarginPct.toFixed(1)}% → ${current.income.netMarginPct.toFixed(1)}%`,
      interpretation: 'Margin compression reduces the cushion available to absorb future shocks.',
      evidenceType: 'INFERENCE',
      recommendedInvestigation: "Use the Finance Center's Profit Diagnostic to decompose the change.",
    });
  }

  return signals;
}
