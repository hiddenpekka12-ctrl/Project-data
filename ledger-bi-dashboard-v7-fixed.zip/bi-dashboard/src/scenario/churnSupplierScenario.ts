import { Row } from '../types/analytics';
import { computeConcentration } from '../risk/concentration';

export interface ChurnScenarioResult {
  dimension: string;
  churnedEntity: string;
  churnedRevenue: number;
  churnedSharePct: number;
  estimatedGrossProfitImpact: number;
  remainingConcentrationPct: number | null;
}

/** Simulates the top entity (customer/supplier) churning, using the same
 * concentration calculation V4 already owns — not a duplicate. Gross
 * profit impact uses the CURRENT gross margin as a stated assumption. */
export function runChurnScenario(rows: Row[], dimensionColumn: string, revenueColumn: string, currentGrossMarginPct: number): ChurnScenarioResult | null {
  const concentration = computeConcentration(rows, dimensionColumn, revenueColumn);
  if (!concentration) return null;

  const churnedRevenue = (concentration.topSharePct / 100) * concentration.total;
  const remainingTotal = concentration.total - churnedRevenue;
  const remainingConcentrationPct = concentration.top5SharePct !== null && remainingTotal > 0 ? Math.max(0, concentration.top5SharePct - concentration.topSharePct) : null;

  return {
    dimension: dimensionColumn,
    churnedEntity: concentration.topEntity,
    churnedRevenue,
    churnedSharePct: concentration.topSharePct,
    estimatedGrossProfitImpact: -churnedRevenue * (currentGrossMarginPct / 100),
    remainingConcentrationPct,
  };
}
