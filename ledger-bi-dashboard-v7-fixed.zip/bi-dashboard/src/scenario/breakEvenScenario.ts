import { computeBreakEven } from '../finance/breakEven';
import { BreakEvenInput, BreakEvenResult } from '../finance/types';

export interface BreakEvenScenarioResult {
  base: BreakEvenResult;
  scenario: BreakEvenResult;
  marginOfSafetyUnits: number | null;
  marginOfSafetyPct: number | null;
}

/** Recalculates break-even under shocked price/variable-cost/fixed-cost
 * inputs using V3's own computeBreakEven — not a second formula. */
export function runBreakEvenScenario(baseInput: BreakEvenInput, scenarioInput: BreakEvenInput, actualOrExpectedUnits: number | null): BreakEvenScenarioResult {
  const base = computeBreakEven(baseInput);
  const scenario = computeBreakEven(scenarioInput);

  const marginOfSafetyUnits = actualOrExpectedUnits !== null && scenario.breakEvenUnits !== null ? actualOrExpectedUnits - scenario.breakEvenUnits : null;
  const marginOfSafetyPct = marginOfSafetyUnits !== null && actualOrExpectedUnits ? (marginOfSafetyUnits / actualOrExpectedUnits) * 100 : null;

  return { base, scenario, marginOfSafetyUnits, marginOfSafetyPct };
}
