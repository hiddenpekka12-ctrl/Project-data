import { ExpectedValueInput, ExpectedValueResult } from './types';

/** Section 41-42: probabilities are NEVER auto-assigned. This function
 * only computes an expected value when the user has explicitly supplied
 * probabilities that sum to 100% — otherwise it refuses and explains why. */
export function computeExpectedValue(inputs: ExpectedValueInput[]): ExpectedValueResult {
  const totalProbabilityPct = inputs.reduce((s, i) => s + i.probabilityPct, 0);

  if (inputs.length === 0) {
    return { valid: false, totalProbabilityPct: 0, expectedValue: null, breakdown: [], error: 'No scenario probabilities provided.' };
  }
  if (Math.abs(totalProbabilityPct - 100) > 0.5) {
    return {
      valid: false,
      totalProbabilityPct,
      expectedValue: null,
      breakdown: [],
      error: `Probabilities sum to ${totalProbabilityPct.toFixed(1)}%, not 100%. Expected value cannot be calculated until they total 100%.`,
    };
  }

  const breakdown = inputs.map((i) => ({ scenarioLabel: i.scenarioLabel, contribution: (i.probabilityPct / 100) * i.outcome }));
  const expectedValue = breakdown.reduce((s, b) => s + b.contribution, 0);

  return { valid: true, totalProbabilityPct, expectedValue, breakdown, error: null };
}
