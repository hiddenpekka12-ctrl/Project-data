import { PeriodModel } from '../finance/buildFinanceModel';
import { BalanceSheetLine, IncomeStatementLine } from '../finance/types';
import { buildLiquidityRatios, buildProfitabilityRatios, buildSolvencyRatios, buildEfficiencyRatios } from '../finance/ratios';
import { buildWorkingCapital } from '../finance/workingCapital';
import { buildDuPont } from '../finance/dupont';
import { buildCashFlow } from '../finance/cashFlow';
import { AssumptionEntry, DriverChanges, PropagationStep } from './types';

function pct(numerator: number, denominator: number): number {
  return denominator === 0 ? 0 : (numerator / denominator) * 100;
}

/**
 * Recomputes revenue, then the full income statement, using the SAME
 * relationships V3 uses (Revenue − COGS = Gross Profit, etc.) — this is
 * arithmetic reuse of V3's own formulas on shocked inputs, not a second
 * finance engine.
 */
export function applyDriversToIncomeStatement(base: IncomeStatementLine, drivers: DriverChanges): IncomeStatementLine {
  let revenue: number;
  if (drivers.priceChangePct !== null || drivers.volumeChangePct !== null) {
    const priceFactor = 1 + (drivers.priceChangePct ?? 0) / 100;
    const volumeFactor = 1 + (drivers.volumeChangePct ?? 0) / 100;
    revenue = base.revenue * priceFactor * volumeFactor;
  } else if (drivers.revenueGrowthPct !== null) {
    revenue = base.revenue * (1 + drivers.revenueGrowthPct / 100);
  } else {
    revenue = base.revenue;
  }

  const cogs = base.cogs * (1 + drivers.cogsChangePct / 100);
  const grossProfit = revenue - cogs;
  const operatingExpenses = base.operatingExpenses * (1 + drivers.opexChangePct / 100);
  const ebitda = grossProfit - operatingExpenses;
  const depreciation = base.depreciation;
  const ebit = ebitda - depreciation;

  const interest = base.interest * (1 + drivers.interestRateChangePct / 100);

  const otherIncome = base.otherIncome;
  const otherExpenses = base.otherExpenses;
  const profitBeforeTax = ebit - interest + otherIncome - otherExpenses;
  const effectiveTaxRate = drivers.taxRateOverridePct !== null ? drivers.taxRateOverridePct / 100 : base.profitBeforeTax !== 0 ? base.tax / base.profitBeforeTax : 0;
  const tax = Math.max(0, profitBeforeTax * effectiveTaxRate);
  const netProfit = profitBeforeTax - tax;

  return {
    revenue,
    cogs,
    grossProfit,
    grossMarginPct: pct(grossProfit, revenue),
    operatingExpenses,
    ebitda,
    ebitdaMarginPct: pct(ebitda, revenue),
    depreciation,
    ebit,
    ebitMarginPct: pct(ebit, revenue),
    interest,
    otherIncome,
    otherExpenses,
    profitBeforeTax,
    tax,
    netProfit,
    netMarginPct: pct(netProfit, revenue),
    momRevenueGrowthPct: pct(revenue - base.revenue, base.revenue),
    yoyRevenueGrowthPct: null,
    momNetProfitGrowthPct: base.netProfit !== 0 ? pct(netProfit - base.netProfit, Math.abs(base.netProfit)) : null,
    yoyNetProfitGrowthPct: null,
  };
}

/**
 * Shocks the balance sheet using DSO/DIO/DPO day-changes (scaled against
 * the shocked income statement) and a capex driver on fixed assets.
 * Equity is set as the balancing residual, exactly like V3's demo
 * company — a legitimate choice since equity IS defined as that residual.
 */
export function applyDriversToBalanceSheet(baseIncome: IncomeStatementLine, scenarioIncome: IncomeStatementLine, baseBs: BalanceSheetLine, drivers: DriverChanges, daysInPeriod: number): BalanceSheetLine {
  const baseDso = baseIncome.revenue === 0 ? 0 : (baseBs.receivables / baseIncome.revenue) * daysInPeriod;
  const baseDio = baseIncome.cogs === 0 ? 0 : (baseBs.inventory / baseIncome.cogs) * daysInPeriod;
  const baseDpo = baseIncome.cogs === 0 ? 0 : (baseBs.currentLiabilities / baseIncome.cogs) * daysInPeriod;

  const newDso = baseDso + drivers.dsoChangeDays;
  const newDio = baseDio + drivers.dioChangeDays;
  const newDpo = Math.max(0, baseDpo + drivers.dpoChangeDays);

  const receivables = (newDso / daysInPeriod) * scenarioIncome.revenue;
  const inventory = (newDio / daysInPeriod) * scenarioIncome.cogs;
  const currentLiabilities = (newDpo / daysInPeriod) * scenarioIncome.cogs;

  const fixedAssets = baseBs.fixedAssets * (1 + drivers.capexChangePct / 100);
  const longTermDebt = baseBs.longTermDebt;

  const netProfitDelta = scenarioIncome.netProfit - baseIncome.netProfit;
  const workingCapitalDelta = (baseBs.receivables - receivables) + (baseBs.inventory - inventory) + (currentLiabilities - baseBs.currentLiabilities);
  const cash = baseBs.cash + netProfitDelta + workingCapitalDelta;

  const currentAssets = cash + receivables + inventory;
  const nonCurrentAssets = fixedAssets;
  const totalAssets = currentAssets + nonCurrentAssets;
  const nonCurrentLiabilities = longTermDebt;
  const totalLiabilities = currentLiabilities + nonCurrentLiabilities;
  const equity = totalAssets - totalLiabilities;

  return {
    cash,
    receivables,
    inventory,
    currentAssets,
    fixedAssets,
    nonCurrentAssets,
    totalAssets,
    currentLiabilities,
    longTermDebt,
    nonCurrentLiabilities,
    totalLiabilities,
    equity,
    balances: true,
    imbalanceAmount: 0,
  };
}

/** Builds a fully-consistent shocked PeriodModel by reusing V3's actual
 * ratio/working-capital/DuPont/cash-flow functions on the shocked
 * statements — this is the "never duplicate V3 formulas" requirement,
 * satisfied literally. */
export function propagateScenario(base: PeriodModel, drivers: DriverChanges, daysInPeriod = 30): PeriodModel {
  const income = applyDriversToIncomeStatement(base.income, drivers);
  const balanceSheet = applyDriversToBalanceSheet(base.income, income, base.balanceSheet, drivers, daysInPeriod);
  const cashFlow = buildCashFlow(income, balanceSheet, base.balanceSheet);
  const workingCapital = buildWorkingCapital(income, balanceSheet, base.balanceSheet, 'month');

  return {
    label: `${base.label} (scenario)`,
    income,
    balanceSheet,
    cashFlow,
    workingCapital,
    liquidityRatios: buildLiquidityRatios(balanceSheet),
    profitabilityRatios: buildProfitabilityRatios(income, balanceSheet, base.balanceSheet),
    solvencyRatios: buildSolvencyRatios(income, balanceSheet),
    efficiencyRatios: buildEfficiencyRatios(income, balanceSheet, base.balanceSheet),
    dupont: buildDuPont(income, balanceSheet, base.balanceSheet),
  };
}

/** Builds the visible propagation chain (Section 8) — the whole point of
 * a driver-based model instead of letting someone silently overwrite a
 * final KPI. */
export function buildPropagationChain(base: PeriodModel, scenario: PeriodModel): PropagationStep[] {
  const steps: [string, number, number][] = [
    ['Revenue', base.income.revenue, scenario.income.revenue],
    ['COGS', base.income.cogs, scenario.income.cogs],
    ['Gross Profit', base.income.grossProfit, scenario.income.grossProfit],
    ['Operating Expenses', base.income.operatingExpenses, scenario.income.operatingExpenses],
    ['EBITDA', base.income.ebitda, scenario.income.ebitda],
    ['EBIT', base.income.ebit, scenario.income.ebit],
    ['Net Profit', base.income.netProfit, scenario.income.netProfit],
    ['Operating Cash Flow', base.cashFlow.operatingCashFlow, scenario.cashFlow.operatingCashFlow],
    ['Cash', base.balanceSheet.cash, scenario.balanceSheet.cash],
  ];
  return steps.map(([label, baseValue, scenarioValue]) => ({
    label,
    baseValue,
    scenarioValue,
    changeDescription: baseValue !== 0 ? `${(((scenarioValue - baseValue) / Math.abs(baseValue)) * 100).toFixed(1)}%` : 'n/a (base was zero)',
  }));
}

export function buildAssumptionEntries(drivers: DriverChanges): AssumptionEntry[] {
  const entries: AssumptionEntry[] = [];
  const push = (input: string, base: string, scenario: string, change: string) => entries.push({ input, baseValue: base, scenarioValue: scenario, change, source: 'User' });

  if (drivers.revenueGrowthPct !== null) push('Revenue growth', '0% (actual)', `${drivers.revenueGrowthPct}%`, `${drivers.revenueGrowthPct >= 0 ? '+' : ''}${drivers.revenueGrowthPct}%`);
  if (drivers.priceChangePct !== null) push('Price change', '0%', `${drivers.priceChangePct}%`, `${drivers.priceChangePct >= 0 ? '+' : ''}${drivers.priceChangePct}%`);
  if (drivers.volumeChangePct !== null) push('Volume change', '0%', `${drivers.volumeChangePct}%`, `${drivers.volumeChangePct >= 0 ? '+' : ''}${drivers.volumeChangePct}%`);
  if (drivers.cogsChangePct !== 0) push('COGS change', '0%', `${drivers.cogsChangePct}%`, `${drivers.cogsChangePct >= 0 ? '+' : ''}${drivers.cogsChangePct}%`);
  if (drivers.opexChangePct !== 0) push('Operating expense change', '0%', `${drivers.opexChangePct}%`, `${drivers.opexChangePct >= 0 ? '+' : ''}${drivers.opexChangePct}%`);
  if (drivers.interestRateChangePct !== 0) push('Interest expense change', '0%', `${drivers.interestRateChangePct}%`, `${drivers.interestRateChangePct >= 0 ? '+' : ''}${drivers.interestRateChangePct}%`);
  if (drivers.taxRateOverridePct !== null) push('Effective tax rate', 'historical average', `${drivers.taxRateOverridePct}%`, 'override');
  if (drivers.dsoChangeDays !== 0) push('DSO change', '0 days', `${drivers.dsoChangeDays} days`, `${drivers.dsoChangeDays >= 0 ? '+' : ''}${drivers.dsoChangeDays} days`);
  if (drivers.dioChangeDays !== 0) push('DIO change', '0 days', `${drivers.dioChangeDays} days`, `${drivers.dioChangeDays >= 0 ? '+' : ''}${drivers.dioChangeDays} days`);
  if (drivers.dpoChangeDays !== 0) push('DPO change', '0 days', `${drivers.dpoChangeDays} days`, `${drivers.dpoChangeDays >= 0 ? '+' : ''}${drivers.dpoChangeDays} days`);
  if (drivers.capexChangePct !== 0) push('Capex / fixed asset change', '0%', `${drivers.capexChangePct}%`, `${drivers.capexChangePct >= 0 ? '+' : ''}${drivers.capexChangePct}%`);

  return entries;
}
