import { DriverChanges, NEUTRAL_DRIVERS, StressTestPreset } from './types';

/** Presets are illustrative starting points, not universal truths about
 * what's "severe" for every business — always shown alongside the
 * driver values so nothing is a black box. */
export const STRESS_PRESETS: StressTestPreset[] = [
  {
    key: 'mild',
    label: 'Mild Stress',
    severity: 'Mild',
    drivers: { revenueGrowthPct: -10, cogsChangePct: 5 },
    description: 'Moderate revenue decline (-10%) with a moderate cost increase (COGS +5%).',
  },
  {
    key: 'severe',
    label: 'Severe Stress',
    severity: 'Severe',
    drivers: { revenueGrowthPct: -25, cogsChangePct: 12, dsoChangeDays: 15 },
    description: 'Large revenue decline (-25%), major cost increase (COGS +12%), and working-capital deterioration (DSO +15 days).',
  },
  {
    key: 'extreme',
    label: 'Extreme Stress',
    severity: 'Extreme',
    drivers: { revenueGrowthPct: -40, cogsChangePct: 20, opexChangePct: 8, dsoChangeDays: 25, interestRateChangePct: 30 },
    description: 'Combination of multiple severe adverse drivers simultaneously: revenue -40%, COGS +20%, OpEx +8%, DSO +25 days, interest expense +30%.',
  },
];

export function mergeDrivers(base: DriverChanges, overrides: Partial<DriverChanges>): DriverChanges {
  return { ...base, ...overrides };
}

export function combinedStressDrivers(shocks: Partial<DriverChanges>[]): DriverChanges {
  return shocks.reduce<DriverChanges>((acc, s) => mergeDrivers(acc, s), NEUTRAL_DRIVERS);
}
