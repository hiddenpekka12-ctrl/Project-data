/**
 * SCENARIO ENGINE TYPES
 * ---------------------
 * A scenario never overwrites a final output directly — every change is
 * a driver, propagated through the same calculation chain V3/V4 already
 * own. Scenario/Forecast/Stress/Actual are always kept visually and
 * semantically distinct (Section 47).
 */

export type ScenarioType = 'Base Case' | 'Upside' | 'Downside' | 'Optimistic' | 'Conservative' | 'Stress' | 'Custom';

export interface DriverChanges {
  revenueGrowthPct: number | null; // direct override
  priceChangePct: number | null; // combines with volume if both set
  volumeChangePct: number | null;
  cogsChangePct: number;
  opexChangePct: number;
  interestRateChangePct: number; // percentage points added to effective rate
  taxRateOverridePct: number | null;
  dsoChangeDays: number;
  dioChangeDays: number;
  dpoChangeDays: number;
  capexChangePct: number;
}

export const NEUTRAL_DRIVERS: DriverChanges = {
  revenueGrowthPct: null,
  priceChangePct: null,
  volumeChangePct: null,
  cogsChangePct: 0,
  opexChangePct: 0,
  interestRateChangePct: 0,
  taxRateOverridePct: null,
  dsoChangeDays: 0,
  dioChangeDays: 0,
  dpoChangeDays: 0,
  capexChangePct: 0,
};

export interface AssumptionEntry {
  input: string;
  baseValue: string;
  scenarioValue: string;
  change: string;
  source: 'User' | 'Historical' | 'Model' | 'External';
}

export interface ScenarioConfig {
  id: string;
  name: string;
  description: string;
  basePeriodLabel: string;
  datasetId: string;
  scenarioType: ScenarioType;
  drivers: DriverChanges;
  horizonNote: string;
  createdDate: string;
  owner: string;
  status: 'Draft' | 'Active' | 'Archived';
  notes: string;
  version: number;
  previousVersionId: string | null;
}

export interface PropagationStep {
  label: string;
  baseValue: number;
  scenarioValue: number;
  changeDescription: string;
}

export interface ScenarioResult {
  config: ScenarioConfig;
  chain: PropagationStep[]; // Section 8's visible propagation chain
  assumptions: AssumptionEntry[];
  financialSummary: {
    revenue: number;
    grossProfit: number;
    ebitda: number;
    ebit: number;
    netProfit: number;
    operatingCashFlow: number;
    closingCash: number;
    debt: number;
    currentRatio: number | null;
    interestCoverage: number | null;
    workingCapital: number;
    cashConversionCycle: number | null;
  };
  riskScoreDelta: number | null; // health score change vs base
  redFlagCount: number;
}

export type SensitivityDriverKey = 'revenueGrowthPct' | 'priceChangePct' | 'volumeChangePct' | 'cogsChangePct' | 'opexChangePct' | 'interestRateChangePct' | 'dsoChangeDays' | 'dioChangeDays' | 'dpoChangeDays';

export interface OneWaySensitivityPoint {
  driverValue: number;
  netProfit: number;
  cash: number;
  riskScore: number | null;
}

export interface OneWaySensitivityResult {
  driver: SensitivityDriverKey;
  points: OneWaySensitivityPoint[];
}

export interface TornadoBar {
  driver: SensitivityDriverKey;
  label: string;
  lowOutcome: number;
  highOutcome: number;
  swing: number;
}

export interface TwoWaySensitivityCell {
  driverAValue: number;
  driverBValue: number;
  outcome: number;
}

export interface TwoWaySensitivityResult {
  driverA: SensitivityDriverKey;
  driverB: SensitivityDriverKey;
  outcomeMetric: string;
  cells: TwoWaySensitivityCell[];
}

export type StressSeverity = 'Mild' | 'Severe' | 'Extreme' | 'Custom';

export interface StressTestPreset {
  key: string;
  label: string;
  severity: StressSeverity;
  drivers: Partial<DriverChanges>;
  description: string;
}

export interface ThresholdBreach {
  metric: string;
  baseValue: number;
  scenarioValue: number;
  threshold: number;
  gap: number;
  breached: boolean;
}

export interface DecisionThresholdSettings {
  minCash: number;
  minCurrentRatio: number;
  minInterestCoverage: number;
  maxDebtToEquity: number;
  minGrossMarginPct: number;
  maxCustomerConcentrationPct: number;
}

export interface DecisionTriggerRule {
  id: string;
  description: string;
  conditionText: string; // human-readable IF condition, e.g. "Revenue decline > 15% AND Cash < threshold"
  actionText: string; // THEN action
  evaluate: (ctx: TriggerEvalContext) => boolean;
}

export interface TriggerEvalContext {
  revenueChangePct: number;
  cash: number;
  cashThreshold: number;
  customerConcentrationPct: number | null;
  interestCoverage: number | null;
}

export interface RobustnessRow {
  optionId: string;
  optionLabel: string;
  base: number;
  upside: number;
  downside: number;
  stress: number;
  worstCase: number;
  bestCase: number;
  variability: number;
  isRobust: boolean;
}

export interface ExpectedValueInput {
  scenarioLabel: string;
  probabilityPct: number;
  outcome: number;
}

export interface ExpectedValueResult {
  valid: boolean;
  totalProbabilityPct: number;
  expectedValue: number | null;
  breakdown: { scenarioLabel: string; contribution: number }[];
  error: string | null;
}

export interface ResilienceComponent {
  label: string;
  points: number;
  maxPoints: number;
  detail: string;
}

export interface ResilienceResult {
  score: number;
  components: ResilienceComponent[];
}

export interface SurvivalThreshold {
  label: string;
  thresholdValue: number;
  unit: string;
  method: string;
}
