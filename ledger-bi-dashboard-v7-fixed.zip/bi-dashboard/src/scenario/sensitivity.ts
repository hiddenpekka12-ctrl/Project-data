import { PeriodModel } from '../finance/buildFinanceModel';
import { propagateScenario } from './driverModel';
import { computeResilienceScore } from './resilience';
import { DriverChanges, NEUTRAL_DRIVERS, OneWaySensitivityResult, SensitivityDriverKey, TornadoBar, TwoWaySensitivityResult } from './types';

const DRIVER_LABELS: Record<SensitivityDriverKey, string> = {
  revenueGrowthPct: 'Revenue Growth',
  priceChangePct: 'Selling Price',
  volumeChangePct: 'Sales Volume',
  cogsChangePct: 'COGS',
  opexChangePct: 'Operating Expenses',
  interestRateChangePct: 'Interest Rate',
  dsoChangeDays: 'DSO',
  dioChangeDays: 'DIO',
  dpoChangeDays: 'DPO',
};

const STANDARD_STEPS = [-20, -10, -5, 0, 5, 10, 20];

function withDriver(driver: SensitivityDriverKey, value: number): DriverChanges {
  return { ...NEUTRAL_DRIVERS, [driver]: value };
}

export function runOneWaySensitivity(base: PeriodModel, driver: SensitivityDriverKey, steps: number[] = STANDARD_STEPS): OneWaySensitivityResult {
  const points = steps.map((step) => {
    const scenario = propagateScenario(base, withDriver(driver, step));
    const resilience = computeResilienceScore(scenario, null);
    return { driverValue: step, netProfit: scenario.income.netProfit, cash: scenario.balanceSheet.cash, riskScore: resilience.score };
  });
  return { driver, points };
}

/** Ranks drivers by the SWING (high minus low outcome) they cause on net
 * profit — a tornado chart's ranking must come from actual calculated
 * sensitivity, never a fabricated order (Section 14). */
export function buildTornadoRanking(base: PeriodModel, drivers: SensitivityDriverKey[], swingPct = 10): TornadoBar[] {
  const bars = drivers.map((driver) => {
    const low = propagateScenario(base, withDriver(driver, -swingPct)).income.netProfit;
    const high = propagateScenario(base, withDriver(driver, swingPct)).income.netProfit;
    const lowOutcome = Math.min(low, high);
    const highOutcome = Math.max(low, high);
    return { driver, label: DRIVER_LABELS[driver], lowOutcome, highOutcome, swing: highOutcome - lowOutcome };
  });
  return bars.sort((a, b) => b.swing - a.swing);
}

export function runTwoWaySensitivity(base: PeriodModel, driverA: SensitivityDriverKey, driverB: SensitivityDriverKey, steps: number[] = [-10, -5, 0, 5, 10]): TwoWaySensitivityResult {
  const cells = steps.flatMap((a) =>
    steps.map((b) => {
      const drivers: DriverChanges = { ...NEUTRAL_DRIVERS, [driverA]: a, [driverB]: b };
      const scenario = propagateScenario(base, drivers);
      return { driverAValue: a, driverBValue: b, outcome: scenario.income.netProfit };
    })
  );
  return { driverA, driverB, outcomeMetric: 'Net Profit', cells };
}

export { DRIVER_LABELS };
