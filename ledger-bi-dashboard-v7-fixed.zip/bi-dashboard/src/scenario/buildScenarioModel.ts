import { PeriodModel } from '../finance/buildFinanceModel';
import { propagateScenario, buildPropagationChain, buildAssumptionEntries } from './driverModel';
import { computeScenarioRiskImpact } from './riskCascade';
import { ScenarioConfig, ScenarioResult } from './types';

export function runScenario(base: PeriodModel, config: ScenarioConfig): { scenario: PeriodModel; result: ScenarioResult; riskImpact: ReturnType<typeof computeScenarioRiskImpact> } {
  const scenario = propagateScenario(base, config.drivers);
  const chain = buildPropagationChain(base, scenario);
  const assumptions = buildAssumptionEntries(config.drivers);
  const riskImpact = computeScenarioRiskImpact(base, scenario, config.name);

  const result: ScenarioResult = {
    config,
    chain,
    assumptions,
    financialSummary: {
      revenue: scenario.income.revenue,
      grossProfit: scenario.income.grossProfit,
      ebitda: scenario.income.ebitda,
      ebit: scenario.income.ebit,
      netProfit: scenario.income.netProfit,
      operatingCashFlow: scenario.cashFlow.operatingCashFlow,
      closingCash: scenario.balanceSheet.cash,
      debt: scenario.balanceSheet.longTermDebt + scenario.balanceSheet.currentLiabilities,
      currentRatio: scenario.liquidityRatios.find((r) => r.key === 'currentRatio')?.value ?? null,
      interestCoverage: scenario.solvencyRatios.find((r) => r.key === 'interestCoverage')?.value ?? null,
      workingCapital: scenario.workingCapital.workingCapital,
      cashConversionCycle: scenario.workingCapital.cashConversionCycle,
    },
    riskScoreDelta: riskImpact.healthScoreDelta,
    redFlagCount: riskImpact.redFlags.length,
  };

  return { scenario, result, riskImpact };
}
