import { PeriodModel } from '../finance/buildFinanceModel';
import { detectRedFlags, RedFlagContext } from '../finance/redFlags';
import { computeHealthScore } from '../finance/healthScore';
import { RedFlag } from '../finance/types';

export interface RiskCascadeStep {
  label: string;
  detail: string;
}

export interface ScenarioRiskImpact {
  cascade: RiskCascadeStep[];
  redFlags: RedFlag[];
  baseHealthScore: number;
  scenarioHealthScore: number;
  healthScoreDelta: number;
}

/**
 * Runs V4's OWN detectRedFlags/computeHealthScore on the shocked period
 * — this is V4 consumption, not a second risk engine (Section 27's
 * explicit requirement).
 */
export function computeScenarioRiskImpact(base: PeriodModel, scenario: PeriodModel, driverLabel: string): ScenarioRiskImpact {
  const redFlagCtx: RedFlagContext = {
    current: { income: scenario.income, bs: scenario.balanceSheet, cashFlow: scenario.cashFlow, wc: scenario.workingCapital, label: scenario.label },
    previous: { income: base.income, bs: base.balanceSheet, cashFlow: base.cashFlow, wc: base.workingCapital, label: base.label },
  };
  const redFlags = detectRedFlags(redFlagCtx);

  const revGrowth = base.income.revenue !== 0 ? ((scenario.income.revenue - base.income.revenue) / base.income.revenue) * 100 : null;
  const baseHealth = computeHealthScore(base.income, base.balanceSheet, base.cashFlow, null);
  const scenarioHealth = computeHealthScore(scenario.income, scenario.balanceSheet, scenario.cashFlow, revGrowth);

  const cascade: RiskCascadeStep[] = [
    { label: 'Scenario Shock', detail: driverLabel },
    { label: 'Business Driver', detail: `Revenue ${scenario.income.revenue >= base.income.revenue ? 'up' : 'down'} to ${scenario.income.revenue.toFixed(0)}, COGS to ${scenario.income.cogs.toFixed(0)}` },
    { label: 'Financial Impact', detail: `Net Profit: ${base.income.netProfit.toFixed(0)} → ${scenario.income.netProfit.toFixed(0)}` },
    { label: 'Operational Impact', detail: `Operating Cash Flow: ${base.cashFlow.operatingCashFlow.toFixed(0)} → ${scenario.cashFlow.operatingCashFlow.toFixed(0)}` },
    { label: 'Risk Impact', detail: `Health Score: ${baseHealth.score} → ${scenarioHealth.score} (${scenarioHealth.status})` },
    { label: 'KRI / Red Flags', detail: redFlags.length ? `${redFlags.length} red flag(s): ${redFlags.map((f) => f.label).join(', ')}` : 'No red flags triggered under this scenario.' },
    { label: 'Management Action', detail: redFlags.length ? 'Review the specific red flags below before deciding on a response.' : 'No immediate action indicated by this scenario alone.' },
  ];

  return { cascade, redFlags, baseHealthScore: baseHealth.score, scenarioHealthScore: scenarioHealth.score, healthScoreDelta: scenarioHealth.score - baseHealth.score };
}
