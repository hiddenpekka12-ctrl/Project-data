import { RobustnessRow } from './types';

export interface OptionScenarioOutcomes {
  optionId: string;
  optionLabel: string;
  base: number;
  upside: number;
  downside: number;
  stress: number;
}

/** A "robust" option is one whose worst case doesn't fall below a
 * management-set floor — never chosen purely by highest expected value
 * (Section 39's explicit requirement). */
export function computeRobustness(outcomes: OptionScenarioOutcomes[], worstCaseFloor: number): RobustnessRow[] {
  return outcomes.map((o) => {
    const values = [o.base, o.upside, o.downside, o.stress];
    const worstCase = Math.min(...values);
    const bestCase = Math.max(...values);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length;
    return {
      optionId: o.optionId,
      optionLabel: o.optionLabel,
      base: o.base,
      upside: o.upside,
      downside: o.downside,
      stress: o.stress,
      worstCase,
      bestCase,
      variability: Math.sqrt(variance),
      isRobust: worstCase >= worstCaseFloor,
    };
  });
}
