import { PeriodModel } from '../finance/buildFinanceModel';
import { propagateScenario } from './driverModel';
import { NEUTRAL_DRIVERS, SurvivalThreshold } from './types';

/** Finds the driver value (e.g. revenue decline %) at which a target
 * metric crosses zero, via binary search on the SAME propagation engine
 * used everywhere else — calculated, not guessed (Section 33). */
function findThreshold(base: PeriodModel, applyDriver: (value: number) => PeriodModel, metricOf: (p: PeriodModel) => number, searchMin: number, searchMax: number): number | null {
  const atMin = metricOf(applyDriver(searchMin));
  const atMax = metricOf(applyDriver(searchMax));
  if ((atMin > 0) === (atMax > 0)) return null;

  let lo = searchMin;
  let hi = searchMax;
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2;
    const val = metricOf(applyDriver(mid));
    if ((val > 0) === (atMin > 0)) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

export function computeSurvivalThresholds(base: PeriodModel): SurvivalThreshold[] {
  const results: SurvivalThreshold[] = [];

  const revenueThreshold = findThreshold(
    base,
    (v) => propagateScenario(base, { ...NEUTRAL_DRIVERS, revenueGrowthPct: v }),
    (p) => p.income.ebitda,
    0,
    -95
  );
  if (revenueThreshold !== null) {
    results.push({ label: 'Maximum revenue decline before EBITDA turns negative', thresholdValue: revenueThreshold, unit: '%', method: 'Binary search on revenue growth driver against EBITDA = 0, using the same propagation engine as scenarios.' });
  }

  const cogsThreshold = findThreshold(
    base,
    (v) => propagateScenario(base, { ...NEUTRAL_DRIVERS, cogsChangePct: v }),
    (p) => p.income.grossProfit,
    0,
    200
  );
  if (cogsThreshold !== null) {
    results.push({ label: 'Maximum COGS increase before gross margin reaches zero', thresholdValue: cogsThreshold, unit: '%', method: 'Binary search on COGS driver against Gross Profit = 0.' });
  }

  const interestThreshold = findThreshold(
    base,
    (v) => propagateScenario(base, { ...NEUTRAL_DRIVERS, interestRateChangePct: v }),
    (p) => p.income.profitBeforeTax,
    0,
    500
  );
  if (interestThreshold !== null) {
    results.push({ label: 'Maximum interest expense increase before profit before tax turns negative', thresholdValue: interestThreshold, unit: '%', method: 'Binary search on interest expense driver against Profit Before Tax = 0.' });
  }

  return results;
}
