import { PeriodModel } from '../finance/buildFinanceModel';
import { ResilienceResult } from './types';

/**
 * BUSINESS RESILIENCE SCORE — a transparent heuristic (Section 32), not a
 * regulated rating or guarantee. Built the same way V3's Health Score and
 * V4's scoring work: fixed point budget per component, each shown.
 */
export function computeResilienceScore(period: PeriodModel, concentrationPct: number | null): ResilienceResult {
  const components: ResilienceResult['components'] = [];

  // Cash buffer (20 pts): months of OpEx covered by cash.
  const monthlyOpex = period.income.operatingExpenses + period.income.cogs;
  const cashBufferMonths = monthlyOpex > 0 ? period.balanceSheet.cash / monthlyOpex : null;
  const cashPoints = cashBufferMonths === null ? 10 : cashBufferMonths >= 3 ? 20 : cashBufferMonths >= 1 ? 12 : 0;
  components.push({ label: 'Cash buffer', points: cashPoints, maxPoints: 20, detail: cashBufferMonths === null ? 'Not computable from current data.' : `Approximately ${cashBufferMonths.toFixed(1)} months of operating costs covered by cash.` });

  // Liquidity (15 pts)
  const currentRatio = period.liquidityRatios.find((r) => r.key === 'currentRatio')?.value ?? null;
  const liquidityPoints = currentRatio === null ? 7 : currentRatio >= 1.5 ? 15 : currentRatio >= 1 ? 9 : 0;
  components.push({ label: 'Liquidity', points: liquidityPoints, maxPoints: 15, detail: currentRatio === null ? 'Not available.' : `Current ratio of ${currentRatio.toFixed(2)}.` });

  // Leverage (15 pts)
  const debtToEquity = period.solvencyRatios.find((r) => r.key === 'debtToEquity')?.value ?? null;
  const leveragePoints = debtToEquity === null ? 7 : debtToEquity <= 1 ? 15 : debtToEquity <= 2 ? 9 : 0;
  components.push({ label: 'Leverage', points: leveragePoints, maxPoints: 15, detail: debtToEquity === null ? 'Not available.' : `Debt-to-equity of ${debtToEquity.toFixed(2)}×.` });

  // Profitability buffer (15 pts): margin cushion above zero.
  const marginPoints = period.income.netMarginPct >= 10 ? 15 : period.income.netMarginPct >= 3 ? 9 : period.income.netMarginPct > 0 ? 4 : 0;
  components.push({ label: 'Margin buffer', points: marginPoints, maxPoints: 15, detail: `Net margin of ${period.income.netMarginPct.toFixed(1)}%.` });

  // Cash flow strength (15 pts)
  const cfPoints = period.cashFlow.operatingCashFlow > 0 && period.cashFlow.freeCashFlow > 0 ? 15 : period.cashFlow.operatingCashFlow > 0 ? 9 : 0;
  components.push({ label: 'Cash flow strength', points: cfPoints, maxPoints: 15, detail: `Operating cash flow ${period.cashFlow.operatingCashFlow >= 0 ? 'positive' : 'negative'}, free cash flow ${period.cashFlow.freeCashFlow >= 0 ? 'positive' : 'negative'}.` });

  // Interest coverage / debt service (10 pts)
  const coverage = period.solvencyRatios.find((r) => r.key === 'interestCoverage')?.value ?? null;
  const coveragePoints = coverage === null ? 5 : coverage >= 5 ? 10 : coverage >= 2 ? 6 : 0;
  components.push({ label: 'Debt service capacity', points: coveragePoints, maxPoints: 10, detail: coverage === null ? 'No interest expense recorded.' : `Interest coverage of ${coverage.toFixed(1)}×.` });

  // Concentration (10 pts)
  const concentrationPoints = concentrationPct === null ? 5 : concentrationPct < 30 ? 10 : concentrationPct < 50 ? 6 : 0;
  components.push({ label: 'Revenue concentration', points: concentrationPoints, maxPoints: 10, detail: concentrationPct === null ? 'No concentration data available.' : `Top entity represents ${concentrationPct.toFixed(1)}% of revenue.` });

  const score = components.reduce((s, c) => s + c.points, 0);
  return { score, components };
}
