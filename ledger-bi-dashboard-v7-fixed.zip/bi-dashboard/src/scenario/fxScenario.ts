export interface FxScenarioResult {
  baseAmountLocal: number;
  fxRateChangePct: number;
  scenarioAmountLocal: number;
  impactLocal: number;
}

/**
 * Illustrative only (stated plainly in the UI) — the app does not track
 * real multi-currency exposure (which currency each transaction is in,
 * hedges, etc.), so this cannot be a full FX exposure model. It shows
 * the mechanical effect of a rate change on a stated foreign-currency
 * exposure amount, nothing more.
 */
export function runFxScenario(exposureAmountForeign: number, baseFxRate: number, fxRateChangePct: number): FxScenarioResult {
  const baseAmountLocal = exposureAmountForeign * baseFxRate;
  const scenarioRate = baseFxRate * (1 + fxRateChangePct / 100);
  const scenarioAmountLocal = exposureAmountForeign * scenarioRate;
  return { baseAmountLocal, fxRateChangePct, scenarioAmountLocal, impactLocal: scenarioAmountLocal - baseAmountLocal };
}
