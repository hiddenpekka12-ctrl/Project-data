import { DecisionTriggerRule, TriggerEvalContext } from './types';

/** A small starting set of configurable IF/THEN triggers (Section 37).
 * Each `evaluate` function is plain, inspectable logic — no hidden
 * decision-making. Users see the condition text and the logic together. */
export const DEFAULT_DECISION_TRIGGERS: DecisionTriggerRule[] = [
  {
    id: 'trigger-1',
    description: 'Revenue decline combined with a cash shortfall',
    conditionText: 'Revenue decline > 15% AND Cash < threshold',
    actionText: 'Review cost reduction and liquidity plan.',
    evaluate: (ctx: TriggerEvalContext) => ctx.revenueChangePct < -15 && ctx.cash < ctx.cashThreshold,
  },
  {
    id: 'trigger-2',
    description: 'High customer concentration',
    conditionText: 'Customer concentration > 60%',
    actionText: 'Evaluate supplier/customer diversification.',
    evaluate: (ctx: TriggerEvalContext) => (ctx.customerConcentrationPct ?? 0) > 60,
  },
  {
    id: 'trigger-3',
    description: 'Weak interest coverage under stress',
    conditionText: 'Interest coverage < 1.5x',
    actionText: 'Review debt structure and refinancing options.',
    evaluate: (ctx: TriggerEvalContext) => ctx.interestCoverage !== null && ctx.interestCoverage < 1.5,
  },
];

export function evaluateTriggers(rules: DecisionTriggerRule[], ctx: TriggerEvalContext): DecisionTriggerRule[] {
  return rules.filter((r) => r.evaluate(ctx));
}
