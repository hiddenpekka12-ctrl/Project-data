import { PeriodModel } from '../finance/buildFinanceModel';
import { DecisionThresholdSettings, ThresholdBreach } from './types';

export const DEFAULT_DECISION_THRESHOLDS: DecisionThresholdSettings = {
  minCash: 0,
  minCurrentRatio: 1.2,
  minInterestCoverage: 2,
  maxDebtToEquity: 2,
  minGrossMarginPct: 20,
  maxCustomerConcentrationPct: 50,
};

export function detectThresholdBreaches(base: PeriodModel, scenario: PeriodModel, settings: DecisionThresholdSettings, concentrationPct: number | null): ThresholdBreach[] {
  const breaches: ThresholdBreach[] = [];

  const push = (metric: string, baseValue: number | null, scenarioValue: number | null, threshold: number, direction: 'min' | 'max') => {
    if (scenarioValue === null || baseValue === null) return;
    const breached = direction === 'min' ? scenarioValue < threshold : scenarioValue > threshold;
    const gap = direction === 'min' ? threshold - scenarioValue : scenarioValue - threshold;
    breaches.push({ metric, baseValue, scenarioValue, threshold, gap, breached });
  };

  push('Cash', base.balanceSheet.cash, scenario.balanceSheet.cash, settings.minCash, 'min');
  push('Current Ratio', base.liquidityRatios.find((r) => r.key === 'currentRatio')?.value ?? null, scenario.liquidityRatios.find((r) => r.key === 'currentRatio')?.value ?? null, settings.minCurrentRatio, 'min');
  push('Interest Coverage', base.solvencyRatios.find((r) => r.key === 'interestCoverage')?.value ?? null, scenario.solvencyRatios.find((r) => r.key === 'interestCoverage')?.value ?? null, settings.minInterestCoverage, 'min');
  push('Debt-to-Equity', base.solvencyRatios.find((r) => r.key === 'debtToEquity')?.value ?? null, scenario.solvencyRatios.find((r) => r.key === 'debtToEquity')?.value ?? null, settings.maxDebtToEquity, 'max');
  push('Gross Margin %', base.income.grossMarginPct, scenario.income.grossMarginPct, settings.minGrossMarginPct, 'min');
  if (concentrationPct !== null) push('Customer Concentration %', concentrationPct, concentrationPct, settings.maxCustomerConcentrationPct, 'max');

  return breaches;
}
