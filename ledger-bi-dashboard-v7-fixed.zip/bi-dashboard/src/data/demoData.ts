import { AlertItem, FinancialPeriod, Organization, RiskFactor } from '../types';

/**
 * DEMO DATA
 * ---------
 * Everything in this file is illustrative, not real financial data.
 * It exists so V1 has something realistic to render and calculate against.
 * A future V2 (CSV/Excel upload) replaces this module's role, not its shape —
 * components should keep consuming FinancialPeriod[] regardless of source.
 */

export const demoOrg: Organization = {
  id: 'org-demo',
  name: 'Personal Holdings (Demo)',
  currency: 'USD',
  fiscalYearStartMonth: 1,
};

// Twelve trailing months, oldest first. Two most recent are used for
// current vs previous-period comparisons on the KPI cards.
export const demoPeriods: FinancialPeriod[] = [
  { id: 'p-01', orgId: 'org-demo', label: 'Oct 2025', periodStart: '2025-10-01', periodEnd: '2025-10-31', revenue: 48200, expenses: 34500, cash: 61200, assets: 210000, liabilities: 92000, debt: 58000 },
  { id: 'p-02', orgId: 'org-demo', label: 'Nov 2025', periodStart: '2025-11-01', periodEnd: '2025-11-30', revenue: 49800, expenses: 35100, cash: 64800, assets: 213500, liabilities: 91200, debt: 57200 },
  { id: 'p-03', orgId: 'org-demo', label: 'Dec 2025', periodStart: '2025-12-01', periodEnd: '2025-12-31', revenue: 52600, expenses: 37800, cash: 67300, assets: 217800, liabilities: 90800, debt: 56300 },
  { id: 'p-04', orgId: 'org-demo', label: 'Jan 2026', periodStart: '2026-01-01', periodEnd: '2026-01-31', revenue: 47300, expenses: 36200, cash: 63100, assets: 219200, liabilities: 90100, debt: 55600 },
  { id: 'p-05', orgId: 'org-demo', label: 'Feb 2026', periodStart: '2026-02-01', periodEnd: '2026-02-28', revenue: 49100, expenses: 35700, cash: 65900, assets: 221000, liabilities: 89400, debt: 54700 },
  { id: 'p-06', orgId: 'org-demo', label: 'Mar 2026', periodStart: '2026-03-01', periodEnd: '2026-03-31', revenue: 51500, expenses: 37200, cash: 68200, assets: 224100, liabilities: 88700, debt: 53900 },
  { id: 'p-07', orgId: 'org-demo', label: 'Apr 2026', periodStart: '2026-04-01', periodEnd: '2026-04-30', revenue: 53900, expenses: 38600, cash: 70500, assets: 227600, liabilities: 88000, debt: 53000 },
  { id: 'p-08', orgId: 'org-demo', label: 'May 2026', periodStart: '2026-05-01', periodEnd: '2026-05-31', revenue: 55200, expenses: 39400, cash: 72100, assets: 231200, liabilities: 87300, debt: 52100 },
  { id: 'p-09', orgId: 'org-demo', label: 'Jun 2026', periodStart: '2026-06-01', periodEnd: '2026-06-30', revenue: 57800, expenses: 41200, cash: 73400, assets: 235000, liabilities: 86600, debt: 51200 },
  { id: 'p-10', orgId: 'org-demo', label: 'Jul 2026', periodStart: '2026-07-01', periodEnd: '2026-07-31', revenue: 60100, expenses: 43500, cash: 74800, assets: 239100, liabilities: 85900, debt: 50300 },
  { id: 'p-11', orgId: 'org-demo', label: 'Aug 2026', periodStart: '2026-08-01', periodEnd: '2026-08-31', revenue: 62400, expenses: 46800, cash: 71600, assets: 243500, liabilities: 85200, debt: 49400 },
  { id: 'p-12', orgId: 'org-demo', label: 'Sep 2026', periodStart: '2026-09-01', periodEnd: '2026-09-30', revenue: 67400, expenses: 52400, cash: 66900, assets: 248200, liabilities: 84600, debt: 48500 },
];

export const demoRiskFactors: RiskFactor[] = [
  { id: 'r-fin', category: 'financial', label: 'Financial risk', score: 38, level: 'moderate', note: 'Expense growth is outpacing revenue growth this period.' },
  { id: 'r-ops', category: 'operational', label: 'Operational risk', score: 22, level: 'low', note: 'No demo disruptions logged this period.' },
  { id: 'r-mkt', category: 'market', label: 'Market risk', score: 45, level: 'moderate', note: 'Demo exposure to a single revenue channel.' },
  { id: 'r-strat', category: 'strategic', label: 'Strategic risk', score: 30, level: 'moderate', note: 'Demo scenario: one growth initiative in progress.' },
];

export const demoAlerts: AlertItem[] = [
  { id: 'a-1', severity: 'warning', message: 'Expense growth is above target this month.', createdAt: '2026-09-05T09:00:00Z' },
  { id: 'a-2', severity: 'info', message: 'Cash position needs monitoring after a two-month dip.', createdAt: '2026-09-05T09:00:00Z' },
  { id: 'a-3', severity: 'positive', message: 'Revenue target was achieved for the third straight month.', createdAt: '2026-09-05T09:00:00Z' },
];
