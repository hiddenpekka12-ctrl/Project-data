import { Row } from '../types/analytics';

/**
 * DEMO DATA — NOT REAL COMPANY DATA
 * ABC Manufacturing Ltd: 24 months of internally consistent financials,
 * generated deterministically (no randomness) so results are reproducible.
 * Equity is set as the balancing residual (Total Assets − Total
 * Liabilities) each month, which is what makes it a legitimate value
 * rather than an assumption — equity IS defined as that residual.
 */
export function buildAbcManufacturingRows(): Row[] {
  const rows: Row[] = [];
  const months = 24;
  let cash = 180000;
  let receivables = 90000;
  let inventory = 120000;
  let fixedAssets = 500000;
  let currentLiabilities = 95000;
  let longTermDebt = 220000;

  for (let m = 0; m < months; m++) {
    const seasonality = 1 + 0.08 * Math.sin((m / 12) * 2 * Math.PI);
    const growth = 1 + 0.012 * m; // gradual growth trend
    const revenue = Math.round(150000 * seasonality * growth);
    const cogs = Math.round(revenue * (0.56 + 0.02 * Math.sin(m / 5)));
    const operatingExpenses = Math.round(revenue * (0.22 + 0.001 * m));
    const depreciation = 8000;
    const interest = Math.round(longTermDebt * (0.09 / 12));
    const otherIncome = 1500;
    const otherExpenses = 800;

    const grossProfit = revenue - cogs;
    const ebitda = grossProfit - operatingExpenses;
    const ebit = ebitda - depreciation;
    const pbt = ebit - interest + otherIncome - otherExpenses;
    const tax = Math.max(0, Math.round(pbt * 0.25));
    const netProfit = pbt - tax;

    // Evolve balance sheet stocks in a plausible, connected way.
    receivables = Math.round(receivables + revenue * 0.02 - revenue * 0.018);
    inventory = Math.round(inventory + cogs * 0.015 - cogs * 0.013);
    currentLiabilities = Math.round(currentLiabilities + cogs * 0.01 - cogs * 0.009);
    fixedAssets = Math.round(fixedAssets - depreciation + (m % 6 === 0 ? 15000 : 0)); // periodic capex
    longTermDebt = Math.round(longTermDebt - 1500); // gradual repayment
    cash = Math.round(cash + netProfit + depreciation - (receivables * 0.001) - (inventory * 0.001) - 1500);

    const totalAssets = cash + receivables + inventory + fixedAssets;
    const totalLiabilities = currentLiabilities + longTermDebt;
    const equity = totalAssets - totalLiabilities; // balancing residual, by construction

    const date = new Date(Date.UTC(2024, m, 1));

    rows.push({
      period: date.toISOString().slice(0, 10),
      revenue,
      cogs,
      operating_expenses: operatingExpenses,
      depreciation,
      interest,
      tax,
      other_income: otherIncome,
      other_expenses: otherExpenses,
      cash,
      receivables,
      inventory,
      fixed_assets: fixedAssets,
      current_liabilities: currentLiabilities,
      long_term_debt: longTermDebt,
      equity,
    });
  }

  return rows;
}

export const ABC_MANUFACTURING_NAME = 'ABC Manufacturing Ltd. — 24-month demo';
