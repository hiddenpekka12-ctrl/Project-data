import { FinancialInsight, IncomeStatementLine } from './types';

let counter = 0;
function id(prefix: string): string {
  counter += 1;
  return `${prefix}-${counter}`;
}

export function generateFinancialInsights(current: IncomeStatementLine, previous: IncomeStatementLine | null, currentLabel: string, previousLabel: string): FinancialInsight[] {
  counter = 0;
  const insights: FinancialInsight[] = [];
  if (!previous) return insights;

  const revGrowth = previous.revenue === 0 ? null : ((current.revenue - previous.revenue) / previous.revenue) * 100;
  const opexGrowth = previous.operatingExpenses === 0 ? null : ((current.operatingExpenses - previous.operatingExpenses) / previous.operatingExpenses) * 100;
  const cogsGrowth = previous.cogs === 0 ? null : ((current.cogs - previous.cogs) / previous.cogs) * 100;

  if (revGrowth !== null && opexGrowth !== null && revGrowth > 0 && opexGrowth > revGrowth) {
    insights.push({
      id: id('opex-outpace'),
      finding: `Revenue increased ${revGrowth.toFixed(1)}% from ${previousLabel} to ${currentLabel}, but operating expenses increased ${opexGrowth.toFixed(1)}%.`,
      supportingData: `Operating margin moved from ${previous.ebitMarginPct.toFixed(1)}% to ${current.ebitMarginPct.toFixed(1)}%.`,
      managementImplication: 'Revenue growth is not translating proportionally into operating profit.',
      suggestedInvestigation: 'Identify which expense categories are driving the increase using the Cost Analyser.',
    });
  }

  if (revGrowth !== null && cogsGrowth !== null && revGrowth > 0 && cogsGrowth > revGrowth) {
    insights.push({
      id: id('cogs-outpace'),
      finding: `Revenue grew ${revGrowth.toFixed(1)}% while COGS grew ${cogsGrowth.toFixed(1)}%, faster than revenue.`,
      supportingData: `Gross margin moved from ${previous.grossMarginPct.toFixed(1)}% to ${current.grossMarginPct.toFixed(1)}%.`,
      managementImplication: 'Unit economics may be weakening — each additional sale is contributing less gross profit than before.',
      suggestedInvestigation: 'Check for input cost inflation, supplier changes, or discounting behind the COGS increase.',
    });
  }

  if (current.netMarginPct < previous.netMarginPct && current.revenue >= previous.revenue) {
    insights.push({
      id: id('margin-despite-growth'),
      finding: `Net margin fell from ${previous.netMarginPct.toFixed(1)}% to ${current.netMarginPct.toFixed(1)}% even though revenue did not decline.`,
      supportingData: `Net profit: ${previous.netProfit.toFixed(0)} → ${current.netProfit.toFixed(0)}.`,
      managementImplication: 'Cost structure, interest, or tax burden is absorbing a larger share of revenue than before.',
      suggestedInvestigation: 'Use the Profit Diagnostic to see exactly which line item is responsible.',
    });
  }

  if (current.interest > previous.interest * 1.1 && previous.interest > 0) {
    insights.push({
      id: id('rising-interest'),
      finding: `Interest expense rose from ${previous.interest.toFixed(0)} to ${current.interest.toFixed(0)}.`,
      supportingData: `Profit before tax: ${previous.profitBeforeTax.toFixed(0)} → ${current.profitBeforeTax.toFixed(0)}.`,
      managementImplication: 'Rising debt service costs are consuming a larger share of operating profit before it reaches shareholders.',
      suggestedInvestigation: 'Check the Solvency ratios for whether leverage has increased.',
    });
  }

  return insights;
}
