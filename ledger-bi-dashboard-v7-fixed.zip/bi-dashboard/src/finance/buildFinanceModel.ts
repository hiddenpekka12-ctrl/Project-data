import { Row } from '../types/analytics';
import { AccountMapping, BalanceSheetLine, CashFlowLine, FinanceMetricsSnapshot, FinanceSettings, HealthScoreResult, IncomeStatementLine, PeriodAggregate, RatioResult, ValidationIssue, WorkingCapitalLine } from './types';
import { buildPeriodAggregates } from './periodizer';
import { buildIncomeStatement, buildBalanceSheet } from './statements';
import { buildCashFlow } from './cashFlow';
import { buildLiquidityRatios, buildProfitabilityRatios, buildSolvencyRatios, buildEfficiencyRatios } from './ratios';
import { buildWorkingCapital } from './workingCapital';
import { buildDuPont } from './dupont';
import { computeHealthScore } from './healthScore';
import { detectRedFlags, RedFlagContext } from './redFlags';
import { generateFinancialInsights } from './insights';
import { validateFinancialData } from './validation';
import { requiredCategoriesPresent } from './accountMapping';

export interface PeriodModel {
  label: string;
  income: IncomeStatementLine;
  balanceSheet: BalanceSheetLine;
  cashFlow: CashFlowLine;
  workingCapital: WorkingCapitalLine;
  liquidityRatios: RatioResult[];
  profitabilityRatios: RatioResult[];
  solvencyRatios: RatioResult[];
  efficiencyRatios: RatioResult[];
  dupont: ReturnType<typeof buildDuPont>;
}

export interface FinanceModel {
  hasRevenue: boolean;
  hasBalanceSheet: boolean;
  missingRequirement: string | null;
  periods: PeriodModel[];
  validation: ValidationIssue[];
  redFlags: ReturnType<typeof detectRedFlags>;
  insights: ReturnType<typeof generateFinancialInsights>;
  health: HealthScoreResult | null;
  snapshot: FinanceMetricsSnapshot | null;
}

const REQUIRED_FOR_INCOME = ['revenue'] as const;
const REQUIRED_FOR_BALANCE = ['cash', 'equity'] as const;

export function buildFinanceModel(rows: Row[], mapping: AccountMapping, settings: FinanceSettings): FinanceModel {
  const revenueCheck = requiredCategoriesPresent(mapping, [...REQUIRED_FOR_INCOME]);
  if (!settings.dateColumn) {
    return {
      hasRevenue: false,
      hasBalanceSheet: false,
      missingRequirement: 'No date column selected. Choose a date column in Finance Settings to build periods.',
      periods: [],
      validation: [],
      redFlags: [],
      insights: [],
      snapshot: null,
      health: null,
    };
  }
  if (!revenueCheck.ok) {
    return {
      hasRevenue: false,
      hasBalanceSheet: false,
      missingRequirement: 'Insufficient financial data to perform this analysis. Map a column to "Revenue" in Account Mapping to get started.',
      periods: [],
      validation: [],
      redFlags: [],
      insights: [],
      snapshot: null,
      health: null,
    };
  }

  const aggregates: PeriodAggregate[] = buildPeriodAggregates(rows, mapping, settings.dateColumn, settings.granularity);
  if (aggregates.length === 0) {
    return {
      hasRevenue: false,
      hasBalanceSheet: false,
      missingRequirement: 'No rows had a parseable date in the selected date column.',
      periods: [],
      validation: [],
      redFlags: [],
      insights: [],
      snapshot: null,
      health: null,
    };
  }

  const balanceCheck = requiredCategoriesPresent(mapping, [...REQUIRED_FOR_BALANCE]);

  const balanceSheets = aggregates.map((_, i) => buildBalanceSheet(aggregates, i));
  const incomeStatements = aggregates.map((_, i) => buildIncomeStatement(aggregates, i));

  const periods: PeriodModel[] = aggregates.map((agg, i) => {
    const income = incomeStatements[i];
    const bs = balanceSheets[i];
    const prevBs = i > 0 ? balanceSheets[i - 1] : null;
    const cashFlow = buildCashFlow(income, bs, prevBs);
    const workingCapital = buildWorkingCapital(income, bs, prevBs, settings.granularity);
    return {
      label: agg.label,
      income,
      balanceSheet: bs,
      cashFlow,
      workingCapital,
      liquidityRatios: buildLiquidityRatios(bs),
      profitabilityRatios: buildProfitabilityRatios(income, bs, prevBs),
      solvencyRatios: buildSolvencyRatios(income, bs),
      efficiencyRatios: buildEfficiencyRatios(income, bs, prevBs),
      dupont: buildDuPont(income, bs, prevBs),
    };
  });

  const last = periods[periods.length - 1];
  const prev = periods.length > 1 ? periods[periods.length - 2] : null;

  const validation = validateFinancialData(aggregates, mapping, balanceSheets);

  const redFlagCtx: RedFlagContext = {
    current: { income: last.income, bs: last.balanceSheet, cashFlow: last.cashFlow, wc: last.workingCapital, label: last.label },
    previous: prev ? { income: prev.income, bs: prev.balanceSheet, cashFlow: prev.cashFlow, wc: prev.workingCapital, label: prev.label } : null,
  };
  const redFlags = balanceCheck.ok ? detectRedFlags(redFlagCtx) : [];

  const insights = generateFinancialInsights(last.income, prev?.income ?? null, last.label, prev?.label ?? '');

  const revenueGrowthPct = prev && prev.income.revenue !== 0 ? ((last.income.revenue - prev.income.revenue) / prev.income.revenue) * 100 : null;
  const health = balanceCheck.ok ? computeHealthScore(last.income, last.balanceSheet, last.cashFlow, revenueGrowthPct) : null;

  const snapshot: FinanceMetricsSnapshot | null = balanceCheck.ok
    ? {
        currentRatio: last.liquidityRatios.find((r) => r.key === 'currentRatio')?.value ?? null,
        debtToEquity: last.solvencyRatios.find((r) => r.key === 'debtToEquity')?.value ?? null,
        interestCoverage: last.solvencyRatios.find((r) => r.key === 'interestCoverage')?.value ?? null,
        operatingCashFlow: last.cashFlow.operatingCashFlow,
        netMargin: last.income.netMarginPct,
        revenueVolatilityPct: computeRevenueVolatility(periods),
        workingCapital: last.workingCapital.workingCapital,
        healthScore: health?.score ?? null,
      }
    : null;

  return {
    hasRevenue: true,
    hasBalanceSheet: balanceCheck.ok,
    missingRequirement: balanceCheck.ok ? null : `Insufficient financial data for balance-sheet-dependent analysis (missing: ${balanceCheck.missing.join(', ')}). Income statement analysis is still available below.`,
    periods,
    validation,
    redFlags,
    insights,
    health,
    snapshot,
  };
}

function computeRevenueVolatility(periods: PeriodModel[]): number | null {
  if (periods.length < 3) return null;
  const values = periods.map((p) => p.income.revenue);
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  if (mean === 0) return null;
  const variance = values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length;
  return (Math.sqrt(variance) / mean) * 100;
}
