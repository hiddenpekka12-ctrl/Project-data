import { IncomeStatementLine, ProfitDiagnosticResult } from './types';

/**
 * Decomposes ΔNet Profit between two periods into named effects. The
 * "other" bucket is a residual (interest, tax, D&A, other income/expense
 * combined) rather than fabricating a split the mapping doesn't support —
 * the four effects always sum exactly to the actual profit change.
 */
export function diagnoseProfitChange(previous: IncomeStatementLine, current: IncomeStatementLine, fromLabel: string, toLabel: string): ProfitDiagnosticResult {
  const revenueEffect = current.revenue - previous.revenue;
  const cogsEffect = -(current.cogs - previous.cogs);
  const opexEffect = -(current.operatingExpenses - previous.operatingExpenses);
  const actualChange = current.netProfit - previous.netProfit;
  const otherEffect = actualChange - (revenueEffect + cogsEffect + opexEffect);

  return {
    fromLabel,
    toLabel,
    startingProfit: previous.netProfit,
    endingProfit: current.netProfit,
    revenueEffect,
    cogsEffect,
    opexEffect,
    otherEffect,
  };
}
