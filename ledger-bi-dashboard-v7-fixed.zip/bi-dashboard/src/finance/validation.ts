import { AccountMapping, BalanceSheetLine, PeriodAggregate, ValidationIssue } from './types';

export function validateFinancialData(periods: PeriodAggregate[], mapping: AccountMapping, balanceSheets: BalanceSheetLine[]): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  if (periods.length === 0) {
    issues.push({ severity: 'error', label: 'No periods found', detail: 'No rows had a parseable date in the selected date column.' });
    return issues;
  }

  // Negative revenue / negative core expenses
  periods.forEach((p) => {
    if (p.values.revenue < 0) {
      issues.push({ severity: 'warning', label: 'Negative revenue', detail: `${p.label}: revenue is ${p.values.revenue.toFixed(2)}. This is unusual — confirm whether this reflects refunds/credits or a data error.` });
    }
    if (p.values.cogs < 0 || p.values.operatingExpenses < 0) {
      issues.push({ severity: 'warning', label: 'Negative expense value', detail: `${p.label}: COGS or Operating Expenses is negative. Confirm the sign convention used in your source data.` });
    }
  });

  // Missing periods (gaps in a monthly sequence)
  for (let i = 1; i < periods.length; i++) {
    const prev = new Date(periods[i - 1].periodStart);
    const curr = new Date(periods[i].periodStart);
    const monthGap = (curr.getUTCFullYear() - prev.getUTCFullYear()) * 12 + (curr.getUTCMonth() - prev.getUTCMonth());
    if (monthGap > 1) {
      issues.push({ severity: 'warning', label: 'Missing periods', detail: `Gap detected between ${periods[i - 1].label} and ${periods[i].label} — ${monthGap - 1} period(s) appear to be missing.` });
    }
  }

  // Balance sheet mismatches
  balanceSheets.forEach((bs, i) => {
    if (!bs.balances) {
      issues.push({
        severity: 'error',
        label: 'BALANCE SHEET ERROR',
        detail: `${periods[i].label}: Assets (${bs.totalAssets.toFixed(2)}) do not equal Liabilities + Equity (${(bs.totalLiabilities + bs.equity).toFixed(2)}). Difference: ${bs.imbalanceAmount.toFixed(2)}. This has not been auto-corrected — check your account mapping and source data.`,
      });
    }
  });

  // Unmapped-but-likely-relevant check
  const mappedCategories = new Set(Object.values(mapping));
  if (!mappedCategories.has('revenue')) {
    issues.push({ severity: 'error', label: 'No revenue column mapped', detail: 'Map a column to "Revenue" in Account Mapping before running Finance analysis.' });
  }

  return issues;
}
