import { AccountMapping, FinanceCategory } from './types';

const KEYWORD_MAP: [FinanceCategory, string[]][] = [
  ['revenue', ['revenue', 'sales', 'income_total', 'turnover']],
  ['cogs', ['cogs', 'cost_of_goods', 'cost of goods']],
  ['operatingExpenses', ['opex', 'operating_expense', 'operating expense', 'sga', 'expenses']],
  ['depreciation', ['depreciation', 'amortization', 'amortisation', 'd&a']],
  ['interest', ['interest']],
  ['tax', ['tax']],
  ['cash', ['cash']],
  ['receivables', ['receivable', 'debtors', 'ar_']],
  ['inventory', ['inventory', 'stock_on_hand']],
  ['fixedAssets', ['fixed_asset', 'fixed asset', 'ppe', 'property_plant']],
  ['currentLiabilities', ['current_liabilit', 'current liabilit', 'payable', 'creditors']],
  ['longTermDebt', ['long_term_debt', 'long-term debt', 'lt_debt', 'loan']],
  ['equity', ['equity', 'shareholder', 'retained_earning']],
  ['otherIncome', ['other_income', 'other income']],
  ['otherExpenses', ['other_expense', 'other expense']],
];

/** Auto-suggests a mapping by matching column names against finance
 * keywords. Never guesses a category it isn't reasonably confident about —
 * anything unmatched comes back 'unmapped' rather than a wrong guess. */
export function suggestAccountMapping(columns: string[]): AccountMapping {
  const mapping: AccountMapping = {};
  const used = new Set<FinanceCategory>();

  columns.forEach((col) => {
    const lower = col.toLowerCase().replace(/\s+/g, '_');
    let match: FinanceCategory = 'unmapped';
    for (const [category, keywords] of KEYWORD_MAP) {
      if (used.has(category)) continue; // one column per category to avoid double-counting
      if (keywords.some((k) => lower.includes(k.replace(/\s+/g, '_')))) {
        match = category;
        break;
      }
    }
    mapping[col] = match;
    if (match !== 'unmapped') used.add(match);
  });

  return mapping;
}

export const CATEGORY_LABELS: Record<FinanceCategory, string> = {
  revenue: 'Revenue',
  cogs: 'COGS',
  operatingExpenses: 'Operating Expenses',
  depreciation: 'Depreciation & Amortization',
  interest: 'Interest',
  tax: 'Tax',
  cash: 'Cash',
  receivables: 'Receivables',
  inventory: 'Inventory',
  fixedAssets: 'Fixed Assets',
  currentLiabilities: 'Current Liabilities',
  longTermDebt: 'Long-term Debt',
  equity: 'Equity',
  otherIncome: 'Other Income',
  otherExpenses: 'Other Expenses',
  unmapped: 'Not used in Finance',
};

export function requiredCategoriesPresent(mapping: AccountMapping, required: FinanceCategory[]): { ok: boolean; missing: FinanceCategory[] } {
  const mapped = new Set(Object.values(mapping));
  const missing = required.filter((r) => !mapped.has(r));
  return { ok: missing.length === 0, missing };
}
