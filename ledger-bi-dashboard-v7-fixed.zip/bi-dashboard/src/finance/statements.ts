import { BalanceSheetLine, IncomeStatementLine, PeriodAggregate } from './types';

const BALANCE_TOLERANCE_PCT = 0.5; // percent of total assets

function pct(numerator: number, denominator: number): number {
  return denominator === 0 ? 0 : (numerator / denominator) * 100;
}

export function buildIncomeStatement(periods: PeriodAggregate[], index: number): IncomeStatementLine {
  const p = periods[index].values;
  const revenue = p.revenue;
  const cogs = p.cogs;
  const grossProfit = revenue - cogs;
  const operatingExpenses = p.operatingExpenses;
  const ebitda = grossProfit - operatingExpenses;
  const depreciation = p.depreciation;
  const ebit = ebitda - depreciation;
  const interest = p.interest;
  const otherIncome = p.otherIncome;
  const otherExpenses = p.otherExpenses;
  const profitBeforeTax = ebit - interest + otherIncome - otherExpenses;
  const tax = p.tax;
  const netProfit = profitBeforeTax - tax;

  const prevPeriod = periods[index - 1];
  const yoyPeriod = periods[index - 12]; // only meaningful for monthly granularity

  const momRevenueGrowthPct = prevPeriod ? growthPct(revenue, prevPeriod.values.revenue) : null;
  const yoyRevenueGrowthPct = yoyPeriod ? growthPct(revenue, yoyPeriod.values.revenue) : null;
  const momNetProfitGrowthPct = prevPeriod ? growthPct(netProfit, netProfitOf(prevPeriod)) : null;
  const yoyNetProfitGrowthPct = yoyPeriod ? growthPct(netProfit, netProfitOf(yoyPeriod)) : null;

  return {
    revenue,
    cogs,
    grossProfit,
    grossMarginPct: pct(grossProfit, revenue),
    operatingExpenses,
    ebitda,
    ebitdaMarginPct: pct(ebitda, revenue),
    depreciation,
    ebit,
    ebitMarginPct: pct(ebit, revenue),
    interest,
    otherIncome,
    otherExpenses,
    profitBeforeTax,
    tax,
    netProfit,
    netMarginPct: pct(netProfit, revenue),
    momRevenueGrowthPct,
    yoyRevenueGrowthPct,
    momNetProfitGrowthPct,
    yoyNetProfitGrowthPct,
  };
}

function netProfitOf(period: PeriodAggregate): number {
  const v = period.values;
  const grossProfit = v.revenue - v.cogs;
  const ebitda = grossProfit - v.operatingExpenses;
  const ebit = ebitda - v.depreciation;
  const pbt = ebit - v.interest + v.otherIncome - v.otherExpenses;
  return pbt - v.tax;
}

function growthPct(current: number, previous: number): number | null {
  if (previous === 0) return null;
  return ((current - previous) / Math.abs(previous)) * 100;
}

/** Balance sheet is built at the level the 15-category mapping actually
 * supports: Current Liabilities and Equity are shown as single combined
 * lines rather than fabricating a payables/short-term-debt or share-
 * capital/retained-earnings split the mapping doesn't collect. */
export function buildBalanceSheet(periods: PeriodAggregate[], index: number): BalanceSheetLine {
  const v = periods[index].values;
  const currentAssets = v.cash + v.receivables + v.inventory;
  const nonCurrentAssets = v.fixedAssets;
  const totalAssets = currentAssets + nonCurrentAssets;
  const currentLiabilities = v.currentLiabilities;
  const nonCurrentLiabilities = v.longTermDebt;
  const totalLiabilities = currentLiabilities + nonCurrentLiabilities;
  const equity = v.equity;

  const imbalanceAmount = totalAssets - (totalLiabilities + equity);
  const tolerance = Math.abs(totalAssets) * (BALANCE_TOLERANCE_PCT / 100);
  const balances = Math.abs(imbalanceAmount) <= Math.max(tolerance, 0.01);

  return {
    cash: v.cash,
    receivables: v.receivables,
    inventory: v.inventory,
    currentAssets,
    fixedAssets: v.fixedAssets,
    nonCurrentAssets,
    totalAssets,
    currentLiabilities,
    longTermDebt: v.longTermDebt,
    nonCurrentLiabilities,
    totalLiabilities,
    equity,
    balances,
    imbalanceAmount,
  };
}
