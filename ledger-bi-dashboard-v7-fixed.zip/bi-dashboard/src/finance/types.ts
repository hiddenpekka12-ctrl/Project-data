/**
 * FINANCE ENGINE TYPES
 * --------------------
 * Mapping matches the 15-category list from the spec exactly (Revenue,
 * COGS, Operating Expenses, Depreciation, Interest, Tax, Cash,
 * Receivables, Inventory, Fixed Assets, Current Liabilities, Long-term
 * Debt, Equity, Other Income, Other Expenses). Everything downstream
 * (statements, ratios, working capital) is built from these 15 buckets —
 * where the full balance-sheet breakdown in the spec calls for more
 * granularity than this mapping collects (e.g. payables vs short-term
 * debt), the combined category is used and clearly labeled as such.
 */

export type FinanceCategory =
  | 'revenue'
  | 'cogs'
  | 'operatingExpenses'
  | 'depreciation'
  | 'interest'
  | 'tax'
  | 'cash'
  | 'receivables'
  | 'inventory'
  | 'fixedAssets'
  | 'currentLiabilities'
  | 'longTermDebt'
  | 'equity'
  | 'otherIncome'
  | 'otherExpenses'
  | 'unmapped';

/** Flow categories are summed within a period (P&L-style). Stock
 * categories are point-in-time balances, so they take the last value
 * observed within a period rather than being summed. */
export const FLOW_CATEGORIES: FinanceCategory[] = [
  'revenue',
  'cogs',
  'operatingExpenses',
  'depreciation',
  'interest',
  'tax',
  'otherIncome',
  'otherExpenses',
];
export const STOCK_CATEGORIES: FinanceCategory[] = [
  'cash',
  'receivables',
  'inventory',
  'fixedAssets',
  'currentLiabilities',
  'longTermDebt',
  'equity',
];

export type AccountMapping = Record<string, FinanceCategory>; // column name -> category

export type PeriodGranularity = 'month' | 'quarter' | 'year';

export interface PeriodAggregate {
  label: string; // e.g. "2026-07"
  periodStart: string;
  values: Record<FinanceCategory, number>;
}

export interface FinanceSettings {
  currency: string;
  exchangeRateSource: string | null;
  exchangeRateDate: string | null;
  granularity: PeriodGranularity;
  dateColumn: string | null;
}

export interface IncomeStatementLine {
  revenue: number;
  cogs: number;
  grossProfit: number;
  grossMarginPct: number;
  operatingExpenses: number;
  ebitda: number;
  ebitdaMarginPct: number;
  depreciation: number;
  ebit: number;
  ebitMarginPct: number;
  interest: number;
  otherIncome: number;
  otherExpenses: number;
  profitBeforeTax: number;
  tax: number;
  netProfit: number;
  netMarginPct: number;
  yoyRevenueGrowthPct: number | null;
  momRevenueGrowthPct: number | null;
  yoyNetProfitGrowthPct: number | null;
  momNetProfitGrowthPct: number | null;
}

export interface BalanceSheetLine {
  cash: number;
  receivables: number;
  inventory: number;
  currentAssets: number;
  fixedAssets: number;
  nonCurrentAssets: number;
  totalAssets: number;
  currentLiabilities: number;
  longTermDebt: number;
  nonCurrentLiabilities: number;
  totalLiabilities: number;
  equity: number;
  balances: boolean;
  imbalanceAmount: number;
}

export interface CashFlowLine {
  netProfit: number;
  depreciationAddBack: number;
  changeInReceivables: number;
  changeInInventory: number;
  changeInCurrentLiabilities: number;
  operatingCashFlow: number;
  changeInFixedAssets: number;
  freeCashFlow: number;
  actualNetChangeInCash: number;
  impliedInvestingPlusFinancing: number;
}

export type RatioBand = 'strong' | 'adequate' | 'weak' | 'unavailable';

export interface RatioResult {
  key: string;
  label: string;
  value: number | null;
  unit: '%' | 'x' | 'ratio';
  formula: string;
  inputs: Record<string, number>;
  interpretation: string;
  band: RatioBand;
  caveat?: string;
}

export interface WorkingCapitalLine {
  workingCapital: number;
  dso: number | null;
  dio: number | null;
  dpo: number | null;
  cashConversionCycle: number | null;
}

export interface DuPontResult {
  roe: number | null;
  netMargin: number | null;
  assetTurnover: number | null;
  equityMultiplier: number | null;
}

export interface BreakEvenInput {
  fixedCosts: number;
  variableCostPerUnit: number;
  sellingPricePerUnit: number;
}

export interface BreakEvenResult {
  contributionPerUnit: number;
  contributionMarginPct: number;
  breakEvenUnits: number | null;
  breakEvenRevenue: number | null;
}

export type HealthStatus = 'Excellent' | 'Healthy' | 'Watch' | 'Warning' | 'Critical';

export interface HealthScoreComponent {
  label: string;
  points: number;
  maxPoints: number;
  detail: string;
}

export interface HealthScoreResult {
  score: number;
  status: HealthStatus;
  components: HealthScoreComponent[];
}

export type RedFlagSeverity = 'critical' | 'warning';

export interface RedFlag {
  id: string;
  severity: RedFlagSeverity;
  label: string;
  whatHappened: string;
  supportingMetric: string;
  whyItMatters: string;
  possibleExplanation: string;
  suggestedInvestigation: string;
}

export interface FinancialInsight {
  id: string;
  finding: string;
  supportingData: string;
  managementImplication: string;
  suggestedInvestigation: string;
}

export interface ProfitDiagnosticResult {
  fromLabel: string;
  toLabel: string;
  startingProfit: number;
  endingProfit: number;
  revenueEffect: number;
  cogsEffect: number;
  opexEffect: number;
  otherEffect: number;
}

export interface FinancialQuestionAnswer {
  question: string;
  answered: boolean;
  answer?: string;
  supporting?: string;
  missingRequirement?: string;
}

export interface ValidationIssue {
  severity: 'error' | 'warning';
  label: string;
  detail: string;
}

/** Plain-object snapshot V4 (Risk) will consume — never recomputed by V4,
 * only read. */
export interface FinanceMetricsSnapshot {
  currentRatio: number | null;
  debtToEquity: number | null;
  interestCoverage: number | null;
  operatingCashFlow: number | null;
  netMargin: number | null;
  revenueVolatilityPct: number | null;
  workingCapital: number | null;
  healthScore: number | null;
}
