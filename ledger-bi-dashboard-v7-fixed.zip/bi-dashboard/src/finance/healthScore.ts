import { BalanceSheetLine, CashFlowLine, HealthScoreComponent, HealthScoreResult, HealthStatus, IncomeStatementLine } from './types';

/**
 * FINANCIAL HEALTH SCORE
 * A decision-support heuristic, NOT a credit rating or investment rating.
 * Starts at 0, earns points across 7 weighted components (100 total), each
 * shown in the breakdown so nothing is a black box.
 */
export function computeHealthScore(
  income: IncomeStatementLine,
  bs: BalanceSheetLine,
  cashFlow: CashFlowLine,
  revenueGrowthPct: number | null
): HealthScoreResult {
  const components: HealthScoreComponent[] = [];

  // Profitability (20 pts) - net margin
  const profitPoints = income.netMarginPct >= 10 ? 20 : income.netMarginPct >= 3 ? 12 : income.netMarginPct > 0 ? 6 : 0;
  components.push({ label: 'Profitability', points: profitPoints, maxPoints: 20, detail: `Net margin of ${income.netMarginPct.toFixed(1)}%.` });

  // Liquidity (15 pts) - current ratio
  const currentRatio = bs.currentLiabilities === 0 ? null : bs.currentAssets / bs.currentLiabilities;
  const liquidityPoints = currentRatio === null ? 7 : currentRatio >= 2 ? 15 : currentRatio >= 1 ? 9 : 0;
  components.push({
    label: 'Liquidity',
    points: liquidityPoints,
    maxPoints: 15,
    detail: currentRatio === null ? 'Current liabilities are zero — treated as neutral.' : `Current ratio of ${currentRatio.toFixed(2)}.`,
  });

  // Solvency (15 pts) - debt-to-equity
  const debtToEquity = bs.equity === 0 ? null : bs.totalLiabilities / bs.equity;
  const solvencyPoints = debtToEquity === null ? 7 : debtToEquity <= 1 ? 15 : debtToEquity <= 2 ? 9 : 0;
  components.push({
    label: 'Solvency',
    points: solvencyPoints,
    maxPoints: 15,
    detail: debtToEquity === null ? 'Equity is zero — treated as neutral.' : `Debt-to-equity of ${debtToEquity.toFixed(2)}×.`,
  });

  // Cash flow (20 pts) - operating cash flow and free cash flow signs
  const cashFlowPoints = cashFlow.operatingCashFlow > 0 && cashFlow.freeCashFlow > 0 ? 20 : cashFlow.operatingCashFlow > 0 ? 12 : 0;
  components.push({
    label: 'Cash Flow',
    points: cashFlowPoints,
    maxPoints: 20,
    detail: `Estimated operating cash flow ${cashFlow.operatingCashFlow >= 0 ? 'positive' : 'negative'}, free cash flow ${cashFlow.freeCashFlow >= 0 ? 'positive' : 'negative'}.`,
  });

  // Debt burden (10 pts) - interest coverage
  const interestCoverage = income.interest === 0 ? null : income.ebit / income.interest;
  const debtPoints = interestCoverage === null ? 5 : interestCoverage >= 5 ? 10 : interestCoverage >= 2 ? 6 : 0;
  components.push({
    label: 'Debt burden',
    points: debtPoints,
    maxPoints: 10,
    detail: interestCoverage === null ? 'No interest expense recorded — treated as neutral.' : `Interest coverage of ${interestCoverage.toFixed(1)}×.`,
  });

  // Growth (10 pts)
  const growthPoints = revenueGrowthPct === null ? 5 : revenueGrowthPct >= 10 ? 10 : revenueGrowthPct >= 0 ? 6 : 0;
  components.push({
    label: 'Growth',
    points: growthPoints,
    maxPoints: 10,
    detail: revenueGrowthPct === null ? 'Not enough periods to assess growth — treated as neutral.' : `Revenue growth of ${revenueGrowthPct.toFixed(1)}% vs. the prior period.`,
  });

  // Efficiency (10 pts) - asset turnover
  const assetTurnover = bs.totalAssets === 0 ? null : income.revenue / bs.totalAssets;
  const efficiencyPoints = assetTurnover === null ? 5 : assetTurnover >= 1 ? 10 : assetTurnover >= 0.5 ? 6 : 0;
  components.push({
    label: 'Efficiency',
    points: efficiencyPoints,
    maxPoints: 10,
    detail: assetTurnover === null ? 'Total assets are zero — treated as neutral.' : `Asset turnover of ${assetTurnover.toFixed(2)}×.`,
  });

  const score = components.reduce((s, c) => s + c.points, 0);
  const status: HealthStatus = score >= 85 ? 'Excellent' : score >= 65 ? 'Healthy' : score >= 45 ? 'Watch' : score >= 25 ? 'Warning' : 'Critical';

  return { score, status, components };
}
