import { FinancialQuestionAnswer, HealthScoreResult, IncomeStatementLine, RatioResult, WorkingCapitalLine } from './types';
import { diagnoseProfitChange } from './profitDiagnostic';

export interface FinanceQAContext {
  incomeSeries: { label: string; income: IncomeStatementLine }[];
  solvencyRatios: RatioResult[];
  workingCapitalSeries: { label: string; wc: WorkingCapitalLine }[];
  health: HealthScoreResult;
  cashFlowNetProfit: number;
  cashFlowActualChange: number;
}

export function answerFinancialQuestion(question: string, ctx: FinanceQAContext): FinancialQuestionAnswer {
  const q = question.toLowerCase();
  const { incomeSeries } = ctx;

  if (incomeSeries.length < 1) {
    return { question, answered: false, missingRequirement: 'No income statement periods are available yet. Map your accounts and ensure at least one period has revenue data.' };
  }

  const current = incomeSeries[incomeSeries.length - 1];
  const previous = incomeSeries.length > 1 ? incomeSeries[incomeSeries.length - 2] : null;

  if (/why.*profit.*(fall|declin|drop)/.test(q) || /profit.*(fall|declin|drop).*why/.test(q)) {
    if (!previous) return { question, answered: false, missingRequirement: 'Need at least two periods to diagnose a change in profit.' };
    const diag = diagnoseProfitChange(previous.income, current.income, previous.label, current.label);
    const effects = [
      { label: 'Revenue', value: diag.revenueEffect },
      { label: 'COGS', value: diag.cogsEffect },
      { label: 'Operating expenses', value: diag.opexEffect },
      { label: 'Other (interest, tax, D&A, other income/expense)', value: diag.otherEffect },
    ].sort((a, b) => a.value - b.value);
    const largest = effects[0];
    return {
      question,
      answered: true,
      answer: `Net profit moved from ${diag.startingProfit.toFixed(0)} to ${diag.endingProfit.toFixed(0)} between ${diag.fromLabel} and ${diag.toLabel}. The largest negative contributor was ${largest.label} (${largest.value.toFixed(0)}).`,
      supporting: 'See the Profit Diagnostic tab for the full waterfall breakdown.',
    };
  }

  if (/financially healthy|financial health/.test(q)) {
    const top = [...ctx.health.components].sort((a, b) => a.points / a.maxPoints - b.points / b.maxPoints)[0];
    return {
      question,
      answered: true,
      answer: `The Financial Health Score is ${ctx.health.score}/100 (${ctx.health.status}). The weakest component is ${top.label} (${top.points}/${top.maxPoints} points) — ${top.detail}`,
      supporting: 'This is a decision-support heuristic, not a credit rating.',
    };
  }

  if (/debt.*dangerous|dangerous.*debt/.test(q)) {
    const dte = ctx.solvencyRatios.find((r) => r.key === 'debtToEquity');
    const coverage = ctx.solvencyRatios.find((r) => r.key === 'interestCoverage');
    if (!dte || dte.value === null) {
      return { question, answered: false, missingRequirement: 'Need Equity and Total Liabilities mapped to assess debt levels.' };
    }
    const concern = dte.value > 2 || (coverage?.value !== null && (coverage?.value ?? 99) < 2);
    return {
      question,
      answered: true,
      answer: `Debt-to-equity is ${dte.value.toFixed(2)}× and interest coverage is ${coverage?.value !== null ? `${coverage?.value?.toFixed(1)}×` : 'undefined'}. ${
        concern ? 'These levels warrant attention — high leverage combined with thin coverage reduces headroom for a downturn.' : 'These levels do not currently show acute leverage or coverage stress.'
      }`,
      supporting: 'See the Ratios (Solvency) tab for full detail.',
    };
  }

  if (/cash.*falling|falling.*cash/.test(q) && /profit/.test(q)) {
    const gap = ctx.cashFlowActualChange - ctx.cashFlowNetProfit;
    return {
      question,
      answered: true,
      answer: `Net profit was ${ctx.cashFlowNetProfit.toFixed(0)} but the actual change in cash was ${ctx.cashFlowActualChange.toFixed(0)} — a gap of ${gap.toFixed(0)}, typically explained by cash tied up in (or released from) working capital, or investing/financing activity not captured in profit.`,
      supporting: 'See the Cash Flow tab, which separates profit from cash movement explicitly.',
    };
  }

  if (/working capital.*improv|improv.*working capital/.test(q)) {
    if (ctx.workingCapitalSeries.length < 2) {
      return { question, answered: false, missingRequirement: 'Need at least two periods of balance sheet data to assess a trend.' };
    }
    const prevWc = ctx.workingCapitalSeries[ctx.workingCapitalSeries.length - 2].wc;
    const currWc = ctx.workingCapitalSeries[ctx.workingCapitalSeries.length - 1].wc;
    const ccPrev = prevWc.cashConversionCycle;
    const ccCurr = currWc.cashConversionCycle;
    if (ccPrev === null || ccCurr === null) {
      return { question, answered: false, missingRequirement: 'Cash Conversion Cycle needs Revenue, COGS, Receivables, Inventory, and Current Liabilities all mapped.' };
    }
    const improving = ccCurr < ccPrev;
    return {
      question,
      answered: true,
      answer: `Cash Conversion Cycle moved from ${ccPrev.toFixed(0)} to ${ccCurr.toFixed(0)} days — ${improving ? 'improving (cash is tied up for less time)' : 'lengthening (cash is tied up for longer)'}.`,
      supporting: 'See the Working Capital tab for the DSO/DIO/DPO breakdown behind this.',
    };
  }

  if (/cost.*increasing fastest|fastest.*cost/.test(q)) {
    if (!previous) return { question, answered: false, missingRequirement: 'Need at least two periods to compare cost growth.' };
    const cogsGrowth = previous.income.cogs === 0 ? null : ((current.income.cogs - previous.income.cogs) / previous.income.cogs) * 100;
    const opexGrowth = previous.income.operatingExpenses === 0 ? null : ((current.income.operatingExpenses - previous.income.operatingExpenses) / previous.income.operatingExpenses) * 100;
    if (cogsGrowth === null && opexGrowth === null) {
      return { question, answered: false, missingRequirement: 'Need non-zero COGS and Operating Expenses in the prior period to compute growth rates.' };
    }
    const faster = (cogsGrowth ?? -Infinity) > (opexGrowth ?? -Infinity) ? 'COGS' : 'Operating Expenses';
    return {
      question,
      answered: true,
      answer: `${faster} grew faster (COGS: ${cogsGrowth?.toFixed(1) ?? 'n/a'}%, Operating Expenses: ${opexGrowth?.toFixed(1) ?? 'n/a'}%).`,
      supporting: 'This mapping only tracks COGS and Operating Expenses as combined totals, not individual line items — for a category-level breakdown, use the Cost Analyser on the raw dataset.',
    };
  }

  if (/margin compression|causing.*margin/.test(q)) {
    if (!previous) return { question, answered: false, missingRequirement: 'Need at least two periods to assess margin change.' };
    const grossDelta = current.income.grossMarginPct - previous.income.grossMarginPct;
    return {
      question,
      answered: true,
      answer: `Gross margin moved ${grossDelta >= 0 ? '+' : ''}${grossDelta.toFixed(1)} points between ${previous.label} and ${current.label}. ${
        grossDelta < 0 ? 'COGS growing faster than revenue is the most direct explanation available from this data — see the Margin Analyser.' : 'Margin was not compressing over this period.'
      }`,
      supporting: 'See the Margin Analyser tab for the revenue-vs-COGS growth comparison behind this.',
    };
  }

  if (/most profitable.*segment|segment.*most profitable/.test(q)) {
    return {
      question,
      answered: false,
      missingRequirement: 'Segment-level profitability needs a categorical column (e.g. product, region, customer) alongside revenue and cost in the raw dataset — the account mapping here works at the whole-company level. Try the "Ask a business question" tool in Analytics, which can compare revenue by category.',
    };
  }

  return {
    question,
    answered: false,
    missingRequirement: 'This question doesn\'t match a supported pattern yet. Try asking about profit decline, financial health, debt risk, cash vs profit, working capital, cost growth, or margin compression.',
  };
}
