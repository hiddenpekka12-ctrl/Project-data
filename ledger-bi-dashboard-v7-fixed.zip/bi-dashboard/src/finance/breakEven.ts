import { BreakEvenInput, BreakEvenResult } from './types';

export function computeBreakEven(input: BreakEvenInput): BreakEvenResult {
  const contributionPerUnit = input.sellingPricePerUnit - input.variableCostPerUnit;
  const contributionMarginPct = input.sellingPricePerUnit === 0 ? 0 : (contributionPerUnit / input.sellingPricePerUnit) * 100;
  const breakEvenUnits = contributionPerUnit > 0 ? input.fixedCosts / contributionPerUnit : null;
  const breakEvenRevenue = contributionMarginPct > 0 ? input.fixedCosts / (contributionMarginPct / 100) : null;

  return { contributionPerUnit, contributionMarginPct, breakEvenUnits, breakEvenRevenue };
}

/** Generates points for a break-even chart: total cost and total revenue
 * lines across a range of unit volumes, so the crossing point is visible. */
export function breakEvenChartData(input: BreakEvenInput, result: BreakEvenResult): { units: number; totalCost: number; totalRevenue: number }[] {
  const maxUnits = result.breakEvenUnits ? result.breakEvenUnits * 2 : 100;
  const steps = 10;
  const stepSize = maxUnits / steps || 1;
  return Array.from({ length: steps + 1 }, (_, i) => {
    const units = Math.round(stepSize * i);
    return {
      units,
      totalCost: input.fixedCosts + input.variableCostPerUnit * units,
      totalRevenue: input.sellingPricePerUnit * units,
    };
  });
}
