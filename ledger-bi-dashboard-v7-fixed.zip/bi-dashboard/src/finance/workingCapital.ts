import { BalanceSheetLine, IncomeStatementLine, PeriodGranularity, WorkingCapitalLine } from './types';

function avg(a: number, b: number | null): number {
  return b === null ? a : (a + b) / 2;
}

function daysInPeriod(granularity: PeriodGranularity): number {
  if (granularity === 'year') return 365;
  if (granularity === 'quarter') return 91;
  return 30;
}

/** DSO/DIO/DPO/CCC describe how long cash stays tied up in the operating
 * cycle. DPO uses Current Liabilities as a payables proxy for the same
 * reason the payables turnover ratio does — noted in the caller's UI. */
export function buildWorkingCapital(
  income: IncomeStatementLine,
  bs: BalanceSheetLine,
  prevBs: BalanceSheetLine | null,
  granularity: PeriodGranularity
): WorkingCapitalLine {
  const days = daysInPeriod(granularity);
  const avgReceivables = avg(bs.receivables, prevBs?.receivables ?? null);
  const avgInventory = avg(bs.inventory, prevBs?.inventory ?? null);
  const avgCurrentLiabilities = avg(bs.currentLiabilities, prevBs?.currentLiabilities ?? null);

  const dso = income.revenue === 0 ? null : (avgReceivables / income.revenue) * days;
  const dio = income.cogs === 0 ? null : (avgInventory / income.cogs) * days;
  const dpo = income.cogs === 0 ? null : (avgCurrentLiabilities / income.cogs) * days;
  const cashConversionCycle = dso !== null && dio !== null && dpo !== null ? dso + dio - dpo : null;

  return {
    workingCapital: bs.currentAssets - bs.currentLiabilities,
    dso,
    dio,
    dpo,
    cashConversionCycle,
  };
}
