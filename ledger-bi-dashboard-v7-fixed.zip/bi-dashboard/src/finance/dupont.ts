import { BalanceSheetLine, DuPontResult, IncomeStatementLine } from './types';

function avg(a: number, b: number | null): number {
  return b === null ? a : (a + b) / 2;
}

export function buildDuPont(income: IncomeStatementLine, bs: BalanceSheetLine, prevBs: BalanceSheetLine | null): DuPontResult {
  const avgAssets = avg(bs.totalAssets, prevBs?.totalAssets ?? null);
  const avgEquity = avg(bs.equity, prevBs?.equity ?? null);

  const netMargin = income.revenue === 0 ? null : income.netProfit / income.revenue;
  const assetTurnover = avgAssets === 0 ? null : income.revenue / avgAssets;
  const equityMultiplier = avgEquity === 0 ? null : avgAssets / avgEquity;

  const roe = netMargin !== null && assetTurnover !== null && equityMultiplier !== null ? netMargin * assetTurnover * equityMultiplier : null;

  return { roe, netMargin, assetTurnover, equityMultiplier };
}
