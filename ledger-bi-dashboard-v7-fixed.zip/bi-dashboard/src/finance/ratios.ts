import { BalanceSheetLine, IncomeStatementLine, RatioBand, RatioResult } from './types';

function avg(a: number, b: number | null): number {
  return b === null ? a : (a + b) / 2;
}

function band(value: number | null, strongAt: number, adequateAt: number, higherIsBetter = true): RatioBand {
  if (value === null || !isFinite(value)) return 'unavailable';
  if (higherIsBetter) {
    if (value >= strongAt) return 'strong';
    if (value >= adequateAt) return 'adequate';
    return 'weak';
  }
  if (value <= strongAt) return 'strong';
  if (value <= adequateAt) return 'adequate';
  return 'weak';
}

export function buildLiquidityRatios(bs: BalanceSheetLine): RatioResult[] {
  const quickAssets = bs.currentAssets - bs.inventory;
  const currentRatio = bs.currentLiabilities === 0 ? null : bs.currentAssets / bs.currentLiabilities;
  const quickRatio = bs.currentLiabilities === 0 ? null : quickAssets / bs.currentLiabilities;
  const cashRatio = bs.currentLiabilities === 0 ? null : bs.cash / bs.currentLiabilities;

  return [
    {
      key: 'currentRatio',
      label: 'Current Ratio',
      unit: 'x' as const,
      value: currentRatio,
      formula: 'Current Assets / Current Liabilities',
      inputs: { 'Current Assets': bs.currentAssets, 'Current Liabilities': bs.currentLiabilities },
      interpretation: currentRatio === null ? 'Current liabilities are zero — ratio undefined.' : `${currentRatio.toFixed(2)} of current assets for every ₹1 of current liabilities.`,
      band: band(currentRatio, 2, 1),
    },
    {
      key: 'quickRatio',
      label: 'Quick Ratio',
      unit: 'x' as const,
      value: quickRatio,
      formula: '(Current Assets − Inventory) / Current Liabilities',
      inputs: { 'Current Assets': bs.currentAssets, Inventory: bs.inventory, 'Current Liabilities': bs.currentLiabilities },
      interpretation: quickRatio === null ? 'Current liabilities are zero — ratio undefined.' : `${quickRatio.toFixed(2)} of quickly-convertible assets per ₹1 of current liabilities.`,
      band: band(quickRatio, 1, 0.7),
    },
    {
      key: 'cashRatio',
      label: 'Cash Ratio',
      unit: 'x' as const,
      value: cashRatio,
      formula: 'Cash / Current Liabilities',
      inputs: { Cash: bs.cash, 'Current Liabilities': bs.currentLiabilities },
      interpretation: cashRatio === null ? 'Current liabilities are zero — ratio undefined.' : `${cashRatio.toFixed(2)} of pure cash per ₹1 of current liabilities.`,
      band: band(cashRatio, 0.5, 0.2),
    },
  ];
}

export function buildProfitabilityRatios(income: IncomeStatementLine, bs: BalanceSheetLine, prevBs: BalanceSheetLine | null): RatioResult[] {
  const avgAssets = avg(bs.totalAssets, prevBs?.totalAssets ?? null);
  const avgEquity = avg(bs.equity, prevBs?.equity ?? null);
  const roa = avgAssets === 0 ? null : income.netProfit / avgAssets;
  const roe = avgEquity === 0 ? null : income.netProfit / avgEquity;
  const capitalEmployed = bs.totalAssets - bs.currentLiabilities;
  const roce = capitalEmployed === 0 ? null : income.ebit / capitalEmployed;

  return [
    {
      key: 'grossMargin',
      label: 'Gross Margin',
      unit: '%' as const,
      value: income.grossMarginPct,
      formula: 'Gross Profit / Revenue × 100',
      inputs: { 'Gross Profit': income.grossProfit, Revenue: income.revenue },
      interpretation: `${income.grossMarginPct.toFixed(1)}% of revenue remains after direct costs of goods sold.`,
      band: band(income.grossMarginPct, 40, 20),
    },
    {
      key: 'ebitdaMargin',
      label: 'EBITDA Margin',
      unit: '%' as const,
      value: income.ebitdaMarginPct,
      formula: 'EBITDA / Revenue × 100',
      inputs: { EBITDA: income.ebitda, Revenue: income.revenue },
      interpretation: `${income.ebitdaMarginPct.toFixed(1)}% of revenue remains before depreciation, interest and tax.`,
      band: band(income.ebitdaMarginPct, 20, 10),
    },
    {
      key: 'operatingMargin',
      label: 'Operating Margin (EBIT)',
      unit: '%' as const,
      value: income.ebitMarginPct,
      formula: 'EBIT / Revenue × 100',
      inputs: { EBIT: income.ebit, Revenue: income.revenue },
      interpretation: `${income.ebitMarginPct.toFixed(1)}% of revenue remains after all operating costs including depreciation.`,
      band: band(income.ebitMarginPct, 15, 5),
    },
    {
      key: 'netMargin',
      label: 'Net Margin',
      unit: '%' as const,
      value: income.netMarginPct,
      formula: 'Net Profit / Revenue × 100',
      inputs: { 'Net Profit': income.netProfit, Revenue: income.revenue },
      interpretation: `${income.netMarginPct.toFixed(1)}% of revenue converts to bottom-line profit.`,
      band: band(income.netMarginPct, 10, 3),
    },
    {
      key: 'roa',
      label: 'Return on Assets (ROA)',
      unit: '%' as const,
      value: roa === null ? null : roa * 100,
      formula: 'Net Profit / Average Total Assets × 100',
      inputs: { 'Net Profit': income.netProfit, 'Average Total Assets': avgAssets },
      interpretation: roa === null ? 'Average total assets are zero — ratio undefined.' : `${(roa * 100).toFixed(1)}% return generated on the asset base.`,
      band: band(roa === null ? null : roa * 100, 8, 3),
      caveat: prevBs ? undefined : 'Only one period of balance sheet data available — using period-end assets instead of a true average.',
    },
    {
      key: 'roe',
      label: 'Return on Equity (ROE)',
      unit: '%' as const,
      value: roe === null ? null : roe * 100,
      formula: 'Net Profit / Average Equity × 100',
      inputs: { 'Net Profit': income.netProfit, 'Average Equity': avgEquity },
      interpretation: roe === null ? 'Average equity is zero — ratio undefined.' : `${(roe * 100).toFixed(1)}% return generated for equity holders.`,
      band: band(roe === null ? null : roe * 100, 15, 8),
      caveat: prevBs ? undefined : 'Only one period of balance sheet data available — using period-end equity instead of a true average.',
    },
    {
      key: 'roce',
      label: 'Return on Capital Employed (ROCE)',
      unit: '%' as const,
      value: roce === null ? null : roce * 100,
      formula: 'EBIT / (Total Assets − Current Liabilities) × 100',
      inputs: { EBIT: income.ebit, 'Capital Employed': capitalEmployed },
      interpretation: roce === null ? 'Capital employed is zero — ratio undefined.' : `${(roce * 100).toFixed(1)}% return on the long-term capital employed in the business.`,
      band: band(roce === null ? null : roce * 100, 15, 8),
      caveat: 'Capital Employed is defined here as Total Assets minus Current Liabilities — a common but not universal definition.',
    },
  ];
}

export function buildSolvencyRatios(income: IncomeStatementLine, bs: BalanceSheetLine): RatioResult[] {
  const debtToEquity = bs.equity === 0 ? null : bs.totalLiabilities / bs.equity;
  const debtRatio = bs.totalAssets === 0 ? null : bs.totalLiabilities / bs.totalAssets;
  const interestCoverage = income.interest === 0 ? null : income.ebit / income.interest;

  return [
    {
      key: 'debtToEquity',
      label: 'Debt-to-Equity',
      unit: 'x' as const,
      value: debtToEquity,
      formula: 'Total Liabilities / Equity',
      inputs: { 'Total Liabilities': bs.totalLiabilities, Equity: bs.equity },
      interpretation: debtToEquity === null ? 'Equity is zero — ratio undefined.' : `${debtToEquity.toFixed(2)}× — for every ₹1 of equity, there is ₹${debtToEquity.toFixed(2)} of total liabilities.`,
      band: band(debtToEquity, 1, 2, false),
      caveat: 'Uses Total Liabilities as a proxy for "debt" since the account mapping does not separate interest-bearing debt from operating payables.',
    },
    {
      key: 'debtRatio',
      label: 'Debt Ratio',
      unit: '%' as const,
      value: debtRatio === null ? null : debtRatio * 100,
      formula: 'Total Liabilities / Total Assets × 100',
      inputs: { 'Total Liabilities': bs.totalLiabilities, 'Total Assets': bs.totalAssets },
      interpretation: debtRatio === null ? 'Total assets are zero — ratio undefined.' : `${(debtRatio * 100).toFixed(1)}% of assets are financed by liabilities rather than equity.`,
      band: band(debtRatio === null ? null : debtRatio * 100, 40, 60, false),
    },
    {
      key: 'interestCoverage',
      label: 'Interest Coverage',
      unit: 'x' as const,
      value: interestCoverage,
      formula: 'EBIT / Interest Expense',
      inputs: { EBIT: income.ebit, 'Interest Expense': income.interest },
      interpretation:
        interestCoverage === null
          ? 'Interest expense is zero or unavailable — interest coverage is undefined, not necessarily a good sign.'
          : `EBIT covers interest expense ${interestCoverage.toFixed(1)}× over.`,
      band: band(interestCoverage, 5, 2),
    },
  ];
}

export function buildEfficiencyRatios(income: IncomeStatementLine, bs: BalanceSheetLine, prevBs: BalanceSheetLine | null): RatioResult[] {
  const avgAssets = avg(bs.totalAssets, prevBs?.totalAssets ?? null);
  const avgInventory = avg(bs.inventory, prevBs?.inventory ?? null);
  const avgReceivables = avg(bs.receivables, prevBs?.receivables ?? null);
  const avgCurrentLiabilities = avg(bs.currentLiabilities, prevBs?.currentLiabilities ?? null);

  const assetTurnover = avgAssets === 0 ? null : income.revenue / avgAssets;
  const inventoryTurnover = avgInventory === 0 ? null : income.cogs / avgInventory;
  const receivablesTurnover = avgReceivables === 0 ? null : income.revenue / avgReceivables;
  const payablesTurnover = avgCurrentLiabilities === 0 ? null : income.cogs / avgCurrentLiabilities;

  return [
    {
      key: 'assetTurnover',
      label: 'Asset Turnover',
      unit: 'x' as const,
      value: assetTurnover,
      formula: 'Revenue / Average Total Assets',
      inputs: { Revenue: income.revenue, 'Average Total Assets': avgAssets },
      interpretation: assetTurnover === null ? 'Average assets are zero — ratio undefined.' : `₹${assetTurnover.toFixed(2)} of revenue generated per ₹1 of assets.`,
      band: band(assetTurnover, 1, 0.5),
    },
    {
      key: 'inventoryTurnover',
      label: 'Inventory Turnover',
      unit: 'x' as const,
      value: inventoryTurnover,
      formula: 'COGS / Average Inventory',
      inputs: { COGS: income.cogs, 'Average Inventory': avgInventory },
      interpretation: inventoryTurnover === null ? 'Average inventory is zero — ratio undefined.' : `Inventory turns over ${inventoryTurnover.toFixed(1)}× per period.`,
      band: band(inventoryTurnover, 6, 3),
    },
    {
      key: 'receivablesTurnover',
      label: 'Receivables Turnover',
      unit: 'x' as const,
      value: receivablesTurnover,
      formula: 'Revenue / Average Receivables',
      inputs: { Revenue: income.revenue, 'Average Receivables': avgReceivables },
      interpretation: receivablesTurnover === null ? 'Average receivables are zero — ratio undefined.' : `Receivables turn over ${receivablesTurnover.toFixed(1)}× per period.`,
      band: band(receivablesTurnover, 8, 4),
    },
    {
      key: 'payablesTurnover',
      label: 'Payables Turnover',
      unit: 'x' as const,
      value: payablesTurnover,
      formula: 'COGS / Average Current Liabilities',
      inputs: { COGS: income.cogs, 'Average Current Liabilities': avgCurrentLiabilities },
      interpretation: payablesTurnover === null ? 'Average current liabilities are zero — ratio undefined.' : `Approximately ${payablesTurnover.toFixed(1)}× per period.`,
      band: band(payablesTurnover, 6, 3),
      caveat: 'Uses total Current Liabilities as a proxy for payables, since payables are not separately mapped.',
    },
  ];
}
