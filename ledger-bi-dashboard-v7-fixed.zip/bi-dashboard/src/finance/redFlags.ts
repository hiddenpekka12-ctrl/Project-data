import { BalanceSheetLine, CashFlowLine, IncomeStatementLine, RedFlag, WorkingCapitalLine } from './types';

let counter = 0;
function id(prefix: string): string {
  counter += 1;
  return `${prefix}-${counter}`;
}

export interface RedFlagContext {
  current: { income: IncomeStatementLine; bs: BalanceSheetLine; cashFlow: CashFlowLine; wc: WorkingCapitalLine; label: string };
  previous: { income: IncomeStatementLine; bs: BalanceSheetLine; cashFlow: CashFlowLine; wc: WorkingCapitalLine; label: string } | null;
}

/** Every flag states what happened, the metric behind it, why it matters,
 * a possible (not certain) explanation, and what to check next. None of
 * these claim financial distress on their own. */
export function detectRedFlags(ctx: RedFlagContext): RedFlag[] {
  counter = 0;
  const flags: RedFlag[] = [];
  const { current, previous } = ctx;

  if (previous) {
    if (current.income.revenue < previous.income.revenue) {
      const change = ((current.income.revenue - previous.income.revenue) / Math.abs(previous.income.revenue || 1)) * 100;
      flags.push({
        id: id('revenue'),
        severity: 'warning',
        label: 'Revenue declining',
        whatHappened: `Revenue fell ${Math.abs(change).toFixed(1)}% from ${previous.label} to ${current.label}.`,
        supportingMetric: `${previous.income.revenue.toFixed(0)} → ${current.income.revenue.toFixed(0)}`,
        whyItMatters: 'Sustained revenue decline pressures every downstream metric — margins, cash flow, and debt capacity.',
        possibleExplanation: 'Could reflect seasonality, lost customers, pricing pressure, or a one-off contract ending.',
        suggestedInvestigation: 'Break revenue down by segment/product/region in the Analytics or Revenue Analysis view to isolate where the decline is concentrated.',
      });
    }

    if (current.income.netProfit < previous.income.netProfit) {
      flags.push({
        id: id('profit'),
        severity: 'warning',
        label: 'Profit declining',
        whatHappened: `Net profit fell from ${previous.income.netProfit.toFixed(0)} to ${current.income.netProfit.toFixed(0)}.`,
        supportingMetric: `Net margin: ${previous.income.netMarginPct.toFixed(1)}% → ${current.income.netMarginPct.toFixed(1)}%`,
        whyItMatters: 'Declining profit reduces the cushion available for debt service, reinvestment, and shocks.',
        possibleExplanation: 'Could be revenue decline, cost growth outpacing revenue, or a one-off expense.',
        suggestedInvestigation: 'Use the Profit Diagnostic to decompose the change into revenue, COGS, and operating expense effects.',
      });
    }

    const opexGrowth = previous.income.operatingExpenses === 0 ? null : ((current.income.operatingExpenses - previous.income.operatingExpenses) / previous.income.operatingExpenses) * 100;
    const revGrowth = previous.income.revenue === 0 ? null : ((current.income.revenue - previous.income.revenue) / previous.income.revenue) * 100;
    if (opexGrowth !== null && revGrowth !== null && opexGrowth > revGrowth + 5) {
      flags.push({
        id: id('opex'),
        severity: 'warning',
        label: 'Rapid expense growth',
        whatHappened: `Operating expenses grew ${opexGrowth.toFixed(1)}% while revenue grew ${revGrowth.toFixed(1)}%.`,
        supportingMetric: `OpEx: ${previous.income.operatingExpenses.toFixed(0)} → ${current.income.operatingExpenses.toFixed(0)}`,
        whyItMatters: 'Cost growth outpacing revenue growth compresses margins even when the top line is healthy.',
        possibleExplanation: 'Could be planned investment (hiring, marketing) or unplanned cost creep.',
        suggestedInvestigation: 'Review the Cost Analyser to identify which expense line is driving the growth.',
      });
    }

    if (current.income.grossMarginPct < previous.income.grossMarginPct - 2) {
      flags.push({
        id: id('margin'),
        severity: 'warning',
        label: 'Margin compression',
        whatHappened: `Gross margin fell from ${previous.income.grossMarginPct.toFixed(1)}% to ${current.income.grossMarginPct.toFixed(1)}%.`,
        supportingMetric: `Gross profit: ${previous.income.grossProfit.toFixed(0)} → ${current.income.grossProfit.toFixed(0)}`,
        whyItMatters: 'Margin compression means each unit of revenue generates less profit than before.',
        possibleExplanation: 'Could reflect input cost inflation, discounting, or a shift in product/customer mix.',
        suggestedInvestigation: 'Use the Margin Analyser to see whether COGS or pricing is the larger driver.',
      });
    }

    if (current.wc.dso !== null && previous.wc.dso !== null && current.wc.dso > previous.wc.dso * 1.15) {
      flags.push({
        id: id('receivables'),
        severity: 'warning',
        label: 'Increasing receivables',
        whatHappened: `Days Sales Outstanding rose from ${previous.wc.dso.toFixed(0)} to ${current.wc.dso.toFixed(0)} days.`,
        supportingMetric: `Receivables: ${previous.bs.receivables.toFixed(0)} → ${current.bs.receivables.toFixed(0)}`,
        whyItMatters: 'Slower collections tie up cash in the operating cycle even when sales look strong.',
        possibleExplanation: 'Could reflect looser credit terms, a large customer paying late, or collection issues.',
        suggestedInvestigation: 'Review the aging of individual receivables balances outside this tool if available.',
      });
    }

    if (current.wc.dio !== null && previous.wc.dio !== null && current.wc.dio > previous.wc.dio * 1.15) {
      flags.push({
        id: id('inventory'),
        severity: 'warning',
        label: 'Increasing inventory',
        whatHappened: `Days Inventory Outstanding rose from ${previous.wc.dio.toFixed(0)} to ${current.wc.dio.toFixed(0)} days.`,
        supportingMetric: `Inventory: ${previous.bs.inventory.toFixed(0)} → ${current.bs.inventory.toFixed(0)}`,
        whyItMatters: 'Slower-moving inventory ties up cash and raises obsolescence risk.',
        possibleExplanation: 'Could reflect a demand slowdown, overstocking, or a new product line ramping up.',
        suggestedInvestigation: 'Check whether the buildup is concentrated in specific product lines.',
      });
    }

    const currentRatioNow = current.bs.currentLiabilities === 0 ? null : current.bs.currentAssets / current.bs.currentLiabilities;
    const currentRatioPrev = previous.bs.currentLiabilities === 0 ? null : previous.bs.currentAssets / previous.bs.currentLiabilities;
    if (currentRatioNow !== null && currentRatioPrev !== null && currentRatioNow < currentRatioPrev && currentRatioNow < 1.5) {
      flags.push({
        id: id('liquidity'),
        severity: 'warning',
        label: 'Deteriorating liquidity',
        whatHappened: `Current ratio fell from ${currentRatioPrev.toFixed(2)} to ${currentRatioNow.toFixed(2)}.`,
        supportingMetric: `Current assets: ${current.bs.currentAssets.toFixed(0)}, Current liabilities: ${current.bs.currentLiabilities.toFixed(0)}`,
        whyItMatters: 'A falling current ratio below common comfort thresholds increases short-term payment risk.',
        possibleExplanation: 'Could be inventory/receivables buildup, rising short-term obligations, or cash being deployed elsewhere.',
        suggestedInvestigation: 'Check the Working Capital view for which component is driving the change.',
      });
    }
  }

  if (current.cashFlow.operatingCashFlow < 0) {
    flags.push({
      id: id('ocf'),
      severity: 'critical',
      label: 'Negative operating cash flow',
      whatHappened: `Estimated operating cash flow is ${current.cashFlow.operatingCashFlow.toFixed(0)} for ${current.label}.`,
      supportingMetric: `Net profit: ${current.income.netProfit.toFixed(0)}, working capital changes included`,
      whyItMatters: 'A business can be profitable on paper while still running out of cash — this is one of the clearest early warning signs.',
      possibleExplanation: 'Could reflect a working-capital buildup (receivables/inventory) rather than a true operating loss.',
      suggestedInvestigation: 'Check the Cash Flow view to see whether receivables/inventory growth is absorbing the cash.',
    });
  }

  if (current.cashFlow.freeCashFlow < 0) {
    flags.push({
      id: id('fcf'),
      severity: 'warning',
      label: 'Negative free cash flow',
      whatHappened: `Estimated free cash flow is ${current.cashFlow.freeCashFlow.toFixed(0)} for ${current.label} (operating cash flow minus estimated capital expenditure).`,
      supportingMetric: `Operating CF: ${current.cashFlow.operatingCashFlow.toFixed(0)}`,
      whyItMatters: 'Persistently negative free cash flow means the business is consuming more cash than it generates, even after covering investment.',
      possibleExplanation: 'Could reflect a deliberate growth/investment phase or an unsustainable cash burn.',
      suggestedInvestigation: 'Confirm whether the capital expenditure implied by fixed-asset growth is planned investment.',
    });
  }

  const debtToEquity = current.bs.equity === 0 ? null : current.bs.totalLiabilities / current.bs.equity;
  if (debtToEquity !== null && debtToEquity > 2) {
    flags.push({
      id: id('leverage'),
      severity: 'warning',
      label: 'High leverage',
      whatHappened: `Debt-to-equity stands at ${debtToEquity.toFixed(2)}×.`,
      supportingMetric: `Total liabilities: ${current.bs.totalLiabilities.toFixed(0)}, Equity: ${current.bs.equity.toFixed(0)}`,
      whyItMatters: 'High leverage amplifies both returns and losses, and increases sensitivity to interest rate or earnings shocks.',
      possibleExplanation: 'Could reflect deliberate leverage for growth, or eroding equity from accumulated losses.',
      suggestedInvestigation: 'Check whether equity has been declining (losses) or liabilities have been rising (borrowing).',
    });
  }

  const interestCoverage = current.income.interest === 0 ? null : current.income.ebit / current.income.interest;
  if (interestCoverage !== null && interestCoverage < 2) {
    flags.push({
      id: id('coverage'),
      severity: 'critical',
      label: 'Weak interest coverage',
      whatHappened: `EBIT covers interest expense only ${interestCoverage.toFixed(1)}× over.`,
      supportingMetric: `EBIT: ${current.income.ebit.toFixed(0)}, Interest: ${current.income.interest.toFixed(0)}`,
      whyItMatters: 'Thin interest coverage leaves little room before operating profit fails to cover debt service.',
      possibleExplanation: 'Could reflect high debt levels, rising interest rates, or depressed operating profit.',
      suggestedInvestigation: 'Review the debt schedule and whether refinancing or deleveraging is feasible.',
    });
  }

  return flags;
}
