import { AccountMapping, FLOW_CATEGORIES, FinanceCategory, PeriodAggregate, PeriodGranularity, STOCK_CATEGORIES } from './types';
import { Row } from '../types/analytics';

function toNumber(v: unknown): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return null;
}

function periodKey(date: Date, granularity: PeriodGranularity): string {
  const y = date.getUTCFullYear();
  const m = date.getUTCMonth();
  if (granularity === 'year') return `${y}`;
  if (granularity === 'quarter') return `${y}-Q${Math.floor(m / 3) + 1}`;
  return `${y}-${String(m + 1).padStart(2, '0')}`;
}

function periodStartOf(date: Date, granularity: PeriodGranularity): string {
  const y = date.getUTCFullYear();
  const m = date.getUTCMonth();
  if (granularity === 'year') return new Date(Date.UTC(y, 0, 1)).toISOString();
  if (granularity === 'quarter') return new Date(Date.UTC(y, Math.floor(m / 3) * 3, 1)).toISOString();
  return new Date(Date.UTC(y, m, 1)).toISOString();
}

/**
 * Builds one PeriodAggregate per period from raw rows + an account mapping.
 * Flow categories (revenue, expenses...) are summed within the period.
 * Stock categories (cash, receivables...) take the LAST value observed in
 * the period (a period-end balance), not a sum — summing balances across
 * transaction rows would double-count. This one rule lets the same
 * function handle both "one row per period" datasets (V1-style demo data)
 * and transaction-level datasets without special-casing either.
 */
export function buildPeriodAggregates(
  rows: Row[],
  mapping: AccountMapping,
  dateColumn: string,
  granularity: PeriodGranularity
): PeriodAggregate[] {
  const buckets = new Map<string, { start: string; sums: Partial<Record<FinanceCategory, number>>; lastSeen: Partial<Record<FinanceCategory, { value: number; time: number }>> }>();

  rows.forEach((row) => {
    const rawDate = row[dateColumn];
    const t = Date.parse(String(rawDate));
    if (isNaN(t)) return;
    const date = new Date(t);
    const key = periodKey(date, granularity);
    if (!buckets.has(key)) {
      buckets.set(key, { start: periodStartOf(date, granularity), sums: {}, lastSeen: {} });
    }
    const bucket = buckets.get(key)!;

    Object.entries(mapping).forEach(([column, category]) => {
      if (category === 'unmapped') return;
      const value = toNumber(row[column]);
      if (value === null) return;

      if (FLOW_CATEGORIES.includes(category)) {
        bucket.sums[category] = (bucket.sums[category] ?? 0) + value;
      } else if (STOCK_CATEGORIES.includes(category)) {
        const existing = bucket.lastSeen[category];
        if (!existing || t >= existing.time) {
          bucket.lastSeen[category] = { value, time: t };
        }
      }
    });
  });

  const allCategories: FinanceCategory[] = [...FLOW_CATEGORIES, ...STOCK_CATEGORIES];

  return Array.from(buckets.entries())
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([label, bucket]) => {
      const values = {} as Record<FinanceCategory, number>;
      allCategories.forEach((c) => {
        values[c] =
          FLOW_CATEGORIES.includes(c) ? bucket.sums[c] ?? 0 : bucket.lastSeen[c]?.value ?? 0;
      });
      values.unmapped = 0;
      return { label, periodStart: bucket.start, values };
    });
}
