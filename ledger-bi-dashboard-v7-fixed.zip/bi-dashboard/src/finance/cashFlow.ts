import { BalanceSheetLine, CashFlowLine, IncomeStatementLine } from './types';

/**
 * The 15-category mapping has no separate investing/financing accounts
 * (no capex, debt issuance/repayment, dividends). So this computes:
 *  - Operating Cash Flow via the simplified indirect method (real formula,
 *    real inputs, but "simplified" because payables/receivables/inventory
 *    are the only working-capital accounts available)
 *  - Free Cash Flow using ΔFixed Assets as a capex proxy (a real but rough
 *    stand-in — ignores disposals and non-cash revaluations)
 *  - Actual Net Change in Cash from the real cash balances (not estimated)
 *  - The gap between the two is shown as one combined "implied investing +
 *    financing" line, since the data can't tell them apart — never split
 *    fabricated into two numbers just to match the spec's line items.
 */
export function buildCashFlow(
  currentIncome: IncomeStatementLine,
  currentBalance: BalanceSheetLine,
  previousBalance: BalanceSheetLine | null
): CashFlowLine {
  const changeInReceivables = previousBalance ? currentBalance.receivables - previousBalance.receivables : 0;
  const changeInInventory = previousBalance ? currentBalance.inventory - previousBalance.inventory : 0;
  const changeInCurrentLiabilities = previousBalance ? currentBalance.currentLiabilities - previousBalance.currentLiabilities : 0;

  const operatingCashFlow =
    currentIncome.netProfit +
    currentIncome.depreciation -
    changeInReceivables -
    changeInInventory +
    changeInCurrentLiabilities;

  const changeInFixedAssets = previousBalance ? currentBalance.fixedAssets - previousBalance.fixedAssets : 0;
  const capexProxy = Math.max(0, changeInFixedAssets);
  const freeCashFlow = operatingCashFlow - capexProxy;

  const actualNetChangeInCash = previousBalance ? currentBalance.cash - previousBalance.cash : 0;
  const impliedInvestingPlusFinancing = actualNetChangeInCash - operatingCashFlow;

  return {
    netProfit: currentIncome.netProfit,
    depreciationAddBack: currentIncome.depreciation,
    changeInReceivables,
    changeInInventory,
    changeInCurrentLiabilities,
    operatingCashFlow,
    changeInFixedAssets,
    freeCashFlow,
    actualNetChangeInCash,
    impliedInvestingPlusFinancing,
  };
}
