import { useMemo, useState } from 'react';
import { useDatasets, DEMO_DATASET_ID } from '../state/DatasetContext';
import { computeOverview, profileDataset } from '../lib/dataProfiling';
import { computeDataQuality } from '../lib/dataQuality';
import { generateAutoInsights } from '../lib/autoEda';
import { buildCorrelationMatrix } from '../lib/correlation';
import { UploadPanel } from '../components/analytics/UploadPanel';
import { DatasetOverviewCard } from '../components/analytics/DatasetOverviewCard';
import { DataTable } from '../components/analytics/DataTable';
import { ProfilingPanel } from '../components/analytics/ProfilingPanel';
import { DataQualityCard } from '../components/analytics/DataQualityCard';
import { CleaningCenter } from '../components/analytics/CleaningCenter';
import { CleaningLog } from '../components/analytics/CleaningLog';
import { OutlierPanel } from '../components/analytics/OutlierPanel';
import { EdaWorkspace } from '../components/analytics/EdaWorkspace';
import { AutoInsightsPanel } from '../components/analytics/AutoInsightsPanel';
import { CorrelationMatrix } from '../components/analytics/CorrelationMatrix';
import { BusinessQuestionBox } from '../components/analytics/BusinessQuestionBox';
import { MyDatasets } from '../components/analytics/MyDatasets';
import { ExportButtons } from '../components/analytics/ExportButtons';
import { DemoDataTag } from '../components/common/StatusStates';

type Tab = 'import' | 'datasets' | 'profile' | 'quality' | 'clean' | 'explore' | 'insights' | 'ask';

const TABS: { key: Tab; label: string }[] = [
  { key: 'import', label: 'Import' },
  { key: 'datasets', label: 'My datasets' },
  { key: 'profile', label: 'Profile' },
  { key: 'quality', label: 'Quality' },
  { key: 'clean', label: 'Clean' },
  { key: 'explore', label: 'Explore (EDA)' },
  { key: 'insights', label: 'Insights' },
  { key: 'ask', label: 'Ask a question' },
];

export function Analytics() {
  const { activeDataset } = useDatasets();
  const [tab, setTab] = useState<Tab>('import');
  const { columns, columnTypes, cleanedRows } = activeDataset;

  const overview = useMemo(() => computeOverview(columns, columnTypes, cleanedRows), [columns, columnTypes, cleanedRows]);
  const profiles = useMemo(() => profileDataset(columns, columnTypes, cleanedRows), [columns, columnTypes, cleanedRows]);
  const quality = useMemo(() => computeDataQuality(overview, profiles, cleanedRows), [overview, profiles, cleanedRows]);
  const insights = useMemo(() => generateAutoInsights(cleanedRows, columnTypes, profiles), [cleanedRows, columnTypes, profiles]);
  const numericColumns = columns.filter((c) => columnTypes[c] === 'numeric');
  const correlations = useMemo(() => buildCorrelationMatrix(cleanedRows, numericColumns), [cleanedRows, numericColumns]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-serif text-2xl text-ink">Data analytics center</h1>
          <p className="text-sm text-ink-faint">Import → Profile → Clean → Explore → Analyze → Insights</p>
        </div>
        <div className="flex items-center gap-2">
          {activeDataset.id === DEMO_DATASET_ID ? (
            <DemoDataTag />
          ) : (
            <span className="rounded-sm border border-amber/30 bg-amber-soft px-1.5 py-0.5 text-[11px] text-amber">User data</span>
          )}
          <span className="text-sm text-ink-soft">{activeDataset.name}</span>
        </div>
      </div>

      <div className="flex flex-wrap gap-1 border-b border-line">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-t px-3 py-2 text-sm ${
              tab === t.key ? 'border-b-2 border-emerald text-emerald' : 'text-ink-faint hover:text-ink-soft'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'import' && (
        <div className="space-y-4">
          <UploadPanel onImported={() => setTab('profile')} />
          <p className="text-xs text-ink-faint">Files are parsed entirely in your browser and are never uploaded to an external service.</p>
        </div>
      )}

      {tab === 'datasets' && (
        <div className="space-y-4">
          <MyDatasets />
          <p className="text-xs text-ink-faint">
            Demo data is always available. Uploaded datasets live for this browser session — a persistent store arrives with V12.
          </p>
        </div>
      )}

      {tab === 'profile' && (
        <div className="space-y-4">
          <DatasetOverviewCard overview={overview} />
          <ProfilingPanel profiles={profiles} />
          <DataTable columns={columns} rows={cleanedRows} />
        </div>
      )}

      {tab === 'quality' && (
        <div className="space-y-4">
          <DataQualityCard result={quality} />
        </div>
      )}

      {tab === 'clean' && (
        <div className="space-y-4">
          <CleaningCenter />
          <OutlierPanel />
          <div>
            <p className="mb-2 text-sm font-medium text-ink">Cleaning history</p>
            <CleaningLog log={activeDataset.cleaningLog} />
          </div>
          <ExportButtons />
        </div>
      )}

      {tab === 'explore' && (
        <div className="space-y-4">
          <EdaWorkspace />
          <CorrelationMatrix cells={correlations} columns={numericColumns} />
        </div>
      )}

      {tab === 'insights' && (
        <div className="space-y-4">
          <AutoInsightsPanel insights={insights} />
        </div>
      )}

      {tab === 'ask' && (
        <div className="space-y-4">
          <BusinessQuestionBox />
        </div>
      )}
    </div>
  );
}
