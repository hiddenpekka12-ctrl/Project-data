import { useMemo, useState } from 'react';
import { useDatasets, DEMO_DATASET_ID } from '../state/DatasetContext';
import { useFinance } from '../state/FinanceContext';
import { buildFinanceModel } from '../finance/buildFinanceModel';
import { diagnoseProfitChange } from '../finance/profitDiagnostic';
import { DataSourcePanel } from '../components/finance/DataSourcePanel';
import { AccountMappingPanel } from '../components/finance/AccountMappingPanel';
import { IncomeStatementView } from '../components/finance/IncomeStatementView';
import { BalanceSheetView } from '../components/finance/BalanceSheetView';
import { CashFlowView } from '../components/finance/CashFlowView';
import { RatioGrid } from '../components/finance/FormulaTrace';
import { WorkingCapitalView } from '../components/finance/WorkingCapitalView';
import { DuPontView } from '../components/finance/DuPontView';
import { BreakEvenView } from '../components/finance/BreakEvenView';
import { MarginAnalyserView } from '../components/finance/MarginAnalyserView';
import { RevenueCostAnalysisView } from '../components/finance/RevenueCostAnalysisView';
import { FinancialHealthView } from '../components/finance/FinancialHealthView';
import { RedFlagsView } from '../components/finance/RedFlagsView';
import { FinancialInsightsView } from '../components/finance/FinancialInsightsView';
import { ProfitDiagnosticView } from '../components/finance/ProfitDiagnosticView';
import { FinancialDecisionBox } from '../components/finance/FinancialDecisionBox';
import { ValidationIssuesView } from '../components/finance/ValidationIssuesView';
import { FinanceExportButtons } from '../components/finance/FinanceExport';
import { formatCurrency } from '../lib/format';

type Tab = 'overview' | 'data' | 'statements' | 'ratios' | 'workingCapital' | 'breakEven' | 'trends' | 'health' | 'insights' | 'decision' | 'validation';

const TABS: { key: Tab; label: string }[] = [
  { key: 'overview', label: 'Overview' },
  { key: 'data', label: 'Data & Mapping' },
  { key: 'statements', label: 'Statements' },
  { key: 'ratios', label: 'Ratios' },
  { key: 'workingCapital', label: 'Working Capital & DuPont' },
  { key: 'breakEven', label: 'Break-even' },
  { key: 'trends', label: 'Margins & Revenue' },
  { key: 'health', label: 'Financial Health' },
  { key: 'insights', label: 'Insights & Diagnostic' },
  { key: 'decision', label: 'Decision Support' },
  { key: 'validation', label: 'Validation & Export' },
];

export function Finance() {
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const [tab, setTab] = useState<Tab>('overview');
  const [periodIndex, setPeriodIndex] = useState<number | null>(null);

  const model = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);

  const index = periodIndex !== null && periodIndex < model.periods.length ? periodIndex : model.periods.length - 1;
  const current = model.periods[index];
  const previous = index > 0 ? model.periods[index - 1] : null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-serif text-2xl text-ink">Finance Center</h1>
          <p className="text-sm text-ink-faint">Import → Validate → Classify → Statements → Ratios → Analysis → Insights</p>
        </div>
        <div className="flex items-center gap-2">
          {activeDataset.id === DEMO_DATASET_ID ? (
            <span className="rounded-sm border border-slateblue/30 bg-slateblue-soft px-1.5 py-0.5 text-[11px] text-slateblue">V1 Demo data</span>
          ) : (
            <span className="rounded-sm border border-amber/30 bg-amber-soft px-1.5 py-0.5 text-[11px] text-amber">{activeDataset.name}</span>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-1 border-b border-line">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-t px-3 py-2 text-sm ${tab === t.key ? 'border-b-2 border-emerald text-emerald' : 'text-ink-faint hover:text-ink-soft'}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {model.missingRequirement && model.periods.length === 0 ? (
        <div className="rounded border border-line bg-surface p-6 text-center">
          <p className="text-sm text-ink-soft">{model.missingRequirement}</p>
          <p className="mt-2 text-xs text-ink-faint">Use the Data & Mapping tab to load the demo company, enter figures manually, or map an uploaded dataset.</p>
          {tab !== 'data' && (
            <button onClick={() => setTab('data')} className="mt-3 rounded border border-emerald bg-emerald-soft px-3 py-1.5 text-xs text-emerald">
              Go to Data & Mapping
            </button>
          )}
        </div>
      ) : (
        <>
          {model.periods.length > 0 && tab !== 'data' && (
            <div className="flex items-center gap-2 text-sm">
              <span className="text-ink-faint">Period:</span>
              <select
                value={index}
                onChange={(e) => setPeriodIndex(Number(e.target.value))}
                className="rounded border border-line bg-base px-2 py-1 text-sm text-ink-soft"
              >
                {model.periods.map((p, i) => (
                  <option key={p.label} value={i}>
                    {p.label}
                  </option>
                ))}
              </select>
              {model.missingRequirement && <span className="text-xs text-amber">{model.missingRequirement}</span>}
            </div>
          )}

          {tab === 'overview' && current && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Metric label="Revenue" value={formatCurrency(current.income.revenue)} />
                <Metric label="Net Profit" value={formatCurrency(current.income.netProfit)} sub={`${current.income.netMarginPct.toFixed(1)}% margin`} />
                <Metric label="Cash" value={formatCurrency(current.balanceSheet.cash)} />
                <Metric label="Financial Health" value={model.health ? `${model.health.score}/100` : 'Data unavailable'} sub={model.health?.status} />
              </div>
              {model.redFlags.length > 0 && (
                <div className="rounded border border-amber/30 bg-amber-soft p-4">
                  <p className="text-sm font-medium text-amber">{model.redFlags.length} red flag(s) detected — see the Financial Health tab for details.</p>
                </div>
              )}
            </div>
          )}

          {tab === 'data' && (
            <div className="space-y-4">
              <DataSourcePanel />
              <AccountMappingPanel />
            </div>
          )}

          {tab === 'statements' && current && (
            <div className="space-y-4">
              <IncomeStatementView income={current.income} label={current.label} />
              {model.hasBalanceSheet ? (
                <>
                  <BalanceSheetView bs={current.balanceSheet} label={current.label} />
                  <CashFlowView cf={current.cashFlow} />
                </>
              ) : (
                <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">
                  Balance Sheet and Cash Flow need Cash and Equity mapped (plus Receivables, Inventory, Fixed Assets, Current Liabilities, Long-term Debt for full detail).
                </p>
              )}
            </div>
          )}

          {tab === 'ratios' && current && (
            <div className="space-y-6">
              {model.hasBalanceSheet ? (
                <>
                  <div>
                    <p className="mb-2 text-sm font-medium text-ink">Liquidity</p>
                    <RatioGrid ratios={current.liquidityRatios} />
                  </div>
                  <div>
                    <p className="mb-2 text-sm font-medium text-ink">Profitability</p>
                    <RatioGrid ratios={current.profitabilityRatios} />
                  </div>
                  <div>
                    <p className="mb-2 text-sm font-medium text-ink">Solvency</p>
                    <RatioGrid ratios={current.solvencyRatios} />
                  </div>
                  <div>
                    <p className="mb-2 text-sm font-medium text-ink">Efficiency</p>
                    <RatioGrid ratios={current.efficiencyRatios} />
                  </div>
                </>
              ) : (
                <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">Ratios need balance sheet data (Cash, Equity, and related categories mapped).</p>
              )}
            </div>
          )}

          {tab === 'workingCapital' && current && (
            <div className="space-y-4">
              {model.hasBalanceSheet ? (
                <>
                  <WorkingCapitalView wc={current.workingCapital} label={current.label} series={model.periods.map((p) => ({ label: p.label, ccc: p.workingCapital.cashConversionCycle }))} />
                  <DuPontView dupont={current.dupont} />
                </>
              ) : (
                <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">Working Capital and DuPont need balance sheet data mapped.</p>
              )}
            </div>
          )}

          {tab === 'breakEven' && <BreakEvenView />}

          {tab === 'trends' && (
            <div className="space-y-4">
              {model.periods.length > 1 ? <MarginAnalyserView periods={model.periods} /> : <p className="text-sm text-ink-faint">Need at least two periods for margin trends.</p>}
              <RevenueCostAnalysisView rows={activeDataset.cleanedRows} mapping={mapping} columnTypes={activeDataset.columnTypes as Record<string, string>} />
            </div>
          )}

          {tab === 'health' && (
            <div className="space-y-4">
              {model.health ? <FinancialHealthView health={model.health} /> : <p className="rounded border border-line bg-surface p-4 text-sm text-ink-faint">Health score needs balance sheet data mapped.</p>}
              <div>
                <p className="mb-2 text-sm font-medium text-ink">Financial Red Flags</p>
                <RedFlagsView flags={model.redFlags} />
              </div>
            </div>
          )}

          {tab === 'insights' && (
            <div className="space-y-4">
              <div>
                <p className="mb-2 text-sm font-medium text-ink">Financial Intelligence</p>
                <FinancialInsightsView insights={model.insights} />
              </div>
              {previous && current && (
                <ProfitDiagnosticView diagnostic={diagnoseProfitChange(previous.income, current.income, previous.label, current.label)} />
              )}
            </div>
          )}

          {tab === 'decision' && current && (
            <FinancialDecisionBox
              ctx={{
                incomeSeries: model.periods.map((p) => ({ label: p.label, income: p.income })),
                solvencyRatios: current.solvencyRatios,
                workingCapitalSeries: model.periods.map((p) => ({ label: p.label, wc: p.workingCapital })),
                health: model.health ?? { score: 0, status: 'Watch', components: [] },
                cashFlowNetProfit: current.income.netProfit,
                cashFlowActualChange: current.cashFlow.actualNetChangeInCash,
              }}
            />
          )}

          {tab === 'validation' && (
            <div className="space-y-4">
              <ValidationIssuesView issues={model.validation} />
              <FinanceExportButtons model={model} datasetName={activeDataset.name} />
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Metric({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-xs text-ink-faint">{label}</p>
      <p className="mt-1 font-serif text-xl tabular text-ink">{value}</p>
      {sub && <p className="mt-1 text-xs text-ink-faint">{sub}</p>}
    </div>
  );
}
