import { useMemo } from 'react';
import { demoAlerts, demoPeriods, demoRiskFactors } from '../data/demoData';
import { buildInsights, buildKpis, buildRiskSnapshot } from '../lib/calculations';
import { KpiCard } from '../components/dashboard/KpiCard';
import { CashFlowChart, ProfitTrendChart, RevenueVsExpensesChart, RiskTrendChart } from '../components/dashboard/Charts';
import { FinancialSnapshot } from '../components/dashboard/FinancialSnapshot';
import { RiskSnapshot } from '../components/dashboard/RiskSnapshot';
import { InsightsPanel } from '../components/dashboard/InsightsPanel';
import { AlertCenter } from '../components/dashboard/AlertCenter';
import { DemoDataTag, ResourcePanel } from '../components/common/StatusStates';
import { Resource } from '../types';
import { useDatasets, DEMO_DATASET_ID } from '../state/DatasetContext';
import { useFinance } from '../state/FinanceContext';
import { buildFinanceModel } from '../finance/buildFinanceModel';
import { detectFinancials } from '../lib/datasetToFinancials';
import { formatCurrency } from '../lib/format';
import { RiskDashboardSection } from '../components/dashboard/RiskDashboardSection';
import { ForecastDashboardSection } from '../components/dashboard/ForecastDashboardSection';
import { ScenarioDashboardSection } from '../components/dashboard/ScenarioDashboardSection';

export function Dashboard() {
  const { activeDataset, setActiveId } = useDatasets();
  const isDemo = activeDataset.id === DEMO_DATASET_ID;

  // All hooks are called unconditionally on every render — the branch
  // decision happens only in the JSX below — so switching datasets never
  // changes how many hooks this component calls.
  const periodsResource: Resource<typeof demoPeriods> = useMemo(() => {
    if (!demoPeriods.length) return { status: 'empty' };
    return { status: 'ready', data: demoPeriods };
  }, []);

  const riskSnapshot = useMemo(() => buildRiskSnapshot(demoRiskFactors), []);
  // Demo-only trailing risk history so the risk trend chart has a series to draw.
  const riskHistory = useMemo(
    () =>
      demoPeriods.map((p, i) => ({
        label: p.label,
        score: Math.max(10, Math.min(90, riskSnapshot.overallScore - (demoPeriods.length - 1 - i) * 1.4)),
      })),
    [riskSnapshot.overallScore]
  );
  const previousRiskScore = riskHistory.length > 1 ? riskHistory[riskHistory.length - 2].score : riskSnapshot.overallScore;

  if (!isDemo) {
    return <UserDatasetDashboard onUseDemoData={() => setActiveId(DEMO_DATASET_ID)} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-serif text-2xl text-ink">Executive dashboard</h1>
          <p className="text-sm text-ink-faint">Trailing 12 months, personal demo organization.</p>
        </div>
        <DemoDataTag />
      </div>

      <ResourcePanel
        resource={periodsResource}
        emptyLabel="No financial periods available yet. Add data in a future version to populate this dashboard."
        render={(periods) => {
          const kpis = buildKpis(periods, riskSnapshot.overallScore, previousRiskScore);
          const insights = buildInsights(kpis);
          const current = periods[periods.length - 1];

          return (
            <div className="space-y-6">
              <section aria-label="Key performance indicators" className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {kpis.map((kpi) => (
                  <KpiCard key={kpi.key} kpi={kpi} />
                ))}
              </section>

              <section aria-label="Charts" className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                <RevenueVsExpensesChart periods={periods} />
                <ProfitTrendChart periods={periods} />
                <CashFlowChart periods={periods} />
                <RiskTrendChart history={riskHistory} />
              </section>

              <section aria-label="Snapshots" className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                <FinancialSnapshot period={current} />
                <RiskSnapshot snapshot={riskSnapshot} />
              </section>

              <section aria-label="Insights and alerts" className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                <InsightsPanel insights={insights} />
                <AlertCenter alerts={demoAlerts} />
              </section>

              <RiskDashboardSection />
              <ForecastDashboardSection />
              <ScenarioDashboardSection />
            </div>
          );
        }}
      />
    </div>
  );
}

/**
 * V2 STEP 18 — Dashboard integration for user-uploaded datasets.
 * Never assumes a dataset is financial: it detects what it can and says
 * plainly what it can't calculate, instead of showing fabricated values.
 */
function UserDatasetDashboard({ onUseDemoData }: { onUseDemoData: () => void }) {
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const detected = useMemo(
    () => detectFinancials(activeDataset.cleanedRows, activeDataset.columnTypes),
    [activeDataset.cleanedRows, activeDataset.columnTypes]
  );
  // V3 STEP 31 — if this dataset has a real Finance Engine mapping (set up
  // in the Finance Center), surface health score / ROE / current ratio /
  // top risk here too. Falls back to "Data unavailable" per metric rather
  // than fabricating anything if the mapping doesn't support it.
  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);
  const lastPeriod = financeModel.periods[financeModel.periods.length - 1];
  const roe = lastPeriod?.profitabilityRatios.find((r) => r.key === 'roe')?.value ?? null;
  const currentRatio = lastPeriod?.liquidityRatios.find((r) => r.key === 'currentRatio')?.value ?? null;
  const topRisk = financeModel.redFlags[0]?.label ?? null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-serif text-2xl text-ink">Executive dashboard</h1>
          <p className="text-sm text-ink-faint">Showing: {activeDataset.name} (uploaded data)</p>
        </div>
        <button onClick={onUseDemoData} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
          Switch to demo data
        </button>
      </div>

      {!detected.hasEnoughData ? (
        <div className="rounded border border-line bg-surface p-6 text-center">
          <p className="text-sm text-ink-soft">{detected.missingReason}</p>
          <p className="mt-2 text-xs text-ink-faint">
            Head to the Analytics section to profile, clean, and explore this dataset on its own terms instead.
          </p>
        </div>
      ) : (
        <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <MetricCard label="Total revenue" value={formatCurrency(detected.totalRevenue ?? 0)} note={`from "${detected.revenueColumn}"`} />
          <MetricCard
            label="Total expenses"
            value={detected.expenseColumn ? formatCurrency(detected.totalExpenses ?? 0) : null}
            note={detected.expenseColumn ? `from "${detected.expenseColumn}"` : 'This dataset does not contain a recognizable expense column.'}
          />
          <MetricCard
            label="Top category"
            value={detected.topCategory ? detected.topCategory.key : null}
            note={
              detected.topCategory
                ? `${formatCurrency(detected.topCategory.total)} from "${detected.categoryColumn}"`
                : 'This dataset does not contain a recognizable category column.'
            }
          />
          <MetricCard
            label="Date coverage"
            value={detected.dateColumn ? detected.dateColumn : null}
            note={detected.dateColumn ? 'detected as the date column' : 'This dataset does not contain a recognizable date column.'}
          />
        </section>
      )}

      {financeModel.hasBalanceSheet && lastPeriod && (
        <section>
          <p className="mb-2 text-xs uppercase tracking-wide text-ink-faint">From the Finance Engine (V3)</p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <MetricCard label="Financial Health Score" value={financeModel.health ? `${financeModel.health.score}/100` : null} note={financeModel.health ? financeModel.health.status : 'Data unavailable'} />
            <MetricCard label="ROE" value={roe === null ? null : `${roe.toFixed(1)}%`} note="Return on Equity" />
            <MetricCard label="Current Ratio" value={currentRatio === null ? null : currentRatio.toFixed(2)} note="Liquidity" />
            <MetricCard label="Major Financial Risk" value={topRisk} note={topRisk ? 'See Finance Center → Financial Health for detail' : 'No red flags detected'} />
          </div>
        </section>
      )}

      <p className="text-xs text-ink-faint">
        The executive dashboard adapts to whichever columns it can confidently identify. For full control over the analysis, use the Analytics or Finance sections.
      </p>

      <RiskDashboardSection />
      <ForecastDashboardSection />
      <ScenarioDashboardSection />
    </div>
  );
}

function MetricCard({ label, value, note }: { label: string; value: string | null; note: string }) {
  return (
    <div className="rounded border border-line bg-surface p-4">
      <p className="text-xs text-ink-faint">{label}</p>
      {value ? (
        <p className="mt-1.5 font-serif text-xl tabular text-ink">{value}</p>
      ) : (
        <p className="mt-1.5 text-sm text-ink-faint">Not available</p>
      )}
      <p className="mt-2 text-xs text-ink-faint">{note}</p>
    </div>
  );
}
