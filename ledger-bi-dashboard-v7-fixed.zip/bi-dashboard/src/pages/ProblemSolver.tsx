import { useState } from 'react';
import { useProblemSolver } from '../state/ProblemSolverContext';
import { emptyProblem } from '../problemSolver/buildProblemSolverModel';
import { ProblemSolverHome } from '../components/problemSolver/ProblemSolverHome';
import { ProblemForm } from '../components/problemSolver/ProblemForm';
import { ProblemWorkspace } from '../components/problemSolver/ProblemWorkspace';
import { BusinessQuestionEngineView } from '../components/problemSolver/BusinessQuestionEngineView';

type View = 'home' | 'new' | { workspace: string } | 'ask';

export function ProblemSolver() {
  const { addProblem } = useProblemSolver();
  const [view, setView] = useState<View>('home');

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-serif text-2xl text-ink">Business Problem Solver</h1>
          <p className="text-sm text-ink-faint">Data → Analytics → Finance → Risk → Problem Diagnosis → Decision → Action</p>
        </div>
        {view !== 'ask' && (
          <button onClick={() => setView('ask')} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
            Ask a business question
          </button>
        )}
        {view === 'ask' && (
          <button onClick={() => setView('home')} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
            ← Back home
          </button>
        )}
      </div>

      {view === 'home' && (
        <ProblemSolverHome
          onOpen={(id) => setView({ workspace: id })}
          onNew={() => setView('new')}
        />
      )}

      {view === 'new' && (
        <ProblemForm
          problem={emptyProblem(`problem-${Date.now()}`)}
          onCancel={() => setView('home')}
          onSave={(p) => {
            addProblem(p);
            setView({ workspace: p.id });
          }}
        />
      )}

      {typeof view === 'object' && <ProblemWorkspace problemId={view.workspace} onBack={() => setView('home')} />}

      {view === 'ask' && <BusinessQuestionEngineView />}
    </div>
  );
}
