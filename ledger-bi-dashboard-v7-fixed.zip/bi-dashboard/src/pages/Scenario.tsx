import { useMemo, useState } from 'react';
import { useDatasets } from '../state/DatasetContext';
import { useFinance } from '../state/FinanceContext';
import { useScenario } from '../state/ScenarioContext';
import { buildFinanceModel } from '../finance/buildFinanceModel';
import { runScenario } from '../scenario/buildScenarioModel';
import { ScenarioConfig } from '../scenario/types';
import { ScenarioBuilder } from '../components/scenario/ScenarioBuilder';
import { ScenarioComparisonView } from '../components/scenario/ScenarioComparisonView';
import { MultiScenarioComparisonTable } from '../components/scenario/MultiScenarioComparisonTable';
import { SensitivityView } from '../components/scenario/SensitivityView';
import { StressTestView } from '../components/scenario/StressTestView';
import { RiskCascadeView } from '../components/scenario/RiskCascadeView';
import { DecisionAnalysisView } from '../components/scenario/DecisionAnalysisView';
import { ScenarioHistoryView } from '../components/scenario/ScenarioHistoryView';
import { ScenarioModeView } from '../components/scenario/ScenarioModeView';
import { OtherScenariosView } from '../components/scenario/OtherScenariosView';
import { LearnThis } from '../components/analytics/LearnThis';

type Tab = 'overview' | 'builder' | 'comparison' | 'sensitivity' | 'stress' | 'risk' | 'decision' | 'other' | 'history' | 'modes' | 'learning';

const TABS: { key: Tab; label: string }[] = [
  { key: 'overview', label: 'Overview' },
  { key: 'builder', label: 'Scenario Builder' },
  { key: 'comparison', label: 'Comparison' },
  { key: 'sensitivity', label: 'Sensitivity' },
  { key: 'stress', label: 'Stress Testing' },
  { key: 'risk', label: 'Risk Impact' },
  { key: 'decision', label: 'Decision Analysis' },
  { key: 'other', label: 'FX & Concentration' },
  { key: 'history', label: 'History' },
  { key: 'modes', label: 'Modes' },
  { key: 'learning', label: 'Learning' },
];

const LEARNING_CONCEPTS: { key: Parameters<typeof LearnThis>[0]['conceptKey']; label: string }[] = [
  { key: 'scenarioPlanningConcept', label: 'Scenario Planning' },
  { key: 'sensitivityAnalysisConcept', label: 'Sensitivity Analysis' },
  { key: 'stressTestingConcept', label: 'Stress Testing' },
  { key: 'breakEven', label: 'Break-even & Margin of Safety' },
  { key: 'expectedValueConcept', label: 'Expected Value' },
  { key: 'resilienceConcept', label: 'Business Resilience' },
  { key: 'tradeOffAnalysisConcept', label: 'Trade-off Analysis' },
  { key: 'riskAppetite', label: 'Risk Appetite (recap)' },
];

export function Scenario() {
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const { addScenario } = useScenario();
  const [tab, setTab] = useState<Tab>('overview');
  const [config, setConfig] = useState<ScenarioConfig | null>(null);

  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);
  const base = financeModel.periods[financeModel.periods.length - 1] ?? null;

  const run = useMemo(() => (config && base ? runScenario(base, config) : null), [config, base]);

  if (!base) {
    return (
      <div className="space-y-4">
        <h1 className="font-serif text-2xl text-ink">Scenario Center</h1>
        <p className="rounded border border-line bg-surface p-6 text-center text-sm text-ink-faint">
          Map accounts in the Finance Center first — the Scenario Engine builds on V3's Finance model.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-serif text-2xl text-ink">Scenario Center</h1>
          <p className="text-sm text-ink-faint">Assumption → Scenario → Calculation → Financial Impact → Risk Impact → Decision → Action</p>
        </div>
        <span className="rounded-sm border border-slateblue/30 bg-slateblue-soft px-1.5 py-0.5 text-[11px] text-slateblue">Base period: {base.label}</span>
      </div>

      <div className="flex flex-wrap gap-1 border-b border-line">
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)} className={`rounded-t px-3 py-2 text-sm ${tab === t.key ? 'border-b-2 border-emerald text-emerald' : 'text-ink-faint hover:text-ink-soft'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && <MultiScenarioComparisonTable base={base} />}
      {tab === 'builder' && <ScenarioBuilder basePeriodLabel={base.label} datasetId={activeDataset.id} onRun={(c) => { setConfig(c); setTab('comparison'); }} />}

      {(tab === 'comparison' || tab === 'risk' || tab === 'modes') && !run && (
        <p className="rounded border border-line bg-surface p-6 text-center text-sm text-ink-faint">Build a scenario in the Builder tab first.</p>
      )}
      {tab === 'comparison' && run && (
        <div className="space-y-3">
          <ScenarioComparisonView result={run.result} />
          <button onClick={() => config && addScenario(config)} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
            Save to Scenario History
          </button>
        </div>
      )}
      {tab === 'sensitivity' && <SensitivityView base={base} />}
      {tab === 'stress' && <StressTestView base={base} />}
      {tab === 'risk' && run && <RiskCascadeView base={base} scenario={run.scenario} scenarioName={run.result.config.name} />}
      {tab === 'decision' && <DecisionAnalysisView />}
      {tab === 'other' && <OtherScenariosView currentGrossMarginPct={base.income.grossMarginPct} />}
      {tab === 'history' && <ScenarioHistoryView />}
      {tab === 'modes' && run && <ScenarioModeView base={base} result={run.result} />}

      {tab === 'learning' && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Scenario Learning Mode</p>
          <div className="flex flex-wrap gap-2">
            {LEARNING_CONCEPTS.map((c) => (
              <span key={c.key} className="flex items-center rounded border border-line bg-base px-2 py-1 text-xs text-ink-soft">
                {c.label}
                <LearnThis conceptKey={c.key} label="Learn" />
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
