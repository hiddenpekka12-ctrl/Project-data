import { useMemo, useState } from 'react';
import { useDatasets } from '../state/DatasetContext';
import { useFinance } from '../state/FinanceContext';
import { useRisk } from '../state/RiskContext';
import { buildFinanceModel } from '../finance/buildFinanceModel';
import { buildRiskModel } from '../risk/buildRiskModel';
import { RiskOverviewView } from '../components/risk/RiskOverviewView';
import { RiskRegisterView } from '../components/risk/RiskRegisterView';
import { RiskHeatmap } from '../components/risk/RiskHeatmap';
import { RiskAppetiteView } from '../components/risk/RiskAppetiteView';
import { KriView } from '../components/risk/KriView';
import { FinancialRiskView } from '../components/risk/FinancialRiskView';
import { CreditRiskView } from '../components/risk/CreditRiskView';
import { ConcentrationRiskView } from '../components/risk/ConcentrationRiskView';
import { ControlsMitigationView } from '../components/risk/ControlsMitigationView';
import { RiskTrendsInsightsView } from '../components/risk/RiskTrendsInsightsView';
import { RiskDecisionBox } from '../components/risk/RiskDecisionBox';
import { RiskReportAndLearning } from '../components/risk/RiskReportAndLearning';

type Tab = 'overview' | 'register' | 'heatmap' | 'appetite' | 'kri' | 'financial' | 'credit' | 'concentration' | 'controls' | 'trends' | 'decision' | 'report';

const TABS: { key: Tab; label: string }[] = [
  { key: 'overview', label: 'Overview' },
  { key: 'register', label: 'Risk Register' },
  { key: 'heatmap', label: 'Heatmap' },
  { key: 'appetite', label: 'Appetite' },
  { key: 'kri', label: 'KRIs' },
  { key: 'financial', label: 'Financial Risk' },
  { key: 'credit', label: 'Credit Risk' },
  { key: 'concentration', label: 'Concentration' },
  { key: 'controls', label: 'Controls & Mitigation' },
  { key: 'trends', label: 'Trends & Insights' },
  { key: 'decision', label: 'Decision Support' },
  { key: 'report', label: 'Report & Learning' },
];

export function Risk() {
  const [tab, setTab] = useState<Tab>('overview');
  const { activeDataset } = useDatasets();
  const { mapping, settings } = useFinance();
  const { registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings } = useRisk();

  const financeModel = useMemo(() => buildFinanceModel(activeDataset.cleanedRows, mapping, settings), [activeDataset.cleanedRows, mapping, settings]);

  const revenueColumn = useMemo(() => Object.entries(mapping).find(([, cat]) => cat === 'revenue')?.[0] ?? null, [mapping]);
  const categoricalColumns = useMemo(
    () => activeDataset.columns.filter((c) => (activeDataset.columnTypes as Record<string, string>)[c] === 'categorical'),
    [activeDataset.columns, activeDataset.columnTypes]
  );

  const riskModel = useMemo(
    () =>
      buildRiskModel(
        registerItems,
        kris,
        controls,
        mitigations,
        appetiteSettings,
        scoringSettings,
        financeModel.periods,
        activeDataset.cleanedRows,
        categoricalColumns,
        revenueColumn
      ),
    [registerItems, kris, controls, mitigations, appetiteSettings, scoringSettings, financeModel.periods, activeDataset.cleanedRows, categoricalColumns, revenueColumn]
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-serif text-2xl text-ink">Risk Management Center</h1>
          <p className="text-sm text-ink-faint">Data → Analytics → Finance → Risk Intelligence → Decision Support</p>
        </div>
        <span className="rounded-sm border border-slateblue/30 bg-slateblue-soft px-1.5 py-0.5 text-[11px] text-slateblue">
          Financial signals from: {activeDataset.name}
        </span>
      </div>

      <div className="flex flex-wrap gap-1 border-b border-line">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-t px-3 py-2 text-sm ${tab === t.key ? 'border-b-2 border-emerald text-emerald' : 'text-ink-faint hover:text-ink-soft'}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && <RiskOverviewView model={riskModel} />}
      {tab === 'register' && <RiskRegisterView />}
      {tab === 'heatmap' && <RiskHeatmap scoredRisks={riskModel.scoredRisks} />}
      {tab === 'appetite' && <RiskAppetiteView />}
      {tab === 'kri' && <KriView />}
      {tab === 'financial' && <FinancialRiskView signals={riskModel.financialSignals} />}
      {tab === 'credit' && <CreditRiskView />}
      {tab === 'concentration' && <ConcentrationRiskView concentrations={riskModel.concentrations} revenueColumn={revenueColumn} />}
      {tab === 'controls' && <ControlsMitigationView />}
      {tab === 'trends' && <RiskTrendsInsightsView model={riskModel} />}
      {tab === 'decision' && (
        <RiskDecisionBox
          ctx={{
            registerItems,
            kris,
            mitigations,
            appetiteSettings,
            financialSignals: riskModel.financialSignals,
          }}
        />
      )}
      {tab === 'report' && <RiskReportAndLearning model={riskModel} companyName={activeDataset.name} />}
    </div>
  );
}
