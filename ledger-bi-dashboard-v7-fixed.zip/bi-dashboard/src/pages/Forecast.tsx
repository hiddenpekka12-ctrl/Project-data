import { useMemo, useState } from 'react';
import { useDatasets } from '../state/DatasetContext';
import { useForecast } from '../state/ForecastContext';
import { buildTimeSeries } from '../forecast/timeSeriesPrep';
import { buildForecastRun, isInsufficientData } from '../forecast/buildForecastModel';
import { ForecastConfig } from '../forecast/types';
import { ForecastOverview } from '../components/forecast/ForecastOverview';
import { ForecastBuilder } from '../components/forecast/ForecastBuilder';
import { HistoricalAnalysisView } from '../components/forecast/HistoricalAnalysisView';
import { ModelComparisonView } from '../components/forecast/ModelComparisonView';
import { ForecastResultView } from '../components/forecast/ForecastResultView';
import { FinancialForecastView } from '../components/forecast/FinancialForecastView';
import { ForecastRiskView } from '../components/forecast/ForecastRiskView';
import { WhatIfView } from '../components/forecast/WhatIfView';
import { ForecastHistoryView } from '../components/forecast/ForecastHistoryView';
import { LearnThis } from '../components/analytics/LearnThis';

type Tab = 'overview' | 'new' | 'historical' | 'models' | 'result' | 'financial' | 'risk' | 'whatif' | 'history' | 'learning';

const TABS: { key: Tab; label: string }[] = [
  { key: 'overview', label: 'Overview' },
  { key: 'new', label: 'New Forecast' },
  { key: 'historical', label: 'Historical Analysis' },
  { key: 'models', label: 'Models & Backtesting' },
  { key: 'result', label: 'Forecast Result' },
  { key: 'financial', label: 'Financial Forecast' },
  { key: 'risk', label: 'Risk Signals' },
  { key: 'whatif', label: 'What-If' },
  { key: 'history', label: 'History' },
  { key: 'learning', label: 'Learning' },
];

const LEARNING_CONCEPTS: { key: Parameters<typeof LearnThis>[0]['conceptKey']; label: string }[] = [
  { key: 'timeSeriesForecasting', label: 'Time Series Forecasting' },
  { key: 'movingAverageForecast', label: 'Moving Average' },
  { key: 'exponentialSmoothingConcept', label: 'Exponential Smoothing' },
  { key: 'regressionForecastConcept', label: 'Regression Forecasting' },
  { key: 'forecastErrorMetrics', label: 'Error Metrics (MAE/RMSE/MAPE/sMAPE)' },
  { key: 'backtestingConcept', label: 'Backtesting' },
  { key: 'forecastIntervalConcept', label: 'Forecast / Prediction Intervals' },
  { key: 'overfittingUnderfitting', label: 'Overfitting & Underfitting' },
];

export function Forecast() {
  const { activeDataset } = useDatasets();
  const { saveForecast } = useForecast();
  const [tab, setTab] = useState<Tab>('overview');
  const [config, setConfig] = useState<ForecastConfig | null>(null);

  const series = useMemo(() => (config ? buildTimeSeries(activeDataset.cleanedRows, config.dateColumn, config.targetColumn, config.frequency) : []), [config, activeDataset.cleanedRows]);
  const runResult = useMemo(() => (config ? buildForecastRun(activeDataset.cleanedRows, config) : null), [config, activeDataset.cleanedRows]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-serif text-2xl text-ink">Forecasting Center</h1>
          <p className="text-sm text-ink-faint">Historical Data → Validation → Pattern Detection → Model → Forecast → Uncertainty → Scenarios → Risk → Action</p>
        </div>
        <span className="rounded-sm border border-slateblue/30 bg-slateblue-soft px-1.5 py-0.5 text-[11px] text-slateblue">Working from: {activeDataset.name}</span>
      </div>

      <div className="flex flex-wrap gap-1 border-b border-line">
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)} className={`rounded-t px-3 py-2 text-sm ${tab === t.key ? 'border-b-2 border-emerald text-emerald' : 'text-ink-faint hover:text-ink-soft'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && <ForecastOverview />}
      {tab === 'new' && <ForecastBuilder onRun={(c) => { setConfig(c); setTab('historical'); }} />}

      {tab !== 'overview' && tab !== 'new' && !config && (
        <p className="rounded border border-line bg-surface p-6 text-center text-sm text-ink-faint">Build a forecast on the "New Forecast" tab first.</p>
      )}

      {config && runResult && isInsufficientData(runResult) && tab !== 'overview' && tab !== 'new' && tab !== 'financial' && tab !== 'risk' && (
        <div className="rounded border border-line bg-surface p-6 text-center">
          <p className="text-sm text-ink-soft">{runResult.message}</p>
        </div>
      )}

      {config && runResult && !isInsufficientData(runResult) && tab === 'historical' && <HistoricalAnalysisView run={runResult} series={series} />}
      {config && runResult && !isInsufficientData(runResult) && tab === 'models' && <ModelComparisonView backtests={runResult.backtests} selectedModel={runResult.selectedModel} />}
      {config && runResult && !isInsufficientData(runResult) && tab === 'result' && (
        <div className="space-y-3">
          <ForecastResultView run={runResult} series={series} />
          <button onClick={() => saveForecast(runResult)} className="rounded border border-line bg-surface px-3 py-1.5 text-xs text-ink-soft hover:bg-base">
            Save to Forecast History
          </button>
        </div>
      )}
      {config && tab === 'financial' && <FinancialForecastView horizon={config.horizon} frequency={config.frequency} />}
      {config && tab === 'risk' && <ForecastRiskView horizon={config.horizon} frequency={config.frequency} />}
      {config && runResult && !isInsufficientData(runResult) && tab === 'whatif' && <WhatIfView run={runResult} />}

      {tab === 'history' && <ForecastHistoryView />}

      {tab === 'learning' && (
        <div className="rounded border border-line bg-surface p-4">
          <p className="mb-2 text-sm font-medium text-ink">Forecast Learning Mode</p>
          <div className="flex flex-wrap gap-2">
            {LEARNING_CONCEPTS.map((c) => (
              <span key={c.key} className="flex items-center rounded border border-line bg-base px-2 py-1 text-xs text-ink-soft">
                {c.label}
                <LearnThis conceptKey={c.key} label="Learn" />
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
