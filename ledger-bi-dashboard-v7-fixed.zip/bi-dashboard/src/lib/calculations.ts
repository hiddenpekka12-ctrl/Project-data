import { FinancialPeriod, Insight, KpiResult, RiskFactor, RiskSnapshot, TrendDirection } from '../types';

/**
 * CALCULATION ENGINE
 * ------------------
 * Every number shown in the UI is derived here, never inline in a component.
 * This keeps an input -> calculation -> result trail: a KpiResult always
 * carries `sourcePeriodIds` back to the FinancialPeriod rows it came from.
 */

export function profit(p: FinancialPeriod): number {
  return p.revenue - p.expenses;
}

export function profitMargin(p: FinancialPeriod): number {
  return p.revenue === 0 ? 0 : (profit(p) / p.revenue) * 100;
}

export function netWorth(p: FinancialPeriod): number {
  return p.assets - p.liabilities;
}

export function workingCapital(p: FinancialPeriod): number {
  // Demo simplification: treats cash as the current-asset proxy and
  // debt as the current-liability proxy. A real V3 finance engine
  // would separate current vs long-term balances.
  return p.cash - p.debt;
}

function percentChange(current: number, previous: number): number {
  if (previous === 0) return current === 0 ? 0 : 100;
  return ((current - previous) / Math.abs(previous)) * 100;
}

function direction(pctChange: number): TrendDirection {
  if (Math.abs(pctChange) < 0.5) return 'flat';
  return pctChange > 0 ? 'up' : 'down';
}

/** Some metrics are "good when up" (revenue) and others are "good when down"
 * (expenses, risk). We keep direction purely descriptive here; components
 * decide the color semantics via `goodDirection`. */
export function buildKpis(periods: FinancialPeriod[], riskScore: number, previousRiskScore: number): KpiResult[] {
  if (periods.length < 2) return [];
  const current = periods[periods.length - 1];
  const previous = periods[periods.length - 2];

  const make = (
    key: string,
    label: string,
    value: number,
    previousValue: number,
    unit: KpiResult['unit'],
    explanation: string
  ): KpiResult => {
    const pct = percentChange(value, previousValue);
    return {
      key,
      label,
      value,
      previousValue,
      percentChange: pct,
      direction: direction(pct),
      unit,
      explanation,
      sourcePeriodIds: [current.id, previous.id],
    };
  };

  return [
    make('revenue', 'Revenue', current.revenue, previous.revenue, 'currency', `Revenue for ${current.label} versus ${previous.label}.`),
    make('expenses', 'Expenses', current.expenses, previous.expenses, 'currency', `Operating expenses for ${current.label} versus ${previous.label}.`),
    make('profit', 'Profit', profit(current), profit(previous), 'currency', 'Revenue minus expenses for the current period.'),
    make('cash', 'Cash', current.cash, previous.cash, 'currency', 'Cash on hand at period end.'),
    make('assets', 'Assets', current.assets, previous.assets, 'currency', 'Total assets at period end.'),
    make('liabilities', 'Liabilities', current.liabilities, previous.liabilities, 'currency', 'Total liabilities at period end.'),
    make('netWorth', 'Net worth', netWorth(current), netWorth(previous), 'currency', 'Assets minus liabilities at period end.'),
    make('riskScore', 'Risk score', riskScore, previousRiskScore, 'score', 'Composite of financial, operational, market and strategic risk.'),
  ];
}

export function riskLevelFromScore(score: number): RiskSnapshot['overallLevel'] {
  if (score < 25) return 'low';
  if (score < 50) return 'moderate';
  if (score < 75) return 'high';
  return 'critical';
}

export function buildRiskSnapshot(factors: RiskFactor[]): RiskSnapshot {
  const overallScore = factors.length
    ? Math.round(factors.reduce((sum, f) => sum + f.score, 0) / factors.length)
    : 0;
  return {
    overallScore,
    overallLevel: riskLevelFromScore(overallScore),
    factors,
  };
}

/** Insights are generated from the same KPI results shown on the cards,
 * rather than being separately hard-coded strings. */
export function buildInsights(kpis: KpiResult[]): Insight[] {
  const insights: Insight[] = [];
  const byKey = Object.fromEntries(kpis.map((k) => [k.key, k]));

  if (byKey.revenue) {
    const k = byKey.revenue;
    insights.push({
      id: 'i-revenue',
      message: `Revenue ${k.direction === 'up' ? 'increased' : k.direction === 'down' ? 'decreased' : 'held flat'} ${Math.abs(k.percentChange).toFixed(1)}% versus the prior period.`,
      basedOn: ['Revenue (current vs previous period)'],
    });
  }
  if (byKey.expenses) {
    const k = byKey.expenses;
    insights.push({
      id: 'i-expenses',
      message: `Operating expenses ${k.direction === 'up' ? 'increased' : k.direction === 'down' ? 'decreased' : 'held flat'} ${Math.abs(k.percentChange).toFixed(1)}% versus the prior period.`,
      basedOn: ['Expenses (current vs previous period)'],
    });
  }
  if (byKey.cash) {
    const k = byKey.cash;
    insights.push({
      id: 'i-cash',
      message: `Cash position ${k.direction === 'up' ? 'improved' : k.direction === 'down' ? 'decreased' : 'held steady'} this period.`,
      basedOn: ['Cash (current vs previous period)'],
    });
  }
  if (byKey.riskScore) {
    const k = byKey.riskScore;
    insights.push({
      id: 'i-risk',
      message: `Risk score ${k.direction === 'up' ? 'increased' : k.direction === 'down' ? 'decreased' : 'held steady'} ${Math.abs(k.percentChange).toFixed(1)}% versus the prior period.`,
      basedOn: ['Composite risk score (current vs previous period)'],
    });
  }
  return insights;
}
