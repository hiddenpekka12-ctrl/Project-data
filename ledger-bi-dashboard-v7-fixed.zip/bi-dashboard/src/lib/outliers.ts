import { OutlierMethod, OutlierResult, Row } from '../types/analytics';

function toNumber(v: unknown): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return null;
}

/**
 * An outlier is a statistically unusual value, not automatically an error.
 * Both methods flag row indexes; the caller decides whether to keep,
 * remove, or just review them.
 */
export function detectOutliersIqr(rows: Row[], column: string): OutlierResult {
  const values = rows.map((r) => toNumber(r[column])).filter((v): v is number => v !== null);
  const sorted = [...values].sort((a, b) => a - b);
  const q1 = quantile(sorted, 0.25);
  const q3 = quantile(sorted, 0.75);
  const iqr = q3 - q1;
  const lowerBound = q1 - 1.5 * iqr;
  const upperBound = q3 + 1.5 * iqr;

  const outlierRowIndexes: number[] = [];
  rows.forEach((r, i) => {
    const n = toNumber(r[column]);
    if (n !== null && (n < lowerBound || n > upperBound)) outlierRowIndexes.push(i);
  });

  return { method: 'iqr', column, lowerBound, upperBound, outlierRowIndexes };
}

export function detectOutliersZScore(rows: Row[], column: string, threshold = 3): OutlierResult {
  const values = rows.map((r) => toNumber(r[column])).filter((v): v is number => v !== null);
  const mean = values.reduce((a, b) => a + b, 0) / (values.length || 1);
  const std = Math.sqrt(values.reduce((a, b) => a + (b - mean) ** 2, 0) / (values.length || 1));

  const outlierRowIndexes: number[] = [];
  rows.forEach((r, i) => {
    const n = toNumber(r[column]);
    if (n !== null && std > 0 && Math.abs((n - mean) / std) > threshold) outlierRowIndexes.push(i);
  });

  return {
    method: 'zscore',
    column,
    lowerBound: mean - threshold * std,
    upperBound: mean + threshold * std,
    outlierRowIndexes,
  };
}

export function detectOutliers(rows: Row[], column: string, method: OutlierMethod): OutlierResult {
  return method === 'iqr' ? detectOutliersIqr(rows, column) : detectOutliersZScore(rows, column);
}

function quantile(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  return sorted[base + 1] !== undefined ? sorted[base] + rest * (sorted[base + 1] - sorted[base]) : sorted[base];
}
