import { ColumnProfile, ColumnType, Row } from '../types/analytics';
import { groupSum } from './autoEda';

const REVENUE_WORDS = ['revenue', 'sales', 'income', 'amount'];
const EXPENSE_WORDS = ['expense', 'cost', 'spend'];

function findColumn(columns: string[], keywords: string[], types: Record<string, ColumnType>, requiredType: ColumnType): string | null {
  const lower = columns.filter((c) => types[c] === requiredType);
  return lower.find((c) => keywords.some((k) => c.toLowerCase().includes(k))) ?? null;
}

export interface DetectedFinancials {
  hasEnoughData: boolean;
  revenueColumn: string | null;
  expenseColumn: string | null;
  dateColumn: string | null;
  categoryColumn: string | null;
  totalRevenue: number | null;
  totalExpenses: number | null;
  topCategory: { key: string; total: number } | null;
  missingReason: string | null;
}

/** Never fabricates a metric: if a required column type isn't present,
 * that metric comes back null with a plain-language reason instead. */
export function detectFinancials(rows: Row[], columnTypes: Record<string, ColumnType>): DetectedFinancials {
  const columns = Object.keys(columnTypes);
  const revenueColumn = findColumn(columns, REVENUE_WORDS, columnTypes, 'numeric');
  const expenseColumn = findColumn(columns, EXPENSE_WORDS, columnTypes, 'numeric');
  const dateColumn = columns.find((c) => columnTypes[c] === 'date') ?? null;
  const categoryColumn = columns.find((c) => columnTypes[c] === 'categorical') ?? null;

  const sum = (col: string | null): number | null =>
    col
      ? rows.reduce((s, r) => {
          const v = r[col];
          const n = typeof v === 'number' ? v : typeof v === 'string' && !isNaN(Number(v)) ? Number(v) : 0;
          return s + n;
        }, 0)
      : null;

  const topCategory =
    categoryColumn && revenueColumn
      ? groupSum(rows, categoryColumn, revenueColumn)[0] ?? null
      : null;

  const hasEnoughData = Boolean(revenueColumn);
  const missingReason = hasEnoughData
    ? null
    : 'This dataset does not contain a recognizable revenue-like numeric column, so the executive dashboard cannot be calculated from it.';

  return {
    hasEnoughData,
    revenueColumn,
    expenseColumn,
    dateColumn,
    categoryColumn,
    totalRevenue: sum(revenueColumn),
    totalExpenses: sum(expenseColumn),
    topCategory,
    missingReason,
  };
}
