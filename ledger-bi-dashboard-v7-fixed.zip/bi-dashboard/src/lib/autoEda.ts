import { AnalyticsInsight, ColumnProfile, ColumnType, Row } from '../types/analytics';
import { detectOutliersIqr } from './outliers';
import { buildCorrelationMatrix } from './correlation';

function toNumber(v: unknown): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return null;
}

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}-${idCounter}`;
}

/** Sums a numeric column grouped by a categorical column. Used both for
 * "top/lowest category" insights and for chart/business-question answers. */
export function groupSum(rows: Row[], groupCol: string, valueCol: string): { key: string; total: number }[] {
  const totals = new Map<string, number>();
  rows.forEach((r) => {
    const key = r[groupCol];
    const value = toNumber(r[valueCol]);
    if (key === null || key === '' || value === null) return;
    totals.set(String(key), (totals.get(String(key)) ?? 0) + value);
  });
  return Array.from(totals.entries())
    .map(([key, total]) => ({ key, total }))
    .sort((a, b) => b.total - a.total);
}

export function groupAverage(rows: Row[], groupCol: string, valueCol: string): { key: string; average: number; count: number }[] {
  const sums = new Map<string, number>();
  const counts = new Map<string, number>();
  rows.forEach((r) => {
    const key = r[groupCol];
    const value = toNumber(r[valueCol]);
    if (key === null || key === '' || value === null) return;
    sums.set(String(key), (sums.get(String(key)) ?? 0) + value);
    counts.set(String(key), (counts.get(String(key)) ?? 0) + 1);
  });
  return Array.from(sums.entries())
    .map(([key, total]) => ({ key, average: total / (counts.get(key) ?? 1), count: counts.get(key) ?? 0 }))
    .sort((a, b) => b.average - a.average);
}

/** Simple linear regression slope sign over a date-ordered numeric series,
 * used to describe a trend as increasing/declining/flat. */
function trendDirection(rows: Row[], dateCol: string, valueCol: string): 'increasing' | 'declining' | 'flat' | null {
  const points = rows
    .map((r) => ({ t: Date.parse(String(r[dateCol])), v: toNumber(r[valueCol]) }))
    .filter((p) => !isNaN(p.t) && p.v !== null) as { t: number; v: number }[];
  if (points.length < 4) return null;
  points.sort((a, b) => a.t - b.t);
  const n = points.length;
  const meanT = points.reduce((s, p) => s + p.t, 0) / n;
  const meanV = points.reduce((s, p) => s + p.v, 0) / n;
  let num = 0;
  let den = 0;
  points.forEach((p) => {
    num += (p.t - meanT) * (p.v - meanV);
    den += (p.t - meanT) ** 2;
  });
  const slope = den === 0 ? 0 : num / den;
  const relativeSlope = meanV !== 0 ? (slope * (points[n - 1].t - points[0].t)) / meanV : 0;
  if (Math.abs(relativeSlope) < 0.05) return 'flat';
  return relativeSlope > 0 ? 'increasing' : 'declining';
}

export function generateAutoInsights(
  rows: Row[],
  columnTypes: Record<string, ColumnType>,
  profiles: Record<string, ColumnProfile>
): AnalyticsInsight[] {
  idCounter = 0;
  const insights: AnalyticsInsight[] = [];
  const numericCols = Object.entries(columnTypes).filter(([, t]) => t === 'numeric').map(([c]) => c);
  const categoricalCols = Object.entries(columnTypes).filter(([, t]) => t === 'categorical').map(([c]) => c);
  const dateCols = Object.entries(columnTypes).filter(([, t]) => t === 'date').map(([c]) => c);

  // Concentration / top category (descriptive)
  if (categoricalCols.length && numericCols.length) {
    const catCol = categoricalCols[0];
    const valCol = numericCols[0];
    const totals = groupSum(rows, catCol, valCol);
    const grandTotal = totals.reduce((s, t) => s + t.total, 0);
    if (totals.length >= 2 && grandTotal > 0) {
      const top = totals[0];
      const pct = (top.total / grandTotal) * 100;
      insights.push({
        id: nextId('concentration'),
        category: 'descriptive',
        finding: `"${top.key}" accounts for ${pct.toFixed(1)}% of total ${valCol} across ${catCol}.`,
        supportingData: `Computed by summing ${valCol} grouped by ${catCol} across ${rows.length} rows.`,
        businessMeaning: pct > 40
          ? 'This level of concentration may create dependency risk if that segment weakens.'
          : 'Distribution is reasonably spread across categories.',
        confidence: 'High',
      });

      const lowest = totals[totals.length - 1];
      insights.push({
        id: nextId('lowest'),
        category: 'descriptive',
        finding: `"${lowest.key}" has the lowest total ${valCol} among ${catCol} (${totals.length} categories compared).`,
        supportingData: `Computed by summing ${valCol} grouped by ${catCol}.`,
        businessMeaning: 'Worth reviewing whether this is an underperforming segment or a genuinely small one.',
        confidence: 'Medium',
      });
    }
  }

  // Trend (descriptive/diagnostic)
  if (dateCols.length && numericCols.length) {
    const dateCol = dateCols[0];
    numericCols.slice(0, 2).forEach((valCol) => {
      const dir = trendDirection(rows, dateCol, valCol);
      if (dir && dir !== 'flat') {
        insights.push({
          id: nextId('trend'),
          category: dir === 'declining' ? 'diagnostic' : 'descriptive',
          finding: `${valCol} has been ${dir} over the period covered by ${dateCol}.`,
          supportingData: `Linear trend fitted across ${rows.length} rows ordered by ${dateCol}.`,
          businessMeaning:
            dir === 'declining'
              ? `Worth investigating what's driving the decline in ${valCol} before it compounds.`
              : `${valCol} growth appears sustained over this period — worth checking what's driving it so it can continue.`,
          confidence: 'Medium',
        });
      }
    });
  }

  // Missing data diagnostic
  Object.entries(profiles).forEach(([col, p]) => {
    if (p.missingPct > 15) {
      insights.push({
        id: nextId('missing'),
        category: 'diagnostic',
        finding: `${col} is missing in ${p.missingPct.toFixed(1)}% of rows.`,
        supportingData: `${p.missing} missing out of ${p.missing + p.count} total values.`,
        businessMeaning: 'High missingness can bias any analysis built on this column — consider why it is missing before trusting downstream metrics.',
        confidence: 'High',
      });
    }
  });

  // Outlier concentration (diagnostic)
  numericCols.forEach((col) => {
    const result = detectOutliersIqr(rows, col);
    const ratio = rows.length ? result.outlierRowIndexes.length / rows.length : 0;
    if (ratio > 0.03) {
      insights.push({
        id: nextId('outlier'),
        category: 'diagnostic',
        finding: `${col} has ${result.outlierRowIndexes.length} statistically unusual values (${(ratio * 100).toFixed(1)}% of rows, IQR method).`,
        supportingData: `Values outside [${result.lowerBound.toFixed(2)}, ${result.upperBound.toFixed(2)}].`,
        businessMeaning: 'These could be data entry errors or genuinely unusual events — review before drawing conclusions from averages.',
        confidence: 'Medium',
      });
    }
  });

  // Correlation highlight (diagnostic, with causation caveat baked into wording)
  if (numericCols.length >= 2) {
    const matrix = buildCorrelationMatrix(rows, numericCols);
    const strongest = [...matrix].sort((a, b) => Math.abs(b.r) - Math.abs(a.r))[0];
    if (strongest && strongest.strength !== 'weak') {
      insights.push({
        id: nextId('correlation'),
        category: 'diagnostic',
        finding: `${strongest.columnA} and ${strongest.columnB} show a ${strongest.strength} ${strongest.direction} relationship (r = ${strongest.r.toFixed(2)}).`,
        supportingData: `Pearson correlation across rows with values in both columns.`,
        businessMeaning: 'Worth exploring further, but correlation does not establish causation on its own.',
        confidence: 'Medium',
      });
    }
  }

  return insights;
}
