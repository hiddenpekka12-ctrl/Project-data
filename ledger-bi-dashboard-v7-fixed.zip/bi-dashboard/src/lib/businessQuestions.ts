import { BusinessQuestionAnswer, ColumnProfile, ColumnType, Row } from '../types/analytics';
import { groupAverage, groupSum } from './autoEda';

/** Picks the best-matching column for a role (categorical/numeric/date) by
 * scoring column names against words in the question, falling back to the
 * first column of that type if nothing matches by name. */
function pickColumn(
  question: string,
  candidates: string[]
): string | null {
  const words = question.toLowerCase().split(/\W+/).filter(Boolean);
  let best: string | null = null;
  let bestScore = 0;
  candidates.forEach((c) => {
    const colWords = c.toLowerCase().split(/[_\s]+/).filter(Boolean);
    const score = colWords.filter((w) => words.includes(w)).length;
    if (score > bestScore) {
      bestScore = score;
      best = c;
    }
  });
  return best ?? candidates[0] ?? null;
}

export function answerBusinessQuestion(
  question: string,
  rows: Row[],
  columnTypes: Record<string, ColumnType>
): BusinessQuestionAnswer {
  const q = question.toLowerCase();
  const numericCols = Object.entries(columnTypes).filter(([, t]) => t === 'numeric').map(([c]) => c);
  const categoricalCols = Object.entries(columnTypes).filter(([, t]) => t === 'categorical').map(([c]) => c);
  const dateCols = Object.entries(columnTypes).filter(([, t]) => t === 'date').map(([c]) => c);

  if (!numericCols.length || !categoricalCols.length) {
    return {
      question,
      answered: false,
      missingRequirement:
        'This dataset does not contain both a numeric column and a categorical column, which most business questions need. Try uploading a dataset with, for example, a "category" or "region" column and a numeric measure like "revenue" or "amount".',
    };
  }

  const valueCol = pickColumn(q, numericCols) ?? numericCols[0];
  const groupCol = pickColumn(q, categoricalCols) ?? categoricalCols[0];

  const wantsAverage = /\baverage\b|\bmean\b|\bper\b/.test(q);
  const wantsLowest = /\blowest\b|\bworst\b|\bpoorly\b|\bsmallest\b|\bdeclin/.test(q);
  const wantsTrend = /\btrend\b|\bover time\b|\bmonthly\b|\bmonth\b|\bgrowth\b|\bincreas/.test(q);

  if (wantsTrend && dateCols.length) {
    const dateCol = dateCols[0];
    const byMonth = new Map<string, number>();
    rows.forEach((r) => {
      const t = Date.parse(String(r[dateCol]));
      const v = r[valueCol];
      const n = typeof v === 'number' ? v : typeof v === 'string' && !isNaN(Number(v)) ? Number(v) : null;
      if (isNaN(t) || n === null) return;
      const key = new Date(t).toISOString().slice(0, 7);
      byMonth.set(key, (byMonth.get(key) ?? 0) + n);
    });
    const series = Array.from(byMonth.entries()).sort(([a], [b]) => (a < b ? -1 : 1));
    if (series.length < 2) {
      return { question, answered: false, missingRequirement: `Not enough dated rows to build a monthly trend for ${valueCol}.` };
    }
    const first = series[0];
    const last = series[series.length - 1];
    const change = first[1] !== 0 ? ((last[1] - first[1]) / Math.abs(first[1])) * 100 : 0;
    return {
      question,
      answered: true,
      answer: `${valueCol} moved from ${first[1].toFixed(0)} in ${first[0]} to ${last[1].toFixed(0)} in ${last[0]}, a change of ${change.toFixed(1)}% across ${series.length} months.`,
      supporting: `Monthly totals of ${valueCol} grouped by ${dateCol}.`,
    };
  }

  if (wantsAverage) {
    const ranked = groupAverage(rows, groupCol, valueCol);
    if (!ranked.length) {
      return { question, answered: false, missingRequirement: `No rows had both a ${groupCol} and a numeric ${valueCol} to average.` };
    }
    const top = ranked[0];
    return {
      question,
      answered: true,
      answer: `"${top.key}" has the highest average ${valueCol} at ${top.average.toFixed(2)}, based on ${top.count} rows.`,
      supporting: `Average ${valueCol} grouped by ${groupCol} across ${rows.length} rows.`,
    };
  }

  const ranked = groupSum(rows, groupCol, valueCol);
  if (!ranked.length) {
    return { question, answered: false, missingRequirement: `No rows had both a ${groupCol} and a numeric ${valueCol} to compare.` };
  }
  const pick = wantsLowest ? ranked[ranked.length - 1] : ranked[0];
  const grandTotal = ranked.reduce((s, r) => s + r.total, 0);
  const share = grandTotal ? (pick.total / grandTotal) * 100 : 0;
  return {
    question,
    answered: true,
    answer: `"${pick.key}" has the ${wantsLowest ? 'lowest' : 'highest'} total ${valueCol} at ${pick.total.toFixed(2)} (${share.toFixed(1)}% of the total across ${groupCol}).`,
    supporting: `Sum of ${valueCol} grouped by ${groupCol} across ${rows.length} rows.`,
  };
}
