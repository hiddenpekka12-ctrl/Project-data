import { ChartType, ColumnProfile, ColumnType, EdaSelection, Row } from '../types/analytics';
import { groupSum } from './autoEda';

function toNumber(v: unknown): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return null;
}

/** Suggests sensible chart types for a given x/y column-type pairing.
 * The first item is the recommended default; the rest remain selectable. */
export function recommendChartTypes(
  xType: ColumnType | null,
  yType: ColumnType | null,
  xUnique: number | null
): ChartType[] {
  if (xType === 'date' && yType === 'numeric') return ['line', 'area', 'bar'];
  if (xType === 'categorical' && yType === 'numeric') {
    return xUnique !== null && xUnique <= 6 ? ['bar', 'pie', 'box'] : ['bar', 'box'];
  }
  if (xType === 'numeric' && yType === 'numeric') return ['scatter', 'histogram'];
  if (xType === 'numeric' && !yType) return ['histogram'];
  if (xType === 'categorical' && !yType) return ['bar', 'pie'];
  return ['bar'];
}

export interface CategoricalSeriesPoint {
  key: string;
  value: number;
}

export function aggregateCategorical(rows: Row[], xCol: string, yCol: string): CategoricalSeriesPoint[] {
  return groupSum(rows, xCol, yCol).map((g) => ({ key: g.key, value: g.total }));
}

export function aggregateByDate(rows: Row[], dateCol: string, valueCol: string): { key: string; value: number }[] {
  const totals = new Map<string, number>();
  rows.forEach((r) => {
    const t = Date.parse(String(r[dateCol]));
    const v = toNumber(r[valueCol]);
    if (isNaN(t) || v === null) return;
    const key = new Date(t).toISOString().slice(0, 10);
    totals.set(key, (totals.get(key) ?? 0) + v);
  });
  return Array.from(totals.entries())
    .map(([key, value]) => ({ key, value }))
    .sort((a, b) => (a.key < b.key ? -1 : 1));
}

export function scatterPoints(rows: Row[], xCol: string, yCol: string): { x: number; y: number }[] {
  return rows
    .map((r) => ({ x: toNumber(r[xCol]), y: toNumber(r[yCol]) }))
    .filter((p): p is { x: number; y: number } => p.x !== null && p.y !== null);
}

export function histogramBins(values: number[], binCount = 10): { bin: string; count: number }[] {
  if (values.length === 0) return [];
  let min = values[0];
  let max = values[0];
  for (const v of values) {
    if (v < min) min = v;
    if (v > max) max = v;
  }
  const width = (max - min) / binCount || 1;
  const bins = new Array(binCount).fill(0);
  values.forEach((v) => {
    const idx = Math.min(binCount - 1, Math.floor((v - min) / width));
    bins[idx] += 1;
  });
  return bins.map((count, i) => ({
    bin: `${(min + i * width).toFixed(1)}–${(min + (i + 1) * width).toFixed(1)}`,
    count,
  }));
}

function quantile(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  return sorted[base + 1] !== undefined ? sorted[base] + rest * (sorted[base + 1] - sorted[base]) : sorted[base];
}

export interface BoxStats {
  key: string;
  min: number;
  q1: number;
  median: number;
  q3: number;
  max: number;
}

export function boxPlotStats(rows: Row[], groupCol: string, valueCol: string): BoxStats[] {
  const groups = new Map<string, number[]>();
  rows.forEach((r) => {
    const key = r[groupCol];
    const v = toNumber(r[valueCol]);
    if (key === null || key === '' || v === null) return;
    const arr = groups.get(String(key)) ?? [];
    arr.push(v);
    groups.set(String(key), arr);
  });
  return Array.from(groups.entries()).map(([key, values]) => {
    const sorted = [...values].sort((a, b) => a - b);
    return {
      key,
      min: sorted[0],
      q1: quantile(sorted, 0.25),
      median: quantile(sorted, 0.5),
      q3: quantile(sorted, 0.75),
      max: sorted[sorted.length - 1],
    };
  });
}

export function isSelectionMeaningful(selection: EdaSelection): boolean {
  if (selection.chartType === 'histogram') return Boolean(selection.xColumn);
  if (selection.chartType === 'pie') return Boolean(selection.xColumn && selection.yColumn);
  return Boolean(selection.xColumn && selection.yColumn);
}

/** Pivots rows into a series-per-groupBy-value table, for multi-series
 * bar/line charts. Returns the pivoted rows plus the list of series keys
 * so the caller can render one <Bar>/<Line> per group. */
export function aggregateGrouped(
  rows: Row[],
  xCol: string,
  yCol: string,
  groupCol: string
): { data: Record<string, string | number>[]; groupKeys: string[] } {
  const groupKeysSet = new Set<string>();
  const xKeysOrdered: string[] = [];
  const seenX = new Set<string>();
  const table = new Map<string, Record<string, number>>();

  rows.forEach((r) => {
    const xVal = r[xCol];
    const groupVal = r[groupCol];
    const yVal = toNumber(r[yCol]);
    if (xVal === null || xVal === '' || groupVal === null || groupVal === '' || yVal === null) return;
    const xKey = String(xVal);
    const groupKey = String(groupVal);
    groupKeysSet.add(groupKey);
    if (!seenX.has(xKey)) {
      seenX.add(xKey);
      xKeysOrdered.push(xKey);
    }
    const row = table.get(xKey) ?? {};
    row[groupKey] = (row[groupKey] ?? 0) + yVal;
    table.set(xKey, row);
  });

  const groupKeys = Array.from(groupKeysSet).slice(0, 8); // cap series count for readability
  const data = xKeysOrdered.map((xKey) => {
    const row = table.get(xKey) ?? {};
    const out: Record<string, string | number> = { key: xKey };
    groupKeys.forEach((g) => {
      out[g] = row[g] ?? 0;
    });
    return out;
  });

  return { data, groupKeys };
}
