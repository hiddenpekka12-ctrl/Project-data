import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { ColumnType, Row } from '../types/analytics';

export const MAX_ROWS = 50000; // hard safety cap for in-browser processing
export const SUPPORTED_EXTENSIONS = ['csv', 'xlsx', 'xls', 'json'];

export class ImportError extends Error {}

export interface ParsedTable {
  columns: string[];
  rows: Row[];
  truncated: boolean;
}

function normalizeHeader(h: string, index: number): string {
  const trimmed = (h ?? '').toString().trim();
  return trimmed.length ? trimmed : `column_${index + 1}`;
}

function dedupeHeaders(headers: string[]): string[] {
  const seen = new Map<string, number>();
  return headers.map((h) => {
    const count = seen.get(h) ?? 0;
    seen.set(h, count + 1);
    return count === 0 ? h : `${h}_${count + 1}`;
  });
}

export function parseCsv(text: string): ParsedTable {
  const result = Papa.parse<Record<string, string>>(text, {
    header: true,
    skipEmptyLines: true,
    dynamicTyping: false,
  });
  if (result.errors.length && !result.data.length) {
    throw new ImportError('This CSV file could not be read. Check that it has a header row and consistent columns.');
  }
  const headers = dedupeHeaders((result.meta.fields ?? []).map((h, i) => normalizeHeader(h, i)));
  const truncated = result.data.length > MAX_ROWS;
  const rows: Row[] = result.data.slice(0, MAX_ROWS).map((r) => {
    const row: Row = {};
    headers.forEach((h, i) => {
      const originalKey = (result.meta.fields ?? [])[i];
      row[h] = coerceCell(originalKey ? r[originalKey] : undefined);
    });
    return row;
  });
  return { columns: headers, rows, truncated };
}

export function parseJson(text: string): ParsedTable {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new ImportError('This JSON file is not valid JSON.');
  }
  const array = Array.isArray(parsed)
    ? parsed
    : parsed && typeof parsed === 'object'
    ? Object.values(parsed).find((v) => Array.isArray(v))
    : null;
  if (!Array.isArray(array) || array.length === 0) {
    throw new ImportError('This JSON file does not contain an array of records to analyze.');
  }
  const columnSet = new Set<string>();
  array.forEach((r) => {
    if (r && typeof r === 'object') Object.keys(r).forEach((k) => columnSet.add(k));
  });
  const columns = Array.from(columnSet);
  const truncated = array.length > MAX_ROWS;
  const rows: Row[] = array.slice(0, MAX_ROWS).map((r: any) => {
    const row: Row = {};
    columns.forEach((c) => {
      row[c] = coerceCell(r?.[c]);
    });
    return row;
  });
  return { columns, rows, truncated };
}

export function parseXlsx(buffer: ArrayBuffer): ParsedTable {
  let workbook: XLSX.WorkBook;
  try {
    workbook = XLSX.read(buffer, { type: 'array' });
  } catch {
    throw new ImportError('This Excel file could not be read. It may be corrupted or password-protected.');
  }
  const sheetName = workbook.SheetNames[0];
  if (!sheetName) throw new ImportError('This Excel file does not contain any sheets.');
  const sheet = workbook.Sheets[sheetName];
  const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: null });
  if (!json.length) throw new ImportError('The first sheet in this Excel file is empty.');
  const columnSet = new Set<string>();
  json.forEach((r) => Object.keys(r).forEach((k) => columnSet.add(k)));
  const columns = dedupeHeaders(Array.from(columnSet).map((h, i) => normalizeHeader(h, i)));
  const truncated = json.length > MAX_ROWS;
  const rows: Row[] = json.slice(0, MAX_ROWS).map((r) => {
    const row: Row = {};
    columns.forEach((c) => {
      row[c] = coerceCell(r[c]);
    });
    return row;
  });
  return { columns, rows, truncated };
}

function coerceCell(value: unknown): string | number | boolean | null {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  return String(value).trim();
}

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}|^\d{1,2}\/\d{1,2}\/\d{2,4}|^\d{1,2}-\d{1,2}-\d{2,4}/;

export function inferColumnType(values: (string | number | boolean | null)[]): ColumnType {
  const present = values.filter((v) => v !== null && v !== '');
  if (present.length === 0) return 'text';

  const allBoolean = present.every((v) => typeof v === 'boolean' || v === 'true' || v === 'false');
  if (allBoolean) return 'boolean';

  const numericCount = present.filter((v) => typeof v === 'number' || (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)))).length;
  if (numericCount / present.length > 0.9) return 'numeric';

  const dateCount = present.filter((v) => {
    if (typeof v !== 'string') return false;
    if (!DATE_PATTERN.test(v)) return false;
    const t = Date.parse(v);
    return !isNaN(t);
  }).length;
  if (dateCount / present.length > 0.9) return 'date';

  const uniqueRatio = new Set(present.map(String)).size / present.length;
  if (uniqueRatio < 0.5 || new Set(present.map(String)).size <= 50) return 'categorical';

  return 'text';
}

export function inferColumnTypes(columns: string[], rows: Row[]): Record<string, ColumnType> {
  const types: Record<string, ColumnType> = {};
  columns.forEach((c) => {
    types[c] = inferColumnType(rows.map((r) => r[c]));
  });
  return types;
}
