import { ColumnProfile, DataQualityBreakdownItem, DataQualityResult, DatasetOverview, Row } from '../types/analytics';
import { detectOutliersIqr } from './outliers';

/**
 * DATA QUALITY SCORE
 * ------------------
 * This is a configurable heuristic, not a statistically authoritative
 * measure. It starts at 100 and deducts points for missingness,
 * duplicates, and outlier concentration in numeric columns. Every
 * deduction is shown in the breakdown so the score is never a black box.
 */
export function computeDataQuality(
  overview: DatasetOverview,
  profiles: Record<string, ColumnProfile>,
  rows: Row[]
): DataQualityResult {
  const breakdown: DataQualityBreakdownItem[] = [];
  let score = 100;

  const totalCells = overview.rows * overview.columns || 1;
  const missingRatio = overview.missingValues / totalCells;
  if (missingRatio > 0) {
    const deduction = Math.min(35, Math.round(missingRatio * 100 * 0.7));
    score -= deduction;
    breakdown.push({
      label: 'Missing data',
      detail: `${overview.missingValues} of ${totalCells} cells (${(missingRatio * 100).toFixed(1)}%) are missing.`,
      pointsDeducted: deduction,
    });
  }

  if (overview.duplicateRows > 0) {
    const dupRatio = overview.duplicateRows / (overview.rows || 1);
    const deduction = Math.min(25, Math.round(dupRatio * 100 * 0.8));
    score -= deduction;
    breakdown.push({
      label: 'Duplicate records',
      detail: `${overview.duplicateRows} of ${overview.rows} rows (${(dupRatio * 100).toFixed(1)}%) are exact duplicates.`,
      pointsDeducted: deduction,
    });
  }

  const numericColumns = Object.entries(profiles).filter(([, p]) => p.type === 'numeric').map(([c]) => c);
  let totalOutliers = 0;
  let totalNumericValues = 0;
  numericColumns.forEach((col) => {
    const result = detectOutliersIqr(rows, col);
    totalOutliers += result.outlierRowIndexes.length;
    totalNumericValues += rows.length;
  });
  if (totalNumericValues > 0) {
    const outlierRatio = totalOutliers / totalNumericValues;
    if (outlierRatio > 0.02) {
      const deduction = Math.min(20, Math.round(outlierRatio * 100 * 0.5));
      score -= deduction;
      breakdown.push({
        label: 'Outliers',
        detail: `${totalOutliers} statistically unusual values found across ${numericColumns.length} numeric column(s) (IQR method).`,
        pointsDeducted: deduction,
      });
    }
  }

  const inconsistentColumns = Object.entries(profiles).filter(
    ([, p]) => p.type === 'categorical' && p.unique > 0 && p.mostCommonCount / Math.max(p.count, 1) < 0.02
  );
  if (inconsistentColumns.length > 0) {
    const deduction = Math.min(10, inconsistentColumns.length * 3);
    score -= deduction;
    breakdown.push({
      label: 'Inconsistent formats',
      detail: `${inconsistentColumns.length} categorical column(s) have unusually high variety, which often means inconsistent text formatting (e.g. "NY" vs "New York").`,
      pointsDeducted: deduction,
    });
  }

  score = Math.max(0, Math.min(100, score));
  const status: DataQualityResult['status'] = score >= 90 ? 'Excellent' : score >= 75 ? 'Good' : score >= 50 ? 'Fair' : 'Poor';

  if (breakdown.length === 0) {
    breakdown.push({ label: 'No issues detected', detail: 'No missing data, duplicates, or notable outliers found.', pointsDeducted: 0 });
  }

  return { score, status, breakdown };
}
