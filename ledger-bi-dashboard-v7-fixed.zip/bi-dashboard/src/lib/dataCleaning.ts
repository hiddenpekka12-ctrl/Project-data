import { CleaningLogEntry, ColumnType, OutlierMethod, Row } from '../types/analytics';
import { detectOutliers } from './outliers';

function toNumber(v: unknown): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return null;
}

function makeLogEntry(operation: string, column: string | null, affectedRows: number, before: string, after: string): CleaningLogEntry {
  return {
    id: `log-${Date.now()}-${Math.round(Math.random() * 1000)}`,
    timestamp: new Date().toISOString(),
    operation,
    column,
    affectedRows,
    before,
    after,
  };
}

export interface CleaningStepResult {
  rows: Row[];
  log: CleaningLogEntry;
}

function rowSignature(row: Row, columns: string[]): string {
  return columns.map((c) => String(row[c] ?? '')).join('␟');
}

export function removeDuplicateRows(rows: Row[], columns: string[]): CleaningStepResult {
  const seen = new Set<string>();
  const result: Row[] = [];
  let removed = 0;
  rows.forEach((r) => {
    const sig = rowSignature(r, columns);
    if (seen.has(sig)) {
      removed += 1;
    } else {
      seen.add(sig);
      result.push(r);
    }
  });
  return {
    rows: result,
    log: makeLogEntry('Removed duplicate rows', null, removed, `${rows.length} rows`, `${result.length} rows`),
  };
}

export function fillMissingNumeric(rows: Row[], column: string, strategy: 'mean' | 'median' | 'zero'): CleaningStepResult {
  const values = rows.map((r) => toNumber(r[column])).filter((v): v is number => v !== null);
  const sorted = [...values].sort((a, b) => a - b);
  const mean = values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
  const median = sorted.length ? sorted[Math.floor(sorted.length / 2)] : 0;
  const fillValue = strategy === 'zero' ? 0 : strategy === 'median' ? median : mean;

  let affected = 0;
  const result = rows.map((r) => {
    if (r[column] === null || r[column] === '') {
      affected += 1;
      return { ...r, [column]: fillValue };
    }
    return r;
  });
  return {
    rows: result,
    log: makeLogEntry(`Filled missing numeric values (${strategy})`, column, affected, 'missing', fillValue.toFixed(2)),
  };
}

export function fillMissingCategorical(rows: Row[], column: string, strategy: 'mode' | 'constant', constant = 'Unknown'): CleaningStepResult {
  const freq = new Map<string, number>();
  rows.forEach((r) => {
    const v = r[column];
    if (v !== null && v !== '') freq.set(String(v), (freq.get(String(v)) ?? 0) + 1);
  });
  const mode = Array.from(freq.entries()).sort((a, b) => b[1] - a[1])[0]?.[0] ?? constant;
  const fillValue = strategy === 'mode' ? mode : constant;

  let affected = 0;
  const result = rows.map((r) => {
    if (r[column] === null || r[column] === '') {
      affected += 1;
      return { ...r, [column]: fillValue };
    }
    return r;
  });
  return {
    rows: result,
    log: makeLogEntry(`Filled missing categorical values (${strategy})`, column, affected, 'missing', fillValue),
  };
}

export function convertColumnType(rows: Row[], column: string, targetType: ColumnType): CleaningStepResult {
  let affected = 0;
  const result = rows.map((r) => {
    const original = r[column];
    if (original === null || original === '') return r;
    let converted: string | number | boolean | null = original;
    if (targetType === 'numeric') {
      const n = toNumber(original);
      converted = n;
    } else if (targetType === 'text' || targetType === 'categorical') {
      converted = String(original);
    } else if (targetType === 'boolean') {
      converted = String(original).toLowerCase() === 'true';
    } else if (targetType === 'date') {
      const t = Date.parse(String(original));
      converted = isNaN(t) ? original : new Date(t).toISOString().slice(0, 10);
    }
    if (converted !== original) affected += 1;
    return { ...r, [column]: converted };
  });
  return {
    rows: result,
    log: makeLogEntry(`Converted column type to ${targetType}`, column, affected, 'mixed types', targetType),
  };
}

export function standardizeTextColumn(rows: Row[], column: string, mode: 'trim' | 'lowercase' | 'uppercase' | 'titlecase'): CleaningStepResult {
  let affected = 0;
  const apply = (s: string): string => {
    const trimmed = s.trim();
    if (mode === 'trim') return trimmed;
    if (mode === 'lowercase') return trimmed.toLowerCase();
    if (mode === 'uppercase') return trimmed.toUpperCase();
    return trimmed.replace(/\w\S*/g, (t) => t.charAt(0).toUpperCase() + t.slice(1).toLowerCase());
  };
  const result = rows.map((r) => {
    const v = r[column];
    if (typeof v !== 'string') return r;
    const next = apply(v);
    if (next !== v) affected += 1;
    return { ...r, [column]: next };
  });
  return {
    rows: result,
    log: makeLogEntry(`Standardized text (${mode})`, column, affected, 'inconsistent casing/spacing', mode),
  };
}

export function removeInvalidRows(rows: Row[], column: string): CleaningStepResult {
  let removed = 0;
  const result = rows.filter((r) => {
    const isInvalid = r[column] === null || r[column] === '';
    if (isInvalid) removed += 1;
    return !isInvalid;
  });
  return {
    rows: result,
    log: makeLogEntry('Removed rows with invalid/missing value', column, removed, `${rows.length} rows`, `${result.length} rows`),
  };
}

export function removeOutlierRows(rows: Row[], column: string, method: OutlierMethod): CleaningStepResult {
  const outlierResult = detectOutliers(rows, column, method);
  const flagged = new Set(outlierResult.outlierRowIndexes);
  const result = rows.filter((_, i) => !flagged.has(i));
  return {
    rows: result,
    log: makeLogEntry(`Removed outliers (${method.toUpperCase()})`, column, flagged.size, `${rows.length} rows`, `${result.length} rows`),
  };
}
