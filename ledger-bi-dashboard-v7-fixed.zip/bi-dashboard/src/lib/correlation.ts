import { CorrelationCell, Row } from '../types/analytics';

function toNumber(v: unknown): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return null;
}

export function pearsonCorrelation(a: number[], b: number[]): number {
  const n = Math.min(a.length, b.length);
  if (n === 0) return 0;
  const meanA = a.reduce((s, v) => s + v, 0) / n;
  const meanB = b.reduce((s, v) => s + v, 0) / n;
  let num = 0;
  let denomA = 0;
  let denomB = 0;
  for (let i = 0; i < n; i++) {
    const da = a[i] - meanA;
    const db = b[i] - meanB;
    num += da * db;
    denomA += da * da;
    denomB += db * db;
  }
  const denom = Math.sqrt(denomA * denomB);
  return denom === 0 ? 0 : num / denom;
}

function strengthOf(r: number): CorrelationCell['strength'] {
  const abs = Math.abs(r);
  if (abs >= 0.7) return 'strong';
  if (abs >= 0.3) return 'moderate';
  return 'weak';
}

/** Builds a correlation matrix across numeric columns, using only rows
 * where both columns have a value (pairwise deletion). Needs at least
 * two numeric columns and a handful of rows to be meaningful. */
export function buildCorrelationMatrix(rows: Row[], numericColumns: string[]): CorrelationCell[] {
  const cells: CorrelationCell[] = [];
  for (let i = 0; i < numericColumns.length; i++) {
    for (let j = i + 1; j < numericColumns.length; j++) {
      const colA = numericColumns[i];
      const colB = numericColumns[j];
      const pairs: [number, number][] = [];
      rows.forEach((r) => {
        const a = toNumber(r[colA]);
        const b = toNumber(r[colB]);
        if (a !== null && b !== null) pairs.push([a, b]);
      });
      const r = pairs.length >= 3 ? pearsonCorrelation(pairs.map((p) => p[0]), pairs.map((p) => p[1])) : 0;
      cells.push({
        columnA: colA,
        columnB: colB,
        r,
        strength: strengthOf(r),
        direction: Math.abs(r) < 0.05 ? 'none' : r > 0 ? 'positive' : 'negative',
      });
    }
  }
  return cells;
}
