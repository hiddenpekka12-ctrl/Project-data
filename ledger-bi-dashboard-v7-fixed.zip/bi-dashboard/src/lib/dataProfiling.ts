import {
  CategoricalProfile,
  ColumnProfile,
  ColumnType,
  DateProfile,
  DatasetOverview,
  NumericProfile,
  Row,
  TextProfile,
} from '../types/analytics';

function toNumber(v: unknown): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return null;
}

function quantile(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  if (sorted[base + 1] !== undefined) {
    return sorted[base] + rest * (sorted[base + 1] - sorted[base]);
  }
  return sorted[base];
}

export function profileNumericColumn(values: unknown[]): NumericProfile {
  const total = values.length;
  const nums = values.map(toNumber).filter((v): v is number => v !== null);
  const missing = total - nums.length;
  const sorted = [...nums].sort((a, b) => a - b);
  const mean = nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
  const variance = nums.length ? nums.reduce((a, b) => a + (b - mean) ** 2, 0) / nums.length : 0;

  return {
    type: 'numeric',
    count: nums.length,
    missing,
    missingPct: total ? (missing / total) * 100 : 0,
    mean,
    median: quantile(sorted, 0.5),
    min: sorted.length ? sorted[0] : 0,
    max: sorted.length ? sorted[sorted.length - 1] : 0,
    std: Math.sqrt(variance),
    q1: quantile(sorted, 0.25),
    q3: quantile(sorted, 0.75),
    unique: new Set(nums).size,
  };
}

export function profileCategoricalColumn(values: unknown[]): CategoricalProfile {
  const total = values.length;
  const present = values.filter((v) => v !== null && v !== '').map(String);
  const missing = total - present.length;
  const freq = new Map<string, number>();
  present.forEach((v) => freq.set(v, (freq.get(v) ?? 0) + 1));
  const sorted = Array.from(freq.entries()).sort((a, b) => b[1] - a[1]);

  return {
    type: 'categorical',
    count: present.length,
    missing,
    missingPct: total ? (missing / total) * 100 : 0,
    unique: freq.size,
    mostCommon: sorted[0]?.[0] ?? '—',
    mostCommonCount: sorted[0]?.[1] ?? 0,
    topValues: sorted.slice(0, 5).map(([value, count]) => ({ value, count })),
  };
}

export function profileDateColumn(values: unknown[]): DateProfile {
  const total = values.length;
  const present = values.filter((v) => v !== null && v !== '');
  const timestamps = present.map((v) => Date.parse(String(v))).filter((t) => !isNaN(t));
  const missing = total - timestamps.length;
  const min = timestamps.length ? Math.min(...timestamps) : 0;
  const max = timestamps.length ? Math.max(...timestamps) : 0;

  return {
    type: 'date',
    count: timestamps.length,
    missing,
    missingPct: total ? (missing / total) * 100 : 0,
    min: timestamps.length ? new Date(min).toISOString().slice(0, 10) : '—',
    max: timestamps.length ? new Date(max).toISOString().slice(0, 10) : '—',
    rangeDays: timestamps.length ? Math.round((max - min) / (1000 * 60 * 60 * 24)) : 0,
  };
}

export function profileTextColumn(values: unknown[]): TextProfile {
  const total = values.length;
  const present = values.filter((v) => v !== null && v !== '');
  return {
    type: 'text',
    count: present.length,
    missing: total - present.length,
    missingPct: total ? ((total - present.length) / total) * 100 : 0,
    unique: new Set(present.map(String)).size,
  };
}

export function profileColumn(type: ColumnProfile['type'], values: unknown[]): ColumnProfile {
  switch (type) {
    case 'numeric':
      return profileNumericColumn(values);
    case 'date':
      return profileDateColumn(values);
    case 'categorical':
      return profileCategoricalColumn(values);
    default:
      return profileTextColumn(values);
  }
}

export function profileDataset(
  columns: string[],
  columnTypes: Record<string, ColumnType>,
  rows: Row[]
): Record<string, ColumnProfile> {
  const profiles: Record<string, ColumnProfile> = {};
  columns.forEach((c) => {
    const type = columnTypes[c] === 'boolean' ? 'categorical' : columnTypes[c];
    profiles[c] = profileColumn(type, rows.map((r) => r[c]));
  });
  return profiles;
}

function rowSignature(row: Row, columns: string[]): string {
  return columns.map((c) => String(row[c] ?? '')).join('␟');
}

export function computeOverview(
  columns: string[],
  columnTypes: Record<string, ColumnType>,
  rows: Row[]
): DatasetOverview {
  const missingValues = rows.reduce(
    (sum, r) => sum + columns.filter((c) => r[c] === null || r[c] === '').length,
    0
  );
  const seen = new Set<string>();
  let duplicateRows = 0;
  rows.forEach((r) => {
    const sig = rowSignature(r, columns);
    if (seen.has(sig)) duplicateRows += 1;
    else seen.add(sig);
  });

  const counts = { numeric: 0, text: 0, date: 0, categorical: 0 };
  columns.forEach((c) => {
    const t = columnTypes[c];
    if (t === 'numeric') counts.numeric += 1;
    else if (t === 'date') counts.date += 1;
    else if (t === 'categorical' || t === 'boolean') counts.categorical += 1;
    else counts.text += 1;
  });

  return {
    rows: rows.length,
    columns: columns.length,
    numericColumns: counts.numeric,
    textColumns: counts.text,
    dateColumns: counts.date,
    categoricalColumns: counts.categorical,
    missingValues,
    duplicateRows,
  };
}
