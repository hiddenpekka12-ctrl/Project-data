import { ErrorMetrics } from './types';

/**
 * MAPE is undefined (returns null, not Infinity or a fabricated number)
 * when actuals are all zero or too close to zero to be meaningful —
 * Section 13's explicit safety requirement. sMAPE is reported alongside
 * since it handles small/zero values more gracefully.
 */
export function computeErrorMetrics(actuals: number[], forecasts: number[]): ErrorMetrics {
  const n = Math.min(actuals.length, forecasts.length);
  if (n === 0) {
    return { mae: 0, mse: 0, rmse: 0, mape: null, smape: 0, bias: 0, biasLabel: 'Approximately unbiased' };
  }

  let sumAbsError = 0;
  let sumSqError = 0;
  let sumError = 0;
  let sumAbsPct = 0;
  let pctCount = 0;
  let sumSmape = 0;

  for (let i = 0; i < n; i++) {
    const a = actuals[i];
    const f = forecasts[i];
    const error = f - a;
    sumAbsError += Math.abs(error);
    sumSqError += error ** 2;
    sumError += error;

    if (Math.abs(a) > 1e-9) {
      sumAbsPct += Math.abs(error / a);
      pctCount += 1;
    }

    const denom = (Math.abs(a) + Math.abs(f)) / 2;
    sumSmape += denom > 1e-9 ? Math.abs(error) / denom : 0;
  }

  const mae = sumAbsError / n;
  const mse = sumSqError / n;
  const rmse = Math.sqrt(mse);
  const mape = pctCount / n < 0.5 ? null : (sumAbsPct / pctCount) * 100; // undefined if most actuals are ~0
  const smape = (sumSmape / n) * 100;
  const bias = sumError / n;

  const meanAbsActual = actuals.slice(0, n).reduce((s, v) => s + Math.abs(v), 0) / n || 1;
  const biasLabel: ErrorMetrics['biasLabel'] = Math.abs(bias) / meanAbsActual < 0.03 ? 'Approximately unbiased' : bias > 0 ? 'Overpredicts' : 'Underpredicts';

  return { mae, mse, rmse, mape, smape, bias, biasLabel };
}
