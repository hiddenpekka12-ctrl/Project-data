import { ForecastRun } from './types';

export interface TrendContinuationAnswer {
  answer: string;
  confidence: string;
  caveat: string;
}

/** Takes an already-built ForecastRun (for whatever metric a V5 problem
 * is about) and phrases it as an answer to "is this trend likely to
 * continue?" — never claims certainty, always carries the forecast's own
 * confidence label and limitations forward. */
export function answerTrendContinuation(run: ForecastRun, metricName: string): TrendContinuationAnswer {
  const first = run.scenario.base[0];
  const last = run.scenario.base[run.scenario.base.length - 1];
  const direction = last.pointForecast > first.pointForecast ? 'continuing to rise' : last.pointForecast < first.pointForecast ? 'continuing to decline' : 'staying roughly flat';

  return {
    answer: `Based on the ${run.selectedModel} model fitted to historical ${metricName}, the trend is projected as ${direction} over the next ${run.config.horizon} period(s), from an estimated ${first.pointForecast.toFixed(0)} to ${last.pointForecast.toFixed(0)}.`,
    confidence: `${run.confidence} confidence — ${run.confidenceReasons.length ? run.confidenceReasons.join(' ') : 'validation performance and data readiness both support this level.'}`,
    caveat: 'This projects the historical pattern forward under the stated assumptions; it does not account for management actions taken in response to the V5 diagnosis, which could change the actual outcome.',
  };
}
