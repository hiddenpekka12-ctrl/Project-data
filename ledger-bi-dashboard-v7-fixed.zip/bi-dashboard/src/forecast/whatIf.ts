import { ForecastPoint } from './types';

/** A single transparent growth-rate adjustment applied to the base
 * forecast — deliberately simple per Section 33. Full multi-variable
 * scenario/stress testing is V7's job, not this. */
export function applyWhatIfGrowthAdjustment(base: ForecastPoint[], adjustmentPct: number): ForecastPoint[] {
  return base.map((p) => ({ ...p, pointForecast: p.pointForecast * (1 + adjustmentPct / 100), lowerBound: null, upperBound: null }));
}
