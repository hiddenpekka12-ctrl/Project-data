import { BacktestResult, ForecastModelKey } from './types';
import { fitModel } from './models';
import { computeErrorMetrics } from './errorMetrics';

/**
 * Expanding-window chronological backtest: train on data up to time t,
 * forecast one step ahead, compare to the actual at t+1, then grow the
 * window and repeat. Never shuffles observations (Section 14).
 */
export function backtestModel(values: number[], model: ForecastModelKey, seasonalPeriod: number | null, minTrainSize: number): BacktestResult {
  const testForecasts: number[] = [];
  const testActuals: number[] = [];
  const trainFittedAll: number[] = [];
  const trainActualAll: number[] = [];

  let windowCount = 0;
  for (let cut = minTrainSize; cut < values.length; cut++) {
    const trainSlice = values.slice(0, cut);
    const fit = fitModel(model, trainSlice, seasonalPeriod);
    const forecast = fit.forecastFn(1);
    testForecasts.push(forecast);
    testActuals.push(values[cut]);
    windowCount += 1;

    if (cut === values.length - 1) {
      trainFittedAll.push(...fit.fittedValues);
      trainActualAll.push(...trainSlice);
    }
  }

  const metrics = computeErrorMetrics(testActuals, testForecasts);
  const trainMetrics = trainFittedAll.length ? computeErrorMetrics(trainActualAll, trainFittedAll) : null;

  const overfittingFlag = trainMetrics !== null && metrics.rmse > 0 && trainMetrics.rmse < metrics.rmse * 0.4;
  const meanAbsActual = testActuals.reduce((s, v) => s + Math.abs(v), 0) / (testActuals.length || 1) || 1;
  const underfittingFlag = metrics.rmse / meanAbsActual > 0.5 && trainMetrics !== null && trainMetrics.rmse / meanAbsActual > 0.3;

  return { model, windowCount, metrics, trainMetrics, overfittingFlag, underfittingFlag };
}

export function compareModels(values: number[], models: ForecastModelKey[], seasonalPeriod: number | null): BacktestResult[] {
  const minTrainSize = Math.max(3, Math.floor(values.length * 0.6));
  if (values.length - minTrainSize < 1) {
    const fallbackTrain = Math.max(1, values.length - 1);
    return models.map((m) => backtestModel(values, m, seasonalPeriod, fallbackTrain));
  }
  return models.map((m) => backtestModel(values, m, seasonalPeriod, minTrainSize));
}

/** Ranks by validation RMSE, not training fit — the whole point of
 * chronological backtesting (Section 17). */
export function rankBacktests(results: BacktestResult[]): BacktestResult[] {
  return [...results].sort((a, b) => a.metrics.rmse - b.metrics.rmse);
}
