import { Row } from '../types/analytics';
import { buildTimeSeries, validateTimeSeries, MIN_OBSERVATIONS } from './timeSeriesPrep';
import { buildHistoricalAnalysis } from './historicalAnalysis';
import { applicableModels } from './models';
import { compareModels, rankBacktests } from './backtesting';
import { buildForecastIntervals, buildScenarios, assessForecastConfidence } from './forecastIntervals';
import { ForecastConfig, ForecastRun } from './types';

const SEASONAL_PERIOD_BY_FREQUENCY: Record<ForecastConfig['frequency'], number | null> = {
  daily: 7,
  weekly: null,
  monthly: 12,
  quarterly: 4,
  annual: null,
};

export function buildForecastRun(rows: Row[], config: ForecastConfig): ForecastRun | { insufficientData: true; message: string } {
  const series = buildTimeSeries(rows, config.dateColumn, config.targetColumn, config.frequency);
  const seasonalPeriod = SEASONAL_PERIOD_BY_FREQUENCY[config.frequency];
  const minObs = seasonalPeriod ? MIN_OBSERVATIONS.moderate : MIN_OBSERVATIONS.simple;

  const validation = validateTimeSeries(series, config.frequency, minObs);
  if (series.length < 3) {
    return {
      insufficientData: true,
      message: 'Insufficient historical data for reliable forecasting. Need at least 3 observations; this dataset has ' + series.length + '. Try a coarser frequency (e.g. monthly instead of weekly) or a longer date range.',
    };
  }

  const values = series.map((p) => p.value);
  const historical = buildHistoricalAnalysis(series, seasonalPeriod);
  const models = applicableModels(series.length, historical.seasonality.detected, seasonalPeriod);
  const backtests = rankBacktests(compareModels(values, models, seasonalPeriod));
  const winner = backtests[0];

  const base = buildForecastIntervals(series[series.length - 1].date, config.frequency, config.horizon, values, winner.model, seasonalPeriod, winner.metrics.rmse);
  const scenario = buildScenarios(base, 10, -10); // default +/-10% management scenario, adjustable via What-If
  const { level: confidence, reasons: confidenceReasons } = assessForecastConfidence(validation, historical, winner);

  const assumptions = [
    `Historical period used: ${series.length} ${config.frequency} observations from ${new Date(series[0].date).toLocaleDateString()} to ${new Date(series[series.length - 1].date).toLocaleDateString()}.`,
    `Model: ${winner.model}, selected by lowest validation RMSE across ${models.length} candidate model(s).`,
    'The forecast assumes the historical pattern (trend/seasonality) continues without a structural change.',
  ];

  const limitations: string[] = [];
  if (validation.readinessLabel !== 'Sufficient') limitations.push(`Data readiness is "${validation.readinessLabel}" — treat this forecast with extra caution.`);
  if (historical.structuralBreaks.length > 0) limitations.push('A structural break was detected in the historical series — the forecast may not reflect a genuine regime change.');
  if (config.horizon > series.length) limitations.push('The forecast horizon is longer than the available historical history — uncertainty compounds quickly beyond this point.');
  if (winner.overfittingFlag) limitations.push('The selected model shows signs of overfitting.');
  if (winner.underfittingFlag) limitations.push('The selected model shows signs of underfitting — it may be too simple to capture the pattern.');

  return {
    config,
    validation,
    historical,
    backtests,
    selectedModel: winner.model,
    scenario,
    confidence,
    confidenceReasons,
    assumptions,
    limitations,
  };
}

export function isInsufficientData(result: ForecastRun | { insufficientData: true; message: string }): result is { insufficientData: true; message: string } {
  return 'insufficientData' in result;
}
