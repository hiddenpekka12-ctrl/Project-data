import { ForecastAlert, ForecastRun } from './types';

export function generateForecastAlerts(run: ForecastRun): ForecastAlert[] {
  const alerts: ForecastAlert[] = [];
  const historicalLast = run.historical.mean; // reference point; caller may pass last actual instead where more meaningful
  const base = run.scenario.base;
  if (base.length === 0) return alerts;
  const last = base[base.length - 1];

  const pctChange = historicalLast !== 0 ? ((last.pointForecast - historicalLast) / Math.abs(historicalLast)) * 100 : 0;

  if (pctChange < -10) {
    alerts.push({
      id: `alert-decline-${run.config.id}`,
      label: `Projected decline in ${run.config.targetColumn}`,
      severity: pctChange < -25 ? 'critical' : 'warning',
      metric: run.config.targetColumn,
      currentValue: historicalLast.toFixed(0),
      forecastValue: last.pointForecast.toFixed(0),
      threshold: '-10%',
      horizon: `${run.config.horizon} ${run.config.frequency} period(s)`,
      model: run.selectedModel,
      uncertaintyNote: last.lowerBound !== null && last.upperBound !== null ? `Interval: ${last.lowerBound.toFixed(0)} to ${last.upperBound.toFixed(0)}` : 'Interval not available for this model.',
      recommendedInvestigation: `Review the Historical Analysis tab for the driver behind this trend before treating it as certain.`,
    });
  }

  if (run.confidence === 'Low') {
    alerts.push({
      id: `alert-confidence-${run.config.id}`,
      label: 'Low forecast confidence',
      severity: 'warning',
      metric: run.config.targetColumn,
      currentValue: 'n/a',
      forecastValue: 'n/a',
      threshold: 'Confidence < Medium',
      horizon: `${run.config.horizon} ${run.config.frequency} period(s)`,
      model: run.selectedModel,
      uncertaintyNote: run.confidenceReasons.join(' '),
      recommendedInvestigation: 'Improve data quality/length before relying heavily on this forecast for decisions.',
    });
  }

  return alerts;
}
