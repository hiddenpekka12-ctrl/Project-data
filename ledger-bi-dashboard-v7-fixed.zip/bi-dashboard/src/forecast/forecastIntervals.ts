import { BacktestResult, ForecastConfidence, ForecastModelKey, ForecastPoint, HistoricalAnalysis, ScenarioForecast, TimeSeriesValidation } from './types';
import { fitModel } from './models';

/** Prediction interval width derived from the winning model's own
 * backtest residual spread (RMSE) — not an arbitrary fixed percentage. A
 * wider interval directly reflects worse historical validation performance. */
export function buildForecastIntervals(
  lastDate: string,
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'annual',
  horizon: number,
  values: number[],
  model: ForecastModelKey,
  seasonalPeriod: number | null,
  backtestRmse: number
): ForecastPoint[] {
  const fit = fitModel(model, values, seasonalPeriod);
  const points: ForecastPoint[] = [];
  const start = new Date(lastDate);

  for (let step = 1; step <= horizon; step++) {
    const date = advanceDate(start, frequency, step);
    const point = fit.forecastFn(step);
    // Uncertainty widens with horizon distance — a simple, transparent
    // scaling (sqrt of steps ahead), not a fabricated precise model.
    const widening = backtestRmse * Math.sqrt(step);
    points.push({
      date: date.toISOString(),
      pointForecast: point,
      lowerBound: backtestRmse > 0 ? point - 1.28 * widening : null, // ~80% interval under a normal-residual assumption
      upperBound: backtestRmse > 0 ? point + 1.28 * widening : null,
    });
  }
  return points;
}

function advanceDate(start: Date, frequency: string, steps: number): Date {
  const d = new Date(start);
  if (frequency === 'daily') d.setUTCDate(d.getUTCDate() + steps);
  else if (frequency === 'weekly') d.setUTCDate(d.getUTCDate() + steps * 7);
  else if (frequency === 'monthly') d.setUTCMonth(d.getUTCMonth() + steps);
  else if (frequency === 'quarterly') d.setUTCMonth(d.getUTCMonth() + steps * 3);
  else d.setUTCFullYear(d.getUTCFullYear() + steps);
  return d;
}

/** Upside/downside are stated management scenarios (Section 20), not
 * automatically generated probabilities — built by applying a percentage
 * adjustment to the base case, with the assumption stated plainly. */
export function buildScenarios(base: ForecastPoint[], upsidePct: number, downsidePct: number): ScenarioForecast {
  return {
    base,
    upside: base.map((p) => ({ ...p, pointForecast: p.pointForecast * (1 + upsidePct / 100), lowerBound: null, upperBound: null })),
    downside: base.map((p) => ({ ...p, pointForecast: p.pointForecast * (1 + downsidePct / 100), lowerBound: null, upperBound: null })),
    upsideAssumption: `${upsidePct >= 0 ? '+' : ''}${upsidePct}% versus the base case model estimate.`,
    downsideAssumption: `${downsidePct >= 0 ? '+' : ''}${downsidePct}% versus the base case model estimate.`,
  };
}

/**
 * Confidence is a qualitative label, not a calculated probability
 * (Section 35) — based on data readiness, validation performance, and
 * historical consistency.
 */
export function assessForecastConfidence(validation: TimeSeriesValidation, historical: HistoricalAnalysis, winningBacktest: BacktestResult): { level: ForecastConfidence; reasons: string[] } {
  const reasons: string[] = [];
  let points = 0;

  if (validation.readinessLabel === 'Sufficient') points += 1;
  else reasons.push(`Data readiness is only "${validation.readinessLabel}" (${validation.readinessPct}%).`);

  if (historical.volatility.level !== 'High') points += 1;
  else reasons.push('Historical volatility is high, which widens forecast uncertainty.');

  const meanAbsActual = Math.abs(historical.mean) || 1;
  if (winningBacktest.metrics.rmse / meanAbsActual < 0.25) points += 1;
  else reasons.push('Backtest validation error is large relative to the typical value of this metric.');

  if (!winningBacktest.overfittingFlag) points += 1;
  else reasons.push('The selected model shows signs of overfitting (training fit much better than validation).');

  if (historical.structuralBreaks.length === 0) points += 1;
  else reasons.push('A structural break was detected in the historical pattern, which reduces confidence in extrapolating it forward.');

  const level: ForecastConfidence = points >= 4 ? 'High' : points >= 2 ? 'Medium' : 'Low';
  return { level, reasons };
}
