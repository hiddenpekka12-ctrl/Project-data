import { HistoricalAnalysis, SeasonalityResult, StructuralBreakFlag, TimeSeriesPoint, TrendResult, VolatilityResult } from './types';
import { detectOutliersIqr } from '../lib/outliers';
import { Row } from '../types/analytics';

function quantileSorted(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  return sorted[base + 1] !== undefined ? sorted[base] + rest * (sorted[base + 1] - sorted[base]) : sorted[base];
}

function linearRegressionSlope(values: number[]): number {
  const n = values.length;
  const xMean = (n - 1) / 2;
  const yMean = values.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let den = 0;
  values.forEach((y, x) => {
    num += (x - xMean) * (y - yMean);
    den += (x - xMean) ** 2;
  });
  return den === 0 ? 0 : num / den;
}

function detectTrend(values: number[]): TrendResult {
  const slope = linearRegressionSlope(values);
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const relativeSlope = mean !== 0 ? (slope * values.length) / Math.abs(mean) : 0;

  // Compare first-half vs second-half slope to catch accelerating/slowing growth.
  const mid = Math.floor(values.length / 2);
  const firstHalfSlope = values.length >= 6 ? linearRegressionSlope(values.slice(0, mid)) : slope;
  const secondHalfSlope = values.length >= 6 ? linearRegressionSlope(values.slice(mid)) : slope;

  let direction: TrendResult['direction'];
  const strengthLabel: TrendResult['strengthLabel'] = Math.abs(relativeSlope) > 0.5 ? 'Strong' : Math.abs(relativeSlope) > 0.15 ? 'Moderate' : 'Weak';

  if (Math.abs(relativeSlope) < 0.05) {
    direction = 'Stable';
  } else if (values.length >= 6 && Math.sign(firstHalfSlope) === Math.sign(secondHalfSlope) && Math.abs(secondHalfSlope) > Math.abs(firstHalfSlope) * 1.3) {
    direction = 'Accelerating growth';
  } else if (values.length >= 6 && Math.sign(firstHalfSlope) === Math.sign(secondHalfSlope) && Math.abs(secondHalfSlope) < Math.abs(firstHalfSlope) * 0.7) {
    direction = 'Slowing growth';
  } else if (strengthLabel === 'Weak') {
    direction = 'Volatile / uncertain';
  } else {
    direction = slope > 0 ? 'Increasing' : 'Decreasing';
  }

  return { direction, slopePerPeriod: slope, strengthLabel };
}

/** A simple, transparent seasonality check: for a candidate periodicity
 * (e.g. 12 for monthly-yearly), compares the variance explained by
 * period-position averages against total variance. Needs at least two
 * full cycles — otherwise reports "not enough history", never guesses. */
function detectSeasonality(values: number[], candidatePeriod: number): SeasonalityResult {
  if (values.length < candidatePeriod * 2) {
    return { detected: false, periodicity: null, strengthPct: null, description: 'Not enough history to check for seasonality (need at least two full cycles).' };
  }
  const grandMean = values.reduce((a, b) => a + b, 0) / values.length;
  const totalVariance = values.reduce((s, v) => s + (v - grandMean) ** 2, 0) / values.length;
  if (totalVariance === 0) return { detected: false, periodicity: null, strengthPct: null, description: 'Series is constant — no seasonality to detect.' };

  const positionSums = new Array(candidatePeriod).fill(0);
  const positionCounts = new Array(candidatePeriod).fill(0);
  values.forEach((v, i) => {
    const pos = i % candidatePeriod;
    positionSums[pos] += v;
    positionCounts[pos] += 1;
  });
  const positionMeans = positionSums.map((s, i) => s / (positionCounts[i] || 1));
  const seasonalVariance = positionMeans.reduce((s, m) => s + (m - grandMean) ** 2, 0) / candidatePeriod;
  const strengthPct = Math.min(100, (seasonalVariance / totalVariance) * 100);

  const detected = strengthPct > 20;
  return {
    detected,
    periodicity: detected ? candidatePeriod : null,
    strengthPct: Math.round(strengthPct),
    description: detected
      ? `An observed seasonal pattern repeats roughly every ${candidatePeriod} periods (${Math.round(strengthPct)}% of variance explained by period position).`
      : 'No clear repeating seasonal pattern detected at this periodicity.',
  };
}

function detectVolatility(values: number[]): VolatilityResult {
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length;
  const stdDev = Math.sqrt(variance);
  const coefficientOfVariation = mean !== 0 ? Math.abs(stdDev / mean) : null;

  const pctChanges: number[] = [];
  for (let i = 1; i < values.length; i++) {
    if (values[i - 1] !== 0) pctChanges.push(Math.abs((values[i] - values[i - 1]) / values[i - 1]));
  }
  const meanAbsPctChange = pctChanges.length ? (pctChanges.reduce((a, b) => a + b, 0) / pctChanges.length) * 100 : null;

  const cv = coefficientOfVariation ?? 0;
  const level: VolatilityResult['level'] = cv > 0.5 ? 'High' : cv > 0.2 ? 'Moderate' : 'Low';

  return { stdDev, coefficientOfVariation, meanAbsPctChange, level };
}

/** Flags a large shift between the first and second half of the series —
 * a candidate structural break, never auto-diagnosed. */
function detectStructuralBreaks(series: TimeSeriesPoint[]): StructuralBreakFlag[] {
  if (series.length < 8) return [];
  const mid = Math.floor(series.length / 2);
  const firstHalf = series.slice(0, mid).map((p) => p.value);
  const secondHalf = series.slice(mid).map((p) => p.value);
  const meanFirst = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length;
  const meanSecond = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length;
  if (meanFirst === 0) return [];
  const change = Math.abs((meanSecond - meanFirst) / meanFirst);
  if (change > 0.4) {
    return [{ atDate: series[mid].date, description: `Historical pattern changed significantly around this period (${(change * 100).toFixed(0)}% shift in average level). Cause not automatically determined — investigate.` }];
  }
  return [];
}

export function buildHistoricalAnalysis(series: TimeSeriesPoint[], seasonalPeriod: number | null): HistoricalAnalysis {
  const values = series.map((p) => p.value);
  const sorted = [...values].sort((a, b) => a - b);
  const mean = values.reduce((a, b) => a + b, 0) / (values.length || 1);
  const variance = values.reduce((s, v) => s + (v - mean) ** 2, 0) / (values.length || 1);

  const rowsForOutliers: Row[] = series.map((p) => ({ value: p.value }));
  const outlierResult = values.length >= 4 ? detectOutliersIqr(rowsForOutliers, 'value') : null;

  const growthPct = values.length >= 2 && values[0] !== 0 ? ((values[values.length - 1] - values[0]) / Math.abs(values[0])) * 100 : null;

  return {
    count: values.length,
    mean,
    median: quantileSorted(sorted, 0.5),
    min: sorted[0] ?? 0,
    max: sorted[sorted.length - 1] ?? 0,
    stdDev: Math.sqrt(variance),
    growthPct,
    trend: values.length >= 3 ? detectTrend(values) : { direction: 'Stable', slopePerPeriod: 0, strengthLabel: 'Weak' },
    seasonality: seasonalPeriod ? detectSeasonality(values, seasonalPeriod) : { detected: false, periodicity: null, strengthPct: null, description: 'No seasonal periodicity applicable to this frequency.' },
    volatility: values.length >= 2 ? detectVolatility(values) : { stdDev: 0, coefficientOfVariation: null, meanAbsPctChange: null, level: 'Low' },
    outlierIndexes: outlierResult?.outlierRowIndexes ?? [],
    structuralBreaks: detectStructuralBreaks(series),
  };
}
