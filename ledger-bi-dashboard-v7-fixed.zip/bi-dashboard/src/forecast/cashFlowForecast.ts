import { PeriodModel } from '../finance/buildFinanceModel';
import { FinancialForecastLine } from './financialForecast';

export interface CashForecastLine {
  periodLabel: string;
  openingCash: number;
  operatingCashFlowEstimate: number;
  closingCash: number;
}

/**
 * Opening Cash + Operating Cash Flow = Closing Cash. Investing and
 * financing activity are NOT forecasted — Section 24 explicitly forbids
 * inventing future financing/investment. Operating cash flow is
 * approximated as forecasted net profit + the historical average
 * depreciation add-back; working-capital changes are not projected
 * (stated as a limitation, not silently assumed to be zero without
 * saying so).
 */
export function buildCashForecast(lastActualCash: number, financialLines: FinancialForecastLine[]): CashForecastLine[] {
  let opening = lastActualCash;
  return financialLines.map((line) => {
    const operatingCashFlowEstimate = line.netProfit + line.depreciation;
    const closing = opening + operatingCashFlowEstimate;
    const result: CashForecastLine = { periodLabel: line.periodLabel, openingCash: opening, operatingCashFlowEstimate, closingCash: closing };
    opening = closing;
    return result;
  });
}

export interface CashRunwayResult {
  applicable: boolean;
  runwayPeriods: number | null;
  reason: string;
}

/** Cash Runway ≈ Available Cash / Net Burn Rate — only applicable when
 * the business has a genuine, meaningful cash burn. Never applied
 * blindly to a business with positive or irregular cash flow. */
export function computeCashRunway(currentCash: number, recentPeriods: PeriodModel[]): CashRunwayResult {
  if (recentPeriods.length < 2) {
    return { applicable: false, runwayPeriods: null, reason: 'Need at least 2 recent periods of actual cash flow to estimate a burn rate.' };
  }
  const ocfValues = recentPeriods.map((p) => p.cashFlow.operatingCashFlow);
  const avgOcf = ocfValues.reduce((a, b) => a + b, 0) / ocfValues.length;

  if (avgOcf >= 0) {
    return { applicable: false, runwayPeriods: null, reason: 'Average operating cash flow over the recent periods is positive — cash runway is not a meaningful concept while cash flow is positive.' };
  }
  const burnRate = Math.abs(avgOcf);
  return { applicable: true, runwayPeriods: currentCash / burnRate, reason: `Based on an average burn rate of ${burnRate.toFixed(0)} per period over the last ${recentPeriods.length} periods.` };
}
