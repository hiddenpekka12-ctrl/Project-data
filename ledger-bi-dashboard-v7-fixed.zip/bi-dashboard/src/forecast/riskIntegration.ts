import { FinancialForecastLine } from './financialForecast';
import { CashForecastLine } from './cashFlowForecast';
import { ForecastRiskSignal } from './types';
import { KeyRiskIndicator } from '../risk/types';

/** Every signal is phrased as "potential", per Section 30's explicit
 * requirement — a forecast never proves a future risk event. */
export function deriveForecastRiskSignals(financialLines: FinancialForecastLine[], cashLines: CashForecastLine[], kris: KeyRiskIndicator[]): ForecastRiskSignal[] {
  const signals: ForecastRiskSignal[] = [];
  if (financialLines.length === 0) return signals;

  const first = financialLines[0];
  const last = financialLines[financialLines.length - 1];

  if (last.revenue < first.revenue) {
    signals.push({
      forecastLabel: `Revenue forecast declines from ${first.revenue.toFixed(0)} to ${last.revenue.toFixed(0)} over the horizon.`,
      potentialRisk: 'Potential revenue/strategic risk signal based on forecast — not a certainty.',
      relatedKriName: kris.find((k) => k.category === 'strategic')?.name ?? null,
      managementAttention: 'Monitor whether early actuals track the forecast; investigate demand drivers if the pattern persists.',
    });
  }

  if (last.netProfit < first.netProfit) {
    signals.push({
      forecastLabel: `Net profit forecast declines from ${first.netProfit.toFixed(0)} to ${last.netProfit.toFixed(0)} over the horizon.`,
      potentialRisk: 'Potential profitability risk signal based on forecast.',
      relatedKriName: kris.find((k) => k.category === 'financial')?.name ?? null,
      managementAttention: 'Review the Financial Forecast tab\'s cost ratio assumptions and validate against early actuals.',
    });
  }

  const negativeCashPeriod = cashLines.find((c) => c.closingCash < 0);
  if (negativeCashPeriod) {
    signals.push({
      forecastLabel: `Projected closing cash goes negative by period ${negativeCashPeriod.periodLabel}.`,
      potentialRisk: 'Potential liquidity risk signal based on forecast — this is a projection under stated assumptions, not a guarantee.',
      relatedKriName: kris.find((k) => k.metric.toLowerCase().includes('cash') || k.metric.toLowerCase().includes('ratio'))?.name ?? null,
      managementAttention: 'Review financing options and cost flexibility well before this period if the trend is confirmed by early actuals.',
    });
  }

  return signals;
}
