import { ForecastModelKey } from './types';

export interface ModelFitResult {
  fittedValues: number[]; // one per input value, for backtesting comparison against actuals
  forecastFn: (stepsAhead: number) => number; // 1-indexed steps beyond the series end
}

function linearRegressionCoefficients(values: number[]): { slope: number; intercept: number } {
  const n = values.length;
  const xMean = (n - 1) / 2;
  const yMean = values.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let den = 0;
  values.forEach((y, x) => {
    num += (x - xMean) * (y - yMean);
    den += (x - xMean) ** 2;
  });
  const slope = den === 0 ? 0 : num / den;
  const intercept = yMean - slope * xMean;
  return { slope, intercept };
}

/** Model 1 — Naive: next period = last observed value. */
export function fitNaive(values: number[]): ModelFitResult {
  const last = values[values.length - 1] ?? 0;
  return {
    fittedValues: values.map((_, i) => (i === 0 ? values[0] : values[i - 1])),
    forecastFn: () => last,
  };
}

/** Model 2 — Mean: next period = historical average. */
export function fitMean(values: number[]): ModelFitResult {
  const mean = values.reduce((a, b) => a + b, 0) / (values.length || 1);
  return {
    fittedValues: values.map(() => mean),
    forecastFn: () => mean,
  };
}

/** Model 3 — Moving Average over a trailing window. */
export function fitMovingAverage(values: number[], window = 3): ModelFitResult {
  const w = Math.min(window, values.length);
  const fittedValues = values.map((_, i) => {
    const start = Math.max(0, i - w);
    const slice = values.slice(start, i);
    return slice.length ? slice.reduce((a, b) => a + b, 0) / slice.length : values[0];
  });
  const tail = values.slice(-w);
  const forecastValue = tail.reduce((a, b) => a + b, 0) / (tail.length || 1);
  return { fittedValues, forecastFn: () => forecastValue };
}

/** Model 4 — Weighted Moving Average: recent observations weighted more. */
export function fitWeightedMovingAverage(values: number[], window = 3): ModelFitResult {
  const w = Math.min(window, values.length);
  const weights = Array.from({ length: w }, (_, i) => i + 1); // 1..w, most recent gets highest weight

  const weightedOf = (slice: number[]): number => {
    if (slice.length === 0) return values[0] ?? 0;
    const localWeights = weights.slice(weights.length - slice.length);
    const localSum = localWeights.reduce((a, b) => a + b, 0);
    return slice.reduce((acc, v, i) => acc + v * localWeights[i], 0) / localSum;
  };

  const fittedValues = values.map((_, i) => weightedOf(values.slice(Math.max(0, i - w), i)));
  const forecastValue = weightedOf(values.slice(-w));
  return { fittedValues, forecastFn: () => forecastValue };
}

/** Model 5 — Exponential Smoothing (simple, single parameter alpha). */
export function fitExponentialSmoothing(values: number[], alpha = 0.3): ModelFitResult {
  const fittedValues: number[] = [];
  let level = values[0] ?? 0;
  values.forEach((v, i) => {
    fittedValues.push(i === 0 ? level : level);
    level = alpha * v + (1 - alpha) * level;
  });
  const finalLevel = level;
  return { fittedValues, forecastFn: () => finalLevel };
}

/** Model 6 — Trend / Linear Regression on time index. */
export function fitLinearRegression(values: number[]): ModelFitResult {
  const { slope, intercept } = linearRegressionCoefficients(values);
  return {
    fittedValues: values.map((_, x) => intercept + slope * x),
    forecastFn: (stepsAhead: number) => intercept + slope * (values.length - 1 + stepsAhead),
  };
}

/** Model 7 — Seasonal: trend + additive seasonal index by position, only
 * used when the caller has confirmed seasonality (never guessed here). */
export function fitSeasonal(values: number[], periodicity: number): ModelFitResult {
  const { slope, intercept } = linearRegressionCoefficients(values);
  const detrended = values.map((v, x) => v - (intercept + slope * x));
  const seasonalSums = new Array(periodicity).fill(0);
  const seasonalCounts = new Array(periodicity).fill(0);
  detrended.forEach((v, i) => {
    seasonalSums[i % periodicity] += v;
    seasonalCounts[i % periodicity] += 1;
  });
  const seasonalIndex = seasonalSums.map((s, i) => s / (seasonalCounts[i] || 1));

  return {
    fittedValues: values.map((_, x) => intercept + slope * x + seasonalIndex[x % periodicity]),
    forecastFn: (stepsAhead: number) => {
      const x = values.length - 1 + stepsAhead;
      return intercept + slope * x + seasonalIndex[x % periodicity];
    },
  };
}

export function fitModel(model: ForecastModelKey, values: number[], seasonalPeriod: number | null): ModelFitResult {
  switch (model) {
    case 'naive': return fitNaive(values);
    case 'mean': return fitMean(values);
    case 'movingAverage': return fitMovingAverage(values);
    case 'weightedMovingAverage': return fitWeightedMovingAverage(values);
    case 'exponentialSmoothing': return fitExponentialSmoothing(values);
    case 'linearRegression': return fitLinearRegression(values);
    case 'seasonal': return fitSeasonal(values, seasonalPeriod ?? 12);
  }
}

/** Which models are even applicable given data length and confirmed
 * seasonality — never runs a sophisticated model on too little data. */
export function applicableModels(observationCount: number, seasonalityConfirmed: boolean, seasonalPeriod: number | null): ForecastModelKey[] {
  const models: ForecastModelKey[] = ['naive', 'mean'];
  if (observationCount >= 4) models.push('movingAverage', 'weightedMovingAverage');
  if (observationCount >= 5) models.push('exponentialSmoothing');
  if (observationCount >= 6) models.push('linearRegression');
  if (seasonalityConfirmed && seasonalPeriod && observationCount >= seasonalPeriod * 2) models.push('seasonal');
  return models;
}
