import { PeriodModel } from '../finance/buildFinanceModel';
import { buildTimeSeries } from './timeSeriesPrep';
import { buildHistoricalAnalysis } from './historicalAnalysis';
import { applicableModels } from './models';
import { compareModels, rankBacktests } from './backtesting';
import { buildForecastIntervals } from './forecastIntervals';
import { ForecastFrequency, ForecastPoint } from './types';
import { Row } from '../types/analytics';

export interface FinancialForecastLine {
  periodLabel: string;
  revenue: number;
  cogs: number;
  grossProfit: number;
  operatingExpenses: number;
  ebitda: number;
  depreciation: number;
  ebit: number;
  interest: number;
  tax: number;
  netProfit: number;
}

export interface FinancialForecastResult {
  revenueForecast: ForecastPoint[];
  lines: FinancialForecastLine[];
  ratiosUsed: { avgCogsPctOfRevenue: number; avgOpexPctOfRevenue: number; avgDepreciation: number; avgInterest: number; avgTaxRate: number };
  method: string;
}

/**
 * Forecasts revenue with the generic time-series engine, then projects
 * COGS/OpEx/D&A/Interest/Tax using the AVERAGE of their actual historical
 * ratios from V3's own PeriodModel series — never re-deriving V3's
 * formulas, just projecting the real historical relationships forward.
 */
export function buildFinancialForecast(periods: PeriodModel[], horizon: number, frequency: ForecastFrequency): FinancialForecastResult | { insufficientData: true; message: string } {
  if (periods.length < 3) {
    return { insufficientData: true, message: `Insufficient historical data for reliable forecasting. Need at least 3 finance periods; this dataset has ${periods.length}.` };
  }

  const rows: Row[] = periods.map((p, i) => ({ date: new Date(2000, i, 1).toISOString(), revenue: p.income.revenue }));
  const series = buildTimeSeries(rows, 'date', 'revenue', frequency);
  const values = series.map((p) => p.value);
  const historical = buildHistoricalAnalysis(series, null);
  const models = applicableModels(series.length, false, null);
  const backtests = rankBacktests(compareModels(values, models, null));
  const winner = backtests[0];
  const revenueForecast = buildForecastIntervals(series[series.length - 1].date, frequency, horizon, values, winner.model, null, winner.metrics.rmse);

  const avgCogsPctOfRevenue = average(periods.map((p) => (p.income.revenue === 0 ? 0 : p.income.cogs / p.income.revenue)));
  const avgOpexPctOfRevenue = average(periods.map((p) => (p.income.revenue === 0 ? 0 : p.income.operatingExpenses / p.income.revenue)));
  const avgDepreciation = average(periods.map((p) => p.income.depreciation));
  const avgInterest = average(periods.map((p) => p.income.interest));
  const avgTaxRate = average(periods.map((p) => (p.income.profitBeforeTax <= 0 ? 0 : p.income.tax / p.income.profitBeforeTax)));

  const lines: FinancialForecastLine[] = revenueForecast.map((rf, i) => {
    const revenue = rf.pointForecast;
    const cogs = revenue * avgCogsPctOfRevenue;
    const grossProfit = revenue - cogs;
    const operatingExpenses = revenue * avgOpexPctOfRevenue;
    const ebitda = grossProfit - operatingExpenses;
    const depreciation = avgDepreciation;
    const ebit = ebitda - depreciation;
    const interest = avgInterest;
    const pbt = ebit - interest;
    const tax = Math.max(0, pbt * avgTaxRate);
    const netProfit = pbt - tax;
    return { periodLabel: `+${i + 1}`, revenue, cogs, grossProfit, operatingExpenses, ebitda, depreciation, ebit, interest, tax, netProfit };
  });

  return {
    revenueForecast,
    lines,
    ratiosUsed: { avgCogsPctOfRevenue, avgOpexPctOfRevenue, avgDepreciation, avgInterest, avgTaxRate },
    method: `Revenue forecast via ${winner.model} (lowest validation RMSE); COGS/OpEx projected as their average historical % of revenue across ${periods.length} periods; D&A and interest held at their historical average; tax applied at the average historical effective rate.`,
  };
}

function average(values: number[]): number {
  return values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
}
