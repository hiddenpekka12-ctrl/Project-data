/**
 * FORECAST ENGINE TYPES
 * ---------------------
 * Every forecast is visibly labeled and distinguished from historical
 * actuals (Section 48). Financial forecasts read V3's PeriodModel ratios
 * rather than re-deriving them; risk signals read V4's RiskModel shape.
 */

export type ForecastFrequency = 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'annual';

export type ForecastModelKey = 'naive' | 'mean' | 'movingAverage' | 'weightedMovingAverage' | 'exponentialSmoothing' | 'linearRegression' | 'seasonal';

export const MODEL_LABELS: Record<ForecastModelKey, string> = {
  naive: 'Naive (last value)',
  mean: 'Mean (historical average)',
  movingAverage: 'Moving Average',
  weightedMovingAverage: 'Weighted Moving Average',
  exponentialSmoothing: 'Exponential Smoothing',
  linearRegression: 'Trend / Regression',
  seasonal: 'Seasonal',
};

export interface TimeSeriesPoint {
  date: string; // ISO
  value: number;
}

export interface TimeSeriesValidation {
  observationCount: number;
  dateRangeStart: string;
  dateRangeEnd: string;
  missingDates: number;
  duplicateDates: number;
  missingValues: number;
  irregularIntervals: boolean;
  readinessPct: number;
  readinessLabel: 'Sufficient' | 'Partially Sufficient' | 'Insufficient';
  issues: string[];
}

export type TrendDirection = 'Increasing' | 'Decreasing' | 'Stable' | 'Accelerating growth' | 'Slowing growth' | 'Volatile / uncertain';

export interface TrendResult {
  direction: TrendDirection;
  slopePerPeriod: number;
  strengthLabel: 'Weak' | 'Moderate' | 'Strong';
}

export interface SeasonalityResult {
  detected: boolean;
  periodicity: number | null; // e.g. 12 for monthly-yearly
  strengthPct: number | null;
  description: string;
}

export interface VolatilityResult {
  stdDev: number;
  coefficientOfVariation: number | null;
  meanAbsPctChange: number | null;
  level: 'Low' | 'Moderate' | 'High';
}

export interface StructuralBreakFlag {
  atDate: string;
  description: string;
}

export interface HistoricalAnalysis {
  count: number;
  mean: number;
  median: number;
  min: number;
  max: number;
  stdDev: number;
  growthPct: number | null;
  trend: TrendResult;
  seasonality: SeasonalityResult;
  volatility: VolatilityResult;
  outlierIndexes: number[];
  structuralBreaks: StructuralBreakFlag[];
}

export interface ErrorMetrics {
  mae: number;
  mse: number;
  rmse: number;
  mape: number | null; // null when undefined (zero actuals dominate)
  smape: number;
  bias: number; // mean(forecast - actual); positive = overpredicts
  biasLabel: 'Overpredicts' | 'Underpredicts' | 'Approximately unbiased';
}

export interface BacktestResult {
  model: ForecastModelKey;
  windowCount: number;
  metrics: ErrorMetrics;
  trainMetrics: ErrorMetrics | null; // for overfitting comparison
  overfittingFlag: boolean;
  underfittingFlag: boolean;
}

export interface ForecastPoint {
  date: string;
  pointForecast: number;
  lowerBound: number | null;
  upperBound: number | null;
}

export interface ScenarioForecast {
  base: ForecastPoint[];
  upside: ForecastPoint[];
  downside: ForecastPoint[];
  upsideAssumption: string;
  downsideAssumption: string;
}

export type ForecastConfidence = 'High' | 'Medium' | 'Low';

export interface ForecastConfig {
  id: string;
  name: string;
  datasetId: string;
  targetColumn: string;
  dateColumn: string;
  frequency: ForecastFrequency;
  horizon: number;
  filters: Record<string, string>;
  currency: string;
  unit: string;
  createdDate: string;
  createdBy: string;
  status: 'Draft' | 'Active' | 'Archived';
}

export interface ForecastRun {
  config: ForecastConfig;
  validation: TimeSeriesValidation;
  historical: HistoricalAnalysis;
  backtests: BacktestResult[];
  selectedModel: ForecastModelKey;
  scenario: ScenarioForecast;
  confidence: ForecastConfidence;
  confidenceReasons: string[];
  assumptions: string[];
  limitations: string[];
}

export interface ForecastVsActualPoint {
  date: string;
  forecast: number;
  actual: number;
  absoluteError: number;
  pctError: number | null;
}

export interface SavedForecast {
  id: string;
  createdDate: string;
  run: ForecastRun;
  actuals: ForecastVsActualPoint[]; // populated later as periods actualize
}

export interface ForecastAlert {
  id: string;
  label: string;
  severity: 'critical' | 'warning';
  metric: string;
  currentValue: string;
  forecastValue: string;
  threshold: string;
  horizon: string;
  model: string;
  uncertaintyNote: string;
  recommendedInvestigation: string;
}

export interface ForecastRiskSignal {
  forecastLabel: string;
  potentialRisk: string;
  relatedKriName: string | null;
  managementAttention: string;
}
