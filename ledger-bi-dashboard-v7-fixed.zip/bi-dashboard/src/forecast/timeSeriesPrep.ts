import { Row } from '../types/analytics';
import { ForecastFrequency, TimeSeriesPoint, TimeSeriesValidation } from './types';

function toNumber(v: unknown): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return null;
}

function periodKey(date: Date, freq: ForecastFrequency): string {
  const y = date.getUTCFullYear();
  const m = date.getUTCMonth();
  const d = date.getUTCDate();
  if (freq === 'annual') return `${y}`;
  if (freq === 'quarterly') return `${y}-Q${Math.floor(m / 3) + 1}`;
  if (freq === 'monthly') return `${y}-${String(m + 1).padStart(2, '0')}`;
  if (freq === 'weekly') {
    const firstJan = new Date(Date.UTC(y, 0, 1));
    const week = Math.ceil(((date.getTime() - firstJan.getTime()) / 86400000 + firstJan.getUTCDay() + 1) / 7);
    return `${y}-W${String(week).padStart(2, '0')}`;
  }
  return `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`; // daily
}

/** Aggregates raw rows into a chronological time series by summing the
 * target column within each period bucket at the requested frequency. */
export function buildTimeSeries(rows: Row[], dateColumn: string, targetColumn: string, frequency: ForecastFrequency): TimeSeriesPoint[] {
  const buckets = new Map<string, { sum: number; date: number }>();
  rows.forEach((r) => {
    const t = Date.parse(String(r[dateColumn]));
    const v = toNumber(r[targetColumn]);
    if (isNaN(t) || v === null) return;
    const date = new Date(t);
    const key = periodKey(date, frequency);
    const existing = buckets.get(key);
    if (existing) {
      existing.sum += v;
    } else {
      buckets.set(key, { sum: v, date: t });
    }
  });

  return Array.from(buckets.entries())
    .sort(([, a], [, b]) => a.date - b.date)
    .map(([, b]) => ({ date: new Date(b.date).toISOString(), value: b.sum }));
}

function expectedIntervalMs(frequency: ForecastFrequency): number {
  switch (frequency) {
    case 'daily': return 86400000;
    case 'weekly': return 7 * 86400000;
    case 'monthly': return 30 * 86400000; // approximate; used only for gap detection
    case 'quarterly': return 91 * 86400000;
    case 'annual': return 365 * 86400000;
  }
}

export function validateTimeSeries(series: TimeSeriesPoint[], frequency: ForecastFrequency, minRecommendedObservations: number): TimeSeriesValidation {
  const issues: string[] = [];
  const count = series.length;

  if (count === 0) {
    return {
      observationCount: 0,
      dateRangeStart: '',
      dateRangeEnd: '',
      missingDates: 0,
      duplicateDates: 0,
      missingValues: 0,
      irregularIntervals: false,
      readinessPct: 0,
      readinessLabel: 'Insufficient',
      issues: ['No valid observations found for this date/target column combination.'],
    };
  }

  const expectedGap = expectedIntervalMs(frequency);
  let gapCount = 0;
  let irregular = false;
  for (let i = 1; i < series.length; i++) {
    const gap = new Date(series[i].date).getTime() - new Date(series[i - 1].date).getTime();
    const ratio = gap / expectedGap;
    if (ratio > 1.5) gapCount += Math.round(ratio) - 1;
    if (ratio < 0.5 || ratio > 2) irregular = true;
  }
  if (gapCount > 0) issues.push(`${gapCount} likely missing period(s) detected in the sequence.`);
  if (irregular) issues.push('Intervals between observations are irregular for the selected frequency.');

  const missingValues = series.filter((p) => p.value === null || isNaN(p.value)).length;
  if (missingValues > 0) issues.push(`${missingValues} period(s) have missing/invalid values.`);

  if (count < minRecommendedObservations) {
    issues.push(`Only ${count} observations available; ${minRecommendedObservations}+ recommended for reliable forecasting at this frequency.`);
  }

  let points = 100;
  if (count < minRecommendedObservations) points -= Math.min(50, (minRecommendedObservations - count) * 5);
  points -= Math.min(25, gapCount * 5);
  points -= irregular ? 15 : 0;
  points -= Math.min(20, missingValues * 5);
  const readinessPct = Math.max(0, Math.min(100, Math.round(points)));
  const readinessLabel = readinessPct >= 70 ? 'Sufficient' : readinessPct >= 40 ? 'Partially Sufficient' : 'Insufficient';

  return {
    observationCount: count,
    dateRangeStart: series[0].date,
    dateRangeEnd: series[series.length - 1].date,
    missingDates: gapCount,
    duplicateDates: 0,
    missingValues,
    irregularIntervals: irregular,
    readinessPct,
    readinessLabel,
    issues,
  };
}

/** Minimum recommended observations by model complexity (Section 7) —
 * configurable, not a single hard-coded number for every model. */
export const MIN_OBSERVATIONS: Record<'simple' | 'moderate' | 'seasonal', number> = {
  simple: 4,
  moderate: 8,
  seasonal: 24,
};
