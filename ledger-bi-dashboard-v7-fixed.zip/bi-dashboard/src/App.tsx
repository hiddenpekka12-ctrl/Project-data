import { useState } from 'react';
import { NavKey, Sidebar } from './components/layout/Sidebar';
import { Dashboard } from './pages/Dashboard';
import { Analytics } from './pages/Analytics';
import { Finance } from './pages/Finance';
import { Risk } from './pages/Risk';
import { ProblemSolver } from './pages/ProblemSolver';
import { Forecast } from './pages/Forecast';
import { Scenario } from './pages/Scenario';
import { ComingSoon } from './components/common/ComingSoon';
import { DatasetProvider } from './state/DatasetContext';
import { FinanceProvider } from './state/FinanceContext';
import { RiskProvider } from './state/RiskContext';
import { ProblemSolverProvider } from './state/ProblemSolverContext';
import { ForecastProvider } from './state/ForecastContext';
import { ScenarioProvider } from './state/ScenarioContext';

const COMING_SOON_LABELS: Record<Exclude<NavKey, 'dashboard' | 'analytics' | 'finance' | 'risk' | 'problemSolver' | 'forecast' | 'scenario'>, { title: string; version: string }> = {
  reports: { title: 'Reports', version: 'V8' },
  learning: { title: 'Learning', version: 'V11' },
  settings: { title: 'Settings', version: 'V12' },
};

const KNOWN: NavKey[] = ['dashboard', 'analytics', 'finance', 'risk', 'problemSolver', 'forecast', 'scenario'];

function AppShell() {
  const [active, setActive] = useState<NavKey>('dashboard');
  const [navOpen, setNavOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-base">
      <Sidebar active={active} onSelect={setActive} open={navOpen} onClose={() => setNavOpen(false)} />

      <div className="flex min-h-screen flex-1 flex-col">
        <header className="flex items-center gap-3 border-b border-line bg-surface px-4 py-3 md:hidden">
          <button
            aria-label="Open navigation"
            onClick={() => setNavOpen(true)}
            className="rounded border border-line px-2 py-1 text-sm text-ink-soft"
          >
            Menu
          </button>
          <p className="font-serif text-lg text-ink">Ledger</p>
        </header>

        <main className="flex-1 px-4 py-6 md:px-8 md:py-8">
          {active === 'dashboard' && <Dashboard />}
          {active === 'analytics' && <Analytics />}
          {active === 'finance' && <Finance />}
          {active === 'risk' && <Risk />}
          {active === 'problemSolver' && <ProblemSolver />}
          {active === 'forecast' && <Forecast />}
          {active === 'scenario' && <Scenario />}
          {!KNOWN.includes(active) && (
            <ComingSoon
              moduleName={COMING_SOON_LABELS[active as Exclude<NavKey, 'dashboard' | 'analytics' | 'finance' | 'risk' | 'problemSolver' | 'forecast' | 'scenario'>].title}
              version={COMING_SOON_LABELS[active as Exclude<NavKey, 'dashboard' | 'analytics' | 'finance' | 'risk' | 'problemSolver' | 'forecast' | 'scenario'>].version}
            />
          )}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <DatasetProvider>
      <FinanceProvider>
        <RiskProvider>
          <ProblemSolverProvider>
            <ForecastProvider>
              <ScenarioProvider>
                <AppShell />
              </ScenarioProvider>
            </ForecastProvider>
          </ProblemSolverProvider>
        </RiskProvider>
      </FinanceProvider>
    </DatasetProvider>
  );
}
